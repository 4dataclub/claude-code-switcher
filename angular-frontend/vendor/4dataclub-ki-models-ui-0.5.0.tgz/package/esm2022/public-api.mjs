/*
 * Public API Surface of @dataclub/ki-models-ui
 *
 * Konsumenten importieren Components + Service + InjectionToken hier von:
 *   import { ModelsTableComponent, KI_MODELS_API_BASE } from '@dataclub/ki-models-ui';
 *
 * Module-Wrapper (für nicht-standalone-Apps) wird in Phase L.2 hinzugefügt.
 */
// ─── Models / Interfaces ─────────────────────────────────────────────────
export * from './lib/models/ai-model';
export * from './lib/models/api-key-setting';
export * from './lib/models/cascade-config';
export * from './lib/models/labels';
// ─── Service + InjectionToken ────────────────────────────────────────────
export * from './lib/services/ki-models-api.service';
export * from './lib/services/ki-models-api.token';
// ─── Components (standalone) ─────────────────────────────────────────────
export * from './lib/components/models-table.component';
export * from './lib/components/add-model-form.component';
export * from './lib/components/cascade-cooldown.component';
export * from './lib/components/api-keys-section.component';
export * from './lib/components/failover-chain.component';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljLWFwaS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3Byb2plY3RzL2tpLW1vZGVscy11aS9zcmMvcHVibGljLWFwaS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7OztHQU9HO0FBRUgsNEVBQTRFO0FBQzVFLGNBQWMsdUJBQXVCLENBQUM7QUFDdEMsY0FBYyw4QkFBOEIsQ0FBQztBQUM3QyxjQUFjLDZCQUE2QixDQUFDO0FBQzVDLGNBQWMscUJBQXFCLENBQUM7QUFFcEMsNEVBQTRFO0FBQzVFLGNBQWMsc0NBQXNDLENBQUM7QUFDckQsY0FBYyxvQ0FBb0MsQ0FBQztBQUVuRCw0RUFBNEU7QUFDNUUsY0FBYyx5Q0FBeUMsQ0FBQztBQUN4RCxjQUFjLDJDQUEyQyxDQUFDO0FBQzFELGNBQWMsNkNBQTZDLENBQUM7QUFDNUQsY0FBYyw2Q0FBNkMsQ0FBQztBQUM1RCxjQUFjLDJDQUEyQyxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIFB1YmxpYyBBUEkgU3VyZmFjZSBvZiBAZGF0YWNsdWIva2ktbW9kZWxzLXVpXG4gKlxuICogS29uc3VtZW50ZW4gaW1wb3J0aWVyZW4gQ29tcG9uZW50cyArIFNlcnZpY2UgKyBJbmplY3Rpb25Ub2tlbiBoaWVyIHZvbjpcbiAqICAgaW1wb3J0IHsgTW9kZWxzVGFibGVDb21wb25lbnQsIEtJX01PREVMU19BUElfQkFTRSB9IGZyb20gJ0BkYXRhY2x1Yi9raS1tb2RlbHMtdWknO1xuICpcbiAqIE1vZHVsZS1XcmFwcGVyIChmw7xyIG5pY2h0LXN0YW5kYWxvbmUtQXBwcykgd2lyZCBpbiBQaGFzZSBMLjIgaGluenVnZWbDvGd0LlxuICovXG5cbi8vIOKUgOKUgOKUgCBNb2RlbHMgLyBJbnRlcmZhY2VzIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuZXhwb3J0ICogZnJvbSAnLi9saWIvbW9kZWxzL2FpLW1vZGVsJztcbmV4cG9ydCAqIGZyb20gJy4vbGliL21vZGVscy9hcGkta2V5LXNldHRpbmcnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvbW9kZWxzL2Nhc2NhZGUtY29uZmlnJztcbmV4cG9ydCAqIGZyb20gJy4vbGliL21vZGVscy9sYWJlbHMnO1xuXG4vLyDilIDilIDilIAgU2VydmljZSArIEluamVjdGlvblRva2VuIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuZXhwb3J0ICogZnJvbSAnLi9saWIvc2VydmljZXMva2ktbW9kZWxzLWFwaS5zZXJ2aWNlJztcbmV4cG9ydCAqIGZyb20gJy4vbGliL3NlcnZpY2VzL2tpLW1vZGVscy1hcGkudG9rZW4nO1xuXG4vLyDilIDilIDilIAgQ29tcG9uZW50cyAoc3RhbmRhbG9uZSkg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5leHBvcnQgKiBmcm9tICcuL2xpYi9jb21wb25lbnRzL21vZGVscy10YWJsZS5jb21wb25lbnQnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvY29tcG9uZW50cy9hZGQtbW9kZWwtZm9ybS5jb21wb25lbnQnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvY29tcG9uZW50cy9jYXNjYWRlLWNvb2xkb3duLmNvbXBvbmVudCc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9jb21wb25lbnRzL2FwaS1rZXlzLXNlY3Rpb24uY29tcG9uZW50JztcbmV4cG9ydCAqIGZyb20gJy4vbGliL2NvbXBvbmVudHMvZmFpbG92ZXItY2hhaW4uY29tcG9uZW50JztcbiJdfQ==