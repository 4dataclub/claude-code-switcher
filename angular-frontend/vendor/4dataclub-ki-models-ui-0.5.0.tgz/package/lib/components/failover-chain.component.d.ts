import { EventEmitter } from '@angular/core';
import { ChainEntry } from '../models/cascade-config';
import { FailoverChainLabels } from '../models/labels';
import * as i0 from "@angular/core";
/**
 * Generischer Failover-Chain-Editor — von beiden Konsumenten (Switcher +
 * EduPro) genutzt. Komponente ist „dumm": sie hält keinen Zustand, sondern
 * emittet `(chainChanged)` bei jeder Edit-Aktion. Der Konsument entscheidet
 * was mit der neuen Chain passiert:
 *
 * - **Switcher** persistiert sie in `_switcher.fallback_chain` (Wrapper liest
 *   das + restartet Claude Code bei Quota-Fehler entlang der Chain).
 * - **EduPro** mapped die Chain auf cascade-models-CRUD (`orderIdx`-Reorder
 *   bei Reorder, POST bei Add, DELETE bei Remove). Damit ist die Chain in
 *   EduPro effektiv die enabled-Modell-Liste in `orderIdx`-Reihenfolge.
 *
 * Switcher-spezifische Features (Aktuelle-Stufe-Indikator, Promote-Button)
 * sind hinter `[showChainPosition]="true"` gegated und in EduPro standardmäßig
 * ausgeblendet.
 *
 * **Inputs:**
 * - `chain` — aktuelle Chain (`{provider, model}[]`)
 * - `availableModels` — Optionen für Modell-Dropdown pro Provider
 * - `availableProviders` — Optionen für Provider-Dropdown
 * - `chainPosition` — aktive Stufe (0-basiert, null = keine)
 * - `showChainPosition` — gated Aktuelle-Stufe-Zeile + Promote-Button
 * - `labels` — i18n-Override
 *
 * **Outputs:**
 * - `chainChanged` — neue Chain nach jeder Edit-Aktion
 * - `promoteRequested` — User klickt „Zurück zu Stufe 1" (nur bei
 *   `showChainPosition && chainPosition > 0` sichtbar)
 */
export declare class FailoverChainComponent {
    /** Aktuelle Chain. Die Komponente mutiert sie in-place beim Editieren und emittet `chainChanged`. */
    chain: ChainEntry[];
    /** Optionen für die Modell-Dropdowns. Pro Provider eine Liste an Modellen. */
    availableModels: {
        provider: string;
        modelId: string;
        displayName: string;
    }[];
    /** Optionen für die Provider-Dropdowns. Default: anthropic/google/openrouter. */
    availableProviders: {
        value: string;
        label: string;
    }[];
    /** Aktive Stufe (0-basiert). Nur relevant bei `showChainPosition=true`. */
    chainPosition: number | null;
    /** Gated die Aktuelle-Stufe-Zeile + Promote-Button (Switcher-only-Feature). */
    showChainPosition: boolean;
    /** Optionale i18n-Override-Strings. */
    set labels(v: Partial<FailoverChainLabels> | undefined);
    L: FailoverChainLabels;
    chainChanged: EventEmitter<ChainEntry[]>;
    promoteRequested: EventEmitter<void>;
    modelsFor(provider: string): {
        provider: string;
        modelId: string;
        displayName: string;
    }[];
    onProviderChange(idx: number): void;
    addRow(): void;
    removeRow(idx: number): void;
    moveUp(idx: number): void;
    moveDown(idx: number): void;
    positionLabel(): string;
    emit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FailoverChainComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FailoverChainComponent, "ki-failover-chain", never, { "chain": { "alias": "chain"; "required": false; }; "availableModels": { "alias": "availableModels"; "required": false; }; "availableProviders": { "alias": "availableProviders"; "required": false; }; "chainPosition": { "alias": "chainPosition"; "required": false; }; "showChainPosition": { "alias": "showChainPosition"; "required": false; }; "labels": { "alias": "labels"; "required": false; }; }, { "chainChanged": "chainChanged"; "promoteRequested": "promoteRequested"; }, never, never, true, never>;
}
