import { EventEmitter } from '@angular/core';
import { ApiKeySetting } from '../models/api-key-setting';
import { ApiKeysSectionLabels } from '../models/labels';
import * as i0 from "@angular/core";
interface KeyOption {
    settingKey: string;
    brand: string;
}
/**
 * Section zur Verwaltung aller API-Keys (settingKey-basiert).
 *
 * **Form (oben):** settingKey-Picker + Value-Input (mit Show/Hide) + Save-Button.
 * Konsument kann beim Add eines neuen Models einen settingKey wählen, der noch
 * keinen Value hat — der bleibt offen bis er hier gesetzt wird.
 *
 * **Status-Liste (unten):** alle konfigurierten settingKeys mit:
 * - Badge: Source (`db` vom Admin gesetzt oder `env` vom Boot-Default)
 * - Wert maskiert
 * - Actions: Edit (lädt in Form oben), Clear (löscht den DB-Override)
 *
 * **Event:** `(keyChanged)` emittet bei jedem Save/Clear damit Konsument seine
 * Modell-Liste neu laden kann (key-Konfiguration ändert sich → Models-Status
 * `keyConfigured` ändert sich).
 */
export declare class ApiKeysSectionComponent {
    keyChanged: EventEmitter<string>;
    set labels(v: Partial<ApiKeysSectionLabels> | undefined);
    L: ApiKeysSectionLabels;
    private readonly api;
    readonly loading: import("@angular/core").WritableSignal<boolean>;
    readonly keys: import("@angular/core").WritableSignal<ApiKeySetting[]>;
    settingKey: string;
    value: string;
    readonly showValue: import("@angular/core").WritableSignal<boolean>;
    readonly saving: import("@angular/core").WritableSignal<boolean>;
    readonly clearing: import("@angular/core").WritableSignal<string | null>;
    /** Bekannte Default-Settings + ihre Brand-Labels (für Add-Form Vorschläge). */
    private readonly defaultCards;
    readonly configuredKeys: import("@angular/core").Signal<ApiKeySetting[]>;
    /** Default-Settings + dynamische (aus DB) als Options im Dropdown. */
    keyOptions(): KeyOption[];
    ngOnInit(): void;
    reload(): void;
    canSave(): boolean;
    save(): void;
    editKey(k: ApiKeySetting): void;
    clearKey(k: ApiKeySetting): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ApiKeysSectionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ApiKeysSectionComponent, "ki-api-keys-section", never, { "labels": { "alias": "labels"; "required": false; }; }, { "keyChanged": "keyChanged"; }, never, never, true, never>;
}
export {};
