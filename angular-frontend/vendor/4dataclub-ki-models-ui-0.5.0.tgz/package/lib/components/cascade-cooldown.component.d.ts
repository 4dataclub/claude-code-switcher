import { CascadeConfig, CooldownOverride } from '../models/cascade-config';
import { CascadeCooldownLabels } from '../models/labels';
import * as i0 from "@angular/core";
/**
 * Tri-State Cooldown-Override-Panel.
 *
 * **States:**
 * - `null` (Default) — jedes Modell nutzt seine eigene Cooldown-Logik (Standard)
 * - `true` (Force ON) — Cooldown global erzwingen (auch wenn Modelle individuell deaktiviert haben)
 * - `false` (Force OFF) — Cooldown global deaktivieren (Tests / Debug)
 *
 * **Effective-Badge** zeigt den vom Backend resolved Endzustand (`effective`,
 * `effectiveCooldown`).
 */
export declare class CascadeCooldownComponent {
    set labels(v: Partial<CascadeCooldownLabels> | undefined);
    L: CascadeCooldownLabels;
    private readonly api;
    readonly loading: import("@angular/core").WritableSignal<boolean>;
    readonly config: import("@angular/core").WritableSignal<CascadeConfig | null>;
    ngOnInit(): void;
    refresh(): void;
    set(value: CooldownOverride): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CascadeCooldownComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CascadeCooldownComponent, "ki-cascade-cooldown", never, { "labels": { "alias": "labels"; "required": false; }; }, {}, never, never, true, never>;
}
