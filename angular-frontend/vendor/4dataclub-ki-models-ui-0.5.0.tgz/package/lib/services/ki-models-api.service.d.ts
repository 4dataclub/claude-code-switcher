import { Observable } from 'rxjs';
import { AiModel, AiModelCreate, AiModelUpdate } from '../models/ai-model';
import { ApiKeySetting, ApiKeySettingUpdate } from '../models/api-key-setting';
import { CascadeConfig, CascadeConfigUpdate } from '../models/cascade-config';
import * as i0 from "@angular/core";
/**
 * Library-API-Service. Spricht alle KI-Modell-/API-Key-/Cascade-Endpoints
 * gegen die vom Konsumenten konfigurierte Base-URL (siehe `KI_MODELS_API_BASE`).
 *
 * **Vertrag:** Konsumentenseitige Endpoints müssen folgenden Pfaden entsprechen:
 *
 * ```
 * GET    {base}/ai-models                   → AiModel[]
 * POST   {base}/ai-models                   → AiModel
 * PUT    {base}/ai-models/{id}              → AiModel
 * DELETE {base}/ai-models/{id}              → { ok: true }
 * POST   {base}/ai-models/{id}/test         → { ok, latencyMs, error? }
 * POST   {base}/ai-models/reorder           → { ok: true }                body: { orderedIds }
 * POST   {base}/ai-models/{id}/toggle       → { id, ok, enabled }         body: { enabled }
 * GET    {base}/api-keys                    → ApiKeySetting[]
 * POST   {base}/api-keys/setting/{key}      → { ok: true }                body: { value }
 * GET    {base}/cascade-config              → CascadeConfig
 * PUT    {base}/cascade-config              → CascadeConfig
 * ```
 *
 * Backend-API-Drift zwischen EduPro und Switcher: jeder Konsument kann diesen
 * Service per Inheritance/Wrapper überschreiben oder via Subclass-Provider
 * austauschen, falls nötig.
 */
export declare class KiModelsApiService {
    private readonly http;
    private readonly base;
    listModels(): Observable<AiModel[]>;
    createModel(body: AiModelCreate): Observable<AiModel>;
    updateModel(id: number, body: AiModelUpdate): Observable<AiModel>;
    deleteModel(id: number): Observable<{
        ok: boolean;
    }>;
    /**
     * `skipped: true` zeigt an, dass das Konsument-Backend den Test bewusst
     * übersprungen hat (z.B. Switcher beim Anthropic-Modell ohne API-Key, weil
     * Max-OAuth den Live-Switch erlaubt aber kein API-Test möglich ist). Die
     * Tabelle deaktiviert das Modell in dem Fall NICHT auto.
     */
    testModel(id: number): Observable<{
        ok: boolean;
        latencyMs?: number;
        error?: string;
        skipped?: boolean;
    }>;
    reorderModels(orderedIds: number[]): Observable<{
        ok: boolean;
    }>;
    toggleModel(id: number, enabled: boolean): Observable<{
        id: number;
        ok: boolean;
        enabled: boolean;
    }>;
    /**
     * Listet alle API-Key-Settings.
     *
     * Akzeptiert zwei Backend-Response-Shapes:
     * - **Array** (`ApiKeySetting[]`) — was die Library als Vertrag definiert
     *   (Switcher liefert das direkt unter `/cascade-settings`).
     * - **Object mit `settings`-Map** — was EduPros bestehender Endpoint
     *   `/admin/api-keys` liefert (`{settings: {key: {keyMasked, keySource, …}}}`).
     *
     * Bei Object-Form werden die Entries in das Array-Format gemapped, damit
     * die Components homogen mit `ApiKeySetting`-Items arbeiten. Pro Konsument
     * brauchen wir so keinen eigenen Adapter — die Library normalisiert selbst.
     */
    listKeys(): Observable<ApiKeySetting[]>;
    setKey(settingKey: string, body: ApiKeySettingUpdate): Observable<{
        ok: boolean;
    }>;
    getCascadeConfig(): Observable<CascadeConfig>;
    setCascadeConfig(body: CascadeConfigUpdate): Observable<CascadeConfig>;
    static ɵfac: i0.ɵɵFactoryDeclaration<KiModelsApiService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<KiModelsApiService>;
}
