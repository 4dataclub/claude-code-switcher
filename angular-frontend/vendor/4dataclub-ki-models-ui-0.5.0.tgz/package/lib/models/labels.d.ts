/**
 * Label-Maps für i18n-Override.
 *
 * Konsumenten (EduPro mit i18n-Pipe, Switcher mit eigenen Strings) übergeben
 * via `<ki-… [labels]="myLabels">` ihre eigenen Strings. Library nutzt sensible
 * englische Defaults wenn nichts überschrieben wird.
 */
export interface ModelsTableLabels {
    refresh: string;
    loading: string;
    empty: string;
    colNum: string;
    colProvider: string;
    colModelId: string;
    colKey: string;
    colEnabled: string;
    colStatus: string;
    colActions: string;
    keySet: string;
    keyMissing: string;
    on: string;
    off: string;
    autoDisabled: string;
    free: string;
    toggleNeedsKey: string;
    btnTest: string;
    btnReenable: string;
    btnDelete: string;
    /** „Als aktiv setzen" — nur sichtbar wenn `[showActiveAction]="true"`. */
    btnSetActive: string;
    /** Badge-Text für die Zeile des aktiven Modells. */
    activeBadge: string;
    confirmDelete: (modelId: string) => string;
}
export declare const MODELS_TABLE_LABELS_EN: ModelsTableLabels;
export interface AddModelFormLabels {
    title: string;
    fieldModelId: string;
    fieldApiKeySettingKey: string;
    fieldDisplayName: string;
    fieldCooldownOverride: string;
    btnAdd: string;
    btnAdding: string;
    hint: string;
    errorRequired: string;
    errorFailed: string;
    providerOptions: {
        value: string;
        label: string;
    }[];
}
export declare const ADD_MODEL_FORM_LABELS_EN: AddModelFormLabels;
export interface CascadeCooldownLabels {
    title: string;
    subtitle: string;
    default: string;
    forceOn: string;
    forceOff: string;
    effectiveOn: string;
    effectiveOff: string;
    hint: string;
    loading: string;
    errorLoad: string;
}
export declare const CASCADE_COOLDOWN_LABELS_EN: CascadeCooldownLabels;
export interface ApiKeysSectionLabels {
    title: string;
    subtitle: string;
    fieldSettingKey: string;
    fieldValue: string;
    btnShow: string;
    btnHide: string;
    btnSave: string;
    btnSaving: string;
    listTitle: string;
    colSettingKey: string;
    colSource: string;
    colValue: string;
    colActions: string;
    sourceDb: string;
    sourceEnv: string;
    sourceMissing: string;
    btnEdit: string;
    btnClear: string;
    empty: string;
    hint: string;
    confirmClear: (settingKey: string) => string;
}
export declare const API_KEYS_SECTION_LABELS_EN: ApiKeysSectionLabels;
/**
 * Labels für `<ki-failover-chain>`. Konsument kann alle oder einzelne Strings
 * überschreiben — Defaults sind englisch.
 */
export interface FailoverChainLabels {
    title: string;
    description: string;
    addRow: string;
    removeRowTitle: string;
    moveUpTitle: string;
    moveDownTitle: string;
    currentStep: string;
    positionLabel: (pos: number, provider: string, model: string) => string;
    promote: string;
    hint: string;
    emptyState: string;
}
export declare const FAILOVER_CHAIN_LABELS_EN: FailoverChainLabels;
