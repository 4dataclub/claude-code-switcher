import * as i0 from '@angular/core';
import { InjectionToken, inject, Injectable, EventEmitter, signal, Input, Output, Component, computed } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i2 from '@angular/forms';
import { FormsModule } from '@angular/forms';

/**
 * Label-Maps für i18n-Override.
 *
 * Konsumenten (EduPro mit i18n-Pipe, Switcher mit eigenen Strings) übergeben
 * via `<ki-… [labels]="myLabels">` ihre eigenen Strings. Library nutzt sensible
 * englische Defaults wenn nichts überschrieben wird.
 */
const MODELS_TABLE_LABELS_EN = {
    refresh: 'Refresh',
    loading: 'Loading models…',
    empty: 'No models configured. Use the form below to add one.',
    colNum: '#',
    colProvider: 'Provider',
    colModelId: 'Model ID',
    colKey: 'Key',
    colEnabled: 'Enabled',
    colStatus: 'Status',
    colActions: 'Actions',
    keySet: 'Key set',
    keyMissing: 'Key missing',
    on: 'ON',
    off: 'OFF',
    autoDisabled: 'Auto-disabled',
    free: 'Free',
    toggleNeedsKey: 'Key required before enabling',
    btnTest: 'Test',
    btnReenable: 'Re-enable',
    btnDelete: 'Delete',
    btnSetActive: 'Use now',
    activeBadge: 'ACTIVE',
    confirmDelete: (id) => `Delete model "${id}"?`,
};
const ADD_MODEL_FORM_LABELS_EN = {
    title: 'Add Model',
    fieldModelId: 'Model ID (e.g. gemini-2.5-flash)',
    fieldApiKeySettingKey: 'API-Key Setting',
    fieldDisplayName: 'Display Name (optional)',
    fieldCooldownOverride: 'Cooldown 503 override (sec, optional)',
    btnAdd: 'Add Model',
    btnAdding: 'Adding…',
    hint: 'The API key setting holds the actual key value — it lives in the API-Keys section below. Multiple models may share the same setting key.',
    errorRequired: 'Provider, Model ID and Setting Key are required',
    errorFailed: 'Failed to add model',
    providerOptions: [
        { value: 'gemini', label: 'Gemini (Google)' },
        { value: 'openai', label: 'OpenAI (api.openai.com)' },
        { value: 'anthropic', label: 'Anthropic (Claude)' },
        { value: 'openrouter', label: 'OpenRouter' },
        { value: 'deepseek', label: 'DeepSeek (api.deepseek.com)' },
        { value: 'openai_compat', label: 'Custom (self-hosted OpenAI API)' },
    ],
};
const CASCADE_COOLDOWN_LABELS_EN = {
    title: 'Cascade Cooldown',
    subtitle: 'Override the per-model cooldown behaviour globally.',
    default: 'Default',
    forceOn: 'Force ON',
    forceOff: 'Force OFF',
    effectiveOn: 'Effective: ON',
    effectiveOff: 'Effective: OFF',
    hint: 'Default = each model decides for itself. Force ON keeps cooldowns even when a model would skip them. Force OFF removes all cooldowns globally — use with care, useful for testing.',
    loading: 'Loading cascade config…',
    errorLoad: 'Failed to load cascade config.',
};
const API_KEYS_SECTION_LABELS_EN = {
    title: 'API Keys',
    subtitle: 'One value per setting-key. Multiple models referencing the same setting-key share the credential.',
    fieldSettingKey: 'Setting Key',
    fieldValue: 'Key value (empty to clear)',
    btnShow: 'Show',
    btnHide: 'Hide',
    btnSave: 'Save Key',
    btnSaving: 'Saving…',
    listTitle: 'Configured Keys',
    colSettingKey: 'Setting Key',
    colSource: 'Source',
    colValue: 'Value',
    colActions: 'Actions',
    sourceDb: 'DB (admin)',
    sourceEnv: 'ENV (boot)',
    sourceMissing: 'missing',
    btnEdit: 'Edit',
    btnClear: 'Clear',
    empty: 'No keys configured yet. Use the form above to add one.',
    hint: "Keys are stored in the consumer's settings table and never echoed to clients in plain text. The value is only used server-side to authenticate model calls.",
    confirmClear: (k) => `Clear DB-stored value for "${k}"? (Env fallback may still apply.)`,
};
const FAILOVER_CHAIN_LABELS_EN = {
    title: 'Failover Chain',
    description: 'Order in which models are tried when one hits a quota / 503.',
    addRow: 'Add stage',
    removeRowTitle: 'Remove',
    moveUpTitle: 'Move up',
    moveDownTitle: 'Move down',
    currentStep: 'Current stage:',
    positionLabel: (pos, provider, model) => `Stage ${pos + 1} (${provider} · ${model})`,
    promote: '↶ Back to stage 1',
    hint: 'On quota error, the wrapper switches to the next stage and restarts.',
    emptyState: 'No stages configured. Add one to start.',
};

/**
 * Base-URL für die KI-Modell-Admin-API.
 *
 * Konsumenten konfigurieren das per `providers`:
 * ```ts
 * { provide: KI_MODELS_API_BASE, useValue: '/api/admin' }   // EduPro
 * { provide: KI_MODELS_API_BASE, useValue: '/api' }         // Switcher
 * ```
 *
 * Die Library hängt an die Base relative Pfade: `/ai-models`, `/api-keys`,
 * `/cascade-config`. Konsumenten müssen sicherstellen dass die Endpoints
 * dem in [`api-contract.md`](../../examples/api-contract.md) dokumentierten
 * Vertrag entsprechen.
 */
const KI_MODELS_API_BASE = new InjectionToken('KI_MODELS_API_BASE');

/**
 * Library-API-Service. Spricht alle KI-Modell-/API-Key-/Cascade-Endpoints
 * gegen die vom Konsumenten konfigurierte Base-URL (siehe `KI_MODELS_API_BASE`).
 *
 * **Vertrag:** Konsumentenseitige Endpoints müssen folgenden Pfaden entsprechen:
 *
 * ```
 * GET    {base}/ai-models                   → AiModel[]
 * POST   {base}/ai-models                   → AiModel
 * PUT    {base}/ai-models/{id}              → AiModel
 * DELETE {base}/ai-models/{id}              → { ok: true }
 * POST   {base}/ai-models/{id}/test         → { ok, latencyMs, error? }
 * POST   {base}/ai-models/reorder           → { ok: true }                body: { orderedIds }
 * POST   {base}/ai-models/{id}/toggle       → { id, ok, enabled }         body: { enabled }
 * GET    {base}/api-keys                    → ApiKeySetting[]
 * POST   {base}/api-keys/setting/{key}      → { ok: true }                body: { value }
 * GET    {base}/cascade-config              → CascadeConfig
 * PUT    {base}/cascade-config              → CascadeConfig
 * ```
 *
 * Backend-API-Drift zwischen EduPro und Switcher: jeder Konsument kann diesen
 * Service per Inheritance/Wrapper überschreiben oder via Subclass-Provider
 * austauschen, falls nötig.
 */
class KiModelsApiService {
    constructor() {
        this.http = inject(HttpClient);
        this.base = inject(KI_MODELS_API_BASE);
    }
    // ─── Models ──────────────────────────────────────────────────────────────
    listModels() {
        return this.http.get(`${this.base}/ai-models`);
    }
    createModel(body) {
        return this.http.post(`${this.base}/ai-models`, body);
    }
    updateModel(id, body) {
        return this.http.put(`${this.base}/ai-models/${id}`, body);
    }
    deleteModel(id) {
        return this.http.delete(`${this.base}/ai-models/${id}`);
    }
    /**
     * `skipped: true` zeigt an, dass das Konsument-Backend den Test bewusst
     * übersprungen hat (z.B. Switcher beim Anthropic-Modell ohne API-Key, weil
     * Max-OAuth den Live-Switch erlaubt aber kein API-Test möglich ist). Die
     * Tabelle deaktiviert das Modell in dem Fall NICHT auto.
     */
    testModel(id) {
        return this.http.post(`${this.base}/ai-models/${id}/test`, {});
    }
    reorderModels(orderedIds) {
        return this.http.post(`${this.base}/ai-models/reorder`, { orderedIds });
    }
    toggleModel(id, enabled) {
        return this.http.post(`${this.base}/ai-models/${id}/toggle`, { enabled });
    }
    // ─── API-Keys ────────────────────────────────────────────────────────────
    /**
     * Listet alle API-Key-Settings.
     *
     * Akzeptiert zwei Backend-Response-Shapes:
     * - **Array** (`ApiKeySetting[]`) — was die Library als Vertrag definiert
     *   (Switcher liefert das direkt unter `/cascade-settings`).
     * - **Object mit `settings`-Map** — was EduPros bestehender Endpoint
     *   `/admin/api-keys` liefert (`{settings: {key: {keyMasked, keySource, …}}}`).
     *
     * Bei Object-Form werden die Entries in das Array-Format gemapped, damit
     * die Components homogen mit `ApiKeySetting`-Items arbeiten. Pro Konsument
     * brauchen wir so keinen eigenen Adapter — die Library normalisiert selbst.
     */
    listKeys() {
        return this.http.get(`${this.base}/api-keys`).pipe(map((resp) => {
            if (Array.isArray(resp))
                return resp;
            // EduPro-Shape: { settings: { <key>: { keyMasked, keySource, keyConfigured, envVar, isDefault } } }
            if (resp && typeof resp === 'object' && resp.settings && typeof resp.settings === 'object') {
                return Object.entries(resp.settings).map(([settingKey, v]) => ({
                    settingKey,
                    valueMasked: v?.keyMasked ?? '',
                    configured: !!v?.keyConfigured,
                    keySource: v?.keySource ?? null,
                    envVar: v?.envVar ?? null,
                    isDefault: !!v?.isDefault,
                }));
            }
            return [];
        }));
    }
    setKey(settingKey, body) {
        return this.http.post(`${this.base}/api-keys/setting/${encodeURIComponent(settingKey)}`, body);
    }
    // ─── Cascade-Config ──────────────────────────────────────────────────────
    getCascadeConfig() {
        return this.http.get(`${this.base}/cascade-config`);
    }
    setCascadeConfig(body) {
        return this.http.put(`${this.base}/cascade-config`, body);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: KiModelsApiService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: KiModelsApiService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: KiModelsApiService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/**
 * Tabelle aller AI-Modelle in der Cascade-Reihenfolge.
 *
 * **Spalten:** #, Provider, Model-ID (+displayName), Key-Status, Enabled-Toggle,
 * Status (autoDisabled-Reason / Cooldown / Free), Actions (Up/Down, Test, Re-Enable,
 * Delete).
 *
 * **Events:**
 * - `(activeModelChanged)` — User klickt „Als aktiv setzen" (Switcher-Feature,
 *   wird in L.2/L.4 ergänzt wenn dem Component ein `[showActiveAction]="true"`
 *   Input mitgegeben wird). Aktuell nicht im Template (folgt L.2.1).
 * - `(modelChanged)` — emittet bei jeder mutating-Aktion (toggle/move/delete/
 *   test) damit der Konsument seine Modell-Liste neu laden kann.
 *
 * Labels sind englisch hardcoded — Konsument-spezifische Übersetzung folgt in
 * Phase L.3 via `@Input()`-Override-Pattern oder eigenem Translation-Service.
 */
class ModelsTableComponent {
    constructor() {
        this.activeModelChanged = new EventEmitter();
        this.modelChanged = new EventEmitter();
        this.L = MODELS_TABLE_LABELS_EN;
        /**
         * Aktiviert pro Modell-Zeile den „Als aktiv setzen"-Button (`btnSetActive`).
         * Default `false` — EduPro nutzt das nicht, Switcher schaltet's auf `true`.
         * Wenn das Modell bereits aktiv ist (siehe `activeModelId`), zeigt sich
         * stattdessen das AKTIV-Badge.
         */
        this.showActiveAction = false;
        /**
         * Aktive Modell-ID (`modelId`-Feld, nicht die DB-id). Wird mit jeder Zeile
         * verglichen um die AKTIV-Badge zu setzen. `null` = kein Modell aktiv.
         */
        this.activeModelId = null;
        this.api = inject(KiModelsApiService);
        this.loading = signal(true);
        this.models = signal([]);
        this.testResult = signal({});
    }
    /** Optionale Labels — Konsument gibt seine i18n-Strings rein. Default = englisch. */
    set labels(v) {
        this.L = { ...MODELS_TABLE_LABELS_EN, ...(v ?? {}) };
    }
    ngOnInit() {
        this.reload();
    }
    reload() {
        this.loading.set(true);
        this.api.listModels().subscribe({
            next: (list) => {
                this.models.set(list);
                this.loading.set(false);
            },
            error: () => this.loading.set(false),
        });
    }
    toggle(m) {
        if (!m.enabled && !m.keyConfigured)
            return;
        this.api.toggleModel(m.id, !m.enabled).subscribe(() => {
            this.modelChanged.emit(m);
            this.reload();
        });
    }
    reEnable(m) {
        this.api.updateModel(m.id, { autoDisabled: false, enabled: true }).subscribe(() => {
            this.modelChanged.emit(m);
            this.reload();
        });
    }
    remove(m) {
        if (!confirm(this.L.confirmDelete(m.modelId)))
            return;
        this.api.deleteModel(m.id).subscribe(() => {
            this.modelChanged.emit(null);
            this.reload();
        });
    }
    move(idx, dir) {
        const target = idx + dir;
        if (target < 0 || target >= this.models().length)
            return;
        const ordered = [...this.models()];
        const [moved] = ordered.splice(idx, 1);
        ordered.splice(target, 0, moved);
        this.api.reorderModels(ordered.map((m) => m.id)).subscribe(() => {
            this.modelChanged.emit(moved);
            this.reload();
        });
    }
    test(m) {
        this.setTest(m.id, { pending: true });
        this.api.testModel(m.id).subscribe({
            next: (r) => {
                this.setTest(m.id, r);
                // Auto-disable nur bei *echten* Failed-Tests (Modell antwortet falsch
                // oder gar nicht). Wenn der Konsument-Backend den Test bewusst
                // übersprungen hat (`skipped: true`), ist das KEIN Grund das Modell
                // auto-zu-deaktivieren — z.B. Switcher kurzschließt den Anthropic-Test
                // wenn kein API-Key da ist, weil Max-OAuth den Live-Switch trotzdem
                // erlaubt. Das Modell ist nutzbar, nur nicht testbar.
                if (m.enabled && r.ok === false && r.skipped !== true) {
                    this.api.toggleModel(m.id, false).subscribe(() => this.reload());
                }
            },
            error: (e) => {
                this.setTest(m.id, { ok: false, error: e?.message ?? 'Error' });
                if (m.enabled)
                    this.api.toggleModel(m.id, false).subscribe(() => this.reload());
            },
        });
    }
    /**
     * „Als aktiv setzen"-Klick — emittet `activeModelChanged`. Der Konsument
     * (z.B. Switcher) entscheidet was passiert: typisch ist ein `/api/switch`
     * mit `{provider, modelId}` damit der Wrapper Claude Code mit dem neuen
     * Provider neu startet.
     */
    setActive(m) {
        this.activeModelChanged.emit(m);
    }
    /** True wenn die Zeile zum `activeModelId`-Input passt. */
    isActiveModel(m) {
        return !!this.activeModelId && m.modelId === this.activeModelId;
    }
    truncate(s, n) {
        return s.length > n ? s.slice(0, n) + '…' : s;
    }
    setTest(id, r) {
        this.testResult.update((tr) => ({ ...tr, [id]: r }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ModelsTableComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ModelsTableComponent, isStandalone: true, selector: "ki-models-table", inputs: { labels: "labels", showActiveAction: "showActiveAction", activeModelId: "activeModelId" }, outputs: { activeModelChanged: "activeModelChanged", modelChanged: "modelChanged" }, ngImport: i0, template: `
    <div class="ki-models-table">
      <div class="ki-models-table-header">
        <button (click)="reload()" class="ki-btn-secondary">↻ {{ L.refresh }}</button>
      </div>

      <div *ngIf="loading()" class="ki-muted">{{ L.loading }}</div>

      <div *ngIf="!loading() && models().length === 0" class="ki-empty">
        {{ L.empty }}
      </div>

      <div *ngIf="models().length > 0" class="ki-table-wrap">
        <table class="ki-table">
          <thead>
            <tr>
              <th>{{ L.colNum }}</th>
              <th>{{ L.colProvider }}</th>
              <th>{{ L.colModelId }}</th>
              <th>{{ L.colKey }}</th>
              <th>{{ L.colEnabled }}</th>
              <th>{{ L.colStatus }}</th>
              <th class="ki-right">{{ L.colActions }}</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let m of models(); let i = index"
                [class.ki-row-auto-disabled]="m.autoDisabled">
              <td class="ki-mono ki-muted">{{ i + 1 }}</td>
              <td class="ki-mono ki-provider">{{ m.provider }}</td>
              <td class="ki-mono">
                <strong>{{ m.modelId }}</strong>
                <div *ngIf="m.displayName" class="ki-muted ki-tiny">{{ m.displayName }}</div>
              </td>
              <td>
                <span *ngIf="m.keyConfigured" class="ki-badge ki-badge-ok">{{ L.keySet }}</span>
                <span *ngIf="!m.keyConfigured" class="ki-badge ki-badge-warn">{{ L.keyMissing }}</span>
                <div class="ki-tiny ki-mono ki-muted">{{ m.apiKeySettingKey }}</div>
              </td>
              <td>
                <button *ngIf="!m.autoDisabled"
                        (click)="toggle(m)"
                        [disabled]="!m.enabled && !m.keyConfigured"
                        [title]="(!m.enabled && !m.keyConfigured) ? L.toggleNeedsKey : ''"
                        class="ki-toggle"
                        [class.ki-toggle-on]="m.enabled"
                        [class.ki-toggle-off]="!m.enabled">
                  {{ m.enabled ? L.on : L.off }}
                </button>
                <span *ngIf="m.autoDisabled" class="ki-badge ki-badge-error">🚫 {{ L.autoDisabled }}</span>
              </td>
              <td>
                <span *ngIf="m.autoDisabled" class="ki-tiny ki-error" [title]="m.autoDisabledReason || ''">
                  {{ truncate(m.autoDisabledReason || '', 60) }}
                </span>
                <span *ngIf="!m.autoDisabled && (m.cooldownRemainingSec ?? 0) > 0" class="ki-tiny ki-cooldown">
                  cd {{ m.cooldownRemainingSec }}s
                </span>
                <span *ngIf="!m.autoDisabled && !(m.cooldownRemainingSec ?? 0)" class="ki-tiny ki-ok">
                  {{ L.free }}
                </span>
                <div *ngIf="testResult()[m.id] as r" class="ki-tiny ki-mono"
                     [class.ki-ok]="r.ok"
                     [class.ki-error]="!r.ok && !r.pending">
                  <span *ngIf="r.pending">…</span>
                  <span *ngIf="r.ok">✓ {{ r.latencyMs }}ms</span>
                  <span *ngIf="!r.ok && !r.pending">✗ {{ truncate(r.error || '', 80) }}</span>
                </div>
              </td>
              <td class="ki-right ki-actions">
                <button (click)="move(i, -1)" [disabled]="i === 0" class="ki-btn-icon">↑</button>
                <button (click)="move(i, 1)" [disabled]="i === models().length - 1" class="ki-btn-icon">↓</button>
                <button (click)="test(m)" class="ki-btn-secondary">{{ L.btnTest }}</button>
                <span *ngIf="showActiveAction && isActiveModel(m)" class="ki-badge ki-badge-active">{{ L.activeBadge }}</span>
                <button
                  *ngIf="showActiveAction && !isActiveModel(m) && m.keyConfigured && !m.autoDisabled"
                  (click)="setActive(m)"
                  class="ki-btn-primary"
                >{{ L.btnSetActive }}</button>
                <button *ngIf="m.autoDisabled" (click)="reEnable(m)" class="ki-btn-warn">{{ L.btnReenable }}</button>
                <button (click)="remove(m)" class="ki-btn-danger">{{ L.btnDelete }}</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  `, isInline: true, styles: [".ki-models-table{font-family:inherit}.ki-models-table-header{display:flex;justify-content:flex-end;margin-bottom:.75rem}.ki-muted{color:#888}.ki-tiny{font-size:.7rem}.ki-mono{font-family:ui-monospace,monospace}.ki-provider{color:#4f46e5;font-weight:700}.ki-empty{text-align:center;padding:2rem;color:#94a3b8;font-weight:600}.ki-table-wrap{overflow-x:auto}.ki-table{width:100%;border-collapse:collapse;font-size:.875rem}.ki-table thead tr{border-bottom:2px solid #e2e8f0}.ki-table th{padding:.75rem .5rem;text-align:left;text-transform:uppercase;font-size:.625rem;font-weight:800;letter-spacing:.1em;color:#64748b}.ki-table td{padding:.75rem .5rem;border-bottom:1px solid #f1f5f9;vertical-align:top}.ki-right{text-align:right}.ki-row-auto-disabled{background:#fef2f2}.ki-badge{display:inline-block;padding:.15rem .4rem;border-radius:.25rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em}.ki-badge-ok{background:#d1fae5;color:#065f46}.ki-badge-warn{background:#fee2e2;color:#991b1b}.ki-badge-error{background:#ef4444;color:#fff}.ki-toggle{padding:.25rem .6rem;border-radius:.375rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;border:none;cursor:pointer;transition:opacity .15s}.ki-toggle:disabled{opacity:.4;cursor:not-allowed}.ki-toggle-on{background:#10b981;color:#fff}.ki-toggle-off{background:#e2e8f0;color:#475569}.ki-actions{white-space:nowrap}.ki-actions>*{margin-left:.25rem}.ki-btn-icon,.ki-btn-secondary,.ki-btn-warn,.ki-btn-danger{padding:.25rem .6rem;border-radius:.375rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;border:none;cursor:pointer}.ki-btn-icon{background:#f1f5f9;color:#1e293b}.ki-btn-icon:disabled{opacity:.3;cursor:not-allowed}.ki-btn-secondary{background:#e0e7ff;color:#3730a3}.ki-btn-primary{background:#10b981;color:#fff}.ki-btn-warn{background:#fef3c7;color:#92400e}.ki-btn-danger{background:#fee2e2;color:#991b1b}.ki-btn-icon,.ki-btn-secondary,.ki-btn-primary,.ki-btn-warn,.ki-btn-danger{padding:.25rem .6rem;border-radius:.375rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;border:none;cursor:pointer}.ki-badge-active{background:#d1fae5;color:#065f46;border:1px solid #10b981}.ki-ok{color:#059669;font-weight:700}.ki-cooldown{color:#d97706;font-weight:700}.ki-error{color:#dc2626;font-weight:700}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ModelsTableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-models-table', standalone: true, imports: [CommonModule], template: `
    <div class="ki-models-table">
      <div class="ki-models-table-header">
        <button (click)="reload()" class="ki-btn-secondary">↻ {{ L.refresh }}</button>
      </div>

      <div *ngIf="loading()" class="ki-muted">{{ L.loading }}</div>

      <div *ngIf="!loading() && models().length === 0" class="ki-empty">
        {{ L.empty }}
      </div>

      <div *ngIf="models().length > 0" class="ki-table-wrap">
        <table class="ki-table">
          <thead>
            <tr>
              <th>{{ L.colNum }}</th>
              <th>{{ L.colProvider }}</th>
              <th>{{ L.colModelId }}</th>
              <th>{{ L.colKey }}</th>
              <th>{{ L.colEnabled }}</th>
              <th>{{ L.colStatus }}</th>
              <th class="ki-right">{{ L.colActions }}</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let m of models(); let i = index"
                [class.ki-row-auto-disabled]="m.autoDisabled">
              <td class="ki-mono ki-muted">{{ i + 1 }}</td>
              <td class="ki-mono ki-provider">{{ m.provider }}</td>
              <td class="ki-mono">
                <strong>{{ m.modelId }}</strong>
                <div *ngIf="m.displayName" class="ki-muted ki-tiny">{{ m.displayName }}</div>
              </td>
              <td>
                <span *ngIf="m.keyConfigured" class="ki-badge ki-badge-ok">{{ L.keySet }}</span>
                <span *ngIf="!m.keyConfigured" class="ki-badge ki-badge-warn">{{ L.keyMissing }}</span>
                <div class="ki-tiny ki-mono ki-muted">{{ m.apiKeySettingKey }}</div>
              </td>
              <td>
                <button *ngIf="!m.autoDisabled"
                        (click)="toggle(m)"
                        [disabled]="!m.enabled && !m.keyConfigured"
                        [title]="(!m.enabled && !m.keyConfigured) ? L.toggleNeedsKey : ''"
                        class="ki-toggle"
                        [class.ki-toggle-on]="m.enabled"
                        [class.ki-toggle-off]="!m.enabled">
                  {{ m.enabled ? L.on : L.off }}
                </button>
                <span *ngIf="m.autoDisabled" class="ki-badge ki-badge-error">🚫 {{ L.autoDisabled }}</span>
              </td>
              <td>
                <span *ngIf="m.autoDisabled" class="ki-tiny ki-error" [title]="m.autoDisabledReason || ''">
                  {{ truncate(m.autoDisabledReason || '', 60) }}
                </span>
                <span *ngIf="!m.autoDisabled && (m.cooldownRemainingSec ?? 0) > 0" class="ki-tiny ki-cooldown">
                  cd {{ m.cooldownRemainingSec }}s
                </span>
                <span *ngIf="!m.autoDisabled && !(m.cooldownRemainingSec ?? 0)" class="ki-tiny ki-ok">
                  {{ L.free }}
                </span>
                <div *ngIf="testResult()[m.id] as r" class="ki-tiny ki-mono"
                     [class.ki-ok]="r.ok"
                     [class.ki-error]="!r.ok && !r.pending">
                  <span *ngIf="r.pending">…</span>
                  <span *ngIf="r.ok">✓ {{ r.latencyMs }}ms</span>
                  <span *ngIf="!r.ok && !r.pending">✗ {{ truncate(r.error || '', 80) }}</span>
                </div>
              </td>
              <td class="ki-right ki-actions">
                <button (click)="move(i, -1)" [disabled]="i === 0" class="ki-btn-icon">↑</button>
                <button (click)="move(i, 1)" [disabled]="i === models().length - 1" class="ki-btn-icon">↓</button>
                <button (click)="test(m)" class="ki-btn-secondary">{{ L.btnTest }}</button>
                <span *ngIf="showActiveAction && isActiveModel(m)" class="ki-badge ki-badge-active">{{ L.activeBadge }}</span>
                <button
                  *ngIf="showActiveAction && !isActiveModel(m) && m.keyConfigured && !m.autoDisabled"
                  (click)="setActive(m)"
                  class="ki-btn-primary"
                >{{ L.btnSetActive }}</button>
                <button *ngIf="m.autoDisabled" (click)="reEnable(m)" class="ki-btn-warn">{{ L.btnReenable }}</button>
                <button (click)="remove(m)" class="ki-btn-danger">{{ L.btnDelete }}</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  `, styles: [".ki-models-table{font-family:inherit}.ki-models-table-header{display:flex;justify-content:flex-end;margin-bottom:.75rem}.ki-muted{color:#888}.ki-tiny{font-size:.7rem}.ki-mono{font-family:ui-monospace,monospace}.ki-provider{color:#4f46e5;font-weight:700}.ki-empty{text-align:center;padding:2rem;color:#94a3b8;font-weight:600}.ki-table-wrap{overflow-x:auto}.ki-table{width:100%;border-collapse:collapse;font-size:.875rem}.ki-table thead tr{border-bottom:2px solid #e2e8f0}.ki-table th{padding:.75rem .5rem;text-align:left;text-transform:uppercase;font-size:.625rem;font-weight:800;letter-spacing:.1em;color:#64748b}.ki-table td{padding:.75rem .5rem;border-bottom:1px solid #f1f5f9;vertical-align:top}.ki-right{text-align:right}.ki-row-auto-disabled{background:#fef2f2}.ki-badge{display:inline-block;padding:.15rem .4rem;border-radius:.25rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em}.ki-badge-ok{background:#d1fae5;color:#065f46}.ki-badge-warn{background:#fee2e2;color:#991b1b}.ki-badge-error{background:#ef4444;color:#fff}.ki-toggle{padding:.25rem .6rem;border-radius:.375rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;border:none;cursor:pointer;transition:opacity .15s}.ki-toggle:disabled{opacity:.4;cursor:not-allowed}.ki-toggle-on{background:#10b981;color:#fff}.ki-toggle-off{background:#e2e8f0;color:#475569}.ki-actions{white-space:nowrap}.ki-actions>*{margin-left:.25rem}.ki-btn-icon,.ki-btn-secondary,.ki-btn-warn,.ki-btn-danger{padding:.25rem .6rem;border-radius:.375rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;border:none;cursor:pointer}.ki-btn-icon{background:#f1f5f9;color:#1e293b}.ki-btn-icon:disabled{opacity:.3;cursor:not-allowed}.ki-btn-secondary{background:#e0e7ff;color:#3730a3}.ki-btn-primary{background:#10b981;color:#fff}.ki-btn-warn{background:#fef3c7;color:#92400e}.ki-btn-danger{background:#fee2e2;color:#991b1b}.ki-btn-icon,.ki-btn-secondary,.ki-btn-primary,.ki-btn-warn,.ki-btn-danger{padding:.25rem .6rem;border-radius:.375rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;border:none;cursor:pointer}.ki-badge-active{background:#d1fae5;color:#065f46;border:1px solid #10b981}.ki-ok{color:#059669;font-weight:700}.ki-cooldown{color:#d97706;font-weight:700}.ki-error{color:#dc2626;font-weight:700}\n"] }]
        }], propDecorators: { activeModelChanged: [{
                type: Output
            }], modelChanged: [{
                type: Output
            }], labels: [{
                type: Input
            }], showActiveAction: [{
                type: Input
            }], activeModelId: [{
                type: Input
            }] } });

/**
 * Form um ein neues AI-Modell zur Cascade hinzuzufügen.
 *
 * **Felder:**
 * - Provider-Dropdown (gemini, openai, anthropic, openrouter, deepseek, openai_compat)
 * - Model-ID-Combobox mit Provider-spezifischen Vorschlägen (datalist)
 * - apiKeySettingKey-Auswahl (vorbelegt aus existierenden API-Keys + Default per Provider)
 * - DisplayName (optional)
 * - Cooldown503OverrideSec (optional)
 * - Add-Button
 *
 * **Event:** `(modelCreated)` emittet das neue Model nach erfolgreichem POST.
 *
 * **Provider-Default-Keys:** Beim Provider-Wechsel wird `apiKeySettingKey`
 * automatisch auf `<provider>ApiKey` umgestellt (Convenience).
 */
class AddModelFormComponent {
    constructor() {
        this.modelCreated = new EventEmitter();
        this.L = ADD_MODEL_FORM_LABELS_EN;
        this.api = inject(KiModelsApiService);
        // Form state
        this.provider = 'gemini';
        this.modelId = '';
        this.apiKeySettingKey = 'geminiApiKey';
        this.displayName = '';
        this.cooldown503OverrideSec = null;
        this.submitting = signal(false);
        this.error = signal(null);
        this.keys = signal([]);
        this.defaultSettingKey = {
            gemini: 'geminiApiKey',
            openai: 'openaiApiKey',
            anthropic: 'anthropicApiKey',
            openrouter: 'openrouterApiKey',
            deepseek: 'deepseekApiKey',
            openai_compat: 'customApiKey',
        };
        this.modelIdSuggestionsByProvider = {
            gemini: [
                'gemini-2.5-flash',
                'gemini-2.5-flash-lite',
                'gemini-2.5-pro',
                'gemini-3-flash-preview',
                'gemini-3-pro-preview',
            ],
            openai: [
                'gpt-4o',
                'gpt-4o-mini',
                'gpt-4.1',
                'gpt-4.1-mini',
                'o1-mini',
                'o1-preview',
            ],
            anthropic: [
                'claude-opus-4-7',
                'claude-sonnet-4-6',
                'claude-haiku-4-5-20251001',
            ],
            openrouter: [
                'deepseek/deepseek-v4-flash',
                'deepseek/deepseek-v4-pro',
                'deepseek/deepseek-chat-v3.1',
                'meta-llama/llama-3.3-70b-instruct:free',
                'openai/gpt-oss-120b:free',
            ],
            deepseek: [
                'deepseek-v4-flash',
                'deepseek-v4-pro',
                'deepseek-chat',
            ],
            openai_compat: [],
        };
    }
    set labels(v) {
        this.L = { ...ADD_MODEL_FORM_LABELS_EN, ...(v ?? {}) };
    }
    ngOnInit() {
        this.api.listKeys().subscribe({
            next: (list) => this.keys.set(list),
            error: () => this.keys.set([]),
        });
    }
    onProviderChange() {
        const def = this.defaultSettingKey[this.provider];
        if (def)
            this.apiKeySettingKey = def;
    }
    modelIdSuggestions() {
        return this.modelIdSuggestionsByProvider[this.provider] ?? [];
    }
    /** Existierende Settings als Optionen + Default-Settings die noch nicht in DB sind. */
    keyOptions() {
        const existing = new Map(this.keys().map((k) => [k.settingKey, k.configured]));
        // Default-settingKeys aus dem Mapping ergänzen (auch wenn DB sie noch nicht hat)
        Object.values(this.defaultSettingKey).forEach((sk) => {
            if (!existing.has(sk))
                existing.set(sk, false);
        });
        return Array.from(existing.entries())
            .map(([settingKey, configured]) => ({ settingKey, configured }))
            .sort((a, b) => a.settingKey.localeCompare(b.settingKey));
    }
    onSubmit() {
        if (!this.provider || !this.modelId || !this.apiKeySettingKey)
            return;
        this.submitting.set(true);
        this.error.set(null);
        const body = {
            provider: this.provider.trim(),
            modelId: this.modelId.trim(),
            apiKeySettingKey: this.apiKeySettingKey.trim(),
            displayName: this.displayName?.trim() || undefined,
            cooldown503OverrideSec: this.cooldown503OverrideSec,
        };
        this.api.createModel(body).subscribe({
            next: (created) => {
                this.modelCreated.emit(created);
                this.modelId = '';
                this.displayName = '';
                this.cooldown503OverrideSec = null;
                this.submitting.set(false);
            },
            error: (err) => {
                this.error.set(err?.error?.error ?? this.L.errorFailed);
                this.submitting.set(false);
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AddModelFormComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: AddModelFormComponent, isStandalone: true, selector: "ki-add-model-form", inputs: { labels: "labels" }, outputs: { modelCreated: "modelCreated" }, ngImport: i0, template: `
    <form class="ki-add-model-form" (ngSubmit)="onSubmit()" #f="ngForm">
      <h4 class="ki-form-title">{{ L.title }}</h4>

      <div class="ki-grid">
        <select [(ngModel)]="provider"
                name="provider"
                (change)="onProviderChange()"
                class="ki-input">
          <option *ngFor="let p of L.providerOptions" [value]="p.value">{{ p.label }}</option>
        </select>

        <input [(ngModel)]="modelId"
               name="modelId"
               list="ki-model-id-suggestions"
               [placeholder]="L.fieldModelId"
               class="ki-input ki-mono"
               required />
        <datalist id="ki-model-id-suggestions">
          <option *ngFor="let s of modelIdSuggestions()" [value]="s"></option>
        </datalist>

        <select [(ngModel)]="apiKeySettingKey"
                name="apiKeySettingKey"
                class="ki-input ki-mono">
          <option value="" disabled>{{ L.fieldApiKeySettingKey }}</option>
          <option *ngFor="let k of keyOptions()" [value]="k.settingKey">
            {{ k.settingKey }} {{ k.configured ? '✓' : '' }}
          </option>
        </select>

        <input [(ngModel)]="displayName"
               name="displayName"
               [placeholder]="L.fieldDisplayName"
               class="ki-input" />

        <input [(ngModel)]="cooldown503OverrideSec"
               name="cooldown503OverrideSec"
               type="number"
               [placeholder]="L.fieldCooldownOverride"
               class="ki-input" />

        <button type="submit"
                [disabled]="submitting() || !provider || !modelId || !apiKeySettingKey"
                class="ki-btn-primary">
          {{ submitting() ? L.btnAdding : L.btnAdd }}
        </button>
      </div>

      <p *ngIf="error()" class="ki-error">{{ error() }}</p>
      <p class="ki-hint">{{ L.hint }}</p>
    </form>
  `, isInline: true, styles: [".ki-add-model-form{font-family:inherit;padding:1rem 0;border-top:1px solid #e2e8f0}.ki-form-title{font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#475569;margin-bottom:.75rem}.ki-grid{display:grid;grid-template-columns:1fr 1fr;gap:.75rem}.ki-input{padding:.75rem;background:#f8fafc;border:2px solid #f1f5f9;border-radius:.75rem;font-size:.875rem;font-weight:700}.ki-mono{font-family:ui-monospace,monospace}.ki-btn-primary{padding:.75rem 1rem;background:#0f172a;color:#fff;border:none;border-radius:1rem;text-transform:uppercase;font-weight:800;letter-spacing:.1em;font-size:.75rem;cursor:pointer;grid-column:span 2}.ki-btn-primary:disabled{opacity:.4;cursor:not-allowed}.ki-error{color:#b91c1c;font-weight:700;margin-top:.5rem;font-size:.75rem}.ki-hint{color:#94a3b8;font-size:.7rem;font-weight:700;margin-top:.75rem}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i2.NgSelectOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.ɵNgSelectMultipleOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2.NumberValueAccessor, selector: "input[type=number][formControlName],input[type=number][formControl],input[type=number][ngModel]" }, { kind: "directive", type: i2.SelectControlValueAccessor, selector: "select:not([multiple])[formControlName],select:not([multiple])[formControl],select:not([multiple])[ngModel]", inputs: ["compareWith"] }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: i2.NgForm, selector: "form:not([ngNoForm]):not([formGroup]),ng-form,[ngForm]", inputs: ["ngFormOptions"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AddModelFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-add-model-form', standalone: true, imports: [CommonModule, FormsModule], template: `
    <form class="ki-add-model-form" (ngSubmit)="onSubmit()" #f="ngForm">
      <h4 class="ki-form-title">{{ L.title }}</h4>

      <div class="ki-grid">
        <select [(ngModel)]="provider"
                name="provider"
                (change)="onProviderChange()"
                class="ki-input">
          <option *ngFor="let p of L.providerOptions" [value]="p.value">{{ p.label }}</option>
        </select>

        <input [(ngModel)]="modelId"
               name="modelId"
               list="ki-model-id-suggestions"
               [placeholder]="L.fieldModelId"
               class="ki-input ki-mono"
               required />
        <datalist id="ki-model-id-suggestions">
          <option *ngFor="let s of modelIdSuggestions()" [value]="s"></option>
        </datalist>

        <select [(ngModel)]="apiKeySettingKey"
                name="apiKeySettingKey"
                class="ki-input ki-mono">
          <option value="" disabled>{{ L.fieldApiKeySettingKey }}</option>
          <option *ngFor="let k of keyOptions()" [value]="k.settingKey">
            {{ k.settingKey }} {{ k.configured ? '✓' : '' }}
          </option>
        </select>

        <input [(ngModel)]="displayName"
               name="displayName"
               [placeholder]="L.fieldDisplayName"
               class="ki-input" />

        <input [(ngModel)]="cooldown503OverrideSec"
               name="cooldown503OverrideSec"
               type="number"
               [placeholder]="L.fieldCooldownOverride"
               class="ki-input" />

        <button type="submit"
                [disabled]="submitting() || !provider || !modelId || !apiKeySettingKey"
                class="ki-btn-primary">
          {{ submitting() ? L.btnAdding : L.btnAdd }}
        </button>
      </div>

      <p *ngIf="error()" class="ki-error">{{ error() }}</p>
      <p class="ki-hint">{{ L.hint }}</p>
    </form>
  `, styles: [".ki-add-model-form{font-family:inherit;padding:1rem 0;border-top:1px solid #e2e8f0}.ki-form-title{font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#475569;margin-bottom:.75rem}.ki-grid{display:grid;grid-template-columns:1fr 1fr;gap:.75rem}.ki-input{padding:.75rem;background:#f8fafc;border:2px solid #f1f5f9;border-radius:.75rem;font-size:.875rem;font-weight:700}.ki-mono{font-family:ui-monospace,monospace}.ki-btn-primary{padding:.75rem 1rem;background:#0f172a;color:#fff;border:none;border-radius:1rem;text-transform:uppercase;font-weight:800;letter-spacing:.1em;font-size:.75rem;cursor:pointer;grid-column:span 2}.ki-btn-primary:disabled{opacity:.4;cursor:not-allowed}.ki-error{color:#b91c1c;font-weight:700;margin-top:.5rem;font-size:.75rem}.ki-hint{color:#94a3b8;font-size:.7rem;font-weight:700;margin-top:.75rem}\n"] }]
        }], propDecorators: { modelCreated: [{
                type: Output
            }], labels: [{
                type: Input
            }] } });

/**
 * Tri-State Cooldown-Override-Panel.
 *
 * **States:**
 * - `null` (Default) — jedes Modell nutzt seine eigene Cooldown-Logik (Standard)
 * - `true` (Force ON) — Cooldown global erzwingen (auch wenn Modelle individuell deaktiviert haben)
 * - `false` (Force OFF) — Cooldown global deaktivieren (Tests / Debug)
 *
 * **Effective-Badge** zeigt den vom Backend resolved Endzustand (`effective`,
 * `effectiveCooldown`).
 */
class CascadeCooldownComponent {
    constructor() {
        this.L = CASCADE_COOLDOWN_LABELS_EN;
        this.api = inject(KiModelsApiService);
        this.loading = signal(true);
        this.config = signal(null);
    }
    set labels(v) {
        this.L = { ...CASCADE_COOLDOWN_LABELS_EN, ...(v ?? {}) };
    }
    ngOnInit() {
        this.refresh();
    }
    refresh() {
        this.loading.set(true);
        this.api.getCascadeConfig().subscribe({
            next: (cfg) => {
                this.config.set(cfg);
                this.loading.set(false);
            },
            error: () => this.loading.set(false),
        });
    }
    set(value) {
        if (this.config()?.cooldownOverride === value)
            return;
        this.api.setCascadeConfig({ cooldownOverride: value }).subscribe((cfg) => this.config.set(cfg));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CascadeCooldownComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CascadeCooldownComponent, isStandalone: true, selector: "ki-cascade-cooldown", inputs: { labels: "labels" }, ngImport: i0, template: `
    <div class="ki-cooldown" *ngIf="config() as cfg">
      <h4 class="ki-section-title">{{ L.title }}</h4>
      <p class="ki-subtitle">{{ L.subtitle }}</p>

      <div class="ki-controls">
        <button (click)="set(null)"
                class="ki-state-btn"
                [class.ki-state-active]="cfg.cooldownOverride === null"
                [class.ki-state-default]="cfg.cooldownOverride === null">
          {{ L.default }}
        </button>
        <button (click)="set(true)"
                class="ki-state-btn"
                [class.ki-state-active]="cfg.cooldownOverride === true"
                [class.ki-state-on]="cfg.cooldownOverride === true">
          {{ L.forceOn }}
        </button>
        <button (click)="set(false)"
                class="ki-state-btn"
                [class.ki-state-active]="cfg.cooldownOverride === false"
                [class.ki-state-off]="cfg.cooldownOverride === false">
          {{ L.forceOff }}
        </button>

        <span class="ki-effective-badge"
              [class.ki-effective-on]="cfg.effectiveCooldown"
              [class.ki-effective-off]="!cfg.effectiveCooldown">
          {{ cfg.effectiveCooldown ? L.effectiveOn : L.effectiveOff }}
        </span>
      </div>

      <p class="ki-hint">{{ L.hint }}</p>
    </div>

    <div *ngIf="!config() && loading()" class="ki-muted">{{ L.loading }}</div>
    <div *ngIf="!config() && !loading()" class="ki-error">{{ L.errorLoad }}</div>
  `, isInline: true, styles: [".ki-cooldown{font-family:inherit;padding:1.5rem 0}.ki-section-title{font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#475569;margin-bottom:.5rem}.ki-subtitle{color:#64748b;font-size:.75rem;font-weight:700;margin-bottom:1.25rem}.ki-controls{display:flex;flex-wrap:wrap;gap:.5rem;align-items:center}.ki-state-btn{padding:.6rem 1rem;border-radius:1rem;font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;border:none;cursor:pointer;background:#f1f5f9;color:#475569;transition:background .15s}.ki-state-btn:hover{background:#e2e8f0}.ki-state-active.ki-state-default{background:#0f172a;color:#fff}.ki-state-active.ki-state-on{background:#10b981;color:#fff}.ki-state-active.ki-state-off{background:#f59e0b;color:#fff}.ki-effective-badge{margin-left:auto;padding:.3rem .75rem;border-radius:999px;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em}.ki-effective-on{background:#d1fae5;color:#065f46}.ki-effective-off{background:#fef3c7;color:#92400e}.ki-hint{color:#94a3b8;font-size:.7rem;font-weight:700;margin-top:1rem}.ki-muted{color:#888}.ki-error{color:#b91c1c;font-weight:700}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CascadeCooldownComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-cascade-cooldown', standalone: true, imports: [CommonModule], template: `
    <div class="ki-cooldown" *ngIf="config() as cfg">
      <h4 class="ki-section-title">{{ L.title }}</h4>
      <p class="ki-subtitle">{{ L.subtitle }}</p>

      <div class="ki-controls">
        <button (click)="set(null)"
                class="ki-state-btn"
                [class.ki-state-active]="cfg.cooldownOverride === null"
                [class.ki-state-default]="cfg.cooldownOverride === null">
          {{ L.default }}
        </button>
        <button (click)="set(true)"
                class="ki-state-btn"
                [class.ki-state-active]="cfg.cooldownOverride === true"
                [class.ki-state-on]="cfg.cooldownOverride === true">
          {{ L.forceOn }}
        </button>
        <button (click)="set(false)"
                class="ki-state-btn"
                [class.ki-state-active]="cfg.cooldownOverride === false"
                [class.ki-state-off]="cfg.cooldownOverride === false">
          {{ L.forceOff }}
        </button>

        <span class="ki-effective-badge"
              [class.ki-effective-on]="cfg.effectiveCooldown"
              [class.ki-effective-off]="!cfg.effectiveCooldown">
          {{ cfg.effectiveCooldown ? L.effectiveOn : L.effectiveOff }}
        </span>
      </div>

      <p class="ki-hint">{{ L.hint }}</p>
    </div>

    <div *ngIf="!config() && loading()" class="ki-muted">{{ L.loading }}</div>
    <div *ngIf="!config() && !loading()" class="ki-error">{{ L.errorLoad }}</div>
  `, styles: [".ki-cooldown{font-family:inherit;padding:1.5rem 0}.ki-section-title{font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#475569;margin-bottom:.5rem}.ki-subtitle{color:#64748b;font-size:.75rem;font-weight:700;margin-bottom:1.25rem}.ki-controls{display:flex;flex-wrap:wrap;gap:.5rem;align-items:center}.ki-state-btn{padding:.6rem 1rem;border-radius:1rem;font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;border:none;cursor:pointer;background:#f1f5f9;color:#475569;transition:background .15s}.ki-state-btn:hover{background:#e2e8f0}.ki-state-active.ki-state-default{background:#0f172a;color:#fff}.ki-state-active.ki-state-on{background:#10b981;color:#fff}.ki-state-active.ki-state-off{background:#f59e0b;color:#fff}.ki-effective-badge{margin-left:auto;padding:.3rem .75rem;border-radius:999px;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em}.ki-effective-on{background:#d1fae5;color:#065f46}.ki-effective-off{background:#fef3c7;color:#92400e}.ki-hint{color:#94a3b8;font-size:.7rem;font-weight:700;margin-top:1rem}.ki-muted{color:#888}.ki-error{color:#b91c1c;font-weight:700}\n"] }]
        }], propDecorators: { labels: [{
                type: Input
            }] } });

/**
 * Section zur Verwaltung aller API-Keys (settingKey-basiert).
 *
 * **Form (oben):** settingKey-Picker + Value-Input (mit Show/Hide) + Save-Button.
 * Konsument kann beim Add eines neuen Models einen settingKey wählen, der noch
 * keinen Value hat — der bleibt offen bis er hier gesetzt wird.
 *
 * **Status-Liste (unten):** alle konfigurierten settingKeys mit:
 * - Badge: Source (`db` vom Admin gesetzt oder `env` vom Boot-Default)
 * - Wert maskiert
 * - Actions: Edit (lädt in Form oben), Clear (löscht den DB-Override)
 *
 * **Event:** `(keyChanged)` emittet bei jedem Save/Clear damit Konsument seine
 * Modell-Liste neu laden kann (key-Konfiguration ändert sich → Models-Status
 * `keyConfigured` ändert sich).
 */
class ApiKeysSectionComponent {
    constructor() {
        this.keyChanged = new EventEmitter();
        this.L = API_KEYS_SECTION_LABELS_EN;
        this.api = inject(KiModelsApiService);
        this.loading = signal(true);
        this.keys = signal([]);
        // Form state
        this.settingKey = '';
        this.value = '';
        this.showValue = signal(false);
        this.saving = signal(false);
        this.clearing = signal(null);
        /** Bekannte Default-Settings + ihre Brand-Labels (für Add-Form Vorschläge). */
        this.defaultCards = [
            { settingKey: 'geminiApiKey', brand: 'Gemini (Google)' },
            { settingKey: 'openaiApiKey', brand: 'OpenAI' },
            { settingKey: 'anthropicApiKey', brand: 'Anthropic' },
            { settingKey: 'openrouterApiKey', brand: 'OpenRouter' },
            { settingKey: 'deepseekApiKey', brand: 'DeepSeek' },
            { settingKey: 'customApiKey', brand: 'Custom (OpenAI-compat)' },
        ];
        this.configuredKeys = computed(() => this.keys().filter((k) => k.configured));
    }
    set labels(v) {
        this.L = { ...API_KEYS_SECTION_LABELS_EN, ...(v ?? {}) };
    }
    /** Default-Settings + dynamische (aus DB) als Options im Dropdown. */
    keyOptions() {
        const fromApi = new Set(this.keys().map((k) => k.settingKey));
        const dynamic = Array.from(fromApi)
            .filter((k) => !this.defaultCards.find((d) => d.settingKey === k))
            .map((k) => ({ settingKey: k, brand: 'Custom' }));
        return [...this.defaultCards, ...dynamic].sort((a, b) => a.settingKey.localeCompare(b.settingKey));
    }
    ngOnInit() {
        this.reload();
    }
    reload() {
        this.loading.set(true);
        this.api.listKeys().subscribe({
            next: (list) => {
                this.keys.set(list);
                this.loading.set(false);
            },
            error: () => this.loading.set(false),
        });
    }
    canSave() {
        return !!this.settingKey && !this.saving();
    }
    save() {
        if (!this.canSave())
            return;
        this.saving.set(true);
        this.api.setKey(this.settingKey, { value: this.value }).subscribe({
            next: () => {
                this.keyChanged.emit(this.settingKey);
                this.value = '';
                this.showValue.set(false);
                this.saving.set(false);
                this.reload();
            },
            error: () => this.saving.set(false),
        });
    }
    editKey(k) {
        this.settingKey = k.settingKey;
        this.value = '';
        this.showValue.set(false);
    }
    clearKey(k) {
        if (!confirm(this.L.confirmClear(k.settingKey)))
            return;
        this.clearing.set(k.settingKey);
        this.api.setKey(k.settingKey, { value: '' }).subscribe({
            next: () => {
                this.keyChanged.emit(k.settingKey);
                this.clearing.set(null);
                this.reload();
            },
            error: () => this.clearing.set(null),
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ApiKeysSectionComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ApiKeysSectionComponent, isStandalone: true, selector: "ki-api-keys-section", inputs: { labels: "labels" }, outputs: { keyChanged: "keyChanged" }, ngImport: i0, template: `
    <div class="ki-keys-section">
      <h4 class="ki-section-title">{{ L.title }}</h4>
      <p class="ki-subtitle">{{ L.subtitle }}</p>

      <!-- Add/Edit Form -->
      <div class="ki-form-grid">
        <select [(ngModel)]="settingKey" class="ki-input ki-mono">
          <option value="" disabled>{{ L.fieldSettingKey }}</option>
          <option *ngFor="let k of keyOptions()" [value]="k.settingKey">
            {{ k.settingKey }} — {{ k.brand }}
          </option>
        </select>

        <div class="ki-input-wrap">
          <input [(ngModel)]="value"
                 [type]="showValue() ? 'text' : 'password'"
                 [placeholder]="L.fieldValue"
                 autocomplete="off"
                 spellcheck="false"
                 class="ki-input ki-mono ki-input-with-toggle" />
          <button type="button" (click)="showValue.set(!showValue())" class="ki-show-toggle">
            {{ showValue() ? L.btnHide : L.btnShow }}
          </button>
        </div>

        <button (click)="save()"
                [disabled]="!canSave() || saving()"
                class="ki-btn-primary">
          {{ saving() ? L.btnSaving : L.btnSave }}
        </button>
      </div>

      <!-- Status-Liste -->
      <ng-container *ngIf="configuredKeys().length > 0; else noKeys">
        <h5 class="ki-list-title">{{ L.listTitle }}</h5>
        <div class="ki-table-wrap">
          <table class="ki-table">
            <thead>
              <tr>
                <th>{{ L.colSettingKey }}</th>
                <th>{{ L.colSource }}</th>
                <th>{{ L.colValue }}</th>
                <th class="ki-right">{{ L.colActions }}</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let k of configuredKeys()">
                <td class="ki-mono">
                  <strong>{{ k.settingKey }}</strong>
                </td>
                <td>
                  <span class="ki-badge"
                        [class.ki-badge-db]="k.keySource === 'db'"
                        [class.ki-badge-env]="k.keySource !== 'db'">
                    {{ k.keySource === 'db' ? L.sourceDb : (k.configured ? L.sourceEnv : L.sourceMissing) }}
                  </span>
                </td>
                <td class="ki-mono ki-value">{{ k.valueMasked || '…' }}</td>
                <td class="ki-right">
                  <button (click)="editKey(k)" class="ki-btn-secondary">{{ L.btnEdit }}</button>
                  <button *ngIf="k.keySource === 'db'"
                          (click)="clearKey(k)"
                          [disabled]="clearing() === k.settingKey"
                          class="ki-btn-danger">
                    {{ clearing() === k.settingKey ? '…' : L.btnClear }}
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </ng-container>
      <ng-template #noKeys>
        <p class="ki-empty">{{ L.empty }}</p>
      </ng-template>

      <p class="ki-hint">{{ L.hint }}</p>
    </div>
  `, isInline: true, styles: [".ki-keys-section{font-family:inherit;padding:1.5rem 0}.ki-section-title{font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#475569;margin-bottom:.5rem}.ki-subtitle{color:#64748b;font-size:.75rem;font-weight:700;margin-bottom:1.25rem}.ki-list-title{font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#94a3b8;margin:1.5rem 0 .75rem}.ki-form-grid{display:grid;grid-template-columns:1fr 1fr;gap:.75rem;margin-bottom:1rem}.ki-input{padding:.75rem;background:#f8fafc;border:2px solid #f1f5f9;border-radius:.75rem;font-size:.875rem;font-weight:700}.ki-mono{font-family:ui-monospace,monospace}.ki-input-wrap{position:relative}.ki-input-with-toggle{width:100%;padding-right:4rem;box-sizing:border-box}.ki-show-toggle{position:absolute;right:.75rem;top:50%;transform:translateY(-50%);padding:.25rem .5rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;background:transparent;border:none;color:#64748b;cursor:pointer}.ki-btn-primary{grid-column:span 2;padding:.75rem 1rem;background:#dc2626;color:#fff;border:none;border-radius:1rem;text-transform:uppercase;font-weight:800;letter-spacing:.1em;font-size:.75rem;cursor:pointer}.ki-btn-primary:disabled{opacity:.4;cursor:not-allowed}.ki-btn-secondary,.ki-btn-danger{padding:.3rem .7rem;border-radius:.375rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;border:none;cursor:pointer}.ki-btn-secondary{background:#f1f5f9;color:#1e293b;margin-right:.25rem}.ki-btn-danger{background:#fee2e2;color:#991b1b}.ki-btn-danger:disabled{opacity:.4;cursor:not-allowed}.ki-table-wrap{overflow-x:auto}.ki-table{width:100%;border-collapse:collapse;font-size:.875rem}.ki-table thead{border-bottom:1px solid #f1f5f9}.ki-table th{padding:.5rem;text-align:left;text-transform:uppercase;font-size:.625rem;font-weight:800;letter-spacing:.1em;color:#94a3b8}.ki-table td{padding:.75rem .5rem;border-bottom:1px solid #f1f5f9;vertical-align:middle}.ki-right{text-align:right}.ki-badge{display:inline-block;padding:.25rem .7rem;border-radius:999px;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em}.ki-badge-db{background:#d1fae5;color:#065f46}.ki-badge-env{background:#e2e8f0;color:#475569}.ki-value{color:#64748b}.ki-empty{color:#94a3b8;font-style:italic;font-size:.75rem;font-weight:700}.ki-hint{color:#94a3b8;font-size:.7rem;font-weight:700;margin-top:1rem}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.NgSelectOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.ɵNgSelectMultipleOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2.SelectControlValueAccessor, selector: "select:not([multiple])[formControlName],select:not([multiple])[formControl],select:not([multiple])[ngModel]", inputs: ["compareWith"] }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ApiKeysSectionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-api-keys-section', standalone: true, imports: [CommonModule, FormsModule], template: `
    <div class="ki-keys-section">
      <h4 class="ki-section-title">{{ L.title }}</h4>
      <p class="ki-subtitle">{{ L.subtitle }}</p>

      <!-- Add/Edit Form -->
      <div class="ki-form-grid">
        <select [(ngModel)]="settingKey" class="ki-input ki-mono">
          <option value="" disabled>{{ L.fieldSettingKey }}</option>
          <option *ngFor="let k of keyOptions()" [value]="k.settingKey">
            {{ k.settingKey }} — {{ k.brand }}
          </option>
        </select>

        <div class="ki-input-wrap">
          <input [(ngModel)]="value"
                 [type]="showValue() ? 'text' : 'password'"
                 [placeholder]="L.fieldValue"
                 autocomplete="off"
                 spellcheck="false"
                 class="ki-input ki-mono ki-input-with-toggle" />
          <button type="button" (click)="showValue.set(!showValue())" class="ki-show-toggle">
            {{ showValue() ? L.btnHide : L.btnShow }}
          </button>
        </div>

        <button (click)="save()"
                [disabled]="!canSave() || saving()"
                class="ki-btn-primary">
          {{ saving() ? L.btnSaving : L.btnSave }}
        </button>
      </div>

      <!-- Status-Liste -->
      <ng-container *ngIf="configuredKeys().length > 0; else noKeys">
        <h5 class="ki-list-title">{{ L.listTitle }}</h5>
        <div class="ki-table-wrap">
          <table class="ki-table">
            <thead>
              <tr>
                <th>{{ L.colSettingKey }}</th>
                <th>{{ L.colSource }}</th>
                <th>{{ L.colValue }}</th>
                <th class="ki-right">{{ L.colActions }}</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let k of configuredKeys()">
                <td class="ki-mono">
                  <strong>{{ k.settingKey }}</strong>
                </td>
                <td>
                  <span class="ki-badge"
                        [class.ki-badge-db]="k.keySource === 'db'"
                        [class.ki-badge-env]="k.keySource !== 'db'">
                    {{ k.keySource === 'db' ? L.sourceDb : (k.configured ? L.sourceEnv : L.sourceMissing) }}
                  </span>
                </td>
                <td class="ki-mono ki-value">{{ k.valueMasked || '…' }}</td>
                <td class="ki-right">
                  <button (click)="editKey(k)" class="ki-btn-secondary">{{ L.btnEdit }}</button>
                  <button *ngIf="k.keySource === 'db'"
                          (click)="clearKey(k)"
                          [disabled]="clearing() === k.settingKey"
                          class="ki-btn-danger">
                    {{ clearing() === k.settingKey ? '…' : L.btnClear }}
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </ng-container>
      <ng-template #noKeys>
        <p class="ki-empty">{{ L.empty }}</p>
      </ng-template>

      <p class="ki-hint">{{ L.hint }}</p>
    </div>
  `, styles: [".ki-keys-section{font-family:inherit;padding:1.5rem 0}.ki-section-title{font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#475569;margin-bottom:.5rem}.ki-subtitle{color:#64748b;font-size:.75rem;font-weight:700;margin-bottom:1.25rem}.ki-list-title{font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#94a3b8;margin:1.5rem 0 .75rem}.ki-form-grid{display:grid;grid-template-columns:1fr 1fr;gap:.75rem;margin-bottom:1rem}.ki-input{padding:.75rem;background:#f8fafc;border:2px solid #f1f5f9;border-radius:.75rem;font-size:.875rem;font-weight:700}.ki-mono{font-family:ui-monospace,monospace}.ki-input-wrap{position:relative}.ki-input-with-toggle{width:100%;padding-right:4rem;box-sizing:border-box}.ki-show-toggle{position:absolute;right:.75rem;top:50%;transform:translateY(-50%);padding:.25rem .5rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;background:transparent;border:none;color:#64748b;cursor:pointer}.ki-btn-primary{grid-column:span 2;padding:.75rem 1rem;background:#dc2626;color:#fff;border:none;border-radius:1rem;text-transform:uppercase;font-weight:800;letter-spacing:.1em;font-size:.75rem;cursor:pointer}.ki-btn-primary:disabled{opacity:.4;cursor:not-allowed}.ki-btn-secondary,.ki-btn-danger{padding:.3rem .7rem;border-radius:.375rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;border:none;cursor:pointer}.ki-btn-secondary{background:#f1f5f9;color:#1e293b;margin-right:.25rem}.ki-btn-danger{background:#fee2e2;color:#991b1b}.ki-btn-danger:disabled{opacity:.4;cursor:not-allowed}.ki-table-wrap{overflow-x:auto}.ki-table{width:100%;border-collapse:collapse;font-size:.875rem}.ki-table thead{border-bottom:1px solid #f1f5f9}.ki-table th{padding:.5rem;text-align:left;text-transform:uppercase;font-size:.625rem;font-weight:800;letter-spacing:.1em;color:#94a3b8}.ki-table td{padding:.75rem .5rem;border-bottom:1px solid #f1f5f9;vertical-align:middle}.ki-right{text-align:right}.ki-badge{display:inline-block;padding:.25rem .7rem;border-radius:999px;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em}.ki-badge-db{background:#d1fae5;color:#065f46}.ki-badge-env{background:#e2e8f0;color:#475569}.ki-value{color:#64748b}.ki-empty{color:#94a3b8;font-style:italic;font-size:.75rem;font-weight:700}.ki-hint{color:#94a3b8;font-size:.7rem;font-weight:700;margin-top:1rem}\n"] }]
        }], propDecorators: { keyChanged: [{
                type: Output
            }], labels: [{
                type: Input
            }] } });

/**
 * Generischer Failover-Chain-Editor — von beiden Konsumenten (Switcher +
 * EduPro) genutzt. Komponente ist „dumm": sie hält keinen Zustand, sondern
 * emittet `(chainChanged)` bei jeder Edit-Aktion. Der Konsument entscheidet
 * was mit der neuen Chain passiert:
 *
 * - **Switcher** persistiert sie in `_switcher.fallback_chain` (Wrapper liest
 *   das + restartet Claude Code bei Quota-Fehler entlang der Chain).
 * - **EduPro** mapped die Chain auf cascade-models-CRUD (`orderIdx`-Reorder
 *   bei Reorder, POST bei Add, DELETE bei Remove). Damit ist die Chain in
 *   EduPro effektiv die enabled-Modell-Liste in `orderIdx`-Reihenfolge.
 *
 * Switcher-spezifische Features (Aktuelle-Stufe-Indikator, Promote-Button)
 * sind hinter `[showChainPosition]="true"` gegated und in EduPro standardmäßig
 * ausgeblendet.
 *
 * **Inputs:**
 * - `chain` — aktuelle Chain (`{provider, model}[]`)
 * - `availableModels` — Optionen für Modell-Dropdown pro Provider
 * - `availableProviders` — Optionen für Provider-Dropdown
 * - `chainPosition` — aktive Stufe (0-basiert, null = keine)
 * - `showChainPosition` — gated Aktuelle-Stufe-Zeile + Promote-Button
 * - `labels` — i18n-Override
 *
 * **Outputs:**
 * - `chainChanged` — neue Chain nach jeder Edit-Aktion
 * - `promoteRequested` — User klickt „Zurück zu Stufe 1" (nur bei
 *   `showChainPosition && chainPosition > 0` sichtbar)
 */
class FailoverChainComponent {
    constructor() {
        /** Aktuelle Chain. Die Komponente mutiert sie in-place beim Editieren und emittet `chainChanged`. */
        this.chain = [];
        /** Optionen für die Modell-Dropdowns. Pro Provider eine Liste an Modellen. */
        this.availableModels = [];
        /** Optionen für die Provider-Dropdowns. Default: anthropic/google/openrouter. */
        this.availableProviders = [
            { value: 'anthropic', label: 'Anthropic' },
            { value: 'google', label: 'Google AI Studio' },
            { value: 'openrouter', label: 'OpenRouter' },
        ];
        /** Aktive Stufe (0-basiert). Nur relevant bei `showChainPosition=true`. */
        this.chainPosition = null;
        /** Gated die Aktuelle-Stufe-Zeile + Promote-Button (Switcher-only-Feature). */
        this.showChainPosition = false;
        this.L = FAILOVER_CHAIN_LABELS_EN;
        this.chainChanged = new EventEmitter();
        this.promoteRequested = new EventEmitter();
    }
    /** Optionale i18n-Override-Strings. */
    set labels(v) {
        this.L = { ...FAILOVER_CHAIN_LABELS_EN, ...(v ?? {}) };
    }
    modelsFor(provider) {
        return this.availableModels.filter((m) => m.provider === provider);
    }
    onProviderChange(idx) {
        // Beim Provider-Wechsel: Modell auf erstes verfügbares des neuen Providers setzen.
        const first = this.modelsFor(this.chain[idx].provider)[0];
        if (first)
            this.chain[idx].model = first.modelId;
        this.emit();
    }
    addRow() {
        // Default-Provider: erster aus availableProviders. Default-Modell: erstes seiner Modelle.
        const firstProvider = this.availableProviders[0]?.value ?? 'anthropic';
        const firstModel = this.modelsFor(firstProvider)[0]?.modelId ?? '';
        this.chain = [...this.chain, { provider: firstProvider, model: firstModel }];
        this.emit();
    }
    removeRow(idx) {
        this.chain = this.chain.filter((_, i) => i !== idx);
        this.emit();
    }
    moveUp(idx) {
        if (idx === 0)
            return;
        const next = [...this.chain];
        [next[idx - 1], next[idx]] = [next[idx], next[idx - 1]];
        this.chain = next;
        this.emit();
    }
    moveDown(idx) {
        if (idx >= this.chain.length - 1)
            return;
        const next = [...this.chain];
        [next[idx], next[idx + 1]] = [next[idx + 1], next[idx]];
        this.chain = next;
        this.emit();
    }
    positionLabel() {
        const pos = this.chainPosition ?? 0;
        const entry = this.chain[pos];
        if (!entry)
            return this.L.positionLabel(pos, '–', '–');
        return this.L.positionLabel(pos, entry.provider, entry.model);
    }
    emit() {
        this.chainChanged.emit([...this.chain]);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FailoverChainComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FailoverChainComponent, isStandalone: true, selector: "ki-failover-chain", inputs: { chain: "chain", availableModels: "availableModels", availableProviders: "availableProviders", chainPosition: "chainPosition", showChainPosition: "showChainPosition", labels: "labels" }, outputs: { chainChanged: "chainChanged", promoteRequested: "promoteRequested" }, ngImport: i0, template: `
    <div>
      <p class="text-sm text-slate-600 dark:text-slate-300 mb-3">
        <strong class="font-semibold text-slate-900 dark:text-slate-100">{{ L.title }}</strong>
        — {{ L.description }}
      </p>

      <div *ngIf="chain.length === 0" class="text-sm italic text-slate-500 dark:text-slate-400 mb-3">
        {{ L.emptyState }}
      </div>

      <div class="space-y-2">
        <div *ngFor="let row of chain; let i = index" class="flex items-center gap-2">
          <span class="w-6 text-xs font-bold text-slate-500 dark:text-slate-400">{{ i + 1 }}.</span>
          <select
            [(ngModel)]="row.provider"
            (change)="onProviderChange(i)"
            class="flex-1 min-w-0 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-2.5 py-1.5 text-sm text-slate-900 dark:text-slate-100"
          >
            <option *ngFor="let p of availableProviders" [value]="p.value">{{ p.label }}</option>
          </select>
          <select
            [(ngModel)]="row.model"
            (change)="emit()"
            class="flex-1 min-w-0 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-2.5 py-1.5 text-sm text-slate-900 dark:text-slate-100"
          >
            <option *ngFor="let m of modelsFor(row.provider)" [value]="m.modelId">{{ m.displayName }}</option>
          </select>
          <button
            type="button"
            (click)="moveUp(i)"
            [disabled]="i === 0"
            [title]="L.moveUpTitle"
            class="w-7 h-7 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-500 hover:bg-slate-300 dark:hover:bg-slate-600 disabled:opacity-40 disabled:cursor-not-allowed transition"
          >↑</button>
          <button
            type="button"
            (click)="moveDown(i)"
            [disabled]="i === chain.length - 1"
            [title]="L.moveDownTitle"
            class="w-7 h-7 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-500 hover:bg-slate-300 dark:hover:bg-slate-600 disabled:opacity-40 disabled:cursor-not-allowed transition"
          >↓</button>
          <button
            type="button"
            (click)="removeRow(i)"
            *ngIf="chain.length > 1"
            [title]="L.removeRowTitle"
            class="w-7 h-7 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-500 hover:bg-red-500 hover:text-white transition"
          >×</button>
        </div>
      </div>

      <button
        type="button"
        (click)="addRow()"
        class="mt-3 px-3 py-1.5 text-xs font-bold rounded-lg border border-dashed border-slate-400 dark:border-slate-600 text-slate-600 dark:text-slate-300 hover:border-slate-950 dark:hover:border-slate-50 hover:text-slate-950 dark:hover:text-slate-50 transition"
      >+ {{ L.addRow }}</button>

      <div *ngIf="showChainPosition" class="flex items-center gap-3 mt-4 pt-3 border-t border-dashed border-slate-300 dark:border-slate-700">
        <span class="text-xs text-slate-500 dark:text-slate-400">{{ L.currentStep }}</span>
        <span class="flex-1 text-sm text-slate-700 dark:text-slate-200">{{ positionLabel() }}</span>
        <button
          type="button"
          *ngIf="(chainPosition ?? 0) > 0"
          (click)="promoteRequested.emit()"
          class="px-3 py-1.5 text-xs font-bold rounded-lg bg-slate-950 dark:bg-slate-50 text-slate-50 dark:text-slate-950 hover:opacity-90 transition"
        >{{ L.promote }}</button>
      </div>

      <p class="mt-3 text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
        {{ L.hint }}
      </p>
    </div>
  `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.NgSelectOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.ɵNgSelectMultipleOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.SelectControlValueAccessor, selector: "select:not([multiple])[formControlName],select:not([multiple])[formControl],select:not([multiple])[ngModel]", inputs: ["compareWith"] }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FailoverChainComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ki-failover-chain',
                    standalone: true,
                    imports: [CommonModule, FormsModule],
                    template: `
    <div>
      <p class="text-sm text-slate-600 dark:text-slate-300 mb-3">
        <strong class="font-semibold text-slate-900 dark:text-slate-100">{{ L.title }}</strong>
        — {{ L.description }}
      </p>

      <div *ngIf="chain.length === 0" class="text-sm italic text-slate-500 dark:text-slate-400 mb-3">
        {{ L.emptyState }}
      </div>

      <div class="space-y-2">
        <div *ngFor="let row of chain; let i = index" class="flex items-center gap-2">
          <span class="w-6 text-xs font-bold text-slate-500 dark:text-slate-400">{{ i + 1 }}.</span>
          <select
            [(ngModel)]="row.provider"
            (change)="onProviderChange(i)"
            class="flex-1 min-w-0 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-2.5 py-1.5 text-sm text-slate-900 dark:text-slate-100"
          >
            <option *ngFor="let p of availableProviders" [value]="p.value">{{ p.label }}</option>
          </select>
          <select
            [(ngModel)]="row.model"
            (change)="emit()"
            class="flex-1 min-w-0 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-2.5 py-1.5 text-sm text-slate-900 dark:text-slate-100"
          >
            <option *ngFor="let m of modelsFor(row.provider)" [value]="m.modelId">{{ m.displayName }}</option>
          </select>
          <button
            type="button"
            (click)="moveUp(i)"
            [disabled]="i === 0"
            [title]="L.moveUpTitle"
            class="w-7 h-7 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-500 hover:bg-slate-300 dark:hover:bg-slate-600 disabled:opacity-40 disabled:cursor-not-allowed transition"
          >↑</button>
          <button
            type="button"
            (click)="moveDown(i)"
            [disabled]="i === chain.length - 1"
            [title]="L.moveDownTitle"
            class="w-7 h-7 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-500 hover:bg-slate-300 dark:hover:bg-slate-600 disabled:opacity-40 disabled:cursor-not-allowed transition"
          >↓</button>
          <button
            type="button"
            (click)="removeRow(i)"
            *ngIf="chain.length > 1"
            [title]="L.removeRowTitle"
            class="w-7 h-7 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-500 hover:bg-red-500 hover:text-white transition"
          >×</button>
        </div>
      </div>

      <button
        type="button"
        (click)="addRow()"
        class="mt-3 px-3 py-1.5 text-xs font-bold rounded-lg border border-dashed border-slate-400 dark:border-slate-600 text-slate-600 dark:text-slate-300 hover:border-slate-950 dark:hover:border-slate-50 hover:text-slate-950 dark:hover:text-slate-50 transition"
      >+ {{ L.addRow }}</button>

      <div *ngIf="showChainPosition" class="flex items-center gap-3 mt-4 pt-3 border-t border-dashed border-slate-300 dark:border-slate-700">
        <span class="text-xs text-slate-500 dark:text-slate-400">{{ L.currentStep }}</span>
        <span class="flex-1 text-sm text-slate-700 dark:text-slate-200">{{ positionLabel() }}</span>
        <button
          type="button"
          *ngIf="(chainPosition ?? 0) > 0"
          (click)="promoteRequested.emit()"
          class="px-3 py-1.5 text-xs font-bold rounded-lg bg-slate-950 dark:bg-slate-50 text-slate-50 dark:text-slate-950 hover:opacity-90 transition"
        >{{ L.promote }}</button>
      </div>

      <p class="mt-3 text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
        {{ L.hint }}
      </p>
    </div>
  `,
                }]
        }], propDecorators: { chain: [{
                type: Input
            }], availableModels: [{
                type: Input
            }], availableProviders: [{
                type: Input
            }], chainPosition: [{
                type: Input
            }], showChainPosition: [{
                type: Input
            }], labels: [{
                type: Input
            }], chainChanged: [{
                type: Output
            }], promoteRequested: [{
                type: Output
            }] } });

/*
 * Public API Surface of @dataclub/ki-models-ui
 *
 * Konsumenten importieren Components + Service + InjectionToken hier von:
 *   import { ModelsTableComponent, KI_MODELS_API_BASE } from '@dataclub/ki-models-ui';
 *
 * Module-Wrapper (für nicht-standalone-Apps) wird in Phase L.2 hinzugefügt.
 */
// ─── Models / Interfaces ─────────────────────────────────────────────────

/**
 * Generated bundle index. Do not edit.
 */

export { ADD_MODEL_FORM_LABELS_EN, API_KEYS_SECTION_LABELS_EN, AddModelFormComponent, ApiKeysSectionComponent, CASCADE_COOLDOWN_LABELS_EN, CascadeCooldownComponent, FAILOVER_CHAIN_LABELS_EN, FailoverChainComponent, KI_MODELS_API_BASE, KiModelsApiService, MODELS_TABLE_LABELS_EN, ModelsTableComponent };
//# sourceMappingURL=4dataclub-ki-models-ui.mjs.map
