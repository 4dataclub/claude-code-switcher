/**
 * Label-Maps für i18n-Override.
 *
 * Konsumenten (EduPro mit i18n-Pipe, Switcher mit eigenen Strings) übergeben
 * via `<ki-… [labels]="myLabels">` ihre eigenen Strings. Library nutzt sensible
 * englische Defaults wenn nichts überschrieben wird.
 */
export interface ModelsTableLabels {
    refresh: string;
    loading: string;
    empty: string;
    colNum: string;
    colProvider: string;
    colModelId: string;
    colKey: string;
    colEnabled: string;
    colStatus: string;
    colCategory: string;
    colActions: string;
    keySet: string;
    keyMissing: string;
    /** v0.11.3 — Badge für Modelle die keinen API-Key brauchen (z.B. Ollama lokal). */
    keyless: string;
    on: string;
    off: string;
    autoDisabled: string;
    free: string;
    toggleNeedsKey: string;
    btnTest: string;
    btnReenable: string;
    btnDelete: string;
    /** „Als aktiv setzen" — nur sichtbar wenn `[showActiveAction]="true"`. */
    btnSetActive: string;
    /** Badge-Text für die Zeile des aktiven Modells. */
    activeBadge: string;
    /** Kategorie-Sektion-Überschriften (Phase R). */
    categoryUtility: string;
    categoryContent: string;
    categoryGeneral: string;
    /** Sub-Beschreibung pro Kategorie (kleine graue Zeile unter dem Header). */
    categoryUtilityHint: string;
    categoryContentHint: string;
    categoryGeneralHint: string;
    /** v0.15.0 — Spaltenkopf für den Inferenz-Server pro Modell. */
    colServer: string;
    /** v0.15.0 — Dropdown-Option/Anzeige für den Default-Server (localhost). */
    serverDefault: string;
    /** v0.15.0 — Badge wenn die Server-Hardware nicht reicht (hardwareCompatible=false). */
    hardwareBlocked: string;
    /** v0.15.0 — Toggle-Tooltip wenn das Aktivieren wegen Hardware gesperrt ist. */
    toggleHardwareBlocked: string;
    confirmDelete: (modelId: string) => string;
}
export declare const MODELS_TABLE_LABELS_EN: ModelsTableLabels;
export interface AddModelFormLabels {
    title: string;
    fieldModelId: string;
    fieldApiKeySettingKey: string;
    fieldDisplayName: string;
    fieldCategory: string;
    fieldCooldownOverride: string;
    /** v0.15.0 — Label für das Inferenz-Server-Dropdown (optional, Default localhost). */
    fieldProviderServer: string;
    /** v0.15.0 — Option „Default (localhost)" im Server-Dropdown. */
    providerServerDefault: string;
    btnAdd: string;
    btnAdding: string;
    hint: string;
    errorRequired: string;
    errorFailed: string;
    providerOptions: {
        value: string;
        label: string;
    }[];
    /**
     * Optionen im Kategorie-Dropdown der Add-Model-Form. Seit v0.10.0 generisch
     * (`value: string`), damit Konsumenten ihre eigenen Kategorien anbieten
     * können (z.B. Switcher: `cloud`/`free-only`, EduPro: `utility`/`content`/
     * `general`). Werte müssen dem Format `[a-z0-9_-]{1,50}` entsprechen
     * (siehe llm-cascade `ApiController.normalizeCategory`).
     */
    categoryOptions: {
        value: string;
        label: string;
    }[];
}
export declare const ADD_MODEL_FORM_LABELS_EN: AddModelFormLabels;
export interface CascadeCooldownLabels {
    title: string;
    subtitle: string;
    default: string;
    forceOn: string;
    forceOff: string;
    effectiveOn: string;
    effectiveOff: string;
    hint: string;
    loading: string;
    errorLoad: string;
}
export declare const CASCADE_COOLDOWN_LABELS_EN: CascadeCooldownLabels;
export interface ApiKeysSectionLabels {
    title: string;
    subtitle: string;
    fieldSettingKey: string;
    fieldValue: string;
    btnShow: string;
    btnHide: string;
    btnSave: string;
    btnSaving: string;
    listTitle: string;
    colSettingKey: string;
    colSource: string;
    colValue: string;
    colActions: string;
    sourceDb: string;
    sourceEnv: string;
    sourceMissing: string;
    btnEdit: string;
    btnClear: string;
    empty: string;
    hint: string;
    confirmClear: (settingKey: string) => string;
}
export declare const API_KEYS_SECTION_LABELS_EN: ApiKeysSectionLabels;
/**
 * Labels für `<ki-failover-chain>`. Konsument kann alle oder einzelne Strings
 * überschreiben — Defaults sind englisch.
 */
export interface CascadesViewLabels {
    /** "Lädt Cascade-Bereiche…" beim ersten Render. */
    loading: string;
    /** Hauptzeile wenn Backend leere Liste oder /cascades nicht kennt. */
    empty: string;
    /** Sekundärzeile wenn empty — Hinweis was zu tun ist. */
    emptyHint: string;
    /** Default-Hint pro Cascade-Karte wenn nicht via [hintByCascade] gesetzt. */
    defaultHint: string;
    /** "Cooldown-Status"-Sektion-Header. */
    cooldownTitle: string;
    /** Anzeige wenn cooldown=0. */
    statusFree: string;
    /** Anzeige wenn cooldown>0 — Präfix vor dem Sekunden-Wert. */
    statusCooldown: string;
    /** Tooltip/Hint für die klickbare Description (v0.10.0 Inline-Edit). */
    editHintTooltip: string;
    /** Placeholder im Textfeld wenn description leer ist (v0.10.0). */
    editHintPlaceholder: string;
    /** Speichern-Button-Label im Edit-Mode (v0.10.0). */
    editHintSave: string;
    /** Abbrechen-Button-Label im Edit-Mode (v0.10.0). */
    editHintCancel: string;
    /** Tooltip beim Trash-Icon das die category_meta löscht (v0.11.1). */
    deleteMetaTooltip: string;
    /** Confirm-Dialog-Text vor dem DELETE — bekommt den Anzeige-Titel der Cascade. */
    deleteMetaConfirm: (cascadeTitle: string) => string;
    /** Tooltip für die klickbare Title-Zeile (v0.11.2 displayName Inline-Edit). */
    editTitleTooltip: string;
    /** Placeholder im Title-Input wenn leer (v0.11.2). */
    editTitlePlaceholder: string;
}
export declare const CASCADES_VIEW_LABELS_EN: CascadesViewLabels;
export interface FailoverChainLabels {
    title: string;
    description: string;
    addRow: string;
    removeRowTitle: string;
    moveUpTitle: string;
    moveDownTitle: string;
    currentStep: string;
    positionLabel: (pos: number, provider: string, model: string) => string;
    promote: string;
    hint: string;
    emptyState: string;
}
export declare const FAILOVER_CHAIN_LABELS_EN: FailoverChainLabels;
/**
 * Labels für `<ki-routing-decisions>` (Phase v0.11.0). Konsumenten überschreiben
 * via [labels]-Input; Defaults sind englisch.
 */
export interface RoutingDecisionsLabels {
    title: string;
    subtitle: string;
    statSize: string;
    statHits: string;
    statMisses: string;
    statFailures: string;
    testLabel: string;
    testPlaceholder: string;
    btnTest: string;
    testing: string;
    entriesTitle: string;
    btnClearAll: string;
    btnClearOne: string;
    loading: string;
    empty: string;
    colPurpose: string;
    colCategory: string;
    colExpires: string;
    colActions: string;
    confirmClearAll: string;
}
export declare const ROUTING_DECISIONS_LABELS_EN: RoutingDecisionsLabels;
/**
 * v0.13.0 — Labels für `<ki-cascade-mode-panel>`. Bereich-Toggle + Auto-Mode
 * Info-Card, die jedem Konsument denselben UX bieten soll.
 */
export interface CascadeModePanelLabels {
    /** "Bereich" über dem Toggle */
    toggleLegend: string;
    /** Hint wenn kein Override aktiv ist */
    hintSemanticRouting: string;
    /** Hint wenn Override aktiv ist, `{cat}` wird durch das Category-Label ersetzt */
    hintOverrideTemplate: string;
    /** Info-Text wenn ein Bereich aktiv ist, `{cat}` wird ersetzt */
    autoCardActiveTemplate: string;
    /** Info-Text wenn kein Bereich aktiv (Semantic Routing) */
    autoCardSemanticHint: string;
    /** Label am Scroll-Button */
    btnScrollToCascade: string;
    /** v0.14.1: Label am „Auto/Off"-Tab links vor den Bereich-Buttons.
     *  Klick darauf setzt activeCategory='' (Semantic Routing aktiv). */
    offButtonLabel: string;
}
export declare const CASCADE_MODE_PANEL_LABELS_EN: CascadeModePanelLabels;
/**
 * v0.15.0 — Labels für `<ki-provider-servers>` (Verwaltung externer
 * Inferenz-Server). Konsument überschreibt via [labels]-Input; Defaults englisch.
 */
export interface ProviderServersLabels {
    title: string;
    subtitle: string;
    colName: string;
    colBaseUrl: string;
    colDefault: string;
    colActions: string;
    badgeDefault: string;
    btnAdd: string;
    btnEdit: string;
    btnDelete: string;
    btnSave: string;
    btnCancel: string;
    btnSetDefault: string;
    fieldName: string;
    fieldBaseUrl: string;
    fieldDescription: string;
    empty: string;
    loading: string;
    hint: string;
    errorNameFormat: string;
    errorBaseUrlRequired: string;
    errorDeleteDefault: string;
    confirmDelete: (name: string) => string;
}
export declare const PROVIDER_SERVERS_LABELS_EN: ProviderServersLabels;
/**
 * v0.18.0 — Labels für `<ki-call-overview>` (Erfolgs-Trend + Totals-Cards +
 * geschätzte Kosten). Konsument überschreibt via [labels]; Defaults englisch.
 */
export interface CallOverviewLabels {
    title: string;
    subtitle: string;
    trendTitle: string;
    /** Card-Labels für die Totals-Reihe. */
    card24h: string;
    card7d: string;
    card30d: string;
    cardSuccess30d: string;
    cardFailed30d: string;
    /** Kosten-Summary. */
    costTitle: string;
    costChars: string;
    costTokens: string;
    costMoney: string;
    loading: string;
    empty: string;
}
export declare const CALL_OVERVIEW_LABELS_EN: CallOverviewLabels;
/**
 * v0.18.0 — Labels für `<ki-failover-analytics>` (Failover-out/Provider-Donut
 * + Provider×Grund-Tabelle). Konsument überschreibt via [labels].
 */
export interface FailoverAnalyticsLabels {
    title: string;
    subtitle: string;
    donutTitle: string;
    donutCenter: string;
    tableTitle: string;
    colProvider: string;
    colReason: string;
    colCount: string;
    loading: string;
    empty: string;
    timelineTitle: string;
    timelineHint: string;
    colType: string;
    colTransition: string;
    colWhen: string;
    filterPlaceholder: string;
}
export declare const FAILOVER_ANALYTICS_LABELS_EN: FailoverAnalyticsLabels;
/**
 * v0.20.0 — Labels für {@link import('../components/mode-events.component').ModeEventsComponent}.
 * Eigene Liste der Modus-/Toggle-Umschaltungen (Modell-an/aus, Pool-Wechsel,
 * Supermodell an/aus).
 */
export interface ModeEventsLabels {
    title: string;
    subtitle: string;
    empty: string;
    loading: string;
    colType: string;
    colTransition: string;
    colReason: string;
    colWhen: string;
    filterPlaceholder: string;
}
export declare const MODE_EVENTS_LABELS_EN: ModeEventsLabels;
