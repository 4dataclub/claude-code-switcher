import * as i0 from "@angular/core";
/**
 * v0.18.0 — Dependency-freier Donut-Chart (reines SVG, portiert aus EduPro).
 * Animiertes Grow-in, Hover-Segmente, Center-Total, klickbare Legende mit
 * Anzahl + Prozent. Keine npm-Dependency, keine Tailwind-Klassen.
 *
 * Eingabe: `data` als `{key,label?,count,color?}[]`. Zeigt max. 8 Segmente.
 * Speist das Failover-out/Provider-Donut in `<ki-failover-analytics>`.
 */
export declare class KiDonutChartComponent {
    data: {
        key: string;
        label?: string;
        count: number;
        color?: string;
    }[];
    centerLabel: string;
    private readonly C;
    readonly glowId: string;
    get total(): number;
    get segments(): {
        key: string;
        label: string;
        count: number;
        pct: number;
        color: string;
        dash: string;
        offset: number;
    }[];
    static ɵfac: i0.ɵɵFactoryDeclaration<KiDonutChartComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<KiDonutChartComponent, "ki-donut-chart", never, { "data": { "alias": "data"; "required": false; }; "centerLabel": { "alias": "centerLabel"; "required": false; }; }, {}, never, never, true, never>;
}
