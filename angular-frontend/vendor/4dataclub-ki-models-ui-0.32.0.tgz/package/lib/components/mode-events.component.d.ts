import { OnDestroy, OnInit } from '@angular/core';
import { FailoverEvent } from '../models/stats-failover';
import { ModeEventsLabels } from '../models/labels';
import * as i0 from "@angular/core";
/**
 * v0.20.0 — Eigene Liste der Modus-/Toggle-Umschaltungen.
 *
 * Speist sich aus `/stats/failover` wie {@link import('./failover-analytics.component')},
 * zeigt aber NUR Host-/Toggle-Events:
 * `toggle_on` / `toggle_off` (Modell an/aus), `pool_switch` (Pool-Wechsel),
 * `supermodel_on` / `supermodel_off` (Supermodell-Achse).
 *
 * Gedacht für den „Modus"-Bereich im Switcher (neben dem Pool-/Supermodell-Panel),
 * damit man dort die letzten Schaltvorgänge mit Datum sieht. Header + absolute
 * Datumsangabe + Filter; Auto-Refresh damit Live-Toggles auftauchen.
 */
export declare class ModeEventsComponent implements OnInit, OnDestroy {
    private readonly api;
    /** Konsumenten-i18n-Override. Default = englische Labels. */
    L: ModeEventsLabels;
    set labels(v: Partial<ModeEventsLabels> | undefined);
    /** Auto-Refresh-Intervall in Sekunden. Default 10s. 0 deaktiviert. */
    autoRefreshSec: number;
    /** Event-Typen die als „Modus-/Toggle-Umschaltung" gelten. */
    private static readonly MODE_TYPES;
    readonly events: import("@angular/core").WritableSignal<FailoverEvent[]>;
    readonly loading: import("@angular/core").WritableSignal<boolean>;
    readonly filter: import("@angular/core").WritableSignal<string>;
    readonly modeEvents: import("@angular/core").Signal<FailoverEvent[]>;
    readonly filteredEvents: import("@angular/core").Signal<FailoverEvent[]>;
    private timer;
    ngOnInit(): void;
    ngOnDestroy(): void;
    setFilter(v: string): void;
    reload(): void;
    badgeClass(type: string): string;
    fmtWhen(iso: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ModeEventsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ModeEventsComponent, "ki-mode-events", never, { "labels": { "alias": "labels"; "required": false; }; "autoRefreshSec": { "alias": "autoRefreshSec"; "required": false; }; }, {}, never, never, true, never>;
}
