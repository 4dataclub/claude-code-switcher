import * as i0 from "@angular/core";
/**
 * v0.18.0 — Dependency-freier Area-Chart (reines SVG, portiert aus EduPro).
 * Smooth-Bézier-Linie, Gradient-Fill, Drop-Shadow, Hover-Punkte. Keine
 * npm-Dependency, keine Tailwind-Klassen (inline Styles).
 *
 * Eingabe: `series` als `{date,value}[]` (chronologisch). X-Labels zeigen
 * `MM-DD` (ISO-Datum ab Position 5). Speist den Erfolgs-Trend in
 * `<ki-call-overview>`.
 */
export declare class KiAreaChartComponent {
    series: {
        date: string;
        value: number;
    }[];
    color: string;
    width: number;
    height: number;
    padX: number;
    padY: number;
    readonly gradId: string;
    readonly shadowId: string;
    get maxValue(): number;
    get yTicks(): {
        y: number;
        value: number;
    }[];
    get points(): {
        x: number;
        y: number;
        value: number;
        label: string;
        shortLabel: string;
    }[];
    get labelStep(): number;
    get linePath(): string;
    get areaPath(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<KiAreaChartComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<KiAreaChartComponent, "ki-area-chart", never, { "series": { "alias": "series"; "required": false; }; "color": { "alias": "color"; "required": false; }; "width": { "alias": "width"; "required": false; }; "height": { "alias": "height"; "required": false; }; }, {}, never, never, true, never>;
}
