import { OnInit } from '@angular/core';
import { LogSnippetRow } from '../models/log-snippet';
import * as i0 from "@angular/core";
/**
 * v0.20.0 — Prompt-Log-Panel: zeigt die zuletzt geloggten Prompt-Snippets
 * (Zeitpunkt/Service/Modell/Provider/Kategorie/Snippet/Status) aus
 * `GET {base}/stats/log-snippets?limit=N`.
 *
 * Ehrlicher Hinweis: Snippets entstehen NUR, wenn das Setting
 * `logPromptSnippet` AN ist UND der Traffic durch die Cascade lief. Der
 * direkte cloud+Anthropic-Pfad umgeht die Cascade → dort wird nichts geloggt.
 *
 * Card/Section-Struktur analog `<ki-call-overview>` / `<ki-failover-analytics>`.
 * Graceful: leeres Array → erklärender Leer-Hinweis statt Crash.
 */
export declare class LogSnippetsComponent implements OnInit {
    private readonly api;
    /** Titel oben — überschreibbar pro Konsument. */
    title: string;
    subtitle: string;
    /** Wie viele Snippets geladen werden. Default 50. */
    limit: number;
    readonly rows: import("@angular/core").WritableSignal<LogSnippetRow[]>;
    readonly loading: import("@angular/core").WritableSignal<boolean>;
    ngOnInit(): void;
    reload(): void;
    fmtWhen(iso: string | null | undefined): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<LogSnippetsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LogSnippetsComponent, "ki-log-snippets", never, { "title": { "alias": "title"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "limit": { "alias": "limit"; "required": false; }; }, {}, never, never, true, never>;
}
