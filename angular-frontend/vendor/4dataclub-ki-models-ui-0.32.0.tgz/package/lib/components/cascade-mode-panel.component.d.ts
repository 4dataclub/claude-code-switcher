import { EventEmitter } from '@angular/core';
import { CascadeModePanelLabels } from '../models/labels';
import * as i0 from "@angular/core";
/**
 * v0.13.0 — Generisches Bereich-Toggle für Cascade-Kategorien.
 *
 * <h3>Was rendert die Component?</h3>
 * <ul>
 *   <li>Ein Toggle (`<button>`-Reihe) mit allen verfügbaren Cascade-Kategorien</li>
 *   <li>Einen kontextuellen Hint-Text (Semantic Routing aktiv vs Override aktiv)</li>
 *   <li>Eine Info-Card im Auto-Mode mit optionalem Scroll-Button zur Cascade-Bereich-
 *       Konfiguration weiter unten auf der Page</li>
 * </ul>
 *
 * <h3>Use-Case (Konsumenten)</h3>
 * <ul>
 *   <li><strong>Switcher</strong>: oben im sw-mode-panel als zweite Toggle-Zeile</li>
 *   <li><strong>EduPro</strong>: über der <code>&lt;ki-cascades-view&gt;</code>
 *       Card im Admin-Tab, damit der Admin das Semantic-Routing-Override toggeln kann</li>
 * </ul>
 *
 * <h3>Architektur-Hinweis</h3>
 * Die Component ist **pure presentational** — kein eigener API-Call. Der
 * Konsument fängt das `(categoryChanged)`-Event und persistiert via
 * {@code KiModelsApiService.setPreferredCategory()}. So bleibt die
 * Component testbar ohne HTTP-Mock und Konsumenten können
 * pre/post-Validierung machen (z.B. Bestätigungs-Dialog).
 *
 * <h3>Auto-Mode-Info-Card</h3>
 * Wenn die Component zusätzlich im Auto-Mode-Kontext gerendert wird (siehe
 * {@link autoMode}-Input), zeigt sie unter dem Toggle eine erklärende
 * Info-Card mit optionalem Scroll-Button zur Cascade-Konfiguration. Wer den
 * Bereich nur als Toggle (ohne Auto-Card) nutzen will, setzt {@link autoMode}
 * auf false (Default) — dann wird nur der Toggle gerendert.
 */
export declare class CascadeModePanelComponent {
    /**
     * Liste der verfügbaren Cascade-Kategorien (z.B. ['cloud', 'free-only']).
     * Leeres Array → die ganze Component rendert nichts.
     */
    categories: string[];
    /** Aktuell aktiver Bereich. Leer = Semantic Routing (kein Override). */
    activeCategory: string;
    /** Optionale Hint-Strings pro Kategorie (z.B. "Bezahlte Premium-Modelle"). */
    categoryHintMap: Record<string, string>;
    /** Optionale Display-Titel pro Kategorie (Vorrang vor `categoryHintMap`).
     *  Beispiel: {`cloud`: 'Cloud — Premium-Modelle'} */
    categoryTitles: Record<string, string>;
    /**
     * Wenn true: zeigt zusätzlich eine Info-Card mit Auto-Failover-Hinweis +
     * optionalem Scroll-Button. Konsument setzt das wenn der umgebende Kontext
     * im Auto-Mode ist (z.B. Switcher: `mode === 'auto'`).
     */
    autoMode: boolean;
    /** Wenn gesetzt: DOM-ID, zu dem der Scroll-Button springen soll
     *  (z.B. "cascade-bereiche-section"). Wenn leer: kein Button. */
    scrollTargetId: string;
    /** Konsumenten-i18n-Override. Default = englische Labels. */
    L: CascadeModePanelLabels;
    set labels(v: Partial<CascadeModePanelLabels> | undefined);
    /** User klickt einen Bereich-Tab → propagiert nach oben. Idempotent. */
    categoryChanged: EventEmitter<string>;
    setCategory(c: string): void;
    /**
     * Display-Label für eine Kategorie. Priorität:
     * 1. categoryTitles[c]
     * 2. categoryHintMap[c]
     * 3. Capitalized-Slug ("free-only" → "Free Only")
     */
    labelFor(c: string): string;
    /** Hint-Text rechts vom Toggle. */
    activeHintText(): string;
    /** Info-Card-Text wenn Bereich aktiv. */
    autoActiveText(): string;
    /**
     * Scroll zur konfigurierten DOM-ID. Nutzt smooth-scroll und block:'start'
     * damit der User die Card oben am Viewport sieht.
     */
    scrollToTarget(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CascadeModePanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CascadeModePanelComponent, "ki-cascade-mode-panel", never, { "categories": { "alias": "categories"; "required": false; }; "activeCategory": { "alias": "activeCategory"; "required": false; }; "categoryHintMap": { "alias": "categoryHintMap"; "required": false; }; "categoryTitles": { "alias": "categoryTitles"; "required": false; }; "autoMode": { "alias": "autoMode"; "required": false; }; "scrollTargetId": { "alias": "scrollTargetId"; "required": false; }; "labels": { "alias": "labels"; "required": false; }; }, { "categoryChanged": "categoryChanged"; }, never, never, true, never>;
}
