import { OnInit } from '@angular/core';
import { FailoverBreakdown, FailoverByProviderReason, FailoverEvents, FailoverEvent } from '../models/stats-failover';
import { FailoverAnalyticsLabels } from '../models/labels';
import { SortState } from './table-tools';
import * as i0 from "@angular/core";
/**
 * v0.18.0 — Geteiltes Failover-Analytics-Panel: Donut „Failover-out / Provider"
 * (welcher Provider wurde wie oft aus der Kaskade gedroppt) plus eine
 * paginierte, sortier-/filterbare Provider×Grund-Tabelle.
 *
 * v0.19.0 — Zusätzlich eine Failover-/Toggle-Events-Timeline (letzte 50 mit
 * Datumsangaben) aus `/stats/failover`. Toggle-Umschaltungen (an/aus) tauchen
 * hier als `toggle_on`/`toggle_off` auf.
 *
 * v0.26.0 — Events-Timeline paginiert (eigener Pager, `pageSize` wie die
 * Provider×Grund-Tabelle) statt alle 50 auf einmal.
 *
 * v0.27.0 — Events als echte `ki-table` (thead/tbody, sortier- + filterbar +
 * Pager) statt Timeline-Divs — einheitliches Tabellen-Design im ganzen Panel.
 *
 * Dependency-frei (reines SVG via `<ki-donut-chart>`), Pager nur ab `pageSize`.
 * Graceful: leere/fehlende Daten → Leer-Hinweis.
 */
export declare class FailoverAnalyticsComponent implements OnInit {
    private readonly api;
    /** Konsumenten-i18n-Override. Default = englische Labels. */
    L: FailoverAnalyticsLabels;
    set labels(v: Partial<FailoverAnalyticsLabels> | undefined);
    /** Seitengröße der Provider×Grund-Tabelle. Default 10. */
    pageSize: number;
    readonly breakdown: import("@angular/core").WritableSignal<FailoverBreakdown>;
    readonly events: import("@angular/core").WritableSignal<FailoverEvents>;
    readonly loading: import("@angular/core").WritableSignal<boolean>;
    readonly page: import("@angular/core").WritableSignal<number>;
    readonly matrixFilter: import("@angular/core").WritableSignal<string>;
    readonly matrixSort: import("@angular/core").WritableSignal<SortState>;
    readonly eventsFilter: import("@angular/core").WritableSignal<string>;
    readonly eventsSort: import("@angular/core").WritableSignal<SortState>;
    readonly eventsPage: import("@angular/core").WritableSignal<number>;
    readonly byProviderReason: import("@angular/core").Signal<FailoverByProviderReason[]>;
    readonly matrixRows: import("@angular/core").Signal<FailoverByProviderReason[]>;
    readonly donutData: import("@angular/core").Signal<{
        key: string;
        label: string;
        count: number;
    }[]>;
    readonly pageRows: import("@angular/core").Signal<FailoverByProviderReason[]>;
    readonly filteredEvents: import("@angular/core").Signal<FailoverEvent[]>;
    readonly eventsPageRows: import("@angular/core").Signal<FailoverEvent[]>;
    readonly isEmpty: import("@angular/core").Signal<boolean>;
    readonly allEmpty: import("@angular/core").Signal<boolean>;
    ngOnInit(): void;
    glyph(key: string): string;
    sortMatrix(key: string): void;
    setMatrixFilter(v: string): void;
    setEventsFilter(v: string): void;
    glyphE(key: string): string;
    sortEvents(key: string): void;
    badgeClass(type: string): string;
    fmtWhen(iso: string): string;
    reload(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FailoverAnalyticsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FailoverAnalyticsComponent, "ki-failover-analytics", never, { "labels": { "alias": "labels"; "required": false; }; "pageSize": { "alias": "pageSize"; "required": false; }; }, {}, never, never, true, never>;
}
