import { OnInit } from '@angular/core';
import { RoutingCache, RoutingCacheEntry, RoutingTestResult } from '../models/routing';
import { RoutingDecisionsLabels } from '../models/labels';
import * as i0 from "@angular/core";
/**
 * Admin-Component fuer Semantic Routing (Phase v0.11.0).
 *
 * Zeigt:
 *   - Counter-Stats (hits / misses / failures / cacheSize)
 *   - Liste aller Cache-Eintraege (purpose preview, gewaehlte Kategorie,
 *     Alter, Restlebenszeit) mit "X"-Button pro Eintrag
 *   - "Cache komplett leeren"-Button
 *   - Test-Preview-Input: tippe eine Task-Beschreibung, sieh welche Kategorie
 *     der Router waehlen wuerde (cached danach)
 *
 * Konsumenten-Setup: gleicher `KI_MODELS_API_BASE` wie die anderen Components.
 * Wenn das Backend < 0.6.0 ist (kein /routing-Endpoint), faellt es auf eine
 * leere Liste + Hinweistext zurueck statt Crash.
 */
export declare class RoutingDecisionsComponent implements OnInit {
    private readonly api;
    readonly cache: import("@angular/core").WritableSignal<RoutingCache | null>;
    readonly loading: import("@angular/core").WritableSignal<boolean>;
    readonly testing: import("@angular/core").WritableSignal<boolean>;
    readonly testResult: import("@angular/core").WritableSignal<RoutingTestResult | null>;
    testPurpose: string;
    /** v0.12.2: Wenn nicht-null, ist der Cascade-Override im Backend aktiv —
     *  Banner zeigt das. */
    readonly overrideCategory: import("@angular/core").WritableSignal<string | null>;
    /** Konsumenten-i18n-Override. Default = englische Labels. */
    L: RoutingDecisionsLabels;
    set labels(v: Partial<RoutingDecisionsLabels> | undefined);
    ngOnInit(): void;
    /**
     * v0.12.2: Override-Status laden (Bereich-Toggle aktiv?). Bei Backend
     * < 0.7.5 wird der Endpoint 404 zurückgeben → wir behandeln das wie
     * „kein Override aktiv" und der Banner bleibt versteckt.
     */
    private loadOverride;
    reload(): void;
    runTest(): void;
    clearAll(): void;
    clearOne(e: RoutingCacheEntry): void;
    /** Sekunden → "23h 45m" / "12m 30s" / "45s". */
    formatDuration(seconds: number): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<RoutingDecisionsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RoutingDecisionsComponent, "ki-routing-decisions", never, {}, {}, never, never, true, never>;
}
