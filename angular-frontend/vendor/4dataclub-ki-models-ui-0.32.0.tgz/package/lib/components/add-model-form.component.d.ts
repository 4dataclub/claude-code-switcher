import { EventEmitter } from '@angular/core';
import { AiModel } from '../models/ai-model';
import { ApiKeySetting } from '../models/api-key-setting';
import { Category } from '../models/category';
import { ProviderServer } from '../models/provider-server';
import { AddModelFormLabels } from '../models/labels';
import * as i0 from "@angular/core";
/**
 * Form um ein neues AI-Modell zur Cascade hinzuzufügen.
 *
 * **Felder:**
 * - Provider-Dropdown (gemini, openai, anthropic, openrouter, deepseek, openai_compat)
 * - Model-ID-Combobox mit Provider-spezifischen Vorschlägen (datalist)
 * - apiKeySettingKey-Auswahl (vorbelegt aus existierenden API-Keys + Default per Provider)
 * - DisplayName (optional)
 * - Cooldown503OverrideSec (optional)
 * - Add-Button
 *
 * **Event:** `(modelCreated)` emittet das neue Model nach erfolgreichem POST.
 *
 * **Provider-Default-Keys:** Beim Provider-Wechsel wird `apiKeySettingKey`
 * automatisch auf `<provider>ApiKey` umgestellt (Convenience).
 */
export declare class AddModelFormComponent {
    modelCreated: EventEmitter<AiModel>;
    set labels(v: Partial<AddModelFormLabels> | undefined);
    L: AddModelFormLabels;
    private readonly api;
    provider: string;
    modelId: string;
    apiKeySettingKey: string;
    displayName: string;
    /**
     * Aktuell gewählte Kategorie. Default `'content'` (Backward-Compat zu
     * EduPro-Setup). Konsumenten mit anderen Kategorie-Schemata setzen den
     * Default über `[defaultCategoryByProvider]` (siehe unten) oder ändern
     * `categoryOptions` in den Labels — die erste Option wird dann beim
     * Provider-Wechsel selektiert wenn kein Match passt.
     */
    category: string;
    cooldown503OverrideSec: number | null;
    /** v0.15.0 — gewählter Inferenz-Server (leer = Default „localhost"). */
    providerServerName: string;
    readonly submitting: import("@angular/core").WritableSignal<boolean>;
    readonly error: import("@angular/core").WritableSignal<string | null>;
    readonly keys: import("@angular/core").WritableSignal<ApiKeySetting[]>;
    /** v0.15.0 — benannte Server fürs Dropdown (leer wenn Backend < 0.8.0). */
    readonly providerServers: import("@angular/core").WritableSignal<ProviderServer[]>;
    /**
     * Kategorien aus dem Backend (v0.10.0 — `GET {base}/categories`). Wird im
     * `ngOnInit` befüllt; bei 404 (Backend ohne CategoryMeta-Endpoint) bleibt
     * das leer und das Dropdown fällt auf `L.categoryOptions` zurück
     * (Konsumenten-Labels — Backward-Compat zu EduPros utility/content/general).
     */
    readonly categoriesFromBackend: import("@angular/core").WritableSignal<Category[]>;
    private readonly defaultSettingKey;
    /**
     * Default-Kategorie pro Provider — heuristisch, weil typische Use-Cases klar
     * sind. User kann immer überschreiben.
     *   gemini       → content (Lehrmaterial, hochwertige Generierung)
     *   ollama       → utility (lokal, billig, gut für Übersetzungen)
     *   openrouter   → general (Mischbestand, oft Fallback)
     *   andere       → general
     */
    /**
     * Default-Kategorie pro Provider (Backward-Compat zum EduPro-Schema
     * `utility`/`content`/`general`). Konsumenten mit eigenem Schema
     * (z.B. Switcher mit `cloud`/`free-only`) überschreiben das via
     * `[defaultCategoryByProvider]`.
     */
    /**
     * Supermodell-Modus (Switcher-Konsument). Steuert das Kategorie-Dropdown:
     *
     *  - `true`  → nur Rollen-Areas (orchestrator/implement/review/research/dispatch)
     *              werden im Datalist angeboten. Der Router routet Rollen-Compounds
     *              (`{role}-{pool}`) nur bei expliziter Kategorie-Adressierung, daher
     *              gehört das UI-Anlegen im AN-Modus zu diesem Set.
     *  - `false` → nur AUS-Areas (alles ausser den 5 Rollen). Aktuell z.B.
     *              general/dev/utility/content plus die Pool-Fallback-Namen
     *              (cloud/free/local). Freie Areas kann der User weiterhin
     *              per Freitext-Eingabe anlegen.
     *  - `undefined` → kein Filter (EduPro-Verhalten, alle Kategorien sichtbar).
     */
    supermodelOn?: boolean;
    /** Areas die im supermodel=AN-Modus als AN-Compounds klassifiziert werden. */
    private readonly ROLE_AREAS;
    defaultCategoryByProvider: Record<string, string>;
    private readonly modelIdSuggestionsByProvider;
    ngOnInit(): void;
    onProviderChange(): void;
    modelIdSuggestions(): string[];
    /**
     * Normalisiert die Kategorie-Eingabe live während des Tippens
     * — lowercase, Trim, Whitespace → `-`. Erlaubte Zeichen sind
     * `[a-z0-9_-]{1,50}`; alles andere wird stillschweigend entfernt
     * (Backend würde sonst auf `general` zurückfallen). v0.10.2 — Folge
     * der Umstellung von `<select>` auf `<input list>` damit neue
     * Kategorien per Freitext angelegt werden können.
     */
    onCategoryInput(): void;
    /**
     * Optionen für das Kategorie-Dropdown. Reihenfolge:
     *   1. Backend-Kategorien (`/api/categories`) — wenn vorhanden, nutzt
     *      `displayName` falls gesetzt sonst Capitalized `name`.
     *   2. `L.categoryOptions` aus den Labels (Konsumenten-Default) — Fallback
     *      für Backend-Versionen ohne CategoryMeta-Endpoint.
     *
     * So bekommt jeder Konsument automatisch SEINE Kategorien (Switcher:
     * cloud/free-only/…, EduPro: utility/content/general) ohne dass die
     * Library oder der Konsument das hardcodieren muss.
     */
    categoryDropdownOptions(): {
        value: string;
        label: string;
    }[];
    /**
     * Filtert Kategorien nach {@link supermodelOn}. Ein Category-Name matcht als
     * Rollen-Compound wenn er entweder exakt einem Rollen-Namen entspricht
     * (`implement`) oder dem Muster `{role}-{suffix}` folgt (`implement-cloud`).
     */
    private applyModeFilter;
    private isRoleCategory;
    private prettifyCategory;
    /** Existierende Settings als Optionen + Default-Settings die noch nicht in DB sind. */
    keyOptions(): {
        settingKey: string;
        configured: boolean;
    }[];
    onSubmit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AddModelFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AddModelFormComponent, "ki-add-model-form", never, { "labels": { "alias": "labels"; "required": false; }; "supermodelOn": { "alias": "supermodelOn"; "required": false; }; "defaultCategoryByProvider": { "alias": "defaultCategoryByProvider"; "required": false; }; }, { "modelCreated": "modelCreated"; }, never, never, true, never>;
}
