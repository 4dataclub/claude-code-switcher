import { OnDestroy, OnInit } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * v0.17.0 — Datenschutz-Toggle für das „logPromptSnippet"-Setting.
 *
 * <h3>Was macht das?</h3>
 * Liest beim Mount `GET {base}/settings`, findet den Eintrag mit
 * `key === 'logPromptSnippet'` und zeigt einen Toggle. Ist das Setting
 * nicht vorhanden oder liefert das Backend einen Fehler (inkl. 404),
 * steht der Toggle auf AUS — Datenschutz als sicherer Default.
 *
 * <h3>Toggle-Aktion:</h3>
 * Beim Flippen ruft die Komponente `POST {base}/settings/logPromptSnippet`
 * mit `{ value: 'true' | 'false' }` auf. Bei Erfolg wird `enabled` auf
 * den neuen Wert gesetzt; bei Fehler bleibt der alte Wert erhalten und
 * ein kurzes Fehler-Feedback erscheint.
 *
 * <h3>Konsument-Use-Case:</h3>
 * - Switcher: in einem Datenschutz-Tab
 * - EduPro: in den Admin-Settings neben anderen App-Settings
 */
export declare class PrivacySettingsComponent implements OnInit, OnDestroy {
    private readonly api;
    /** Titel oben — überschreibbar pro Konsument. */
    title: string;
    subtitle: string;
    /** Eindeutige ID damit label[for] korrekt funktioniert, auch wenn die Component mehrfach gemountet wird. */
    readonly toggleId: string;
    readonly enabled: import("@angular/core").WritableSignal<boolean>;
    readonly loading: import("@angular/core").WritableSignal<boolean>;
    readonly saving: import("@angular/core").WritableSignal<boolean>;
    readonly savedMsg: import("@angular/core").WritableSignal<string | null>;
    readonly errorMsg: import("@angular/core").WritableSignal<string | null>;
    private savedTimer;
    private errorTimer;
    ngOnInit(): void;
    ngOnDestroy(): void;
    onToggle(event: Event): void;
    private clearMessages;
    static ɵfac: i0.ɵɵFactoryDeclaration<PrivacySettingsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PrivacySettingsComponent, "ki-privacy-settings", never, { "title": { "alias": "title"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; }, {}, never, never, true, never>;
}
