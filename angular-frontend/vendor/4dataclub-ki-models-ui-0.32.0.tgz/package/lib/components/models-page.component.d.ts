import { EventEmitter } from '@angular/core';
import { AiModel } from '../models/ai-model';
import { CascadesViewLabels, FailoverChainLabels, ModelsTableLabels, AddModelFormLabels, ApiKeysSectionLabels, ProviderServersLabels, CallOverviewLabels, FailoverAnalyticsLabels } from '../models/labels';
import { CascadesViewComponent } from './cascades-view.component';
import { ModelsTableComponent } from './models-table.component';
import { SupermodelMatrixComponent } from './supermodel-matrix.component';
import * as i0 from "@angular/core";
/**
 * Default-Provider-Optionen für die Failover-Chain-Dropdowns. Wird genutzt
 * wenn der Konsument `cascadeProviderOptions` nicht setzt — ein leerer Default
 * würde den Provider-Dropdown komplett leer rendern (`validProviders()` filtert
 * gegen eine leere Liste). `validProviders()` engt diese Liste ohnehin auf die
 * Provider ein, für die wirklich Modelle existieren, also ist die volle Liste
 * hier unbedenklich. Spiegelt den Default in {@link CascadesViewComponent}.
 */
export declare const DEFAULT_CASCADE_PROVIDER_OPTIONS: {
    value: string;
    label: string;
}[];
/** Optional config bundle — every field is optional; bare mount renders with defaults. */
export interface KiModelsPageConfig {
    cascadesViewLabels?: Partial<CascadesViewLabels>;
    cascadeChainLabels?: Partial<FailoverChainLabels>;
    cascadeHints?: Record<string, string>;
    cascadeProviderOptions?: {
        value: string;
        label: string;
    }[];
    modelsTableLabels?: Partial<ModelsTableLabels>;
    showActiveAction?: boolean;
    activeModelId?: string | null;
    categoryTitles?: Record<string, string>;
    categoryHints?: Record<string, string>;
    categoryOrder?: string[];
    keylessProviders?: string[];
    addModelFormLabels?: Partial<AddModelFormLabels>;
    defaultCategoryByProvider?: Record<string, string>;
    apiKeysSectionLabels?: Partial<ApiKeysSectionLabels>;
    providerServersLabels?: Partial<ProviderServersLabels>;
    qualityTitle?: string;
    qualitySubtitle?: string;
    performanceTitle?: string;
    performanceSubtitle?: string;
    costMapping?: Record<string, number> | null;
    costCurrency?: 'USD' | 'EUR';
    usdToEur?: number;
    cooldownTitle?: string;
    cooldownSubtitle?: string;
    cooldownAutoRefreshSec?: number;
    privacyTitle?: string;
    privacySubtitle?: string;
    delegationTitle?: string;
    delegationSubtitle?: string;
    delegationAutoRefreshSec?: number;
    delegationMaxRows?: number;
    callOverviewLabels?: Partial<CallOverviewLabels>;
    failoverAnalyticsLabels?: Partial<FailoverAnalyticsLabels>;
    analyticsPageSize?: number;
    analyticsCostPerMillionTokens?: number;
    logSnippetsTitle?: string;
    logSnippetsSubtitle?: string;
    logSnippetsLimit?: number;
}
/**
 * ki-models-page — Single-Source Composer
 *
 * Renders every section in canonical order. A bare
 * `<ki-models-page></ki-models-page>` works with EduPro defaults.
 *
 * Canonical order:
 * Supermodell: supermodel-matrix (nur sichtbar wenn supermodelOn — oben damit
 *              der User die aktive Rollen-Matrix direkt beim Öffnen sieht)
 * Verwaltung: cascades-view → models-table →
 *             add-model-form → api-keys-section → privacy-settings
 * Statistiken: provider-servers → models-quality-stats →
 *              models-performance → models-cooldown-state →
 *              call-overview → failover-analytics → log-snippets →
 *              delegation-live
 */
export declare class ModelsPageComponent {
    /** Optional config bundle — all fields optional, defaults apply. */
    config: KiModelsPageConfig;
    /** Template-Fallback für die Failover-Chain-Provider-Dropdowns. */
    readonly defaultProviderOptions: {
        value: string;
        label: string;
    }[];
    activePool?: string;
    supermodelOn: boolean;
    localOrchestratorPending: boolean;
    supermodelDisabled: boolean;
    supermodelDisabledHint?: string;
    supermodelPools?: string[];
    supermodelRoles?: string[];
    supermodelLabels?: any;
    /**
     * Optionale Whitelist sichtbarer Kategorien/Cascaden — wird an
     * `<ki-models-table>` (visibleCategories) und `<ki-cascades-view>`
     * (visibleCascades) weitergereicht. `null` (Default) = alle zeigen
     * (EduPro). Der Switcher berechnet die Liste aus Pool + Supermodell-Zustand:
     * AUS → nur Pool-Kategorie, AN → nur Rollen-Kategorien des aktiven Pools.
     */
    visibleCategories: string[] | null;
    /**
     * Wenn `true`, filtert `<ki-add-model-form>` seine Kategorie-Auswahl gemäß
     * {@link supermodelOn}: AN-Modus zeigt nur Rollen-Areas, AUS-Modus zeigt nur
     * die übrigen Areas. Default `false` behält das EduPro-Verhalten (kein Filter).
     * Der Switcher-Konsument setzt das auf `true`.
     */
    addModelFilterEnabled: boolean;
    modelChanged: EventEmitter<AiModel | null>;
    activeModelChanged: EventEmitter<AiModel>;
    modelCreated: EventEmitter<AiModel>;
    keyChanged: EventEmitter<string>;
    modelsTable?: ModelsTableComponent;
    cascadesView?: CascadesViewComponent;
    supermodelMatrix?: SupermodelMatrixComponent;
    onModelChanged(model: AiModel | null): void;
    onActiveModelChanged(model: AiModel): void;
    onModelCreated(model: AiModel): void;
    onKeyChanged(key: string): void;
    onCascadeChanged(): void;
    onServersChanged(): void;
    /** Public reload — host can call after pool/config changes. */
    reload(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ModelsPageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ModelsPageComponent, "ki-models-page", never, { "config": { "alias": "config"; "required": false; }; "activePool": { "alias": "activePool"; "required": false; }; "supermodelOn": { "alias": "supermodelOn"; "required": false; }; "localOrchestratorPending": { "alias": "localOrchestratorPending"; "required": false; }; "supermodelDisabled": { "alias": "supermodelDisabled"; "required": false; }; "supermodelDisabledHint": { "alias": "supermodelDisabledHint"; "required": false; }; "supermodelPools": { "alias": "supermodelPools"; "required": false; }; "supermodelRoles": { "alias": "supermodelRoles"; "required": false; }; "supermodelLabels": { "alias": "supermodelLabels"; "required": false; }; "visibleCategories": { "alias": "visibleCategories"; "required": false; }; "addModelFilterEnabled": { "alias": "addModelFilterEnabled"; "required": false; }; }, { "modelChanged": "modelChanged"; "activeModelChanged": "activeModelChanged"; "modelCreated": "modelCreated"; "keyChanged": "keyChanged"; }, never, never, true, never>;
}
