import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * v0.18.0 — Dependency-freier Pager für alle Tabellen, deren Einträge zu
 * lang werden. Rein presentational: nimmt `total`/`page`/`pageSize` und
 * emittiert `pageChange`. Sichtbar NUR wenn `total > pageSize` — bei kurzen
 * Tabellen rendert die Komponente nichts (kein DOM, kein Platzverbrauch).
 *
 * Seiten sind 0-basiert. Konsumenten halten die aktuelle Seite selbst und
 * slicen ihre Daten mit dem `paginate()`-Helper.
 */
export declare class KiPagerComponent {
    total: number;
    page: number;
    pageSize: number;
    pageChange: EventEmitter<number>;
    get lastPage(): number;
    get rangeStart(): number;
    get rangeEnd(): number;
    go(p: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<KiPagerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<KiPagerComponent, "ki-pager", never, { "total": { "alias": "total"; "required": false; }; "page": { "alias": "page"; "required": false; }; "pageSize": { "alias": "pageSize"; "required": false; }; }, { "pageChange": "pageChange"; }, never, never, true, never>;
}
/**
 * Slice-Helper passend zum {@link KiPagerComponent}. Schneidet die aktuelle
 * Seite aus einem Array. Klemmt die Seite defensiv, falls die Datenmenge
 * zwischen Renders schrumpft.
 */
export declare function paginate<T>(rows: T[], page: number, pageSize: number): T[];
