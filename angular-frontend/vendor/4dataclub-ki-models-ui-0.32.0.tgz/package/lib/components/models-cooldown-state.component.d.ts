import { OnDestroy, OnInit } from '@angular/core';
import { CooldownRow } from '../models/cooldown';
import { SortState } from './table-tools';
import * as i0 from "@angular/core";
/**
 * v0.14.0 — Cooldown + Auto-Disable State pro Modell.
 *
 * Zeigt:
 * - rote Zeile bei `autoDisabled=true` (System hat das Modell gekillt)
 * - gelbe Zeile bei `cooldownRemainingSec > 0` (Modell hat gerade Fehler, kommt zurück)
 * - grüne / neutrale Zeile für gesunde Modelle
 * - Live-Auto-Refresh alle 30s damit der Cooldown-Counter live runterläuft
 *
 * Konsumenten-Use-Case:
 * - EduPro: ersetzt die `/admin/stats/gemini`-Card im Operations-Tab
 * - Switcher: kann embedded werden für Cooldown-Visibilität
 */
export declare class ModelsCooldownStateComponent implements OnInit, OnDestroy {
    private readonly api;
    title: string;
    subtitle: string;
    /** Auto-Refresh-Intervall in Sekunden. Default 30s. 0 disabled. */
    autoRefreshSec: number;
    /** Seitengröße. Pager nur sichtbar wenn mehr Zeilen. Kein Page-Reset beim
     *  Auto-Refresh — paginate() klemmt defensiv. */
    pageSize: number;
    readonly rows: import("@angular/core").WritableSignal<CooldownRow[]>;
    readonly loading: import("@angular/core").WritableSignal<boolean>;
    readonly page: import("@angular/core").WritableSignal<number>;
    readonly filter: import("@angular/core").WritableSignal<string>;
    readonly sort: import("@angular/core").WritableSignal<SortState>;
    readonly viewRows: import("@angular/core").Signal<CooldownRow[]>;
    readonly pageRows: import("@angular/core").Signal<CooldownRow[]>;
    glyph(key: string): string;
    sortCol(key: string): void;
    setFilter(v: string): void;
    /** v0.15.0 — 1s-Tick, lässt den Cooldown-Zähler zwischen den Reloads sichtbar
     *  runterlaufen. `fetchedAt` = Zeitpunkt des letzten Backend-Werts. */
    readonly tick: import("@angular/core").WritableSignal<number>;
    private fetchedAt;
    private timer;
    private tickTimer;
    ngOnInit(): void;
    ngOnDestroy(): void;
    reload(): void;
    /**
     * v0.15.0 — Live-Restzeit: Backend-Wert minus seither vergangene Sekunden.
     * Liest {@link tick}, damit die Anzeige jede Sekunde neu berechnet wird.
     */
    liveRemaining(r: CooldownRow): number;
    statusIcon(r: CooldownRow): string;
    /**
     * Cooldown-Sekunden lesbar machen.
     * 0-90s: "Xs", 90s-90min: "Xm", 90min+: "Xh"
     */
    formatCooldown(sec: number): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ModelsCooldownStateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ModelsCooldownStateComponent, "ki-models-cooldown-state", never, { "title": { "alias": "title"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "autoRefreshSec": { "alias": "autoRefreshSec"; "required": false; }; "pageSize": { "alias": "pageSize"; "required": false; }; }, {}, never, never, true, never>;
}
