import { OnInit } from '@angular/core';
import { TrendPoint } from '../models/stats-trend';
import { StatsTotals } from '../models/stats-totals';
import { CallOverviewLabels } from '../models/labels';
import * as i0 from "@angular/core";
/**
 * v0.18.0 — Geteiltes Analytics-Panel: Erfolgs-Trend (30 Tage) als Area-Chart,
 * KI-Calls-Totals-Cards (24h/7d/30d/✓/✗) und eine geschätzte-Kosten-Summary.
 *
 * Speist sich aus den genuin geteilten Endpunkten `/stats/trend` und
 * `/stats/totals` (llm-cascade → Switcher-Proxy). Kosten werden client-seitig
 * aus `outputChars30d` geschätzt: Tokens ≈ chars/4, € = tokens × Rate.
 *
 * Dependency-frei (reines SVG via `<ki-area-chart>`), keine Tailwind-Klassen.
 * Graceful: fehlende/leere Daten → Leer-Hinweis statt Crash.
 */
export declare class CallOverviewComponent implements OnInit {
    private readonly api;
    /** Konsumenten-i18n-Override. Default = englische Labels. */
    L: CallOverviewLabels;
    set labels(v: Partial<CallOverviewLabels> | undefined);
    /** Tage für den Trend. Default 30. */
    trendDays: number;
    /** Geschätzte Kosten pro 1 Mio. Output-Tokens (in der Währung von `currency`). */
    costPerMillionTokens: number;
    currency: string;
    readonly trend: import("@angular/core").WritableSignal<TrendPoint[]>;
    readonly totals: import("@angular/core").WritableSignal<StatsTotals>;
    readonly loading: import("@angular/core").WritableSignal<boolean>;
    readonly trendSeries: import("@angular/core").Signal<{
        date: string;
        value: number;
    }[]>;
    readonly outputChars: import("@angular/core").Signal<number>;
    readonly estTokens: import("@angular/core").Signal<number>;
    readonly isEmpty: import("@angular/core").Signal<boolean>;
    ngOnInit(): void;
    reload(): void;
    estCostLabel(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<CallOverviewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CallOverviewComponent, "ki-call-overview", never, { "labels": { "alias": "labels"; "required": false; }; "trendDays": { "alias": "trendDays"; "required": false; }; "costPerMillionTokens": { "alias": "costPerMillionTokens"; "required": false; }; "currency": { "alias": "currency"; "required": false; }; }, {}, never, never, true, never>;
}
