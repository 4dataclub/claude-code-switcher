/**
 * v0.19.0 — Dependency-freie Sortier-/Filter-Helfer für die Stats-Tabellen.
 * Reine Funktionen, kein Angular — von mehreren Komponenten geteilt, damit
 * alle Tabellen identisch sortieren/filtern.
 */
export type SortDir = 'asc' | 'desc' | null;
export interface SortState {
    key: string | null;
    dir: SortDir;
}
/**
 * Klick auf eine Spalte: zyklus asc → desc → aus. Klick auf andere Spalte
 * startet wieder bei asc.
 */
export declare function nextSort(state: SortState, key: string): SortState;
/** Sortier-Glyph für den Spaltenkopf. */
export declare function sortGlyph(state: SortState, key: string): string;
/** Stabile Kopie sortiert nach `state.key`. `dir=null` → Originalreihenfolge. */
export declare function sortRows<T extends Record<string, any>>(rows: T[], state: SortState): T[];
/**
 * Case-insensitive Substring-Filter. Durchsucht `fields` (oder alle Werte
 * der Zeile, wenn nicht angegeben). Leerer Query → unverändert.
 */
export declare function filterRows<T extends Record<string, any>>(rows: T[], query: string, fields?: (keyof T)[]): T[];
