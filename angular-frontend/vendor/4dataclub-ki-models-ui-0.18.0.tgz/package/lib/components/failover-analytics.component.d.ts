import { OnInit } from '@angular/core';
import { FailoverBreakdown, FailoverByProviderReason } from '../models/stats-failover';
import { FailoverAnalyticsLabels } from '../models/labels';
import * as i0 from "@angular/core";
/**
 * v0.18.0 — Geteiltes Failover-Analytics-Panel: Donut „Failover-out / Provider"
 * (welcher Provider wurde wie oft aus der Kaskade gedroppt) plus eine
 * paginierte Provider×Grund-Tabelle.
 *
 * Speist sich aus `/stats/failover-breakdown` (llm-cascade → Switcher-Proxy).
 * Dependency-frei (reines SVG via `<ki-donut-chart>`), Pager nur ab `pageSize`.
 * Graceful: leere/fehlende Daten → Leer-Hinweis.
 */
export declare class FailoverAnalyticsComponent implements OnInit {
    private readonly api;
    /** Konsumenten-i18n-Override. Default = englische Labels. */
    L: FailoverAnalyticsLabels;
    set labels(v: Partial<FailoverAnalyticsLabels> | undefined);
    /** Seitengröße der Provider×Grund-Tabelle. Default 25. */
    pageSize: number;
    readonly breakdown: import("@angular/core").WritableSignal<FailoverBreakdown>;
    readonly loading: import("@angular/core").WritableSignal<boolean>;
    readonly page: import("@angular/core").WritableSignal<number>;
    readonly byProviderReason: import("@angular/core").Signal<FailoverByProviderReason[]>;
    readonly donutData: import("@angular/core").Signal<{
        key: string;
        label: string;
        count: number;
    }[]>;
    readonly pageRows: import("@angular/core").Signal<FailoverByProviderReason[]>;
    readonly isEmpty: import("@angular/core").Signal<boolean>;
    ngOnInit(): void;
    reload(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FailoverAnalyticsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FailoverAnalyticsComponent, "ki-failover-analytics", never, { "labels": { "alias": "labels"; "required": false; }; "pageSize": { "alias": "pageSize"; "required": false; }; }, {}, never, never, true, never>;
}
