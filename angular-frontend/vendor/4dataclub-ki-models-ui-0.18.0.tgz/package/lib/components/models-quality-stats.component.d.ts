import { OnInit } from '@angular/core';
import { QualityStatRow } from '../models/quality';
import * as i0 from "@angular/core";
/**
 * v0.7.1 / Library v0.12.0 — Quality-Bewertung pro Modell aus den letzten
 * 30 Tagen, sortiert worst-first (KILL-Kandidaten oben).
 *
 * <h3>Was zeigt das?</h3>
 * Eine simple Tabelle pro Modell mit:
 *  - Tier-Icon (★ top / ◐ ok / ▽ weak / ✗ kill)
 *  - Quality-Score (0.0 - 2.0+)
 *  - Success-Rate, Avg-Chars, Anzahl Calls
 *  - Rotes Highlighting für KILL-Kandidaten
 *
 * <h3>Wofür?</h3>
 * Admin sieht auf einen Blick welche Modelle nicht laufen. Statt durch
 * eine lange Liste zu scrollen ist das problematische ganz oben.
 *
 * <h3>Konsument-Use-Case:</h3>
 * - EduPro: in den Operations-Tab embedded, ersetzt die alte AI-Quality-Card
 * - Switcher: in Stats-Tab embedded
 */
export declare class ModelsQualityStatsComponent implements OnInit {
    private readonly api;
    /** Label oben — überschreibbar pro Konsument. */
    title: string;
    subtitle: string;
    sortBy: 'worst-first' | 'best-first' | 'calls-desc';
    /** Seitengröße der Tabelle. Pager nur sichtbar wenn mehr Zeilen. */
    pageSize: number;
    readonly rows: import("@angular/core").WritableSignal<QualityStatRow[]>;
    readonly loading: import("@angular/core").WritableSignal<boolean>;
    readonly page: import("@angular/core").WritableSignal<number>;
    readonly pageRows: import("@angular/core").Signal<QualityStatRow[]>;
    readonly running: import("@angular/core").WritableSignal<boolean>;
    readonly autoDisableEnabled: import("@angular/core").WritableSignal<boolean>;
    readonly autoDisableMinCalls: import("@angular/core").WritableSignal<number>;
    readonly lastResult: import("@angular/core").WritableSignal<{
        disabled: string[];
    } | null>;
    /** Hide result-banner nach 8s. Timer-Ref damit reload nicht zwei Timer parallel laufen lässt. */
    private resultTimer;
    ngOnInit(): void;
    /**
     * Holt einmal beim Mount die Auto-Disable-Config. Bei Backend &lt; 0.7.3
     * (kein Endpoint) bleibt {@link autoDisableEnabled} false → der Button
     * wird gar nicht erst sichtbar. Saubere Backward-Compat.
     */
    private loadAutoDisableConfig;
    reload(): void;
    /**
     * v0.12.1: triggert den Auto-Disable-Job im Backend, zeigt das Ergebnis
     * im Banner und lädt die Stats-Tabelle neu (damit die jetzt-disabled-
     * Modelle ihre neue {@code autoDisabled=true}-Markierung kriegen — die
     * Tabelle zeigt zwar nicht direkt das autoDisabled-Feld, aber das
     * UI-„DISABLE"-Badge basiert auf der frischen Server-Antwort).
     *
     * Bei Backend-Fehler (z.B. Endpoint nicht da): kurze rote Fallback-
     * Meldung „nicht verfügbar". Der Button bleibt nutzbar.
     */
    runAutoDisable(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ModelsQualityStatsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ModelsQualityStatsComponent, "ki-models-quality-stats", never, { "title": { "alias": "title"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "pageSize": { "alias": "pageSize"; "required": false; }; }, {}, never, never, true, never>;
}
