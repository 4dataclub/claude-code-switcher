import { OnDestroy, OnInit } from '@angular/core';
import { DelegationCall } from '../models/delegation-call';
import * as i0 from "@angular/core";
/**
 * v0.17.0 — Live-Browser-Watcher für Delegations-Calls.
 *
 * Zeigt die letzten `maxRows` Delegations-Calls in einer kompakten Tabelle.
 * - Zeit (toLocaleTimeString), ✓/✗-Status (grün/rot), Provider:Modell,
 *   [Service], Output-Chars, und — falls `logPromptSnippet` AN — der Snippet.
 * - Auto-Refresh alle `autoRefreshSec` Sekunden (Default 5s).
 * - Graceful 404/Fehler → leerer Zustand, kein Crash.
 *
 * Konsumenten-Use-Case:
 * - Switcher/EduPro: ersetzt den Bash-Watcher; einbettbar in Admin-Tabs.
 */
export declare class DelegationLiveComponent implements OnInit, OnDestroy {
    private readonly api;
    title: string;
    subtitle: string;
    /** Auto-Refresh-Intervall in Sekunden. Default 5s. 0 deaktiviert. */
    autoRefreshSec: number;
    /** Maximale Anzahl angezeigter Zeilen. */
    maxRows: number;
    /** Seitengröße. Pager nur sichtbar wenn mehr Zeilen geladen sind. */
    pageSize: number;
    readonly rows: import("@angular/core").WritableSignal<DelegationCall[]>;
    readonly loading: import("@angular/core").WritableSignal<boolean>;
    readonly error: import("@angular/core").WritableSignal<boolean>;
    readonly page: import("@angular/core").WritableSignal<number>;
    readonly pageRows: import("@angular/core").Signal<DelegationCall[]>;
    private timer;
    ngOnInit(): void;
    ngOnDestroy(): void;
    reload(): void;
    formatTime(calledAt: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<DelegationLiveComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DelegationLiveComponent, "ki-delegation-live", never, { "title": { "alias": "title"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "autoRefreshSec": { "alias": "autoRefreshSec"; "required": false; }; "maxRows": { "alias": "maxRows"; "required": false; }; "pageSize": { "alias": "pageSize"; "required": false; }; }, {}, never, never, true, never>;
}
