import { EventEmitter } from '@angular/core';
import { ProviderServer } from '../models/provider-server';
import { ProviderServersLabels } from '../models/labels';
import * as i0 from "@angular/core";
/**
 * v0.15.0 — Verwaltung benannter Inferenz-Server (llm-cascade ≥ 0.8.0).
 *
 * Lokale Modelle (Ollama) laufen normalerweise auf „localhost"; über benannte
 * Server kann ein Modell seine Inferenz an einen externen Rechner auslagern.
 * Diese Komponente listet die Server + erlaubt Add/Edit/Delete/Set-Default.
 * Das pro-Modell-Dropdown lebt in `<ki-models-table>` / `<ki-add-model-form>`.
 *
 * **Event:** `(serversChanged)` nach jeder Mutation — Konsument kann z.B. die
 * Models-Table neu laden lassen damit das Server-Dropdown aktuell ist.
 *
 * **Graceful degrade:** Backend < 0.8.0 liefert 404 auf `/provider-servers` →
 * leere Liste + dezenter Hinweis, kein Fehler.
 */
export declare class ProviderServersComponent {
    serversChanged: EventEmitter<void>;
    set labels(v: Partial<ProviderServersLabels> | undefined);
    L: ProviderServersLabels;
    private readonly api;
    /** Seitengröße der Server-Tabelle. Pager nur sichtbar wenn mehr Zeilen. */
    pageSize: number;
    readonly loading: import("@angular/core").WritableSignal<boolean>;
    readonly saving: import("@angular/core").WritableSignal<boolean>;
    readonly servers: import("@angular/core").WritableSignal<ProviderServer[]>;
    readonly error: import("@angular/core").WritableSignal<string | null>;
    readonly page: import("@angular/core").WritableSignal<number>;
    readonly pageServers: import("@angular/core").Signal<ProviderServer[]>;
    /** Name des aktuell editierten Servers; null = Add-Modus. */
    readonly editingName: import("@angular/core").WritableSignal<string | null>;
    formName: string;
    formBaseUrl: string;
    formDescription: string;
    private static readonly NAME_RE;
    ngOnInit(): void;
    reload(): void;
    startEdit(s: ProviderServer): void;
    cancelEdit(): void;
    save(): void;
    setDefault(s: ProviderServer): void;
    remove(s: ProviderServer): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProviderServersComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProviderServersComponent, "ki-provider-servers", never, { "labels": { "alias": "labels"; "required": false; }; "pageSize": { "alias": "pageSize"; "required": false; }; }, { "serversChanged": "serversChanged"; }, never, never, true, never>;
}
