import { EventEmitter } from '@angular/core';
import { AiModel } from '../models/ai-model';
import { CascadesViewLabels, FailoverChainLabels, ModelsTableLabels, AddModelFormLabels, ApiKeysSectionLabels, ProviderServersLabels, CallOverviewLabels, FailoverAnalyticsLabels } from '../models/labels';
import { CascadesViewComponent } from './cascades-view.component';
import { ModelsTableComponent } from './models-table.component';
import { SupermodelMatrixComponent } from './supermodel-matrix.component';
import * as i0 from "@angular/core";
/** Optional config bundle — every field is optional; bare mount renders with defaults. */
export interface KiModelsPageConfig {
    cascadesViewLabels?: Partial<CascadesViewLabels>;
    cascadeChainLabels?: Partial<FailoverChainLabels>;
    cascadeHints?: Record<string, string>;
    cascadeProviderOptions?: {
        value: string;
        label: string;
    }[];
    modelsTableLabels?: Partial<ModelsTableLabels>;
    showActiveAction?: boolean;
    activeModelId?: string | null;
    categoryTitles?: Record<string, string>;
    categoryHints?: Record<string, string>;
    categoryOrder?: string[];
    keylessProviders?: string[];
    addModelFormLabels?: Partial<AddModelFormLabels>;
    defaultCategoryByProvider?: Record<string, string>;
    apiKeysSectionLabels?: Partial<ApiKeysSectionLabels>;
    providerServersLabels?: Partial<ProviderServersLabels>;
    qualityTitle?: string;
    qualitySubtitle?: string;
    performanceTitle?: string;
    performanceSubtitle?: string;
    costMapping?: Record<string, number> | null;
    costCurrency?: 'USD' | 'EUR';
    usdToEur?: number;
    cooldownTitle?: string;
    cooldownSubtitle?: string;
    cooldownAutoRefreshSec?: number;
    privacyTitle?: string;
    privacySubtitle?: string;
    delegationTitle?: string;
    delegationSubtitle?: string;
    delegationAutoRefreshSec?: number;
    delegationMaxRows?: number;
    callOverviewLabels?: Partial<CallOverviewLabels>;
    failoverAnalyticsLabels?: Partial<FailoverAnalyticsLabels>;
    analyticsPageSize?: number;
    analyticsCostPerMillionTokens?: number;
}
/**
 * ki-models-page — Single-Source Composer
 *
 * Renders every section in canonical order. A bare
 * `<ki-models-page></ki-models-page>` works with EduPro defaults.
 *
 * Canonical order:
 * Verwaltung: cascades-view → models-table →
 *             add-model-form → api-keys-section → privacy-settings
 * Supermodell: supermodel-matrix
 * Statistiken: provider-servers → models-quality-stats →
 *              models-performance → models-cooldown-state →
 *              call-overview → failover-analytics → delegation-live
 */
export declare class ModelsPageComponent {
    /** Optional config bundle — all fields optional, defaults apply. */
    config: KiModelsPageConfig;
    activePool?: string;
    supermodelOn: boolean;
    localOrchestratorPending: boolean;
    supermodelDisabled: boolean;
    supermodelDisabledHint?: string;
    supermodelPools?: string[];
    supermodelRoles?: string[];
    supermodelLabels?: any;
    modelChanged: EventEmitter<AiModel | null>;
    activeModelChanged: EventEmitter<AiModel>;
    modelCreated: EventEmitter<AiModel>;
    keyChanged: EventEmitter<string>;
    modelsTable?: ModelsTableComponent;
    cascadesView?: CascadesViewComponent;
    supermodelMatrix?: SupermodelMatrixComponent;
    onModelChanged(model: AiModel | null): void;
    onActiveModelChanged(model: AiModel): void;
    onModelCreated(model: AiModel): void;
    onKeyChanged(key: string): void;
    onCascadeChanged(): void;
    onServersChanged(): void;
    /** Public reload — host can call after pool/config changes. */
    reload(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ModelsPageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ModelsPageComponent, "ki-models-page", never, { "config": { "alias": "config"; "required": false; }; "activePool": { "alias": "activePool"; "required": false; }; "supermodelOn": { "alias": "supermodelOn"; "required": false; }; "localOrchestratorPending": { "alias": "localOrchestratorPending"; "required": false; }; "supermodelDisabled": { "alias": "supermodelDisabled"; "required": false; }; "supermodelDisabledHint": { "alias": "supermodelDisabledHint"; "required": false; }; "supermodelPools": { "alias": "supermodelPools"; "required": false; }; "supermodelRoles": { "alias": "supermodelRoles"; "required": false; }; "supermodelLabels": { "alias": "supermodelLabels"; "required": false; }; }, { "modelChanged": "modelChanged"; "activeModelChanged": "activeModelChanged"; "modelCreated": "modelCreated"; "keyChanged": "keyChanged"; }, never, never, true, never>;
}
