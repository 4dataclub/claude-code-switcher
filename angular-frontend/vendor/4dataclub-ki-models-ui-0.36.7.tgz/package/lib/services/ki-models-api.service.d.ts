import { Observable } from 'rxjs';
import { AiModel, AiModelCreate, AiModelUpdate } from '../models/ai-model';
import { ApiKeySetting, ApiKeySettingUpdate } from '../models/api-key-setting';
import { CascadeConfig, CascadeConfigUpdate } from '../models/cascade-config';
import { Cascade } from '../models/cascade';
import { Category, CategoryUpdate } from '../models/category';
import { RoutingCache, RoutingTestResult } from '../models/routing';
import { QualityStatRow } from '../models/quality';
import { PerformanceRow } from '../models/performance';
import { CooldownRow } from '../models/cooldown';
import { ProviderServer, ProviderServerUpsert } from '../models/provider-server';
import { AppSetting } from '../models/app-setting';
import { DelegationCall } from '../models/delegation-call';
import { TrendPoint } from '../models/stats-trend';
import { StatsTotals } from '../models/stats-totals';
import { FailoverBreakdown, FailoverEvents } from '../models/stats-failover';
import { LogSnippetRow } from '../models/log-snippet';
import * as i0 from "@angular/core";
/**
 * Library-API-Service. Spricht alle KI-Modell-/API-Key-/Cascade-Endpoints
 * gegen die vom Konsumenten konfigurierte Base-URL (siehe `KI_MODELS_API_BASE`).
 *
 * **Vertrag:** Konsumentenseitige Endpoints müssen folgenden Pfaden entsprechen:
 *
 * ```
 * GET    {base}/ai-models                   → AiModel[]
 * POST   {base}/ai-models                   → AiModel
 * PUT    {base}/ai-models/{id}              → AiModel
 * DELETE {base}/ai-models/{id}              → { ok: true }
 * POST   {base}/ai-models/{id}/test         → { ok, latencyMs, error? }
 * POST   {base}/ai-models/reorder           → { ok: true }                body: { orderedIds }
 * POST   {base}/ai-models/{id}/toggle       → { id, ok, enabled }         body: { enabled }
 * GET    {base}/api-keys                    → ApiKeySetting[]
 * POST   {base}/api-keys/setting/{key}      → { ok: true }                body: { value }
 * GET    {base}/cascade-config              → CascadeConfig
 * PUT    {base}/cascade-config              → CascadeConfig
 * ```
 *
 * Backend-API-Drift zwischen EduPro und Switcher: jeder Konsument kann diesen
 * Service per Inheritance/Wrapper überschreiben oder via Subclass-Provider
 * austauschen, falls nötig.
 */
export declare class KiModelsApiService {
    private readonly http;
    private readonly base;
    listModels(): Observable<AiModel[]>;
    createModel(body: AiModelCreate): Observable<AiModel>;
    updateModel(id: number, body: AiModelUpdate): Observable<AiModel>;
    deleteModel(id: number): Observable<{
        ok: boolean;
    }>;
    /**
     * `skipped: true` zeigt an, dass das Konsument-Backend den Test bewusst
     * übersprungen hat (z.B. Switcher beim Anthropic-Modell ohne API-Key, weil
     * Max-OAuth den Live-Switch erlaubt aber kein API-Test möglich ist). Die
     * Tabelle deaktiviert das Modell in dem Fall NICHT auto.
     */
    testModel(id: number): Observable<{
        ok: boolean;
        latencyMs?: number;
        error?: string;
        skipped?: boolean;
    }>;
    reorderModels(orderedIds: number[]): Observable<{
        ok: boolean;
    }>;
    toggleModel(id: number, enabled: boolean): Observable<{
        id: number;
        ok: boolean;
        enabled: boolean;
    }>;
    /**
     * Listet alle API-Key-Settings.
     *
     * Akzeptiert zwei Backend-Response-Shapes:
     * - **Array** (`ApiKeySetting[]`) — was die Library als Vertrag definiert
     *   (Switcher liefert das direkt unter `/cascade-settings`).
     * - **Object mit `settings`-Map** — was EduPros bestehender Endpoint
     *   `/admin/api-keys` liefert (`{settings: {key: {keyMasked, keySource, …}}}`).
     *
     * Bei Object-Form werden die Entries in das Array-Format gemapped, damit
     * die Components homogen mit `ApiKeySetting`-Items arbeiten. Pro Konsument
     * brauchen wir so keinen eigenen Adapter — die Library normalisiert selbst.
     */
    listKeys(): Observable<ApiKeySetting[]>;
    setKey(settingKey: string, body: ApiKeySettingUpdate): Observable<{
        ok: boolean;
    }>;
    /**
     * Liefert alle Cascade-Bereiche der Konsumenten-DB.
     *
     * **Vertrag**: Backend exponiert `GET {base}/cascades` → `Cascade[]`.
     * Frontend (z.B. `<ki-cascades-view>`) rendert eine Karte pro Eintrag.
     *
     * Fallback: liefert das Backend `[]` zurueck oder ist Endpoint nicht
     * verfuegbar, gibt der Wrapper-Component einen leeren Zustand — der
     * Konsument kann optional die alten 3 Default-Categories als Fallback
     * rendern.
     */
    listCascades(): Observable<Cascade[]>;
    /** Detail einer einzelnen Cascade. Selten direkt gebraucht; meistens reicht {@link #listCascades}. */
    getCascade(name: string): Observable<Cascade>;
    /**
     * Liste aller Kategorien (Display-Metadaten). Backend vereint implizite
     * Kategorien aus `ai_model_config.category` mit persistierten
     * `category_meta`-Einträgen — Felder ohne gesetzte Metadaten kommen mit
     * `null` zurück. Wenn der Endpoint nicht existiert (Backward-Compat zu
     * llm-cascade < 0.5), liefert der Konsument `404`; das Frontend muss
     * dann selbst auf leeren Default zurückfallen.
     */
    listCategories(): Observable<Category[]>;
    /**
     * Upsert für die Display-Metadaten einer Kategorie. Wird vom Inline-Edit
     * der Cascades-View aufgerufen. Partial-Update: Felder die nicht im Body
     * stehen werden NICHT angefasst; `null` löscht das Feld explizit.
     */
    updateCategory(name: string, body: CategoryUpdate): Observable<{
        ok: boolean;
    }>;
    /**
     * Löscht NUR die Metadaten-Zeile — die Kategorie selbst lebt weiter,
     * solange ein Modell sie nutzt. Nach Delete bekommt sie wieder die
     * UI-Fallbacks (capitalized name, leerer Hint).
     */
    deleteCategoryMeta(name: string): Observable<{
        ok: boolean;
    }>;
    /**
     * Reset auf Werkseinstellungen: setzt die kanonischen Descriptions
     * (utility, content, …) auf die Default-Texte zurück. User-defined
     * Kategorien außerhalb der Default-Liste bleiben unangetastet.
     */
    resetCategoryDescriptions(): Observable<{
        ok: boolean;
        created: number;
        updated: number;
        unchanged: number;
        total: number;
    }>;
    getCascadeConfig(): Observable<CascadeConfig>;
    setCascadeConfig(body: CascadeConfigUpdate): Observable<CascadeConfig>;
    /**
     * Snapshot des Routing-Caches mit Counter-Stats. Wird vom
     * `<ki-routing-decisions>`-Component periodisch geladen damit der User
     * sieht welche purpose-Strings auf welche Kategorie geroutet wurden.
     */
    getRoutingCache(): Observable<RoutingCache>;
    /** Kompletter Cache leeren — User-Aktion im UI. */
    clearRoutingCache(): Observable<{
        ok: boolean;
    }>;
    /** Einzelnen Cache-Eintrag (per purposeHash) entfernen. */
    clearRoutingCacheEntry(purposeHash: string): Observable<{
        ok: boolean;
    }>;
    /**
     * Test-Modus: einen purpose probe-routen ohne den eigentlichen Generate-
     * Call durchzufuehren. Cached das Ergebnis trotzdem (sodass der naechste
     * echte Call den gleichen Pfad nimmt). Praktisch um zu sehen welche
     * Kategorie der Router fuer eine bestimmte Task-Beschreibung waehlen
     * wuerde, bevor man's live ausrollt.
     */
    testRouting(purpose: string): Observable<RoutingTestResult>;
    /**
     * Liefert Quality-Bewertung pro Modell aus den letzten 30 Tagen.
     * Default-Sortierung „worst-first": KILL-Kandidaten und schlechte Modelle
     * stehen oben, damit Admin Probleme sofort sieht.
     *
     * @param sortBy 'worst-first' (Default) | 'best-first' | 'calls-desc'
     */
    getQualityStats(sortBy?: 'worst-first' | 'best-first' | 'calls-desc'): Observable<QualityStatRow[]>;
    /**
     * Manueller Trigger für den Auto-Disable-Job. Statt 6h auf den
     * nächsten {@code @Scheduled}-Tick zu warten, kann der Admin das
     * Cleanup per Knopfdruck anstoßen.
     *
     * Server-Antwort listet auf:
     * - {@code checked}: wie viele Modelle insgesamt geprüft wurden
     * - {@code disabled}: Modelle die jetzt gerade auto-disabled wurden
     * - {@code skippedAlreadyDisabled}: schon vorher auto-disabled
     * - {@code skippedNotKill}: Tier ist nicht „kill"
     * - {@code skippedTooFewCalls}: unter dem min-calls Schwellwert
     *
     * Bei Backend &lt; 0.7.3 (Endpoint nicht vorhanden): die Component
     * fängt den 404 und zeigt eine kurze „Feature nicht verfügbar"-Meldung.
     */
    runQualityAutoDisable(): Observable<{
        checked: number;
        disabled: string[];
        skippedAlreadyDisabled: string[];
        skippedNotKill: string[];
        skippedTooFewCalls: string[];
    }>;
    /**
     * Status des Auto-Disable-Features — ob aktiv und mit welchen Schwellwerten.
     * Die UI nutzt das um zu entscheiden ob der „Jetzt Auto-Disable laufen
     * lassen"-Button überhaupt sichtbar gemacht wird (wenn deaktiviert ist's
     * verwirrend einen Button zu zeigen).
     */
    getQualityAutoDisableConfig(): Observable<{
        enabled: boolean;
        minCalls: number;
        note: string;
    }>;
    /**
     * Liest den aktuellen Cascade-Kategorie-Override. Wenn `active=true`,
     * geht jeder generate-Call ohne explizite category an die gesetzte
     * Kategorie statt durch den Semantic Router.
     *
     * Use-Case: Routing-Decisions-Component nutzt das um anzuzeigen wenn
     * der Cache irrelevant ist (Override aktiv = Cache wird umgangen).
     *
     * Bei Backend &lt; 0.7.5 (Endpoint nicht da): `{category: "", active: false}`
     * via graceful fallback.
     */
    getPreferredCategory(): Observable<{
        category: string;
        active: boolean;
        note?: string;
    }>;
    /**
     * v0.13.0 — Setzt den Cascade-Kategorie-Override. Empty-String setzt
     * zurück auf Semantic Routing.
     *
     * Wird vom `<ki-cascade-mode-panel>`-Embed im Konsument-Code
     * (Switcher/EduPro) im categoryChanged-Handler aufgerufen.
     */
    setPreferredCategory(category: string): Observable<{
        ok: boolean;
        category: string;
    }>;
    /**
     * Performance-Stats pro Modell aus den letzten 30 Tagen.
     * Wird vom Library-Component {@code <ki-models-performance>} aufgerufen.
     *
     * @param sortBy 'calls-desc' (Default) | 'success-desc' | 'chars-desc'
     */
    getPerformance(sortBy?: 'calls-desc' | 'success-desc' | 'chars-desc'): Observable<PerformanceRow[]>;
    /**
     * Cooldown + Auto-Disable State pro Modell. Wird vom Library-Component
     * {@code <ki-models-cooldown-state>} aufgerufen, typischerweise mit
     * Auto-Refresh alle 30s damit Cooldown-Timer live runterticken.
     */
    getCooldownState(): Observable<CooldownRow[]>;
    /**
     * Liste der benannten Inferenz-Server. Bei Backend < 0.8.0 (Endpoint nicht
     * vorhanden) liefert der Konsument 404 → die Component fängt das und zeigt
     * einen leeren Zustand (Feature degradiert sauber).
     */
    listProviderServers(): Observable<ProviderServer[]>;
    /** Upsert eines Servers (anlegen/ändern). Setzt {@code isDefault} ggf. exklusiv. */
    upsertProviderServer(name: string, body: ProviderServerUpsert): Observable<{
        ok: boolean;
    }>;
    /** Löscht einen Server. Der Default-Server kann nicht gelöscht werden (Backend 400). */
    deleteProviderServer(name: string): Observable<{
        ok: boolean;
    }>;
    getSettings(): Observable<AppSetting[]>;
    setSetting(key: string, value: string): Observable<{
        ok: boolean;
    }>;
    getDelegationCalls(): Observable<DelegationCall[]>;
    /**
     * Erfolgs-Trend pro Tag (Calls total/success/failed) der letzten `days`
     * Tage. Speist den Area-Chart in `<ki-call-overview>`. Bei Backend ohne
     * Endpoint liefert der Proxy ein leeres Array.
     */
    getStatsTrend(days?: number): Observable<TrendPoint[]>;
    /**
     * KI-Calls-Totals (24h/7d/30d + Erfolg/Fehlschlag + Output-Chars).
     * Speist die Übersichts-Cards + Kosten-Schätzung in `<ki-call-overview>`.
     */
    getStatsTotals(): Observable<StatsTotals>;
    /**
     * Failover-Aufschlüsselung (Provider/Grund, 30 Tage). Speist Donut +
     * Tabelle in `<ki-failover-analytics>`. Leer-Objekt-Felder werden auf
     * leere Arrays normalisiert.
     */
    getStatsFailoverBreakdown(): Observable<FailoverBreakdown>;
    /**
     * v0.19.0 — Failover-/Toggle-Events-Timeline (letzte 50 + total30d).
     * Speist die Timeline in `<ki-failover-analytics>`. Leer-Fallback.
     */
    getStatsFailover(): Observable<FailoverEvents>;
    /**
     * v0.20.0 — Geloggte Prompt-Snippets (absteigend nach `calledAt`). Speist die
     * Tabelle in `<ki-log-snippets>`. Existieren nur, wenn `logPromptSnippet` AN
     * ist UND der Traffic durch die Cascade lief. Leer-Fallback (`[]`) bei
     * fehlendem Endpoint/Fehler.
     */
    getLogSnippets(limit?: number): Observable<LogSnippetRow[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<KiModelsApiService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<KiModelsApiService>;
}
