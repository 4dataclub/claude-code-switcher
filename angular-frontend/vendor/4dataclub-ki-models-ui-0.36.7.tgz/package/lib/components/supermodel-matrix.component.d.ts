import { OnInit } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * v0.17.0 — Supermodell-Rollen-Matrix (Compound-Kategorie-Übersicht).
 *
 * <h3>Was zeigt das?</h3>
 * Eine Tabelle/Grid der Compound-Kategorien {role}-{pool}, jeweils mit den
 * zugeordneten Modellen in Failover-Reihenfolge. Portiert aus dem Switcher
 * (Rollen-im-Pool-Panel, app.component.ts) als wiederverwendbare Library-
 * Komponente.
 *
 * <h3>Sichtbarkeit:</h3>
 * Die Matrix ist nur sichtbar wenn `supermodelOn = true` (Host setzt
 * explizit). Default ist `false` — nacktes Mount zeigt nichts. Wenn
 * `disabled = true`: Panel ist sichtbar aber gedimmt + gesperrt.
 *
 * <h3>Konsument-Use-Case:</h3>
 * - Switcher: `[supermodelOn]="supermodel()"` — zeigt Matrix wenn Supermodell aktiv
 * - EduPro: `[disabled]="true"` — Panel sichtbar aber Feature noch nicht freigeschaltet
 */
export declare class SupermodelMatrixComponent implements OnInit {
    private readonly api;
    pools: string[];
    roles: string[];
    /**
     * If not provided, derived via getPreferredCategory().
     * Signal-backed damit `effectivePool` (computed) auf Pool-Wechsel reagiert —
     * ein plain @Input würde vom computed NICHT als Dependency erfasst und die
     * Überschrift bliebe stale bis zum nächsten manuellen Refresh.
     */
    private readonly _activePool;
    set activePool(v: string | undefined);
    get activePool(): string | undefined;
    /**
     * CRITICAL DEFAULT: false — panel renders NOTHING when false.
     * Host must explicitly pass supermodelOn=true to show the matrix.
     */
    supermodelOn: boolean;
    localOrchestratorPending: boolean;
    /**
     * When true: panel is visible but dimmed/locked (display-only).
     * EduPro mounts with disabled=true to preview the feature.
     */
    disabled: boolean;
    disabledHint: string;
    labels?: {
        roleMeta?: Record<string, {
            label: string;
            desc: string;
        }>;
        poolTitles?: Record<string, string>;
    };
    private readonly DEFAULT_POOL_TITLES;
    private readonly DEFAULT_ROLE_META;
    /** All models grouped by compound category key (role-pool). */
    readonly matrixModels: import("@angular/core").WritableSignal<Record<string, {
        provider: string;
        modelId: string;
        displayName: string;
        enabled: boolean;
    }[]>>;
    /** Derived pool when activePool input is absent. */
    private readonly derivedPool;
    /** Resolved pool: input takes priority, then derived, then first pool. */
    readonly effectivePool: import("@angular/core").Signal<string>;
    /** Merged roleMeta: defaults + optional label overrides. */
    readonly effectiveRoleMeta: import("@angular/core").Signal<Record<string, {
        label: string;
        desc: string;
    }>>;
    /** Merged poolTitles: defaults + optional label overrides. */
    readonly effectivePoolTitles: import("@angular/core").Signal<Record<string, string>>;
    /**
     * True when supermodelOn=true but NO model matches any role-pool compound
     * key (e.g. EduPro backend with only utility/content/general categories).
     * Renders a calm empty state instead of crashing.
     */
    readonly noMatrixData: import("@angular/core").Signal<boolean>;
    ngOnInit(): void;
    /**
     * Öffentlicher Refresh — vom Host (z. B. <ki-models-page>) nach Pool-Wechsel
     * aufgerufen. Das Backend filtert die Modell-Liste nach aktivem Pool, daher
     * muss die Matrix neu laden wenn sich der Pool ändert — sonst zeigt sie die
     * (leeren) Zellen des alten Pools.
     */
    reload(): void;
    /**
     * Load all models and group them by compound category (role-pool).
     * Includes disabled models — they appear greyed out in the matrix.
     * On error: graceful empty ({}).
     */
    private loadModels;
    /**
     * Derive active pool from getPreferredCategory() when activePool input is absent.
     * Parses compound key format "<role>-<pool>"; falls back to pools[0] on error
     * or if the category does not match the compound pattern.
     */
    private loadDerivedPool;
    /**
     * Returns models for the compound cell {role}-{effectivePool}.
     * Order preserved from API (orderIdx = failover chain order).
     */
    cellModels(role: string): {
        provider: string;
        modelId: string;
        displayName: string;
        enabled: boolean;
    }[];
    static ɵfac: i0.ɵɵFactoryDeclaration<SupermodelMatrixComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SupermodelMatrixComponent, "ki-supermodel-matrix", never, { "pools": { "alias": "pools"; "required": false; }; "roles": { "alias": "roles"; "required": false; }; "activePool": { "alias": "activePool"; "required": false; }; "supermodelOn": { "alias": "supermodelOn"; "required": false; }; "localOrchestratorPending": { "alias": "localOrchestratorPending"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "disabledHint": { "alias": "disabledHint"; "required": false; }; "labels": { "alias": "labels"; "required": false; }; }, {}, never, never, true, never>;
}
