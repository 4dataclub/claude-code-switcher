/*
 * Public API Surface of @dataclub/ki-models-ui
 *
 * Konsumenten importieren Components + Service + InjectionToken hier von:
 *   import { ModelsTableComponent, KI_MODELS_API_BASE } from '@dataclub/ki-models-ui';
 *
 * Module-Wrapper (für nicht-standalone-Apps) wird in Phase L.2 hinzugefügt.
 */
// ─── Models / Interfaces ─────────────────────────────────────────────────
export * from './lib/models/ai-model';
export * from './lib/models/api-key-setting';
export * from './lib/models/cascade-config';
export * from './lib/models/cascade';
export * from './lib/models/labels';
// ─── Service + InjectionToken ────────────────────────────────────────────
export * from './lib/services/ki-models-api.service';
export * from './lib/services/ki-models-api.token';
// ─── Components (standalone) ─────────────────────────────────────────────
export * from './lib/components/models-table.component';
export * from './lib/components/add-model-form.component';
export * from './lib/components/cascade-cooldown.component';
export * from './lib/components/api-keys-section.component';
export * from './lib/components/failover-chain.component';
export * from './lib/components/cascades-view.component';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljLWFwaS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3Byb2plY3RzL2tpLW1vZGVscy11aS9zcmMvcHVibGljLWFwaS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7OztHQU9HO0FBRUgsNEVBQTRFO0FBQzVFLGNBQWMsdUJBQXVCLENBQUM7QUFDdEMsY0FBYyw4QkFBOEIsQ0FBQztBQUM3QyxjQUFjLDZCQUE2QixDQUFDO0FBQzVDLGNBQWMsc0JBQXNCLENBQUM7QUFDckMsY0FBYyxxQkFBcUIsQ0FBQztBQUVwQyw0RUFBNEU7QUFDNUUsY0FBYyxzQ0FBc0MsQ0FBQztBQUNyRCxjQUFjLG9DQUFvQyxDQUFDO0FBRW5ELDRFQUE0RTtBQUM1RSxjQUFjLHlDQUF5QyxDQUFDO0FBQ3hELGNBQWMsMkNBQTJDLENBQUM7QUFDMUQsY0FBYyw2Q0FBNkMsQ0FBQztBQUM1RCxjQUFjLDZDQUE2QyxDQUFDO0FBQzVELGNBQWMsMkNBQTJDLENBQUM7QUFDMUQsY0FBYywwQ0FBMEMsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBQdWJsaWMgQVBJIFN1cmZhY2Ugb2YgQGRhdGFjbHViL2tpLW1vZGVscy11aVxuICpcbiAqIEtvbnN1bWVudGVuIGltcG9ydGllcmVuIENvbXBvbmVudHMgKyBTZXJ2aWNlICsgSW5qZWN0aW9uVG9rZW4gaGllciB2b246XG4gKiAgIGltcG9ydCB7IE1vZGVsc1RhYmxlQ29tcG9uZW50LCBLSV9NT0RFTFNfQVBJX0JBU0UgfSBmcm9tICdAZGF0YWNsdWIva2ktbW9kZWxzLXVpJztcbiAqXG4gKiBNb2R1bGUtV3JhcHBlciAoZsO8ciBuaWNodC1zdGFuZGFsb25lLUFwcHMpIHdpcmQgaW4gUGhhc2UgTC4yIGhpbnp1Z2Vmw7xndC5cbiAqL1xuXG4vLyDilIDilIDilIAgTW9kZWxzIC8gSW50ZXJmYWNlcyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmV4cG9ydCAqIGZyb20gJy4vbGliL21vZGVscy9haS1tb2RlbCc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9tb2RlbHMvYXBpLWtleS1zZXR0aW5nJztcbmV4cG9ydCAqIGZyb20gJy4vbGliL21vZGVscy9jYXNjYWRlLWNvbmZpZyc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9tb2RlbHMvY2FzY2FkZSc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9tb2RlbHMvbGFiZWxzJztcblxuLy8g4pSA4pSA4pSAIFNlcnZpY2UgKyBJbmplY3Rpb25Ub2tlbiDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmV4cG9ydCAqIGZyb20gJy4vbGliL3NlcnZpY2VzL2tpLW1vZGVscy1hcGkuc2VydmljZSc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9zZXJ2aWNlcy9raS1tb2RlbHMtYXBpLnRva2VuJztcblxuLy8g4pSA4pSA4pSAIENvbXBvbmVudHMgKHN0YW5kYWxvbmUpIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuZXhwb3J0ICogZnJvbSAnLi9saWIvY29tcG9uZW50cy9tb2RlbHMtdGFibGUuY29tcG9uZW50JztcbmV4cG9ydCAqIGZyb20gJy4vbGliL2NvbXBvbmVudHMvYWRkLW1vZGVsLWZvcm0uY29tcG9uZW50JztcbmV4cG9ydCAqIGZyb20gJy4vbGliL2NvbXBvbmVudHMvY2FzY2FkZS1jb29sZG93bi5jb21wb25lbnQnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvY29tcG9uZW50cy9hcGkta2V5cy1zZWN0aW9uLmNvbXBvbmVudCc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9jb21wb25lbnRzL2ZhaWxvdmVyLWNoYWluLmNvbXBvbmVudCc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9jb21wb25lbnRzL2Nhc2NhZGVzLXZpZXcuY29tcG9uZW50JztcbiJdfQ==