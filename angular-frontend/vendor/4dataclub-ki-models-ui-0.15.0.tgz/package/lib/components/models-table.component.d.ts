import { EventEmitter } from '@angular/core';
import { AiModel } from '../models/ai-model';
import { ProviderServer } from '../models/provider-server';
import { ModelsTableLabels } from '../models/labels';
import * as i0 from "@angular/core";
/**
 * Tabelle aller AI-Modelle in der Cascade-Reihenfolge.
 *
 * **Spalten:** #, Provider, Model-ID (+displayName), Key-Status, Enabled-Toggle,
 * Status (autoDisabled-Reason / Cooldown / Free), Actions (Up/Down, Test, Re-Enable,
 * Delete).
 *
 * **Events:**
 * - `(activeModelChanged)` — User klickt „Als aktiv setzen" (Switcher-Feature,
 *   wird in L.2/L.4 ergänzt wenn dem Component ein `[showActiveAction]="true"`
 *   Input mitgegeben wird). Aktuell nicht im Template (folgt L.2.1).
 * - `(modelChanged)` — emittet bei jeder mutating-Aktion (toggle/move/delete/
 *   test) damit der Konsument seine Modell-Liste neu laden kann.
 *
 * Labels sind englisch hardcoded — Konsument-spezifische Übersetzung folgt in
 * Phase L.3 via `@Input()`-Override-Pattern oder eigenem Translation-Service.
 */
export declare class ModelsTableComponent {
    activeModelChanged: EventEmitter<AiModel>;
    modelChanged: EventEmitter<AiModel | null>;
    /** Optionale Labels — Konsument gibt seine i18n-Strings rein. Default = englisch. */
    set labels(v: Partial<ModelsTableLabels> | undefined);
    L: ModelsTableLabels;
    /**
     * Aktiviert pro Modell-Zeile den „Als aktiv setzen"-Button (`btnSetActive`).
     * Default `false` — EduPro nutzt das nicht, Switcher schaltet's auf `true`.
     * Wenn das Modell bereits aktiv ist (siehe `activeModelId`), zeigt sich
     * stattdessen das AKTIV-Badge.
     */
    showActiveAction: boolean;
    /**
     * Aktive Modell-ID (`modelId`-Feld, nicht die DB-id). Wird mit jeder Zeile
     * verglichen um die AKTIV-Badge zu setzen. `null` = kein Modell aktiv.
     */
    activeModelId: string | null;
    /**
     * Anzeige-Titel pro Kategorie. Generisch seit v0.10.0 — Konsumenten reichen
     * eine Map aller Kategorien rein, die ihre Modelle nutzen. Fehlende
     * Einträge fallen auf `categoryUtility`/`categoryContent`/`categoryGeneral`
     * aus den Labels zurück (Backward-Compat zu v0.9.x), und für alles andere
     * auf den capitalized Kategorie-String selbst.
     *
     * Beispiele:
     *  - EduPro übergibt nichts → Defaults aus `MODELS_TABLE_LABELS_*` greifen.
     *  - Switcher übergibt `{ cloud: 'Cloud — Premium', 'free-only': 'Free Tier' }`.
     */
    categoryTitles: Record<string, string>;
    /** Sub-Beschreibung pro Kategorie. Selbe Fallback-Kette wie `categoryTitles`. */
    categoryHints: Record<string, string>;
    /**
     * Explizite Reihenfolge der Kategorie-Sektionen. Wenn leer (Default),
     * werden Kategorien in der Reihenfolge gezeigt, in der sie erstmals in
     * `models()` auftauchen — was wiederum der globalen `orderIdx`-Reihenfolge
     * folgt. Für deterministische UI: Konsument liefert seine Wunsch-Reihenfolge.
     */
    categoryOrder: string[];
    /**
     * v0.11.3 — Konsumenten-spezifische Liste von Provider-Namen die keinen
     * API-Key brauchen. Zusätzlich zu dem `keyless`-Flag aus dem Backend.
     *
     * Beispiele:
     *  - Switcher: `['anthropic']` — Claude via Max-OAuth (Cookie), kein
     *    sk-ant-Key nötig. Cascade-Backend ruft anthropic nicht direkt;
     *    Wrapper handled das.
     *  - EduPro: `[]` — alle Cloud-Provider brauchen ihren Key, weil EduPro-
     *    Backend selbst HTTP-Calls an api.anthropic.com etc. macht.
     *
     * Default `[]`. Ollama ist immer keyless (vom Backend markiert), egal
     * was hier steht.
     */
    keylessProviders: string[];
    private readonly api;
    readonly loading: import("@angular/core").WritableSignal<boolean>;
    readonly models: import("@angular/core").WritableSignal<AiModel[]>;
    readonly testResult: import("@angular/core").WritableSignal<Record<number, {
        ok?: boolean | undefined;
        latencyMs?: number | undefined;
        error?: string | undefined;
        pending?: boolean | undefined;
        skipped?: boolean | undefined;
    }>>;
    /** v0.15.0 — benannte Inferenz-Server für das pro-Modell-Dropdown. Leer wenn
     *  Backend < 0.8.0 (Endpoint 404) → Dropdown zeigt nur „Default". */
    readonly providerServers: import("@angular/core").WritableSignal<ProviderServer[]>;
    /**
     * Modelle gruppiert nach Kategorie. null/undefined/leer → `'general'`
     * (bleibt Default — passt zum llm-cascade-Backend, das ebenfalls auf
     * `general` fällt). Beliebige String-Kategorien werden akzeptiert.
     */
    readonly modelsByCategory: import("@angular/core").Signal<Record<string, AiModel[]>>;
    /**
     * Kategorien die mindestens 1 Modell enthalten. Reihenfolge:
     *   1. Explizit via `[categoryOrder]` — diese kommen zuerst (in der
     *      gegebenen Reihenfolge, sofern sie überhaupt Modelle enthalten).
     *   2. Alle restlichen Kategorien danach in der Reihenfolge ihres
     *      ersten Auftretens in `models()` (= globaler `orderIdx`).
     */
    readonly categoriesWithModels: import("@angular/core").Signal<string[]>;
    /**
     * Capitalize + Bindestrich/Underscore zu Leerzeichen — als letztes Fallback
     * für unbekannte Kategorien (z.B. `free-only` → `Free Only`, `cloud` → `Cloud`).
     * Damit sieht die UI auch ohne explizite `categoryTitles`-Map nicht roh aus.
     */
    private prettifyCategory;
    /**
     * Title-Lookup-Reihenfolge:
     *   1. Explizit via `[categoryTitles]`-Map (Konsumenten-Override)
     *   2. Backward-Compat zu v0.9.x: hardcoded utility/content/general aus Labels
     *   3. Capitalized Kategorie-String als Fallback
     */
    categoryTitle(c: string): string;
    /**
     * Hint-Lookup-Reihenfolge analog `categoryTitle`. Wenn kein Hint gefunden:
     * leerer String (UI zeigt dann nur den Title).
     */
    categoryHint(c: string): string;
    ngOnInit(): void;
    reload(): void;
    /** v0.15.0 — lädt die benannten Server fürs Server-Dropdown. Backend < 0.8.0
     *  liefert 404 → leere Liste, Dropdown zeigt nur „Default". */
    private loadProviderServers;
    /** v0.15.0 — Server-Auswahl nur für lokale/self-hosted Provider sinnvoll.
     *  Cloud-Provider haben feste Endpoints und ignorieren den Server. */
    supportsCustomServer(m: AiModel): boolean;
    /** v0.15.0 — weist einem Modell einen Inferenz-Server zu (leer = Default). */
    setServer(m: AiModel, name: string): void;
    /** Tooltip für den (ggf. deaktivierten) Enable-Toggle: Key-Grund vs. Hardware-Grund. */
    toggleDisabledReason(m: AiModel): string;
    toggle(m: AiModel): void;
    reEnable(m: AiModel): void;
    remove(m: AiModel): void;
    move(idx: number, dir: -1 | 1): void;
    /**
     * Move innerhalb einer Kategorie: tauscht zwei kategoriegleiche Modelle in der
     * globalen `orderIdx`-Liste. Cross-Kategorie-Swap nicht möglich (Buttons
     * sind am Ende der Kategorie disabled). Globale Reihenfolge bleibt stabil,
     * nur die zwei Positionen werden gewechselt.
     */
    moveInCategory(cat: string, idxInCat: number, dir: -1 | 1): void;
    test(m: AiModel): void;
    /**
     * „Als aktiv setzen"-Klick — emittet `activeModelChanged`. Der Konsument
     * (z.B. Switcher) entscheidet was passiert: typisch ist ein `/api/switch`
     * mit `{provider, modelId}` damit der Wrapper Claude Code mit dem neuen
     * Provider neu startet.
     */
    setActive(m: AiModel): void;
    /** True wenn die Zeile zum `activeModelId`-Input passt. */
    isActiveModel(m: AiModel): boolean;
    /**
     * v0.11.4 — true wenn das Modell als „keyless" zu rendern ist (blaues
     * "Lokal"-Badge statt "Key fehlt"/"Key set").
     *
     * Logik:
     *  1. Backend-keyless (`m.keyless===true`, z.B. Ollama lokal) → IMMER true
     *  2. Konsument-Override (`keylessProviders.includes(provider)`) + KEIN
     *     Key konfiguriert → true (Beispiel: Switcher-anthropic ohne sk-ant-Key,
     *     Wechsel läuft via Max-OAuth ohne API-Call)
     *  3. Konsument-Override + Key konfiguriert → FALSE — User hat einen Key
     *     gesetzt, also „Key set" anzeigen + Test geht (Switcher-anthropic mit
     *     sk-ant-Key → echter api.anthropic.com-Call funktioniert)
     *  4. Sonst → false (normaler Cloud-Provider mit/ohne Key)
     */
    isKeylessModel(m: AiModel): boolean;
    truncate(s: string, n: number): string;
    private setTest;
    static ɵfac: i0.ɵɵFactoryDeclaration<ModelsTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ModelsTableComponent, "ki-models-table", never, { "labels": { "alias": "labels"; "required": false; }; "showActiveAction": { "alias": "showActiveAction"; "required": false; }; "activeModelId": { "alias": "activeModelId"; "required": false; }; "categoryTitles": { "alias": "categoryTitles"; "required": false; }; "categoryHints": { "alias": "categoryHints"; "required": false; }; "categoryOrder": { "alias": "categoryOrder"; "required": false; }; "keylessProviders": { "alias": "keylessProviders"; "required": false; }; }, { "activeModelChanged": "activeModelChanged"; "modelChanged": "modelChanged"; }, never, never, true, never>;
}
