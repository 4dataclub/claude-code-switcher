/*
 * Public API Surface of @dataclub/ki-models-ui
 *
 * Konsumenten importieren Components + Service + InjectionToken hier von:
 *   import { ModelsTableComponent, KI_MODELS_API_BASE } from '@dataclub/ki-models-ui';
 *
 * Module-Wrapper (für nicht-standalone-Apps) wird in Phase L.2 hinzugefügt.
 */
// ─── Models / Interfaces ─────────────────────────────────────────────────
export * from './lib/models/ai-model';
export * from './lib/models/api-key-setting';
export * from './lib/models/cascade-config';
export * from './lib/models/cascade';
export * from './lib/models/category';
export * from './lib/models/routing';
export * from './lib/models/quality';
export * from './lib/models/performance';
export * from './lib/models/cooldown';
export * from './lib/models/provider-server';
export * from './lib/models/labels';
// ─── Service + InjectionToken ────────────────────────────────────────────
export * from './lib/services/ki-models-api.service';
export * from './lib/services/ki-models-api.token';
// ─── Components (standalone) ─────────────────────────────────────────────
export * from './lib/components/models-table.component';
export * from './lib/components/add-model-form.component';
export * from './lib/components/cascade-cooldown.component';
export * from './lib/components/api-keys-section.component';
export * from './lib/components/failover-chain.component';
export * from './lib/components/cascades-view.component';
export * from './lib/components/routing-decisions.component';
export * from './lib/components/models-quality-stats.component';
export * from './lib/components/cascade-mode-panel.component';
export * from './lib/components/models-performance.component';
export * from './lib/components/models-cooldown-state.component';
export * from './lib/components/provider-servers.component';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljLWFwaS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3Byb2plY3RzL2tpLW1vZGVscy11aS9zcmMvcHVibGljLWFwaS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7OztHQU9HO0FBRUgsNEVBQTRFO0FBQzVFLGNBQWMsdUJBQXVCLENBQUM7QUFDdEMsY0FBYyw4QkFBOEIsQ0FBQztBQUM3QyxjQUFjLDZCQUE2QixDQUFDO0FBQzVDLGNBQWMsc0JBQXNCLENBQUM7QUFDckMsY0FBYyx1QkFBdUIsQ0FBQztBQUN0QyxjQUFjLHNCQUFzQixDQUFDO0FBQ3JDLGNBQWMsc0JBQXNCLENBQUM7QUFDckMsY0FBYywwQkFBMEIsQ0FBQztBQUN6QyxjQUFjLHVCQUF1QixDQUFDO0FBQ3RDLGNBQWMsOEJBQThCLENBQUM7QUFDN0MsY0FBYyxxQkFBcUIsQ0FBQztBQUVwQyw0RUFBNEU7QUFDNUUsY0FBYyxzQ0FBc0MsQ0FBQztBQUNyRCxjQUFjLG9DQUFvQyxDQUFDO0FBRW5ELDRFQUE0RTtBQUM1RSxjQUFjLHlDQUF5QyxDQUFDO0FBQ3hELGNBQWMsMkNBQTJDLENBQUM7QUFDMUQsY0FBYyw2Q0FBNkMsQ0FBQztBQUM1RCxjQUFjLDZDQUE2QyxDQUFDO0FBQzVELGNBQWMsMkNBQTJDLENBQUM7QUFDMUQsY0FBYywwQ0FBMEMsQ0FBQztBQUN6RCxjQUFjLDhDQUE4QyxDQUFDO0FBQzdELGNBQWMsaURBQWlELENBQUM7QUFDaEUsY0FBYywrQ0FBK0MsQ0FBQztBQUM5RCxjQUFjLCtDQUErQyxDQUFDO0FBQzlELGNBQWMsa0RBQWtELENBQUM7QUFDakUsY0FBYyw2Q0FBNkMsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBQdWJsaWMgQVBJIFN1cmZhY2Ugb2YgQGRhdGFjbHViL2tpLW1vZGVscy11aVxuICpcbiAqIEtvbnN1bWVudGVuIGltcG9ydGllcmVuIENvbXBvbmVudHMgKyBTZXJ2aWNlICsgSW5qZWN0aW9uVG9rZW4gaGllciB2b246XG4gKiAgIGltcG9ydCB7IE1vZGVsc1RhYmxlQ29tcG9uZW50LCBLSV9NT0RFTFNfQVBJX0JBU0UgfSBmcm9tICdAZGF0YWNsdWIva2ktbW9kZWxzLXVpJztcbiAqXG4gKiBNb2R1bGUtV3JhcHBlciAoZsO8ciBuaWNodC1zdGFuZGFsb25lLUFwcHMpIHdpcmQgaW4gUGhhc2UgTC4yIGhpbnp1Z2Vmw7xndC5cbiAqL1xuXG4vLyDilIDilIDilIAgTW9kZWxzIC8gSW50ZXJmYWNlcyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmV4cG9ydCAqIGZyb20gJy4vbGliL21vZGVscy9haS1tb2RlbCc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9tb2RlbHMvYXBpLWtleS1zZXR0aW5nJztcbmV4cG9ydCAqIGZyb20gJy4vbGliL21vZGVscy9jYXNjYWRlLWNvbmZpZyc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9tb2RlbHMvY2FzY2FkZSc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9tb2RlbHMvY2F0ZWdvcnknO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvbW9kZWxzL3JvdXRpbmcnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvbW9kZWxzL3F1YWxpdHknO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvbW9kZWxzL3BlcmZvcm1hbmNlJztcbmV4cG9ydCAqIGZyb20gJy4vbGliL21vZGVscy9jb29sZG93bic7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9tb2RlbHMvcHJvdmlkZXItc2VydmVyJztcbmV4cG9ydCAqIGZyb20gJy4vbGliL21vZGVscy9sYWJlbHMnO1xuXG4vLyDilIDilIDilIAgU2VydmljZSArIEluamVjdGlvblRva2VuIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuZXhwb3J0ICogZnJvbSAnLi9saWIvc2VydmljZXMva2ktbW9kZWxzLWFwaS5zZXJ2aWNlJztcbmV4cG9ydCAqIGZyb20gJy4vbGliL3NlcnZpY2VzL2tpLW1vZGVscy1hcGkudG9rZW4nO1xuXG4vLyDilIDilIDilIAgQ29tcG9uZW50cyAoc3RhbmRhbG9uZSkg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5leHBvcnQgKiBmcm9tICcuL2xpYi9jb21wb25lbnRzL21vZGVscy10YWJsZS5jb21wb25lbnQnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvY29tcG9uZW50cy9hZGQtbW9kZWwtZm9ybS5jb21wb25lbnQnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvY29tcG9uZW50cy9jYXNjYWRlLWNvb2xkb3duLmNvbXBvbmVudCc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9jb21wb25lbnRzL2FwaS1rZXlzLXNlY3Rpb24uY29tcG9uZW50JztcbmV4cG9ydCAqIGZyb20gJy4vbGliL2NvbXBvbmVudHMvZmFpbG92ZXItY2hhaW4uY29tcG9uZW50JztcbmV4cG9ydCAqIGZyb20gJy4vbGliL2NvbXBvbmVudHMvY2FzY2FkZXMtdmlldy5jb21wb25lbnQnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvY29tcG9uZW50cy9yb3V0aW5nLWRlY2lzaW9ucy5jb21wb25lbnQnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvY29tcG9uZW50cy9tb2RlbHMtcXVhbGl0eS1zdGF0cy5jb21wb25lbnQnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvY29tcG9uZW50cy9jYXNjYWRlLW1vZGUtcGFuZWwuY29tcG9uZW50JztcbmV4cG9ydCAqIGZyb20gJy4vbGliL2NvbXBvbmVudHMvbW9kZWxzLXBlcmZvcm1hbmNlLmNvbXBvbmVudCc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9jb21wb25lbnRzL21vZGVscy1jb29sZG93bi1zdGF0ZS5jb21wb25lbnQnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvY29tcG9uZW50cy9wcm92aWRlci1zZXJ2ZXJzLmNvbXBvbmVudCc7XG4iXX0=