import { EventEmitter } from '@angular/core';
import { AiModel, AiModelCategory } from '../models/ai-model';
import { ApiKeySetting } from '../models/api-key-setting';
import { AddModelFormLabels } from '../models/labels';
import * as i0 from "@angular/core";
/**
 * Form um ein neues AI-Modell zur Cascade hinzuzufügen.
 *
 * **Felder:**
 * - Provider-Dropdown (gemini, openai, anthropic, openrouter, deepseek, openai_compat)
 * - Model-ID-Combobox mit Provider-spezifischen Vorschlägen (datalist)
 * - apiKeySettingKey-Auswahl (vorbelegt aus existierenden API-Keys + Default per Provider)
 * - DisplayName (optional)
 * - Cooldown503OverrideSec (optional)
 * - Add-Button
 *
 * **Event:** `(modelCreated)` emittet das neue Model nach erfolgreichem POST.
 *
 * **Provider-Default-Keys:** Beim Provider-Wechsel wird `apiKeySettingKey`
 * automatisch auf `<provider>ApiKey` umgestellt (Convenience).
 */
export declare class AddModelFormComponent {
    modelCreated: EventEmitter<AiModel>;
    set labels(v: Partial<AddModelFormLabels> | undefined);
    L: AddModelFormLabels;
    private readonly api;
    provider: string;
    modelId: string;
    apiKeySettingKey: string;
    displayName: string;
    /** Default content — neue Gemini-Modelle sind typischerweise Content. */
    category: AiModelCategory;
    cooldown503OverrideSec: number | null;
    readonly submitting: import("@angular/core").WritableSignal<boolean>;
    readonly error: import("@angular/core").WritableSignal<string | null>;
    readonly keys: import("@angular/core").WritableSignal<ApiKeySetting[]>;
    private readonly defaultSettingKey;
    /**
     * Default-Kategorie pro Provider — heuristisch, weil typische Use-Cases klar
     * sind. User kann immer überschreiben.
     *   gemini       → content (Lehrmaterial, hochwertige Generierung)
     *   ollama       → utility (lokal, billig, gut für Übersetzungen)
     *   openrouter   → general (Mischbestand, oft Fallback)
     *   andere       → general
     */
    private readonly defaultCategory;
    private readonly modelIdSuggestionsByProvider;
    ngOnInit(): void;
    onProviderChange(): void;
    modelIdSuggestions(): string[];
    /** Existierende Settings als Optionen + Default-Settings die noch nicht in DB sind. */
    keyOptions(): {
        settingKey: string;
        configured: boolean;
    }[];
    onSubmit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AddModelFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AddModelFormComponent, "ki-add-model-form", never, { "labels": { "alias": "labels"; "required": false; }; }, { "modelCreated": "modelCreated"; }, never, never, true, never>;
}
