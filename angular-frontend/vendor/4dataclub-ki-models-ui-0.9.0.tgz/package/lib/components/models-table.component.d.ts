import { EventEmitter } from '@angular/core';
import { AiModel, AiModelCategory } from '../models/ai-model';
import { ModelsTableLabels } from '../models/labels';
import * as i0 from "@angular/core";
/**
 * Tabelle aller AI-Modelle in der Cascade-Reihenfolge.
 *
 * **Spalten:** #, Provider, Model-ID (+displayName), Key-Status, Enabled-Toggle,
 * Status (autoDisabled-Reason / Cooldown / Free), Actions (Up/Down, Test, Re-Enable,
 * Delete).
 *
 * **Events:**
 * - `(activeModelChanged)` — User klickt „Als aktiv setzen" (Switcher-Feature,
 *   wird in L.2/L.4 ergänzt wenn dem Component ein `[showActiveAction]="true"`
 *   Input mitgegeben wird). Aktuell nicht im Template (folgt L.2.1).
 * - `(modelChanged)` — emittet bei jeder mutating-Aktion (toggle/move/delete/
 *   test) damit der Konsument seine Modell-Liste neu laden kann.
 *
 * Labels sind englisch hardcoded — Konsument-spezifische Übersetzung folgt in
 * Phase L.3 via `@Input()`-Override-Pattern oder eigenem Translation-Service.
 */
export declare class ModelsTableComponent {
    activeModelChanged: EventEmitter<AiModel>;
    modelChanged: EventEmitter<AiModel | null>;
    /** Optionale Labels — Konsument gibt seine i18n-Strings rein. Default = englisch. */
    set labels(v: Partial<ModelsTableLabels> | undefined);
    L: ModelsTableLabels;
    /**
     * Aktiviert pro Modell-Zeile den „Als aktiv setzen"-Button (`btnSetActive`).
     * Default `false` — EduPro nutzt das nicht, Switcher schaltet's auf `true`.
     * Wenn das Modell bereits aktiv ist (siehe `activeModelId`), zeigt sich
     * stattdessen das AKTIV-Badge.
     */
    showActiveAction: boolean;
    /**
     * Aktive Modell-ID (`modelId`-Feld, nicht die DB-id). Wird mit jeder Zeile
     * verglichen um die AKTIV-Badge zu setzen. `null` = kein Modell aktiv.
     */
    activeModelId: string | null;
    private readonly api;
    readonly loading: import("@angular/core").WritableSignal<boolean>;
    readonly models: import("@angular/core").WritableSignal<AiModel[]>;
    readonly testResult: import("@angular/core").WritableSignal<Record<number, {
        ok?: boolean | undefined;
        latencyMs?: number | undefined;
        error?: string | undefined;
        pending?: boolean | undefined;
        skipped?: boolean | undefined;
    }>>;
    /** Modelle gruppiert nach Kategorie. null/undefined → 'general'. */
    readonly modelsByCategory: import("@angular/core").Signal<Record<AiModelCategory, AiModel[]>>;
    /** Kategorien die mindestens 1 Modell enthalten — leere Sections werden ausgeblendet. */
    readonly categoriesWithModels: import("@angular/core").Signal<AiModelCategory[]>;
    categoryTitle(c: AiModelCategory): string;
    categoryHint(c: AiModelCategory): string;
    ngOnInit(): void;
    reload(): void;
    toggle(m: AiModel): void;
    reEnable(m: AiModel): void;
    remove(m: AiModel): void;
    move(idx: number, dir: -1 | 1): void;
    /**
     * Move innerhalb einer Kategorie: tauscht zwei kategoriegleiche Modelle in der
     * globalen `orderIdx`-Liste. Cross-Kategorie-Swap nicht möglich (Buttons
     * sind am Ende der Kategorie disabled). Globale Reihenfolge bleibt stabil,
     * nur die zwei Positionen werden gewechselt.
     */
    moveInCategory(cat: AiModelCategory, idxInCat: number, dir: -1 | 1): void;
    test(m: AiModel): void;
    /**
     * „Als aktiv setzen"-Klick — emittet `activeModelChanged`. Der Konsument
     * (z.B. Switcher) entscheidet was passiert: typisch ist ein `/api/switch`
     * mit `{provider, modelId}` damit der Wrapper Claude Code mit dem neuen
     * Provider neu startet.
     */
    setActive(m: AiModel): void;
    /** True wenn die Zeile zum `activeModelId`-Input passt. */
    isActiveModel(m: AiModel): boolean;
    truncate(s: string, n: number): string;
    private setTest;
    static ɵfac: i0.ɵɵFactoryDeclaration<ModelsTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ModelsTableComponent, "ki-models-table", never, { "labels": { "alias": "labels"; "required": false; }; "showActiveAction": { "alias": "showActiveAction"; "required": false; }; "activeModelId": { "alias": "activeModelId"; "required": false; }; }, { "activeModelChanged": "activeModelChanged"; "modelChanged": "modelChanged"; }, never, never, true, never>;
}
