import { EventEmitter, OnInit } from '@angular/core';
import { AiModel } from '../models/ai-model';
import { Cascade } from '../models/cascade';
import { ChainEntry } from '../models/cascade-config';
import { CascadesViewLabels, FailoverChainLabels } from '../models/labels';
import * as i0 from "@angular/core";
/**
 * Phase S' (2026-05-21) — Wrapper-Komponente die N Cascade-Bereiche als
 * eigenständige Karten rendert. Jeder Bereich hat seine eigene
 * Failover-Chain + Cooldown-Anzeige.
 *
 * **Vertrag:** Backend liefert per {@code GET /cascades} eine Liste der
 * Cascade-Namen mit Stats. Pro Name filtert dieser Wrapper die Modelle aus
 * {@code /ai-models} nach {@code category=name} (plus {@code "general"} als
 * Fallback wenn der Name nicht selbst "general" ist) und übergibt die
 * Subset-Liste der "dummen" `<ki-failover-chain>`.
 *
 * **Reorder-Verhalten:** Wenn der Admin Up/Down innerhalb einer Cascade
 * drückt, mappt der Wrapper das in eine globale `reorderModels()`-Anfrage:
 * er nimmt die aktuelle Globale Liste, swappt nur die beiden Modelle der
 * jeweiligen Cascade, übermittelt die neue globale Reihenfolge.
 *
 * **Backward-Compat:** Wenn das Backend `/cascades` nicht kennt oder `[]`
 * liefert, zeigt die Komponente einen leeren Zustand mit Hinweis-Text
 * (Konsument kann dann auf alte 3-Categories-Tabellen fallback).
 */
export declare class CascadesViewComponent implements OnInit {
    set labels(v: Partial<CascadesViewLabels> | undefined);
    L: CascadesViewLabels;
    chainLabels?: Partial<FailoverChainLabels>;
    /**
     * Optional: Pro Cascade-Name eine Sub-Hint (z.B. „Lehrinhalte, Prüfungen, Chat").
     * Wenn nicht gesetzt, wird der Default-Hint aus `L.defaultHint` genommen.
     */
    hintByCascade: Record<string, string>;
    /** Provider-Optionen für das Dropdown im Failover-Editor. */
    providerOptions: {
        value: string;
        label: string;
    }[];
    /** Wird emittet wenn der Admin in einer der Cascades reordert oder Modelle tauscht. */
    cascadeChanged: EventEmitter<{
        cascadeName: string;
        chain: ChainEntry[];
    }>;
    private readonly api;
    readonly loading: import("@angular/core").WritableSignal<boolean>;
    readonly cascades: import("@angular/core").WritableSignal<Cascade[]>;
    readonly allModels: import("@angular/core").WritableSignal<AiModel[]>;
    ngOnInit(): void;
    reload(): void;
    /**
     * Modelle die zu dieser Cascade gehören.
     * Konvention: `category=cascadeName` ODER `category=general` (wenn die
     * Cascade selbst nicht „general" heißt → general wird als Fallback gezeigt).
     */
    modelsFor(cascadeName: string): AiModel[];
    /** Wandelt die gefilterte Modell-Liste in ChainEntry[] für die Failover-Chain. */
    chainFor(cascadeName: string): ChainEntry[];
    /**
     * Für `availableModels`-Input der Failover-Chain — strikter Typ ohne
     * nullable. Wir liefern alle enabled+nicht-disabled-Modelle (nicht nur
     * cascade-spezifische), damit der Admin im Dropdown auch Modelle aus
     * anderen Cascades wählen kann (z.B. um ein gemini auch in utility zu
     * hängen).
     */
    availableModelsFor(_cascadeName: string): {
        provider: string;
        modelId: string;
        displayName: string;
    }[];
    hintFor(cascadeName: string): string;
    hasCooldown(c: Cascade): boolean;
    cooldownEntries(c: Cascade): {
        key: string;
        sec: number;
    }[];
    /**
     * Cascade-scoped Reorder: nimmt die neue Cascade-spezifische Chain vom
     * Failover-Editor und übersetzt das in eine globale `reorderModels()`-
     * Anfrage. Die globale Liste wird so umsortiert, dass die Position der
     * cascade-eigenen Modelle der neuen Reihenfolge entspricht; alle anderen
     * Modelle bleiben in ihrer relativen Position.
     */
    onChainChanged(cascadeName: string, newChain: ChainEntry[]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CascadesViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CascadesViewComponent, "ki-cascades-view", never, { "labels": { "alias": "labels"; "required": false; }; "chainLabels": { "alias": "chainLabels"; "required": false; }; "hintByCascade": { "alias": "hintByCascade"; "required": false; }; "providerOptions": { "alias": "providerOptions"; "required": false; }; }, { "cascadeChanged": "cascadeChanged"; }, never, never, true, never>;
}
