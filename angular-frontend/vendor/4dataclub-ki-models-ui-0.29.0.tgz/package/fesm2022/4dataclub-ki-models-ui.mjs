import * as i0 from '@angular/core';
import { InjectionToken, inject, Injectable, EventEmitter, Output, Input, Component, signal, computed, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, firstValueFrom, forkJoin } from 'rxjs';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i2 from '@angular/forms';
import { FormsModule } from '@angular/forms';

/**
 * Well-known Kategorien-IDs als Convenience-Konstanten — KEIN Enum.
 * Konsumenten dürfen jeden String nutzen, der dem Identifier-Format genügt.
 * Diese Liste wird intern nur noch als Default-Order verwendet, falls der
 * Konsument keinen `[categoryOrder]`-Input liefert UND Modelle exakt diese
 * Kategorien haben (rückwärtskompatibel zu v0.9.x EduPro-Setup).
 */
const AI_MODEL_CATEGORIES_DEFAULT_ORDER = ['utility', 'content', 'general'];
/** @deprecated Seit v0.10.0 — siehe {@link AI_MODEL_CATEGORIES_DEFAULT_ORDER}. */
const AI_MODEL_CATEGORIES = AI_MODEL_CATEGORIES_DEFAULT_ORDER;

/**
 * Semantic-Routing-Modelle (Phase v0.11.0 — passend zu llm-cascade ≥ 0.6.0).
 *
 * Konzept: Caller schickt einen freien Task-Beschreibungs-String (`purpose`)
 * mit `POST /generate` statt einer hardcoded `category`. llm-cascade laesst
 * einen Mini-LLM-Call entscheiden welche der in `category_meta` gepflegten
 * Kategorien am besten passt. Ergebnis wird gecached (in-mem LRU, 24h TTL).
 *
 * Das Admin-UI nutzt diese Endpoints zur Cache-Inspection + manueller
 * Steuerung + Test-Preview (purpose-String eintippen, sehen welche Kategorie
 * gewaehlt wird, ohne den eigentlichen Generate-Call durchzufuehren).
 */

/**
 * v0.7.1 — Quality-Stats pro Modell (siehe llm-cascade ≥ 0.7.2).
 *
 * Wird vom Endpoint `GET {base}/stats/quality?sortBy=worst-first` als
 * Liste geliefert. Default-Sortierung „worst-first" weil Admin
 * Probleme sehen will, nicht die laufenden Top-Modelle.
 */

/**
 * Label-Maps für i18n-Override.
 *
 * Konsumenten (EduPro mit i18n-Pipe, Switcher mit eigenen Strings) übergeben
 * via `<ki-… [labels]="myLabels">` ihre eigenen Strings. Library nutzt sensible
 * englische Defaults wenn nichts überschrieben wird.
 */
const MODELS_TABLE_LABELS_EN = {
    title: 'AI Models',
    refresh: 'Refresh',
    loading: 'Loading models…',
    empty: 'No models configured. Use the form below to add one.',
    colNum: '#',
    colProvider: 'Provider',
    colModelId: 'Model ID',
    colKey: 'Key',
    colEnabled: 'Enabled',
    colStatus: 'Status',
    colCategory: 'Category',
    colActions: 'Actions',
    keySet: 'Key set',
    keyMissing: 'Key missing',
    keyless: 'Local',
    on: 'ON',
    off: 'OFF',
    autoDisabled: 'Auto-disabled',
    free: 'Free',
    toggleNeedsKey: 'Key required before enabling',
    btnTest: 'Test',
    btnReenable: 'Re-enable',
    btnDelete: 'Delete',
    btnSetActive: 'Use now',
    activeBadge: 'ACTIVE',
    categoryUtility: 'Utility',
    categoryContent: 'Content',
    categoryGeneral: 'General (fallback)',
    categoryUtilityHint: 'Translations, audits, verifier — cheap/free models preferred.',
    categoryContentHint: 'Lesson content, exams, chat — quality matters.',
    categoryGeneralHint: 'Used in both cascades when category-specific models are exhausted.',
    colServer: 'Server',
    serverDefault: 'Default (localhost)',
    hardwareBlocked: 'Hardware insufficient',
    toggleHardwareBlocked: 'Server hardware insufficient — add RAM, use an external server, or pick a smaller model',
    confirmDelete: (id) => `Delete model "${id}"?`,
    btnEdit: 'Edit',
    editTitle: 'Edit model',
    editFieldProvider: 'Provider',
    editFieldModelId: 'Model ID',
    editFieldDisplayName: 'Display name',
    editFieldCategory: 'Category',
    editFieldApiKeySettingKey: 'API key setting',
    editFieldCooldown: '503 cooldown override (s)',
    editFieldServer: 'Inference server',
    btnSave: 'Save',
    btnSaving: 'Saving…',
    btnCancel: 'Cancel',
    editError: 'Update failed',
};
const ADD_MODEL_FORM_LABELS_EN = {
    title: 'Add Model',
    fieldModelId: 'Model ID (e.g. gemini-2.5-flash)',
    fieldApiKeySettingKey: 'API-Key Setting',
    fieldDisplayName: 'Display Name (optional)',
    fieldCategory: 'Category',
    fieldCooldownOverride: 'Cooldown 503 override (sec, optional)',
    fieldProviderServer: 'Inference server (optional)',
    providerServerDefault: 'Default (localhost)',
    btnAdd: 'Add Model',
    btnAdding: 'Adding…',
    hint: 'The API key setting holds the actual key value — it lives in the API-Keys section below. Multiple models may share the same setting key. Category routes the request: utility for translations/audits, content for lessons/exams, general for both.',
    errorRequired: 'Provider, Model ID and Setting Key are required',
    errorFailed: 'Failed to add model',
    providerOptions: [
        { value: 'gemini', label: 'Gemini (Google)' },
        { value: 'openai', label: 'OpenAI (api.openai.com)' },
        { value: 'anthropic', label: 'Anthropic (Claude)' },
        { value: 'openrouter', label: 'OpenRouter' },
        { value: 'deepseek', label: 'DeepSeek (api.deepseek.com)' },
        { value: 'ollama', label: 'Ollama (local)' },
        { value: 'openai_compat', label: 'Custom (self-hosted OpenAI API)' },
    ],
    categoryOptions: [
        { value: 'utility', label: 'Utility — translations, audits, verifier' },
        { value: 'content', label: 'Content — lessons, exams, chat' },
        { value: 'general', label: 'General — fallback for both' },
    ],
};
const CASCADE_COOLDOWN_LABELS_EN = {
    title: 'Cascade Cooldown',
    subtitle: 'Override the per-model cooldown behaviour globally.',
    default: 'Default',
    forceOn: 'Force ON',
    forceOff: 'Force OFF',
    effectiveOn: 'Effective: ON',
    effectiveOff: 'Effective: OFF',
    hint: 'Default = each model decides for itself. Force ON keeps cooldowns even when a model would skip them. Force OFF removes all cooldowns globally — use with care, useful for testing.',
    loading: 'Loading cascade config…',
    errorLoad: 'Failed to load cascade config.',
};
const API_KEYS_SECTION_LABELS_EN = {
    title: 'API Keys',
    subtitle: 'One value per setting-key. Multiple models referencing the same setting-key share the credential.',
    fieldSettingKey: 'Setting Key',
    fieldValue: 'Key value (empty to clear)',
    btnShow: 'Show',
    btnHide: 'Hide',
    btnSave: 'Save Key',
    btnSaving: 'Saving…',
    listTitle: 'Configured Keys',
    colSettingKey: 'Setting Key',
    colSource: 'Source',
    colValue: 'Value',
    colActions: 'Actions',
    sourceDb: 'DB (admin)',
    sourceEnv: 'ENV (boot)',
    sourceMissing: 'missing',
    btnEdit: 'Edit',
    btnClear: 'Clear',
    empty: 'No keys configured yet. Use the form above to add one.',
    hint: "Keys are stored in the consumer's settings table and never echoed to clients in plain text. The value is only used server-side to authenticate model calls.",
    confirmClear: (k) => `Clear DB-stored value for "${k}"? (Env fallback may still apply.)`,
};
const CASCADES_VIEW_LABELS_EN = {
    loading: 'Loading cascade areas…',
    empty: 'No cascade areas configured yet.',
    emptyHint: 'Add at least one model with a category to see it as a cascade card here.',
    defaultHint: 'Independent failover chain — own cooldown timer + sticky pointer.',
    cooldownTitle: 'Cooldown status',
    statusFree: 'free',
    statusCooldown: 'cooldown',
    editHintTooltip: 'Click to edit description',
    editHintPlaceholder: 'Describe what this cascade is for (e.g. "Premium tier — paid models, own cooldown")…',
    editHintSave: 'Save',
    editHintCancel: 'Cancel',
    deleteMetaTooltip: 'Delete display texts (models stay)',
    deleteMetaConfirm: (title) => `Delete display texts for "${title}"? Models stay; remove them in the Models table to make the cascade disappear entirely.`,
    editTitleTooltip: 'Click to edit display name',
    editTitlePlaceholder: 'Display name (e.g. "Free Only — Rate-Limited")…',
    sectionTitle: 'Cascade areas',
    refreshTooltip: 'Reload cascade list',
};
const FAILOVER_CHAIN_LABELS_EN = {
    title: 'Failover Chain',
    description: 'Order in which models are tried when one hits a quota / 503.',
    addRow: 'Add stage',
    removeRowTitle: 'Remove',
    moveUpTitle: 'Move up',
    moveDownTitle: 'Move down',
    currentStep: 'Current stage:',
    positionLabel: (pos, provider, model) => `Stage ${pos + 1} (${provider} · ${model})`,
    promote: '↶ Back to stage 1',
    hint: 'On quota error, the wrapper switches to the next stage and restarts.',
    emptyState: 'No stages configured. Add one to start.',
};
const ROUTING_DECISIONS_LABELS_EN = {
    title: 'Semantic Routing Cache',
    subtitle: 'Recent task-description → category routing decisions. Cached 24h.',
    statSize: 'Cached',
    statHits: 'Hits',
    statMisses: 'Misses',
    statFailures: 'Fallbacks',
    testLabel: 'Test a task description',
    testPlaceholder: 'e.g. "translate German i18n keys to English"',
    btnTest: 'Route it',
    testing: 'Routing…',
    entriesTitle: 'Cache entries',
    btnClearAll: 'Clear all',
    btnClearOne: 'Remove entry',
    loading: 'Loading…',
    empty: 'No routing decisions cached yet. Test one above, or wait for a real `purpose`-call.',
    colPurpose: 'Task description',
    colCategory: 'Chosen category',
    colExpires: 'Expires in',
    colActions: 'Actions',
    confirmClearAll: 'Clear the entire routing cache? All future requests will be re-routed.',
};
const CASCADE_MODE_PANEL_LABELS_EN = {
    toggleLegend: 'Cascade',
    hintSemanticRouting: 'Semantic Routing — Cascade decides per call.',
    hintOverrideTemplate: 'Override: every generate call goes to “{cat}”.',
    autoCardActiveTemplate: 'Auto-Failover runs via cascade area “{cat}”. See card below for chain + cooldown.',
    autoCardSemanticHint: 'Semantic Routing active — pick a cascade above to override per-call routing.',
    btnScrollToCascade: '↓ Open cascade configuration',
    offButtonLabel: 'Auto',
};
const PROVIDER_SERVERS_LABELS_EN = {
    title: 'Inference Servers',
    subtitle: 'Named servers for local models (Ollama). A model can run its inference on an external machine; the default is localhost.',
    colName: 'Name',
    colBaseUrl: 'Base URL',
    colDefault: 'Default',
    colActions: 'Actions',
    badgeDefault: 'DEFAULT',
    btnAdd: 'Add server',
    btnEdit: 'Edit',
    btnDelete: 'Delete',
    btnSave: 'Save',
    btnCancel: 'Cancel',
    btnSetDefault: 'Set default',
    fieldName: 'Name (e.g. gpu-box) — [a-z0-9_-]',
    fieldBaseUrl: 'Base URL (incl. /v1, e.g. http://gpu-box:11434/v1)',
    fieldDescription: 'Description (optional)',
    empty: 'No servers yet. The default "localhost" is seeded by the backend on first start.',
    loading: 'Loading servers…',
    hint: 'Only relevant for local providers (Ollama). Cloud providers (Gemini, OpenRouter…) have fixed endpoints and ignore this. The default server cannot be deleted.',
    errorNameFormat: 'Name must match [a-z0-9_-]{1,50}',
    errorBaseUrlRequired: 'Base URL is required',
    errorDeleteDefault: 'The default server cannot be deleted. Set another as default first.',
    confirmDelete: (name) => `Delete server "${name}"?`,
};
const CALL_OVERVIEW_LABELS_EN = {
    title: 'AI Call Overview',
    subtitle: 'Success trend, call totals and estimated cost across all providers.',
    trendTitle: 'Success trend (30 days)',
    card24h: 'Calls 24h',
    card7d: 'Calls 7d',
    card30d: 'Calls 30d',
    cardSuccess30d: 'Success 30d',
    cardFailed30d: 'Failed 30d',
    costTitle: 'Estimated cost (30d)',
    costChars: 'Output chars',
    costTokens: 'Tokens (≈chars/4)',
    costMoney: 'Cost',
    loading: 'Loading call stats…',
    empty: 'No calls recorded yet.',
};
const FAILOVER_ANALYTICS_LABELS_EN = {
    title: 'Failover Analytics',
    subtitle: 'Where the cascade dropped a model (last 30 days) — by provider and reason.',
    donutTitle: 'Failover-out / provider',
    donutCenter: 'OUT',
    tableTitle: 'Provider × reason',
    colProvider: 'Provider',
    colReason: 'Reason',
    colCount: 'Count',
    loading: 'Loading failover stats…',
    empty: 'No failover events in the last 30 days.',
    timelineTitle: 'Failover events',
    timelineHint: 'When the cascade switched (quota / 503 / promote-back) or a model was toggled — last 50.',
    colType: 'Type',
    colTransition: 'From → To',
    colWhen: 'When',
    filterPlaceholder: 'Filter…',
};
const MODE_EVENTS_LABELS_EN = {
    title: 'Mode switches',
    subtitle: 'Model toggles, pool changes and supermodel on/off — last 50.',
    empty: 'No mode switches logged yet.',
    loading: 'Loading mode switches…',
    colType: 'Type',
    colTransition: 'From → To',
    colReason: 'Reason',
    colWhen: 'When',
    filterPlaceholder: 'Filter…',
};

/**
 * Base-URL für die KI-Modell-Admin-API.
 *
 * Konsumenten konfigurieren das per `providers`:
 * ```ts
 * { provide: KI_MODELS_API_BASE, useValue: '/api/admin' }   // EduPro
 * { provide: KI_MODELS_API_BASE, useValue: '/api' }         // Switcher
 * ```
 *
 * Die Library hängt an die Base relative Pfade: `/ai-models`, `/api-keys`,
 * `/cascade-config`. Konsumenten müssen sicherstellen dass die Endpoints
 * dem in [`api-contract.md`](../../examples/api-contract.md) dokumentierten
 * Vertrag entsprechen.
 */
const KI_MODELS_API_BASE = new InjectionToken('KI_MODELS_API_BASE');

/**
 * Library-API-Service. Spricht alle KI-Modell-/API-Key-/Cascade-Endpoints
 * gegen die vom Konsumenten konfigurierte Base-URL (siehe `KI_MODELS_API_BASE`).
 *
 * **Vertrag:** Konsumentenseitige Endpoints müssen folgenden Pfaden entsprechen:
 *
 * ```
 * GET    {base}/ai-models                   → AiModel[]
 * POST   {base}/ai-models                   → AiModel
 * PUT    {base}/ai-models/{id}              → AiModel
 * DELETE {base}/ai-models/{id}              → { ok: true }
 * POST   {base}/ai-models/{id}/test         → { ok, latencyMs, error? }
 * POST   {base}/ai-models/reorder           → { ok: true }                body: { orderedIds }
 * POST   {base}/ai-models/{id}/toggle       → { id, ok, enabled }         body: { enabled }
 * GET    {base}/api-keys                    → ApiKeySetting[]
 * POST   {base}/api-keys/setting/{key}      → { ok: true }                body: { value }
 * GET    {base}/cascade-config              → CascadeConfig
 * PUT    {base}/cascade-config              → CascadeConfig
 * ```
 *
 * Backend-API-Drift zwischen EduPro und Switcher: jeder Konsument kann diesen
 * Service per Inheritance/Wrapper überschreiben oder via Subclass-Provider
 * austauschen, falls nötig.
 */
class KiModelsApiService {
    constructor() {
        this.http = inject(HttpClient);
        this.base = inject(KI_MODELS_API_BASE);
    }
    // ─── Models ──────────────────────────────────────────────────────────────
    listModels() {
        return this.http.get(`${this.base}/ai-models`);
    }
    createModel(body) {
        return this.http.post(`${this.base}/ai-models`, body);
    }
    updateModel(id, body) {
        return this.http.put(`${this.base}/ai-models/${id}`, body);
    }
    deleteModel(id) {
        return this.http.delete(`${this.base}/ai-models/${id}`);
    }
    /**
     * `skipped: true` zeigt an, dass das Konsument-Backend den Test bewusst
     * übersprungen hat (z.B. Switcher beim Anthropic-Modell ohne API-Key, weil
     * Max-OAuth den Live-Switch erlaubt aber kein API-Test möglich ist). Die
     * Tabelle deaktiviert das Modell in dem Fall NICHT auto.
     */
    testModel(id) {
        return this.http.post(`${this.base}/ai-models/${id}/test`, {});
    }
    reorderModels(orderedIds) {
        return this.http.post(`${this.base}/ai-models/reorder`, { orderedIds });
    }
    toggleModel(id, enabled) {
        return this.http.post(`${this.base}/ai-models/${id}/toggle`, { enabled });
    }
    // ─── API-Keys ────────────────────────────────────────────────────────────
    /**
     * Listet alle API-Key-Settings.
     *
     * Akzeptiert zwei Backend-Response-Shapes:
     * - **Array** (`ApiKeySetting[]`) — was die Library als Vertrag definiert
     *   (Switcher liefert das direkt unter `/cascade-settings`).
     * - **Object mit `settings`-Map** — was EduPros bestehender Endpoint
     *   `/admin/api-keys` liefert (`{settings: {key: {keyMasked, keySource, …}}}`).
     *
     * Bei Object-Form werden die Entries in das Array-Format gemapped, damit
     * die Components homogen mit `ApiKeySetting`-Items arbeiten. Pro Konsument
     * brauchen wir so keinen eigenen Adapter — die Library normalisiert selbst.
     */
    listKeys() {
        return this.http.get(`${this.base}/api-keys`).pipe(map((resp) => {
            if (Array.isArray(resp))
                return resp;
            // EduPro-Shape: { settings: { <key>: { keyMasked, keySource, keyConfigured, envVar, isDefault } } }
            if (resp && typeof resp === 'object' && resp.settings && typeof resp.settings === 'object') {
                return Object.entries(resp.settings).map(([settingKey, v]) => ({
                    settingKey,
                    valueMasked: v?.keyMasked ?? '',
                    configured: !!v?.keyConfigured,
                    keySource: v?.keySource ?? null,
                    envVar: v?.envVar ?? null,
                    isDefault: !!v?.isDefault,
                }));
            }
            return [];
        }));
    }
    setKey(settingKey, body) {
        return this.http.post(`${this.base}/api-keys/setting/${encodeURIComponent(settingKey)}`, body);
    }
    // ─── Cascades (Phase S' — Bereiche mit eigener Failover-Chain + Cooldown) ──
    /**
     * Liefert alle Cascade-Bereiche der Konsumenten-DB.
     *
     * **Vertrag**: Backend exponiert `GET {base}/cascades` → `Cascade[]`.
     * Frontend (z.B. `<ki-cascades-view>`) rendert eine Karte pro Eintrag.
     *
     * Fallback: liefert das Backend `[]` zurueck oder ist Endpoint nicht
     * verfuegbar, gibt der Wrapper-Component einen leeren Zustand — der
     * Konsument kann optional die alten 3 Default-Categories als Fallback
     * rendern.
     */
    listCascades() {
        return this.http.get(`${this.base}/cascades`);
    }
    /** Detail einer einzelnen Cascade. Selten direkt gebraucht; meistens reicht {@link #listCascades}. */
    getCascade(name) {
        return this.http.get(`${this.base}/cascades/${encodeURIComponent(name)}`);
    }
    // ─── Categories (Display-Metadaten pro Kategorie — v0.10.0) ─────────────
    /**
     * Liste aller Kategorien (Display-Metadaten). Backend vereint implizite
     * Kategorien aus `ai_model_config.category` mit persistierten
     * `category_meta`-Einträgen — Felder ohne gesetzte Metadaten kommen mit
     * `null` zurück. Wenn der Endpoint nicht existiert (Backward-Compat zu
     * llm-cascade < 0.5), liefert der Konsument `404`; das Frontend muss
     * dann selbst auf leeren Default zurückfallen.
     */
    listCategories() {
        return this.http.get(`${this.base}/categories`);
    }
    /**
     * Upsert für die Display-Metadaten einer Kategorie. Wird vom Inline-Edit
     * der Cascades-View aufgerufen. Partial-Update: Felder die nicht im Body
     * stehen werden NICHT angefasst; `null` löscht das Feld explizit.
     */
    updateCategory(name, body) {
        return this.http.put(`${this.base}/categories/${encodeURIComponent(name)}`, body);
    }
    /**
     * Löscht NUR die Metadaten-Zeile — die Kategorie selbst lebt weiter,
     * solange ein Modell sie nutzt. Nach Delete bekommt sie wieder die
     * UI-Fallbacks (capitalized name, leerer Hint).
     */
    deleteCategoryMeta(name) {
        return this.http.delete(`${this.base}/categories/${encodeURIComponent(name)}`);
    }
    // ─── Cascade-Config ──────────────────────────────────────────────────────
    getCascadeConfig() {
        return this.http.get(`${this.base}/cascade-config`);
    }
    setCascadeConfig(body) {
        return this.http.put(`${this.base}/cascade-config`, body);
    }
    // ─── Semantic Routing (Phase v0.11.0 — llm-cascade ≥ 0.6.0) ──────────────
    /**
     * Snapshot des Routing-Caches mit Counter-Stats. Wird vom
     * `<ki-routing-decisions>`-Component periodisch geladen damit der User
     * sieht welche purpose-Strings auf welche Kategorie geroutet wurden.
     */
    getRoutingCache() {
        return this.http.get(`${this.base}/routing/cache`);
    }
    /** Kompletter Cache leeren — User-Aktion im UI. */
    clearRoutingCache() {
        return this.http.delete(`${this.base}/routing/cache`);
    }
    /** Einzelnen Cache-Eintrag (per purposeHash) entfernen. */
    clearRoutingCacheEntry(purposeHash) {
        return this.http.delete(`${this.base}/routing/cache/${encodeURIComponent(purposeHash)}`);
    }
    /**
     * Test-Modus: einen purpose probe-routen ohne den eigentlichen Generate-
     * Call durchzufuehren. Cached das Ergebnis trotzdem (sodass der naechste
     * echte Call den gleichen Pfad nimmt). Praktisch um zu sehen welche
     * Kategorie der Router fuer eine bestimmte Task-Beschreibung waehlen
     * wuerde, bevor man's live ausrollt.
     */
    testRouting(purpose) {
        return this.http.post(`${this.base}/routing/test`, { purpose });
    }
    // ─── Quality-Stats (v0.7.1 — llm-cascade ≥ 0.7.2) ────────────────────────
    /**
     * Liefert Quality-Bewertung pro Modell aus den letzten 30 Tagen.
     * Default-Sortierung „worst-first": KILL-Kandidaten und schlechte Modelle
     * stehen oben, damit Admin Probleme sofort sieht.
     *
     * @param sortBy 'worst-first' (Default) | 'best-first' | 'calls-desc'
     */
    getQualityStats(sortBy = 'worst-first') {
        return this.http.get(`${this.base}/stats/quality?sortBy=${sortBy}`);
    }
    // ─── Quality Auto-Disable (v0.12.1 — llm-cascade ≥ 0.7.3) ───────────────
    /**
     * Manueller Trigger für den Auto-Disable-Job. Statt 6h auf den
     * nächsten {@code @Scheduled}-Tick zu warten, kann der Admin das
     * Cleanup per Knopfdruck anstoßen.
     *
     * Server-Antwort listet auf:
     * - {@code checked}: wie viele Modelle insgesamt geprüft wurden
     * - {@code disabled}: Modelle die jetzt gerade auto-disabled wurden
     * - {@code skippedAlreadyDisabled}: schon vorher auto-disabled
     * - {@code skippedNotKill}: Tier ist nicht „kill"
     * - {@code skippedTooFewCalls}: unter dem min-calls Schwellwert
     *
     * Bei Backend &lt; 0.7.3 (Endpoint nicht vorhanden): die Component
     * fängt den 404 und zeigt eine kurze „Feature nicht verfügbar"-Meldung.
     */
    runQualityAutoDisable() {
        return this.http.post(`${this.base}/quality/run-auto-disable`, {});
    }
    /**
     * Status des Auto-Disable-Features — ob aktiv und mit welchen Schwellwerten.
     * Die UI nutzt das um zu entscheiden ob der „Jetzt Auto-Disable laufen
     * lassen"-Button überhaupt sichtbar gemacht wird (wenn deaktiviert ist's
     * verwirrend einen Button zu zeigen).
     */
    getQualityAutoDisableConfig() {
        return this.http.get(`${this.base}/quality/auto-disable-config`);
    }
    // ─── Preferred Category Override (v0.12.2 — llm-cascade ≥ 0.7.5) ────────
    /**
     * Liest den aktuellen Cascade-Kategorie-Override. Wenn `active=true`,
     * geht jeder generate-Call ohne explizite category an die gesetzte
     * Kategorie statt durch den Semantic Router.
     *
     * Use-Case: Routing-Decisions-Component nutzt das um anzuzeigen wenn
     * der Cache irrelevant ist (Override aktiv = Cache wird umgangen).
     *
     * Bei Backend &lt; 0.7.5 (Endpoint nicht da): `{category: "", active: false}`
     * via graceful fallback.
     */
    getPreferredCategory() {
        return this.http.get(`${this.base}/preferred-category`);
    }
    /**
     * v0.13.0 — Setzt den Cascade-Kategorie-Override. Empty-String setzt
     * zurück auf Semantic Routing.
     *
     * Wird vom `<ki-cascade-mode-panel>`-Embed im Konsument-Code
     * (Switcher/EduPro) im categoryChanged-Handler aufgerufen.
     */
    setPreferredCategory(category) {
        return this.http.post(`${this.base}/preferred-category`, { category: category ?? '' });
    }
    // ─── Performance + Cooldown (v0.14.0 — cascade ≥ 0.7.6) ─────────────────
    /**
     * Performance-Stats pro Modell aus den letzten 30 Tagen.
     * Wird vom Library-Component {@code <ki-models-performance>} aufgerufen.
     *
     * @param sortBy 'calls-desc' (Default) | 'success-desc' | 'chars-desc'
     */
    getPerformance(sortBy = 'calls-desc') {
        return this.http.get(`${this.base}/stats/performance?sortBy=${sortBy}`);
    }
    /**
     * Cooldown + Auto-Disable State pro Modell. Wird vom Library-Component
     * {@code <ki-models-cooldown-state>} aufgerufen, typischerweise mit
     * Auto-Refresh alle 30s damit Cooldown-Timer live runterticken.
     */
    getCooldownState() {
        return this.http.get(`${this.base}/cooldown-state`);
    }
    // ─── Provider-Server (v0.15.0 — externe Inferenz-Server, cascade ≥ 0.8.0) ──
    /**
     * Liste der benannten Inferenz-Server. Bei Backend < 0.8.0 (Endpoint nicht
     * vorhanden) liefert der Konsument 404 → die Component fängt das und zeigt
     * einen leeren Zustand (Feature degradiert sauber).
     */
    listProviderServers() {
        return this.http.get(`${this.base}/provider-servers`);
    }
    /** Upsert eines Servers (anlegen/ändern). Setzt {@code isDefault} ggf. exklusiv. */
    upsertProviderServer(name, body) {
        return this.http.put(`${this.base}/provider-servers/${encodeURIComponent(name)}`, body);
    }
    /** Löscht einen Server. Der Default-Server kann nicht gelöscht werden (Backend 400). */
    deleteProviderServer(name) {
        return this.http.delete(`${this.base}/provider-servers/${encodeURIComponent(name)}`);
    }
    // ─── App-Settings + Delegation-Calls (v0.17.0) ───────────────────────────
    getSettings() {
        return this.http.get(`${this.base}/settings`).pipe(map((r) => Array.isArray(r)
            ? r.map(x => ({ key: x.key ?? x.settingKey, value: String(x.value ?? '') }))
            : []));
    }
    setSetting(key, value) {
        return this.http.post(`${this.base}/settings/${encodeURIComponent(key)}`, { value });
    }
    getDelegationCalls() {
        return this.http.get(`${this.base}/stats/calls`);
    }
    // ─── Shared-Analytics (v0.18.0 — cascade ≥ 0.9 / Switcher-Proxy) ─────────
    /**
     * Erfolgs-Trend pro Tag (Calls total/success/failed) der letzten `days`
     * Tage. Speist den Area-Chart in `<ki-call-overview>`. Bei Backend ohne
     * Endpoint liefert der Proxy ein leeres Array.
     */
    getStatsTrend(days = 30) {
        return this.http.get(`${this.base}/stats/trend?days=${days}`).pipe(map((r) => Array.isArray(r) ? r : []));
    }
    /**
     * KI-Calls-Totals (24h/7d/30d + Erfolg/Fehlschlag + Output-Chars).
     * Speist die Übersichts-Cards + Kosten-Schätzung in `<ki-call-overview>`.
     */
    getStatsTotals() {
        return this.http.get(`${this.base}/stats/totals`).pipe(map((r) => (r && typeof r === 'object') ? r : {}));
    }
    /**
     * Failover-Aufschlüsselung (Provider/Grund, 30 Tage). Speist Donut +
     * Tabelle in `<ki-failover-analytics>`. Leer-Objekt-Felder werden auf
     * leere Arrays normalisiert.
     */
    getStatsFailoverBreakdown() {
        return this.http.get(`${this.base}/stats/failover-breakdown`).pipe(map((r) => ({
            byProvider: Array.isArray(r?.byProvider) ? r.byProvider : [],
            byProviderReason: Array.isArray(r?.byProviderReason) ? r.byProviderReason : [],
            byReason: Array.isArray(r?.byReason) ? r.byReason : [],
        })));
    }
    /**
     * v0.19.0 — Failover-/Toggle-Events-Timeline (letzte 50 + total30d).
     * Speist die Timeline in `<ki-failover-analytics>`. Leer-Fallback.
     */
    getStatsFailover() {
        return this.http.get(`${this.base}/stats/failover`).pipe(map((r) => ({
            recent: Array.isArray(r?.recent) ? r.recent : [],
            total30d: typeof r?.total30d === 'number' ? r.total30d : 0,
        })));
    }
    /**
     * v0.20.0 — Geloggte Prompt-Snippets (absteigend nach `calledAt`). Speist die
     * Tabelle in `<ki-log-snippets>`. Existieren nur, wenn `logPromptSnippet` AN
     * ist UND der Traffic durch die Cascade lief. Leer-Fallback (`[]`) bei
     * fehlendem Endpoint/Fehler.
     */
    getLogSnippets(limit = 50) {
        return this.http.get(`${this.base}/stats/log-snippets?limit=${limit}`).pipe(map((r) => Array.isArray(r) ? r : []));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: KiModelsApiService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: KiModelsApiService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: KiModelsApiService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/**
 * v0.18.0 — Dependency-freier Pager für alle Tabellen, deren Einträge zu
 * lang werden. Rein presentational: nimmt `total`/`page`/`pageSize` und
 * emittiert `pageChange`. Sichtbar NUR wenn `total > pageSize` — bei kurzen
 * Tabellen rendert die Komponente nichts (kein DOM, kein Platzverbrauch).
 *
 * Seiten sind 0-basiert. Konsumenten halten die aktuelle Seite selbst und
 * slicen ihre Daten mit dem `paginate()`-Helper.
 */
class KiPagerComponent {
    constructor() {
        this.total = 0;
        this.page = 0;
        this.pageSize = 10;
        this.pageChange = new EventEmitter();
    }
    get lastPage() {
        return Math.max(0, Math.ceil(this.total / this.pageSize) - 1);
    }
    get rangeStart() {
        return this.total === 0 ? 0 : this.page * this.pageSize + 1;
    }
    get rangeEnd() {
        return Math.min(this.total, (this.page + 1) * this.pageSize);
    }
    go(p) {
        const clamped = Math.max(0, Math.min(p, this.lastPage));
        if (clamped !== this.page)
            this.pageChange.emit(clamped);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: KiPagerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: KiPagerComponent, isStandalone: true, selector: "ki-pager", inputs: { total: "total", page: "page", pageSize: "pageSize" }, outputs: { pageChange: "pageChange" }, ngImport: i0, template: `
    <div *ngIf="total > pageSize" class="ki-pager">
      <button class="ki-pg-btn" [disabled]="page <= 0"
              (click)="go(page - 1)" title="Zurück">‹</button>
      <span class="ki-pg-info">
        {{ rangeStart }}–{{ rangeEnd }} / {{ total }}
      </span>
      <button class="ki-pg-btn" [disabled]="page >= lastPage"
              (click)="go(page + 1)" title="Weiter">›</button>
    </div>
  `, isInline: true, styles: [".ki-pager{display:flex;align-items:center;justify-content:flex-end;gap:.6rem;margin-top:.6rem;font-size:.7rem;color:#64748b}.ki-pg-btn{min-width:1.6rem;padding:.2rem .5rem;background:#f1f5f9;color:#334155;border:1px solid #e2e8f0;border-radius:.375rem;font-size:.85rem;font-weight:800;cursor:pointer;line-height:1}.ki-pg-btn:disabled{opacity:.4;cursor:default}.ki-pg-btn:not(:disabled):hover{background:#e0e7ff;color:#3730a3}.ki-pg-info{font-variant-numeric:tabular-nums;font-weight:700}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: KiPagerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-pager', standalone: true, imports: [CommonModule], template: `
    <div *ngIf="total > pageSize" class="ki-pager">
      <button class="ki-pg-btn" [disabled]="page <= 0"
              (click)="go(page - 1)" title="Zurück">‹</button>
      <span class="ki-pg-info">
        {{ rangeStart }}–{{ rangeEnd }} / {{ total }}
      </span>
      <button class="ki-pg-btn" [disabled]="page >= lastPage"
              (click)="go(page + 1)" title="Weiter">›</button>
    </div>
  `, styles: [".ki-pager{display:flex;align-items:center;justify-content:flex-end;gap:.6rem;margin-top:.6rem;font-size:.7rem;color:#64748b}.ki-pg-btn{min-width:1.6rem;padding:.2rem .5rem;background:#f1f5f9;color:#334155;border:1px solid #e2e8f0;border-radius:.375rem;font-size:.85rem;font-weight:800;cursor:pointer;line-height:1}.ki-pg-btn:disabled{opacity:.4;cursor:default}.ki-pg-btn:not(:disabled):hover{background:#e0e7ff;color:#3730a3}.ki-pg-info{font-variant-numeric:tabular-nums;font-weight:700}\n"] }]
        }], propDecorators: { total: [{
                type: Input
            }], page: [{
                type: Input
            }], pageSize: [{
                type: Input
            }], pageChange: [{
                type: Output
            }] } });
/**
 * Slice-Helper passend zum {@link KiPagerComponent}. Schneidet die aktuelle
 * Seite aus einem Array. Klemmt die Seite defensiv, falls die Datenmenge
 * zwischen Renders schrumpft.
 */
function paginate(rows, page, pageSize) {
    if (!Array.isArray(rows) || rows.length === 0)
        return [];
    const lastPage = Math.max(0, Math.ceil(rows.length / pageSize) - 1);
    const p = Math.max(0, Math.min(page, lastPage));
    const start = p * pageSize;
    return rows.slice(start, start + pageSize);
}

/**
 * v0.19.0 — Dependency-freie Sortier-/Filter-Helfer für die Stats-Tabellen.
 * Reine Funktionen, kein Angular — von mehreren Komponenten geteilt, damit
 * alle Tabellen identisch sortieren/filtern.
 */
/**
 * Klick auf eine Spalte: zyklus asc → desc → aus. Klick auf andere Spalte
 * startet wieder bei asc.
 */
function nextSort(state, key) {
    if (state.key !== key)
        return { key, dir: 'asc' };
    if (state.dir === 'asc')
        return { key, dir: 'desc' };
    if (state.dir === 'desc')
        return { key: null, dir: null };
    return { key, dir: 'asc' };
}
/** Sortier-Glyph für den Spaltenkopf. */
function sortGlyph(state, key) {
    if (state.key !== key)
        return '⇅';
    return state.dir === 'asc' ? '▲' : state.dir === 'desc' ? '▼' : '⇅';
}
function cmp(a, b) {
    const an = typeof a === 'number';
    const bn = typeof b === 'number';
    if (an && bn)
        return a - b;
    const as = a == null ? '' : String(a);
    const bs = b == null ? '' : String(b);
    return as.localeCompare(bs, undefined, { numeric: true, sensitivity: 'base' });
}
/** Stabile Kopie sortiert nach `state.key`. `dir=null` → Originalreihenfolge. */
function sortRows(rows, state) {
    if (!state.key || !state.dir)
        return rows;
    const key = state.key;
    const factor = state.dir === 'asc' ? 1 : -1;
    return [...rows].sort((x, y) => factor * cmp(x[key], y[key]));
}
/**
 * Case-insensitive Substring-Filter. Durchsucht `fields` (oder alle Werte
 * der Zeile, wenn nicht angegeben). Leerer Query → unverändert.
 */
function filterRows(rows, query, fields) {
    const q = (query ?? '').trim().toLowerCase();
    if (!q)
        return rows;
    return rows.filter((row) => {
        const values = fields ? fields.map((f) => row[f]) : Object.values(row);
        return values.some((v) => v != null && String(v).toLowerCase().includes(q));
    });
}

/**
 * Tabelle aller AI-Modelle in der Cascade-Reihenfolge.
 *
 * **Spalten:** #, Provider, Model-ID (+displayName), Key-Status, Enabled-Toggle,
 * Status (autoDisabled-Reason / Cooldown / Free), Actions (Up/Down, Test, Re-Enable,
 * Delete).
 *
 * **Events:**
 * - `(activeModelChanged)` — User klickt „Als aktiv setzen" (Switcher-Feature,
 *   wird in L.2/L.4 ergänzt wenn dem Component ein `[showActiveAction]="true"`
 *   Input mitgegeben wird). Aktuell nicht im Template (folgt L.2.1).
 * - `(modelChanged)` — emittet bei jeder mutating-Aktion (toggle/move/delete/
 *   test) damit der Konsument seine Modell-Liste neu laden kann.
 *
 * Labels sind englisch hardcoded — Konsument-spezifische Übersetzung folgt in
 * Phase L.3 via `@Input()`-Override-Pattern oder eigenem Translation-Service.
 */
class ModelsTableComponent {
    constructor() {
        this.activeModelChanged = new EventEmitter();
        this.modelChanged = new EventEmitter();
        this.L = MODELS_TABLE_LABELS_EN;
        /**
         * Aktiviert pro Modell-Zeile den „Als aktiv setzen"-Button (`btnSetActive`).
         * Default `false` — EduPro nutzt das nicht, Switcher schaltet's auf `true`.
         * Wenn das Modell bereits aktiv ist (siehe `activeModelId`), zeigt sich
         * stattdessen das AKTIV-Badge.
         */
        this.showActiveAction = false;
        /**
         * Aktive Modell-ID (`modelId`-Feld, nicht die DB-id). Wird mit jeder Zeile
         * verglichen um die AKTIV-Badge zu setzen. `null` = kein Modell aktiv.
         */
        this.activeModelId = null;
        /**
         * Anzeige-Titel pro Kategorie. Generisch seit v0.10.0 — Konsumenten reichen
         * eine Map aller Kategorien rein, die ihre Modelle nutzen. Fehlende
         * Einträge fallen auf `categoryUtility`/`categoryContent`/`categoryGeneral`
         * aus den Labels zurück (Backward-Compat zu v0.9.x), und für alles andere
         * auf den capitalized Kategorie-String selbst.
         *
         * Beispiele:
         *  - EduPro übergibt nichts → Defaults aus `MODELS_TABLE_LABELS_*` greifen.
         *  - Switcher übergibt `{ cloud: 'Cloud — Premium', 'free-only': 'Free Tier' }`.
         */
        this.categoryTitles = {};
        /** Sub-Beschreibung pro Kategorie. Selbe Fallback-Kette wie `categoryTitles`. */
        this.categoryHints = {};
        /**
         * Explizite Reihenfolge der Kategorie-Sektionen. Wenn leer (Default),
         * werden Kategorien in der Reihenfolge gezeigt, in der sie erstmals in
         * `models()` auftauchen — was wiederum der globalen `orderIdx`-Reihenfolge
         * folgt. Für deterministische UI: Konsument liefert seine Wunsch-Reihenfolge.
         */
        this.categoryOrder = [];
        /**
         * Optionale Whitelist sichtbarer Kategorien. `null`/`undefined` (Default) →
         * alle Kategorien mit Modellen werden gezeigt (EduPro-Verhalten). Wird eine
         * Liste gesetzt, werden NUR diese Kategorien gerendert — der Switcher nutzt
         * das, um je nach Pool/Supermodell-Zustand nur die passenden Cascaden zu
         * zeigen (Supermodell AUS → nur Pool-Kategorie; AN → nur Rollen-Kategorien).
         *
         * Signal-backed (wie `<ki-cascades-view>._visibleCascades`), damit die
         * `computed()`-Sichten (categoriesWithModels/categoriesByPool) auf Änderungen
         * des Inputs REAGIEREN — ein plain @Input würde von computed() nicht getrackt
         * und die Tabelle bliebe beim Umschalten (z.B. Pool-Anzeige-Toggle) stehen.
         */
        this._visibleCategories = signal(null);
        /**
         * Pool-Anzeigenamen für die Pool-gruppierte Matrix. Wird nur genutzt, wenn
         * `visibleCategories` gesetzt ist (Switcher-Fall) — dann werden die
         * Kategorie-Sections zusätzlich nach Pool (cloud → free → local) gruppiert
         * und mit dieser Überschrift versehen. Fehlt ein Eintrag, fällt der Header
         * auf den capitalized Pool-Namen zurück.
         */
        this.poolTitles = {
            cloud: 'Cloud — Premium (bezahlt)',
            free: 'Free — OpenRouter :free',
            local: 'Lokal — Ollama (privat)',
        };
        /**
         * v0.11.3 — Konsumenten-spezifische Liste von Provider-Namen die keinen
         * API-Key brauchen. Zusätzlich zu dem `keyless`-Flag aus dem Backend.
         *
         * Beispiele:
         *  - Switcher: `['anthropic']` — Claude via Max-OAuth (Cookie), kein
         *    sk-ant-Key nötig. Cascade-Backend ruft anthropic nicht direkt;
         *    Wrapper handled das.
         *  - EduPro: `[]` — alle Cloud-Provider brauchen ihren Key, weil EduPro-
         *    Backend selbst HTTP-Calls an api.anthropic.com etc. macht.
         *
         * Default `[]`. Ollama ist immer keyless (vom Backend markiert), egal
         * was hier steht.
         */
        this.keylessProviders = [];
        /** Seitengröße pro Kategorie-Section. Pager nur sichtbar wenn mehr Zeilen. */
        this.pageSize = 10;
        this.api = inject(KiModelsApiService);
        this.loading = signal(true);
        this.models = signal([]);
        this.filter = signal('');
        /** Gefilterte Modelle (über alle Kategorien). Reorder operiert weiter auf der
         *  vollen `models()`-Liste, nur die Anzeige/Gruppierung wird gefiltert. */
        this.filteredModels = computed(() => filterRows(this.models(), this.filter(), ['provider', 'modelId', 'displayName', 'category']));
        /** Aktuelle Seite je Kategorie (0-basiert). Default 0. */
        this.pageByCategory = signal({});
        this.testResult = signal({});
        /** DB-id des Modells dessen Inline-Edit-Formular gerade offen ist (null = keins). */
        this.editingId = signal(null);
        this.savingEdit = signal(false);
        this.editError = signal(null);
        /** Arbeitskopie der editierbaren Felder — wird beim Öffnen aus dem Modell befüllt. */
        this.editForm = { provider: '', modelId: '', displayName: '', category: '', apiKeySettingKey: '', cooldown503OverrideSec: null, providerServerName: null };
        /** v0.15.0 — benannte Inferenz-Server für das pro-Modell-Dropdown. Leer wenn
         *  Backend < 0.8.0 (Endpoint 404) → Dropdown zeigt nur „Default". */
        this.providerServers = signal([]);
        /**
         * Modelle gruppiert nach Kategorie. null/undefined/leer → `'general'`
         * (bleibt Default — passt zum llm-cascade-Backend, das ebenfalls auf
         * `general` fällt). Beliebige String-Kategorien werden akzeptiert.
         */
        this.modelsByCategory = computed(() => {
            const buckets = {};
            for (const m of this.filteredModels()) {
                const cat = m.category && m.category.trim() ? m.category : 'general';
                (buckets[cat] ??= []).push(m);
            }
            return buckets;
        });
        /**
         * Kategorien die mindestens 1 Modell enthalten. Reihenfolge:
         *   1. Explizit via `[categoryOrder]` — diese kommen zuerst (in der
         *      gegebenen Reihenfolge, sofern sie überhaupt Modelle enthalten).
         *   2. Alle restlichen Kategorien danach in der Reihenfolge ihres
         *      ersten Auftretens in `models()` (= globaler `orderIdx`).
         */
        this.categoriesWithModels = computed(() => {
            const by = this.modelsByCategory();
            const present = Object.keys(by);
            const seen = new Set();
            const ordered = [];
            for (const c of this.categoryOrder) {
                if (by[c]?.length && !seen.has(c)) {
                    ordered.push(c);
                    seen.add(c);
                }
            }
            for (const m of this.filteredModels()) {
                const c = m.category && m.category.trim() ? m.category : 'general';
                if (by[c]?.length && !seen.has(c)) {
                    ordered.push(c);
                    seen.add(c);
                }
            }
            for (const c of present) {
                if (!seen.has(c)) {
                    ordered.push(c);
                    seen.add(c);
                }
            }
            if (this.visibleCategories != null) {
                const allow = new Set(this.visibleCategories);
                return ordered.filter((c) => allow.has(c));
            }
            return ordered;
        });
        /** Bekannte Pools in Anzeige-Reihenfolge. */
        this.POOL_ORDER = ['cloud', 'free', 'local'];
        /**
         * Pool-gruppierte Sicht — nur aktiv, wenn `visibleCategories` gesetzt ist
         * (Switcher-Matrix). Jede Gruppe enthält die sichtbaren Kategorien-mit-Modellen
         * dieses Pools in bestehender `categoriesWithModels`-Reihenfolge; Pools in
         * fester Reihenfolge cloud → free → local. Nur Pools mit mind. einer
         * Kategorie werden zurückgegeben. Kategorien ohne ableitbaren Pool landen
         * in einer namenlosen Gruppe (key null) am Ende, ohne Header.
         */
        this.categoriesByPool = computed(() => {
            const cats = this.categoriesWithModels();
            if (this.visibleCategories == null)
                return [{ pool: null, cats }];
            const groups = [];
            const byPool = new Map();
            for (const c of cats) {
                const p = this.poolOf(c);
                if (!byPool.has(p))
                    byPool.set(p, []);
                byPool.get(p).push(c);
            }
            for (const pool of this.POOL_ORDER) {
                const list = byPool.get(pool);
                if (list?.length)
                    groups.push({ pool, cats: list });
            }
            // Nicht-poolbare Kategorien (z.B. 'general') ohne Header hinten anhängen.
            const rest = byPool.get(null);
            if (rest?.length)
                groups.push({ pool: null, cats: rest });
            return groups;
        });
    }
    /** Optionale Labels — Konsument gibt seine i18n-Strings rein. Default = englisch. */
    set labels(v) {
        this.L = { ...MODELS_TABLE_LABELS_EN, ...(v ?? {}) };
    }
    set visibleCategories(v) {
        this._visibleCategories.set(v ?? null);
    }
    get visibleCategories() {
        return this._visibleCategories();
    }
    /**
     * Leitet den Pool einer Kategorie ab:
     *   - bare Pool-Name ('cloud'|'free'|'local') → dieser Pool
     *   - 'free-only' (Legacy) → 'free'
     *   - Compound '{area|role}-{pool}' → Suffix nach dem letzten '-'
     *   - sonst (z.B. 'general') → null (nicht gruppierbar)
     */
    poolOf(cat) {
        if (cat === 'free-only')
            return 'free';
        if (this.POOL_ORDER.includes(cat))
            return cat;
        const idx = cat.lastIndexOf('-');
        if (idx >= 0) {
            const suffix = cat.slice(idx + 1);
            if (this.POOL_ORDER.includes(suffix))
                return suffix;
        }
        return null;
    }
    /** Header-Label für eine Pool-Gruppe. */
    poolTitle(pool) {
        return this.poolTitles[pool] || this.prettifyCategory(pool);
    }
    /**
     * Capitalize + Bindestrich/Underscore zu Leerzeichen — als letztes Fallback
     * für unbekannte Kategorien (z.B. `free-only` → `Free Only`, `cloud` → `Cloud`).
     * Damit sieht die UI auch ohne explizite `categoryTitles`-Map nicht roh aus.
     */
    prettifyCategory(c) {
        return c.replace(/[-_]+/g, ' ').replace(/\b\w/g, ch => ch.toUpperCase());
    }
    /**
     * Title-Lookup-Reihenfolge:
     *   1. Explizit via `[categoryTitles]`-Map (Konsumenten-Override)
     *   2. Backward-Compat zu v0.9.x: hardcoded utility/content/general aus Labels
     *   3. Capitalized Kategorie-String als Fallback
     */
    categoryTitle(c) {
        if (this.categoryTitles[c])
            return this.categoryTitles[c];
        if (c === 'utility')
            return this.L.categoryUtility;
        if (c === 'content')
            return this.L.categoryContent;
        if (c === 'general')
            return this.L.categoryGeneral;
        return this.prettifyCategory(c);
    }
    /**
     * Hint-Lookup-Reihenfolge analog `categoryTitle`. Wenn kein Hint gefunden:
     * leerer String (UI zeigt dann nur den Title).
     */
    categoryHint(c) {
        if (this.categoryHints[c])
            return this.categoryHints[c];
        if (c === 'utility')
            return this.L.categoryUtilityHint;
        if (c === 'content')
            return this.L.categoryContentHint;
        if (c === 'general')
            return this.L.categoryGeneralHint;
        return '';
    }
    ngOnInit() {
        this.reload();
        this.loadProviderServers();
    }
    reload() {
        this.loading.set(true);
        this.pageByCategory.set({});
        this.api.listModels().subscribe({
            next: (list) => {
                this.models.set(list);
                this.loading.set(false);
            },
            error: () => this.loading.set(false),
        });
    }
    setFilter(v) { this.filter.set(v); this.pageByCategory.set({}); }
    /** Aktuelle Seite einer Kategorie (0-basiert, Default 0). */
    catPage(cat) {
        return this.pageByCategory()[cat] ?? 0;
    }
    /** Setzt die Seite einer Kategorie (vom Pager-Event). */
    setCatPage(cat, page) {
        this.pageByCategory.update((m) => ({ ...m, [cat]: page }));
    }
    /** Aktuelle Seiten-Slice einer Kategorie. */
    pagedModels(cat) {
        return paginate(this.modelsByCategory()[cat] ?? [], this.catPage(cat), this.pageSize);
    }
    /** v0.15.0 — lädt die benannten Server fürs Server-Dropdown. Backend < 0.8.0
     *  liefert 404 → leere Liste, Dropdown zeigt nur „Default". */
    loadProviderServers() {
        this.api.listProviderServers().subscribe({
            next: (list) => this.providerServers.set(list ?? []),
            error: () => this.providerServers.set([]),
        });
    }
    /** v0.15.0 — Server-Auswahl nur für lokale/self-hosted Provider sinnvoll.
     *  Cloud-Provider haben feste Endpoints und ignorieren den Server. */
    supportsCustomServer(m) {
        return m.provider === 'ollama' || m.provider === 'openai_compat';
    }
    /** v0.15.0 — weist einem Modell einen Inferenz-Server zu (leer = Default). */
    setServer(m, name) {
        this.api.updateModel(m.id, { providerServerName: name || null }).subscribe(() => {
            this.modelChanged.emit(m);
            this.reload();
        });
    }
    /** Tooltip für den (ggf. deaktivierten) Enable-Toggle: Key-Grund vs. Hardware-Grund. */
    toggleDisabledReason(m) {
        if (!m.enabled && m.hardwareCompatible === false)
            return this.L.toggleHardwareBlocked;
        if (!m.enabled && !m.keyConfigured && !this.isKeylessModel(m))
            return this.L.toggleNeedsKey;
        return '';
    }
    toggle(m) {
        // v0.11.3 — keyless Modelle (Ollama, oder Konsument-Override für anthropic
        // via Max-OAuth) duerfen auch ohne keyConfigured aktiviert werden.
        if (!m.enabled && !m.keyConfigured && !this.isKeylessModel(m))
            return;
        // v0.15.0 — hardware-geblockte Modelle nicht aktivierbar (nur OFF→ON sperren;
        // ein bereits aktives Modell bleibt abschaltbar). Geht von selbst wieder auf
        // sobald das Backend hardwareCompatible=true liefert (mehr RAM / ext. Server).
        if (!m.enabled && m.hardwareCompatible === false)
            return;
        this.api.toggleModel(m.id, !m.enabled).subscribe(() => {
            this.modelChanged.emit(m);
            this.reload();
        });
    }
    reEnable(m) {
        this.api.updateModel(m.id, { autoDisabled: false, enabled: true }).subscribe(() => {
            this.modelChanged.emit(m);
            this.reload();
        });
    }
    remove(m) {
        if (!confirm(this.L.confirmDelete(m.modelId)))
            return;
        this.api.deleteModel(m.id).subscribe(() => {
            this.modelChanged.emit(null);
            this.reload();
        });
    }
    /** Öffnet das Inline-Edit-Formular und befüllt die Arbeitskopie aus dem Modell. */
    startEdit(m) {
        this.editError.set(null);
        this.editForm = {
            provider: m.provider,
            modelId: m.modelId,
            displayName: m.displayName ?? '',
            category: m.category ?? '',
            apiKeySettingKey: m.apiKeySettingKey,
            cooldown503OverrideSec: m.cooldown503OverrideSec ?? null,
            providerServerName: m.providerServerName ?? null,
        };
        this.editingId.set(m.id);
    }
    cancelEdit() {
        this.editingId.set(null);
        this.editError.set(null);
    }
    /** True wenn der im Formular gewählte Provider einen benannten Server unterstützt. */
    editSupportsServer() {
        return this.editForm.provider === 'ollama' || this.editForm.provider === 'openai_compat';
    }
    saveEdit(m) {
        const f = this.editForm;
        const body = {
            provider: f.provider.trim(),
            modelId: f.modelId.trim(),
            displayName: f.displayName.trim() || null,
            category: f.category.trim() || undefined,
            apiKeySettingKey: f.apiKeySettingKey.trim(),
            cooldown503OverrideSec: f.cooldown503OverrideSec,
            providerServerName: this.editSupportsServer() ? (f.providerServerName || null) : null,
        };
        this.savingEdit.set(true);
        this.editError.set(null);
        this.api.updateModel(m.id, body).subscribe({
            next: () => {
                this.savingEdit.set(false);
                this.editingId.set(null);
                this.modelChanged.emit(m);
                this.reload();
            },
            error: (e) => {
                this.savingEdit.set(false);
                this.editError.set(e?.error?.error ?? this.L.editError);
            },
        });
    }
    move(idx, dir) {
        const target = idx + dir;
        if (target < 0 || target >= this.models().length)
            return;
        const ordered = [...this.models()];
        const [moved] = ordered.splice(idx, 1);
        ordered.splice(target, 0, moved);
        this.api.reorderModels(ordered.map((m) => m.id)).subscribe(() => {
            this.modelChanged.emit(moved);
            this.reload();
        });
    }
    /**
     * Move innerhalb einer Kategorie: tauscht zwei kategoriegleiche Modelle in der
     * globalen `orderIdx`-Liste. Cross-Kategorie-Swap nicht möglich (Buttons
     * sind am Ende der Kategorie disabled). Globale Reihenfolge bleibt stabil,
     * nur die zwei Positionen werden gewechselt.
     */
    moveInCategory(cat, idxInCat, dir) {
        const subset = this.modelsByCategory()[cat];
        const target = idxInCat + dir;
        if (target < 0 || target >= subset.length)
            return;
        const movedModel = subset[idxInCat];
        const swapModel = subset[target];
        const ordered = [...this.models()];
        const movedGlobalIdx = ordered.findIndex(m => m.id === movedModel.id);
        const swapGlobalIdx = ordered.findIndex(m => m.id === swapModel.id);
        if (movedGlobalIdx < 0 || swapGlobalIdx < 0)
            return;
        [ordered[movedGlobalIdx], ordered[swapGlobalIdx]] = [ordered[swapGlobalIdx], ordered[movedGlobalIdx]];
        this.api.reorderModels(ordered.map(m => m.id)).subscribe(() => {
            this.modelChanged.emit(movedModel);
            this.reload();
        });
    }
    test(m) {
        this.setTest(m.id, { pending: true });
        this.api.testModel(m.id).subscribe({
            next: (r) => {
                this.setTest(m.id, r);
                // Auto-disable nur bei *echten* Failed-Tests (Modell antwortet falsch
                // oder gar nicht). Wenn der Konsument-Backend den Test bewusst
                // übersprungen hat (`skipped: true`), ist das KEIN Grund das Modell
                // auto-zu-deaktivieren — z.B. Switcher kurzschließt den Anthropic-Test
                // wenn kein API-Key da ist, weil Max-OAuth den Live-Switch trotzdem
                // erlaubt. Das Modell ist nutzbar, nur nicht testbar.
                if (m.enabled && r.ok === false && r.skipped !== true) {
                    this.api.toggleModel(m.id, false).subscribe(() => this.reload());
                }
            },
            error: (e) => {
                this.setTest(m.id, { ok: false, error: e?.message ?? 'Error' });
                if (m.enabled)
                    this.api.toggleModel(m.id, false).subscribe(() => this.reload());
            },
        });
    }
    /**
     * „Als aktiv setzen"-Klick — emittet `activeModelChanged`. Der Konsument
     * (z.B. Switcher) entscheidet was passiert: typisch ist ein `/api/switch`
     * mit `{provider, modelId}` damit der Wrapper Claude Code mit dem neuen
     * Provider neu startet.
     */
    setActive(m) {
        this.activeModelChanged.emit(m);
    }
    /** True wenn die Zeile zum `activeModelId`-Input passt. */
    isActiveModel(m) {
        return !!this.activeModelId && m.modelId === this.activeModelId;
    }
    /**
     * v0.11.4 — true wenn das Modell als „keyless" zu rendern ist (blaues
     * "Lokal"-Badge statt "Key fehlt"/"Key set").
     *
     * Logik:
     *  1. Backend-keyless (`m.keyless===true`, z.B. Ollama lokal) → IMMER true
     *  2. Konsument-Override (`keylessProviders.includes(provider)`) + KEIN
     *     Key konfiguriert → true (Beispiel: Switcher-anthropic ohne sk-ant-Key,
     *     Wechsel läuft via Max-OAuth ohne API-Call)
     *  3. Konsument-Override + Key konfiguriert → FALSE — User hat einen Key
     *     gesetzt, also „Key set" anzeigen + Test geht (Switcher-anthropic mit
     *     sk-ant-Key → echter api.anthropic.com-Call funktioniert)
     *  4. Sonst → false (normaler Cloud-Provider mit/ohne Key)
     */
    isKeylessModel(m) {
        if (m.keyless === true)
            return true;
        return this.keylessProviders.includes(m.provider) && !m.keyConfigured;
    }
    truncate(s, n) {
        return s.length > n ? s.slice(0, n) + '…' : s;
    }
    setTest(id, r) {
        this.testResult.update((tr) => ({ ...tr, [id]: r }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ModelsTableComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ModelsTableComponent, isStandalone: true, selector: "ki-models-table", inputs: { labels: "labels", showActiveAction: "showActiveAction", activeModelId: "activeModelId", categoryTitles: "categoryTitles", categoryHints: "categoryHints", categoryOrder: "categoryOrder", visibleCategories: "visibleCategories", poolTitles: "poolTitles", keylessProviders: "keylessProviders", pageSize: "pageSize" }, outputs: { activeModelChanged: "activeModelChanged", modelChanged: "modelChanged" }, ngImport: i0, template: `
    <div class="ki-models-table">
      <div class="ki-models-table-header">
        <h3 class="ki-section-title">{{ L.title }}</h3>
        <button (click)="reload()" class="ki-btn-secondary">↻ {{ L.refresh }}</button>
      </div>

      <input *ngIf="!loading() && models().length > 0"
        class="ki-filter" type="text" placeholder="Filtern…"
        [value]="filter()" (input)="setFilter($any($event.target).value)" />

      <div *ngIf="loading()" class="ki-muted">{{ L.loading }}</div>

      <div *ngIf="!loading() && models().length === 0" class="ki-empty">
        {{ L.empty }}
      </div>

      <!-- Phase R: Gruppierte Ansicht nach Routing-Kategorie. Jede Section
           rendert ihre eigene Tabelle. Reorder (Pfeile) ist innerhalb einer
           Kategorie scoped — globaler orderIdx wird im Hintergrund neu
           vergeben, aber Cross-Kategorie-Swap ist nicht erlaubt. -->
      <div *ngIf="models().length > 0">
        <div *ngFor="let group of categoriesByPool()" class="ki-pool-group">
          <h3 *ngIf="group.pool" class="ki-pool-title">{{ poolTitle(group.pool) }}</h3>
          <section *ngFor="let cat of group.cats" class="ki-category-section">
          <header class="ki-category-header">
            <h4 class="ki-category-title">{{ categoryTitle(cat) }}</h4>
            <p class="ki-category-hint">{{ categoryHint(cat) }}</p>
          </header>

          <div class="ki-table-wrap">
            <table class="ki-table">
              <thead>
                <tr>
                  <th>{{ L.colNum }}</th>
                  <th>{{ L.colProvider }}</th>
                  <th>{{ L.colModelId }}</th>
                  <th>{{ L.colKey }}</th>
                  <th>{{ L.colEnabled }}</th>
                  <th>{{ L.colStatus }}</th>
                  <th>{{ L.colServer }}</th>
                  <th class="ki-right">{{ L.colActions }}</th>
                </tr>
              </thead>
              <tbody>
                <ng-container *ngFor="let m of pagedModels(cat); let i = index">
                <tr [class.ki-row-auto-disabled]="m.autoDisabled">
                  <td class="ki-mono ki-muted">{{ catPage(cat) * pageSize + i + 1 }}</td>
                  <td class="ki-mono ki-provider">{{ m.provider }}</td>
                  <td class="ki-mono">
                    <strong>{{ m.modelId }}</strong>
                    <div *ngIf="m.displayName" class="ki-muted ki-tiny">{{ m.displayName }}</div>
                  </td>
                  <td>
                    <span *ngIf="isKeylessModel(m)" class="ki-badge ki-badge-local">{{ L.keyless }}</span>
                    <span *ngIf="!isKeylessModel(m) && m.keyConfigured" class="ki-badge ki-badge-ok">{{ L.keySet }}</span>
                    <span *ngIf="!isKeylessModel(m) && !m.keyConfigured" class="ki-badge ki-badge-warn">{{ L.keyMissing }}</span>
                    <div class="ki-tiny ki-mono ki-muted">{{ m.apiKeySettingKey }}</div>
                  </td>
                  <td>
                    <button *ngIf="!m.autoDisabled"
                            (click)="toggle(m)"
                            [disabled]="(!m.enabled && !m.keyConfigured && !isKeylessModel(m)) || (!m.enabled && m.hardwareCompatible === false)"
                            [title]="toggleDisabledReason(m)"
                            class="ki-toggle"
                            [class.ki-toggle-on]="m.enabled"
                            [class.ki-toggle-off]="!m.enabled">
                      {{ m.enabled ? L.on : L.off }}
                    </button>
                    <span *ngIf="m.autoDisabled" class="ki-badge ki-badge-error">🚫 {{ L.autoDisabled }}</span>
                  </td>
                  <td>
                    <span *ngIf="m.hardwareCompatible === false" class="ki-badge ki-badge-warn">⚠ {{ L.hardwareBlocked }}</span>
                    <span *ngIf="m.hardwareCompatible === false" class="ki-tiny ki-error" [title]="m.hardwareReason || ''">
                      {{ truncate(m.hardwareReason || '', 60) }}
                    </span>
                    <span *ngIf="m.autoDisabled" class="ki-tiny ki-error" [title]="m.autoDisabledReason || ''">
                      {{ truncate(m.autoDisabledReason || '', 60) }}
                    </span>
                    <span *ngIf="!m.autoDisabled && (m.cooldownRemainingSec ?? 0) > 0" class="ki-tiny ki-cooldown">
                      cd {{ m.cooldownRemainingSec }}s
                    </span>
                    <span *ngIf="!m.autoDisabled && !(m.cooldownRemainingSec ?? 0) && m.hardwareCompatible !== false" class="ki-tiny ki-ok">
                      {{ L.free }}
                    </span>
                    <div *ngIf="testResult()[m.id] as r" class="ki-tiny ki-mono"
                         [class.ki-ok]="r.ok"
                         [class.ki-error]="!r.ok && !r.pending">
                      <span *ngIf="r.pending">…</span>
                      <span *ngIf="r.ok">✓ {{ r.latencyMs }}ms</span>
                      <span *ngIf="!r.ok && !r.pending">✗ {{ truncate(r.error || '', 80) }}</span>
                    </div>
                  </td>
                  <td>
                    <select *ngIf="supportsCustomServer(m); else noServer"
                            class="ki-server-select"
                            (change)="setServer(m, $any($event.target).value)">
                      <option value="" [selected]="!m.providerServerName">{{ L.serverDefault }}</option>
                      <option *ngFor="let s of providerServers()" [value]="s.name"
                              [selected]="m.providerServerName === s.name">{{ s.name }}</option>
                    </select>
                    <ng-template #noServer><span class="ki-muted ki-tiny">—</span></ng-template>
                  </td>
                  <td class="ki-right ki-actions">
                    <button (click)="moveInCategory(cat, catPage(cat) * pageSize + i, -1)"
                            [disabled]="catPage(cat) * pageSize + i === 0"
                            class="ki-btn-icon">↑</button>
                    <button (click)="moveInCategory(cat, catPage(cat) * pageSize + i, 1)"
                            [disabled]="catPage(cat) * pageSize + i === modelsByCategory()[cat].length - 1"
                            class="ki-btn-icon">↓</button>
                    <button (click)="test(m)" class="ki-btn-secondary">{{ L.btnTest }}</button>
                    <span *ngIf="showActiveAction && isActiveModel(m)" class="ki-badge ki-badge-active">{{ L.activeBadge }}</span>
                    <button
                      *ngIf="showActiveAction && !isActiveModel(m) && (m.keyConfigured || isKeylessModel(m)) && !m.autoDisabled"
                      (click)="setActive(m)"
                      class="ki-btn-primary"
                    >{{ L.btnSetActive }}</button>
                    <button *ngIf="m.autoDisabled" (click)="reEnable(m)" class="ki-btn-warn">{{ L.btnReenable }}</button>
                    <button (click)="startEdit(m)" class="ki-btn-secondary">{{ L.btnEdit }}</button>
                    <button (click)="remove(m)" class="ki-btn-danger">{{ L.btnDelete }}</button>
                  </td>
                </tr>

                <!-- Inline-Edit-Zeile: erscheint unter der Modell-Zeile wenn der
                     Edit-Button geklickt wurde. Voll-Edit der Konfigurationsfelder
                     (Aktiv-Toggle + Reihenfolge haben eigene Controls oben). -->
                <tr *ngIf="editingId() === m.id" class="ki-edit-row">
                  <td [attr.colspan]="8">
                    <div class="ki-edit-form">
                      <h5 class="ki-edit-title">{{ L.editTitle }}</h5>
                      <div class="ki-edit-grid">
                        <label class="ki-edit-field">
                          <span class="ki-edit-label">{{ L.editFieldProvider }}</span>
                          <input [(ngModel)]="editForm.provider" class="ki-edit-input ki-mono" />
                        </label>
                        <label class="ki-edit-field">
                          <span class="ki-edit-label">{{ L.editFieldModelId }}</span>
                          <input [(ngModel)]="editForm.modelId" class="ki-edit-input ki-mono" />
                        </label>
                        <label class="ki-edit-field">
                          <span class="ki-edit-label">{{ L.editFieldDisplayName }}</span>
                          <input [(ngModel)]="editForm.displayName" class="ki-edit-input" />
                        </label>
                        <label class="ki-edit-field">
                          <span class="ki-edit-label">{{ L.editFieldCategory }}</span>
                          <input [(ngModel)]="editForm.category" class="ki-edit-input ki-mono" />
                        </label>
                        <label class="ki-edit-field">
                          <span class="ki-edit-label">{{ L.editFieldApiKeySettingKey }}</span>
                          <input [(ngModel)]="editForm.apiKeySettingKey" class="ki-edit-input ki-mono" />
                        </label>
                        <label class="ki-edit-field">
                          <span class="ki-edit-label">{{ L.editFieldCooldown }}</span>
                          <input [(ngModel)]="editForm.cooldown503OverrideSec" type="number" class="ki-edit-input ki-mono" />
                        </label>
                        <label *ngIf="editSupportsServer()" class="ki-edit-field">
                          <span class="ki-edit-label">{{ L.editFieldServer }}</span>
                          <select [(ngModel)]="editForm.providerServerName" class="ki-edit-input ki-mono">
                            <option [ngValue]="null">{{ L.serverDefault }}</option>
                            <option *ngFor="let s of providerServers()" [ngValue]="s.name">{{ s.name }}</option>
                          </select>
                        </label>
                      </div>
                      <p *ngIf="editError()" class="ki-tiny ki-error">{{ editError() }}</p>
                      <div class="ki-edit-actions">
                        <button (click)="saveEdit(m)" [disabled]="savingEdit()" class="ki-btn-primary">
                          {{ savingEdit() ? L.btnSaving : L.btnSave }}
                        </button>
                        <button (click)="cancelEdit()" [disabled]="savingEdit()" class="ki-btn-icon">{{ L.btnCancel }}</button>
                      </div>
                    </div>
                  </td>
                </tr>
                </ng-container>
              </tbody>
            </table>

            <ki-pager
              [total]="modelsByCategory()[cat].length"
              [page]="catPage(cat)"
              [pageSize]="pageSize"
              (pageChange)="setCatPage(cat, $event)">
            </ki-pager>
          </div>
          </section>
        </div>
      </div>
    </div>
  `, isInline: true, styles: [".ki-models-table{font-family:inherit}.ki-models-table-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:.75rem}.ki-section-title{font-size:.85rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#1e293b;margin:0}.ki-filter{width:100%;box-sizing:border-box;padding:.4rem .6rem;margin-bottom:1rem;border:1px solid #e2e8f0;border-radius:.375rem;font-size:.8rem}.ki-pool-group{margin-bottom:2.5rem}.ki-pool-group:last-child{margin-bottom:0}.ki-pool-title{font-size:.9rem;font-weight:900;letter-spacing:.02em;color:#0f172a;margin:0 0 1rem;padding-bottom:.4rem;border-bottom:2px solid #cbd5e1}.ki-category-section{margin-bottom:2rem}.ki-category-section:last-child{margin-bottom:0}.ki-category-header{margin-bottom:.5rem}.ki-category-title{font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.12em;color:#1e293b;margin:0 0 .15rem}.ki-category-hint{font-size:.7rem;color:#64748b;margin:0}.ki-muted{color:#888}.ki-tiny{font-size:.7rem}.ki-mono{font-family:ui-monospace,monospace}.ki-provider{color:#4f46e5;font-weight:700}.ki-empty{text-align:center;padding:2rem;color:#94a3b8;font-weight:600}.ki-table-wrap{overflow-x:auto;-webkit-overflow-scrolling:touch}.ki-table{width:100%;min-width:46rem;border-collapse:collapse;font-size:.875rem}.ki-table thead tr{border-bottom:2px solid #e2e8f0}.ki-table th{padding:.75rem .5rem;text-align:left;text-transform:uppercase;font-size:.625rem;font-weight:800;letter-spacing:.1em;color:#64748b}.ki-table td{padding:.75rem .5rem;border-bottom:1px solid #f1f5f9;vertical-align:top}.ki-right{text-align:right}.ki-row-auto-disabled{background:#fef2f2}.ki-badge{display:inline-block;padding:.15rem .4rem;border-radius:.25rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em}.ki-badge-ok{background:#d1fae5;color:#065f46}.ki-badge-warn{background:#fee2e2;color:#991b1b}.ki-badge-local{background:#dbeafe;color:#1e40af}.ki-server-select{font-size:.75rem;padding:.1rem .25rem;border-radius:.25rem;border:1px solid #cbd5e1;background:#fff;max-width:9rem}.ki-badge-error{background:#ef4444;color:#fff}.ki-toggle{padding:.25rem .6rem;border-radius:.375rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;border:none;cursor:pointer;transition:opacity .15s}.ki-toggle:disabled{opacity:.4;cursor:not-allowed}.ki-toggle-on{background:#10b981;color:#fff}.ki-toggle-off{background:#e2e8f0;color:#475569}.ki-actions{white-space:nowrap}.ki-actions>*{margin-left:.25rem}.ki-btn-icon,.ki-btn-secondary,.ki-btn-warn,.ki-btn-danger{padding:.25rem .6rem;border-radius:.375rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;border:none;cursor:pointer}.ki-btn-icon{background:#f1f5f9;color:#1e293b}.ki-btn-icon:disabled{opacity:.3;cursor:not-allowed}.ki-btn-secondary{background:#e0e7ff;color:#3730a3}.ki-btn-primary{background:#10b981;color:#fff}.ki-btn-warn{background:#fef3c7;color:#92400e}.ki-btn-danger{background:#fee2e2;color:#991b1b}.ki-btn-icon,.ki-btn-secondary,.ki-btn-primary,.ki-btn-warn,.ki-btn-danger{padding:.25rem .6rem;border-radius:.375rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;border:none;cursor:pointer}.ki-badge-active{background:#d1fae5;color:#065f46;border:1px solid #10b981}.ki-ok{color:#059669;font-weight:700}.ki-cooldown{color:#d97706;font-weight:700}.ki-error{color:#dc2626;font-weight:700}.ki-edit-row td{background:#f8fafc}.ki-edit-form{padding:.5rem .25rem}.ki-edit-title{font-size:.65rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#475569;margin:0 0 .6rem}.ki-edit-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(13rem,1fr));gap:.6rem}.ki-edit-field{display:flex;flex-direction:column;gap:.2rem}.ki-edit-label{font-size:.6rem;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:#64748b}.ki-edit-input{padding:.4rem .5rem;border:1px solid #cbd5e1;border-radius:.375rem;font-size:.8rem;background:#fff}.ki-edit-actions{display:flex;gap:.5rem;margin-top:.7rem}.ki-edit-actions>button{text-transform:uppercase}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.NgSelectOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.ɵNgSelectMultipleOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2.NumberValueAccessor, selector: "input[type=number][formControlName],input[type=number][formControl],input[type=number][ngModel]" }, { kind: "directive", type: i2.SelectControlValueAccessor, selector: "select:not([multiple])[formControlName],select:not([multiple])[formControl],select:not([multiple])[ngModel]", inputs: ["compareWith"] }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: KiPagerComponent, selector: "ki-pager", inputs: ["total", "page", "pageSize"], outputs: ["pageChange"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ModelsTableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-models-table', standalone: true, imports: [CommonModule, FormsModule, KiPagerComponent], template: `
    <div class="ki-models-table">
      <div class="ki-models-table-header">
        <h3 class="ki-section-title">{{ L.title }}</h3>
        <button (click)="reload()" class="ki-btn-secondary">↻ {{ L.refresh }}</button>
      </div>

      <input *ngIf="!loading() && models().length > 0"
        class="ki-filter" type="text" placeholder="Filtern…"
        [value]="filter()" (input)="setFilter($any($event.target).value)" />

      <div *ngIf="loading()" class="ki-muted">{{ L.loading }}</div>

      <div *ngIf="!loading() && models().length === 0" class="ki-empty">
        {{ L.empty }}
      </div>

      <!-- Phase R: Gruppierte Ansicht nach Routing-Kategorie. Jede Section
           rendert ihre eigene Tabelle. Reorder (Pfeile) ist innerhalb einer
           Kategorie scoped — globaler orderIdx wird im Hintergrund neu
           vergeben, aber Cross-Kategorie-Swap ist nicht erlaubt. -->
      <div *ngIf="models().length > 0">
        <div *ngFor="let group of categoriesByPool()" class="ki-pool-group">
          <h3 *ngIf="group.pool" class="ki-pool-title">{{ poolTitle(group.pool) }}</h3>
          <section *ngFor="let cat of group.cats" class="ki-category-section">
          <header class="ki-category-header">
            <h4 class="ki-category-title">{{ categoryTitle(cat) }}</h4>
            <p class="ki-category-hint">{{ categoryHint(cat) }}</p>
          </header>

          <div class="ki-table-wrap">
            <table class="ki-table">
              <thead>
                <tr>
                  <th>{{ L.colNum }}</th>
                  <th>{{ L.colProvider }}</th>
                  <th>{{ L.colModelId }}</th>
                  <th>{{ L.colKey }}</th>
                  <th>{{ L.colEnabled }}</th>
                  <th>{{ L.colStatus }}</th>
                  <th>{{ L.colServer }}</th>
                  <th class="ki-right">{{ L.colActions }}</th>
                </tr>
              </thead>
              <tbody>
                <ng-container *ngFor="let m of pagedModels(cat); let i = index">
                <tr [class.ki-row-auto-disabled]="m.autoDisabled">
                  <td class="ki-mono ki-muted">{{ catPage(cat) * pageSize + i + 1 }}</td>
                  <td class="ki-mono ki-provider">{{ m.provider }}</td>
                  <td class="ki-mono">
                    <strong>{{ m.modelId }}</strong>
                    <div *ngIf="m.displayName" class="ki-muted ki-tiny">{{ m.displayName }}</div>
                  </td>
                  <td>
                    <span *ngIf="isKeylessModel(m)" class="ki-badge ki-badge-local">{{ L.keyless }}</span>
                    <span *ngIf="!isKeylessModel(m) && m.keyConfigured" class="ki-badge ki-badge-ok">{{ L.keySet }}</span>
                    <span *ngIf="!isKeylessModel(m) && !m.keyConfigured" class="ki-badge ki-badge-warn">{{ L.keyMissing }}</span>
                    <div class="ki-tiny ki-mono ki-muted">{{ m.apiKeySettingKey }}</div>
                  </td>
                  <td>
                    <button *ngIf="!m.autoDisabled"
                            (click)="toggle(m)"
                            [disabled]="(!m.enabled && !m.keyConfigured && !isKeylessModel(m)) || (!m.enabled && m.hardwareCompatible === false)"
                            [title]="toggleDisabledReason(m)"
                            class="ki-toggle"
                            [class.ki-toggle-on]="m.enabled"
                            [class.ki-toggle-off]="!m.enabled">
                      {{ m.enabled ? L.on : L.off }}
                    </button>
                    <span *ngIf="m.autoDisabled" class="ki-badge ki-badge-error">🚫 {{ L.autoDisabled }}</span>
                  </td>
                  <td>
                    <span *ngIf="m.hardwareCompatible === false" class="ki-badge ki-badge-warn">⚠ {{ L.hardwareBlocked }}</span>
                    <span *ngIf="m.hardwareCompatible === false" class="ki-tiny ki-error" [title]="m.hardwareReason || ''">
                      {{ truncate(m.hardwareReason || '', 60) }}
                    </span>
                    <span *ngIf="m.autoDisabled" class="ki-tiny ki-error" [title]="m.autoDisabledReason || ''">
                      {{ truncate(m.autoDisabledReason || '', 60) }}
                    </span>
                    <span *ngIf="!m.autoDisabled && (m.cooldownRemainingSec ?? 0) > 0" class="ki-tiny ki-cooldown">
                      cd {{ m.cooldownRemainingSec }}s
                    </span>
                    <span *ngIf="!m.autoDisabled && !(m.cooldownRemainingSec ?? 0) && m.hardwareCompatible !== false" class="ki-tiny ki-ok">
                      {{ L.free }}
                    </span>
                    <div *ngIf="testResult()[m.id] as r" class="ki-tiny ki-mono"
                         [class.ki-ok]="r.ok"
                         [class.ki-error]="!r.ok && !r.pending">
                      <span *ngIf="r.pending">…</span>
                      <span *ngIf="r.ok">✓ {{ r.latencyMs }}ms</span>
                      <span *ngIf="!r.ok && !r.pending">✗ {{ truncate(r.error || '', 80) }}</span>
                    </div>
                  </td>
                  <td>
                    <select *ngIf="supportsCustomServer(m); else noServer"
                            class="ki-server-select"
                            (change)="setServer(m, $any($event.target).value)">
                      <option value="" [selected]="!m.providerServerName">{{ L.serverDefault }}</option>
                      <option *ngFor="let s of providerServers()" [value]="s.name"
                              [selected]="m.providerServerName === s.name">{{ s.name }}</option>
                    </select>
                    <ng-template #noServer><span class="ki-muted ki-tiny">—</span></ng-template>
                  </td>
                  <td class="ki-right ki-actions">
                    <button (click)="moveInCategory(cat, catPage(cat) * pageSize + i, -1)"
                            [disabled]="catPage(cat) * pageSize + i === 0"
                            class="ki-btn-icon">↑</button>
                    <button (click)="moveInCategory(cat, catPage(cat) * pageSize + i, 1)"
                            [disabled]="catPage(cat) * pageSize + i === modelsByCategory()[cat].length - 1"
                            class="ki-btn-icon">↓</button>
                    <button (click)="test(m)" class="ki-btn-secondary">{{ L.btnTest }}</button>
                    <span *ngIf="showActiveAction && isActiveModel(m)" class="ki-badge ki-badge-active">{{ L.activeBadge }}</span>
                    <button
                      *ngIf="showActiveAction && !isActiveModel(m) && (m.keyConfigured || isKeylessModel(m)) && !m.autoDisabled"
                      (click)="setActive(m)"
                      class="ki-btn-primary"
                    >{{ L.btnSetActive }}</button>
                    <button *ngIf="m.autoDisabled" (click)="reEnable(m)" class="ki-btn-warn">{{ L.btnReenable }}</button>
                    <button (click)="startEdit(m)" class="ki-btn-secondary">{{ L.btnEdit }}</button>
                    <button (click)="remove(m)" class="ki-btn-danger">{{ L.btnDelete }}</button>
                  </td>
                </tr>

                <!-- Inline-Edit-Zeile: erscheint unter der Modell-Zeile wenn der
                     Edit-Button geklickt wurde. Voll-Edit der Konfigurationsfelder
                     (Aktiv-Toggle + Reihenfolge haben eigene Controls oben). -->
                <tr *ngIf="editingId() === m.id" class="ki-edit-row">
                  <td [attr.colspan]="8">
                    <div class="ki-edit-form">
                      <h5 class="ki-edit-title">{{ L.editTitle }}</h5>
                      <div class="ki-edit-grid">
                        <label class="ki-edit-field">
                          <span class="ki-edit-label">{{ L.editFieldProvider }}</span>
                          <input [(ngModel)]="editForm.provider" class="ki-edit-input ki-mono" />
                        </label>
                        <label class="ki-edit-field">
                          <span class="ki-edit-label">{{ L.editFieldModelId }}</span>
                          <input [(ngModel)]="editForm.modelId" class="ki-edit-input ki-mono" />
                        </label>
                        <label class="ki-edit-field">
                          <span class="ki-edit-label">{{ L.editFieldDisplayName }}</span>
                          <input [(ngModel)]="editForm.displayName" class="ki-edit-input" />
                        </label>
                        <label class="ki-edit-field">
                          <span class="ki-edit-label">{{ L.editFieldCategory }}</span>
                          <input [(ngModel)]="editForm.category" class="ki-edit-input ki-mono" />
                        </label>
                        <label class="ki-edit-field">
                          <span class="ki-edit-label">{{ L.editFieldApiKeySettingKey }}</span>
                          <input [(ngModel)]="editForm.apiKeySettingKey" class="ki-edit-input ki-mono" />
                        </label>
                        <label class="ki-edit-field">
                          <span class="ki-edit-label">{{ L.editFieldCooldown }}</span>
                          <input [(ngModel)]="editForm.cooldown503OverrideSec" type="number" class="ki-edit-input ki-mono" />
                        </label>
                        <label *ngIf="editSupportsServer()" class="ki-edit-field">
                          <span class="ki-edit-label">{{ L.editFieldServer }}</span>
                          <select [(ngModel)]="editForm.providerServerName" class="ki-edit-input ki-mono">
                            <option [ngValue]="null">{{ L.serverDefault }}</option>
                            <option *ngFor="let s of providerServers()" [ngValue]="s.name">{{ s.name }}</option>
                          </select>
                        </label>
                      </div>
                      <p *ngIf="editError()" class="ki-tiny ki-error">{{ editError() }}</p>
                      <div class="ki-edit-actions">
                        <button (click)="saveEdit(m)" [disabled]="savingEdit()" class="ki-btn-primary">
                          {{ savingEdit() ? L.btnSaving : L.btnSave }}
                        </button>
                        <button (click)="cancelEdit()" [disabled]="savingEdit()" class="ki-btn-icon">{{ L.btnCancel }}</button>
                      </div>
                    </div>
                  </td>
                </tr>
                </ng-container>
              </tbody>
            </table>

            <ki-pager
              [total]="modelsByCategory()[cat].length"
              [page]="catPage(cat)"
              [pageSize]="pageSize"
              (pageChange)="setCatPage(cat, $event)">
            </ki-pager>
          </div>
          </section>
        </div>
      </div>
    </div>
  `, styles: [".ki-models-table{font-family:inherit}.ki-models-table-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:.75rem}.ki-section-title{font-size:.85rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#1e293b;margin:0}.ki-filter{width:100%;box-sizing:border-box;padding:.4rem .6rem;margin-bottom:1rem;border:1px solid #e2e8f0;border-radius:.375rem;font-size:.8rem}.ki-pool-group{margin-bottom:2.5rem}.ki-pool-group:last-child{margin-bottom:0}.ki-pool-title{font-size:.9rem;font-weight:900;letter-spacing:.02em;color:#0f172a;margin:0 0 1rem;padding-bottom:.4rem;border-bottom:2px solid #cbd5e1}.ki-category-section{margin-bottom:2rem}.ki-category-section:last-child{margin-bottom:0}.ki-category-header{margin-bottom:.5rem}.ki-category-title{font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.12em;color:#1e293b;margin:0 0 .15rem}.ki-category-hint{font-size:.7rem;color:#64748b;margin:0}.ki-muted{color:#888}.ki-tiny{font-size:.7rem}.ki-mono{font-family:ui-monospace,monospace}.ki-provider{color:#4f46e5;font-weight:700}.ki-empty{text-align:center;padding:2rem;color:#94a3b8;font-weight:600}.ki-table-wrap{overflow-x:auto;-webkit-overflow-scrolling:touch}.ki-table{width:100%;min-width:46rem;border-collapse:collapse;font-size:.875rem}.ki-table thead tr{border-bottom:2px solid #e2e8f0}.ki-table th{padding:.75rem .5rem;text-align:left;text-transform:uppercase;font-size:.625rem;font-weight:800;letter-spacing:.1em;color:#64748b}.ki-table td{padding:.75rem .5rem;border-bottom:1px solid #f1f5f9;vertical-align:top}.ki-right{text-align:right}.ki-row-auto-disabled{background:#fef2f2}.ki-badge{display:inline-block;padding:.15rem .4rem;border-radius:.25rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em}.ki-badge-ok{background:#d1fae5;color:#065f46}.ki-badge-warn{background:#fee2e2;color:#991b1b}.ki-badge-local{background:#dbeafe;color:#1e40af}.ki-server-select{font-size:.75rem;padding:.1rem .25rem;border-radius:.25rem;border:1px solid #cbd5e1;background:#fff;max-width:9rem}.ki-badge-error{background:#ef4444;color:#fff}.ki-toggle{padding:.25rem .6rem;border-radius:.375rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;border:none;cursor:pointer;transition:opacity .15s}.ki-toggle:disabled{opacity:.4;cursor:not-allowed}.ki-toggle-on{background:#10b981;color:#fff}.ki-toggle-off{background:#e2e8f0;color:#475569}.ki-actions{white-space:nowrap}.ki-actions>*{margin-left:.25rem}.ki-btn-icon,.ki-btn-secondary,.ki-btn-warn,.ki-btn-danger{padding:.25rem .6rem;border-radius:.375rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;border:none;cursor:pointer}.ki-btn-icon{background:#f1f5f9;color:#1e293b}.ki-btn-icon:disabled{opacity:.3;cursor:not-allowed}.ki-btn-secondary{background:#e0e7ff;color:#3730a3}.ki-btn-primary{background:#10b981;color:#fff}.ki-btn-warn{background:#fef3c7;color:#92400e}.ki-btn-danger{background:#fee2e2;color:#991b1b}.ki-btn-icon,.ki-btn-secondary,.ki-btn-primary,.ki-btn-warn,.ki-btn-danger{padding:.25rem .6rem;border-radius:.375rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;border:none;cursor:pointer}.ki-badge-active{background:#d1fae5;color:#065f46;border:1px solid #10b981}.ki-ok{color:#059669;font-weight:700}.ki-cooldown{color:#d97706;font-weight:700}.ki-error{color:#dc2626;font-weight:700}.ki-edit-row td{background:#f8fafc}.ki-edit-form{padding:.5rem .25rem}.ki-edit-title{font-size:.65rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#475569;margin:0 0 .6rem}.ki-edit-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(13rem,1fr));gap:.6rem}.ki-edit-field{display:flex;flex-direction:column;gap:.2rem}.ki-edit-label{font-size:.6rem;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:#64748b}.ki-edit-input{padding:.4rem .5rem;border:1px solid #cbd5e1;border-radius:.375rem;font-size:.8rem;background:#fff}.ki-edit-actions{display:flex;gap:.5rem;margin-top:.7rem}.ki-edit-actions>button{text-transform:uppercase}\n"] }]
        }], propDecorators: { activeModelChanged: [{
                type: Output
            }], modelChanged: [{
                type: Output
            }], labels: [{
                type: Input
            }], showActiveAction: [{
                type: Input
            }], activeModelId: [{
                type: Input
            }], categoryTitles: [{
                type: Input
            }], categoryHints: [{
                type: Input
            }], categoryOrder: [{
                type: Input
            }], visibleCategories: [{
                type: Input
            }], poolTitles: [{
                type: Input
            }], keylessProviders: [{
                type: Input
            }], pageSize: [{
                type: Input
            }] } });

/**
 * Form um ein neues AI-Modell zur Cascade hinzuzufügen.
 *
 * **Felder:**
 * - Provider-Dropdown (gemini, openai, anthropic, openrouter, deepseek, openai_compat)
 * - Model-ID-Combobox mit Provider-spezifischen Vorschlägen (datalist)
 * - apiKeySettingKey-Auswahl (vorbelegt aus existierenden API-Keys + Default per Provider)
 * - DisplayName (optional)
 * - Cooldown503OverrideSec (optional)
 * - Add-Button
 *
 * **Event:** `(modelCreated)` emittet das neue Model nach erfolgreichem POST.
 *
 * **Provider-Default-Keys:** Beim Provider-Wechsel wird `apiKeySettingKey`
 * automatisch auf `<provider>ApiKey` umgestellt (Convenience).
 */
class AddModelFormComponent {
    constructor() {
        this.modelCreated = new EventEmitter();
        this.L = ADD_MODEL_FORM_LABELS_EN;
        this.api = inject(KiModelsApiService);
        // Form state
        this.provider = 'gemini';
        this.modelId = '';
        this.apiKeySettingKey = 'geminiApiKey';
        this.displayName = '';
        /**
         * Aktuell gewählte Kategorie. Default `'content'` (Backward-Compat zu
         * EduPro-Setup). Konsumenten mit anderen Kategorie-Schemata setzen den
         * Default über `[defaultCategoryByProvider]` (siehe unten) oder ändern
         * `categoryOptions` in den Labels — die erste Option wird dann beim
         * Provider-Wechsel selektiert wenn kein Match passt.
         */
        this.category = 'content';
        this.cooldown503OverrideSec = null;
        /** v0.15.0 — gewählter Inferenz-Server (leer = Default „localhost"). */
        this.providerServerName = '';
        this.submitting = signal(false);
        this.error = signal(null);
        this.keys = signal([]);
        /** v0.15.0 — benannte Server fürs Dropdown (leer wenn Backend < 0.8.0). */
        this.providerServers = signal([]);
        /**
         * Kategorien aus dem Backend (v0.10.0 — `GET {base}/categories`). Wird im
         * `ngOnInit` befüllt; bei 404 (Backend ohne CategoryMeta-Endpoint) bleibt
         * das leer und das Dropdown fällt auf `L.categoryOptions` zurück
         * (Konsumenten-Labels — Backward-Compat zu EduPros utility/content/general).
         */
        this.categoriesFromBackend = signal([]);
        this.defaultSettingKey = {
            gemini: 'geminiApiKey',
            openai: 'openaiApiKey',
            anthropic: 'anthropicApiKey',
            openrouter: 'openrouterApiKey',
            deepseek: 'deepseekApiKey',
            ollama: 'ollamaApiKey',
            openai_compat: 'customApiKey',
        };
        /** Areas die im supermodel=AN-Modus als AN-Compounds klassifiziert werden. */
        this.ROLE_AREAS = new Set([
            'orchestrator', 'implement', 'review', 'research', 'dispatch'
        ]);
        this.defaultCategoryByProvider = {
            gemini: 'content',
            openai: 'content',
            anthropic: 'content',
            openrouter: 'general',
            deepseek: 'utility',
            ollama: 'utility',
            openai_compat: 'general',
        };
        this.modelIdSuggestionsByProvider = {
            gemini: [
                'gemini-2.5-flash',
                'gemini-2.5-flash-lite',
                'gemini-2.5-pro',
                'gemini-3-flash-preview',
                'gemini-3-pro-preview',
            ],
            // Ollama-Vorschläge — sortiert grob nach Größe (klein → groß).
            // Kleine Modelle (≤7B) laufen auf CPU-only-Servern; größere brauchen GPU
            // mit min. der angegebenen VRAM. Die ID ist nur ein Tipp im Dropdown —
            // Ollama pullt das Modell beim ersten Call automatisch wenn lokal nicht
            // vorhanden. Wer auf einer Firmen-Maschine mit 16+ GB VRAM arbeitet,
            // wählt entsprechend größere Modelle für mehr Qualität.
            ollama: [
                // ── Klein (CPU-tauglich, < 8 GB RAM) ──
                'llama3.2:3b', // 2 GB
                'gemma3:4b', // 3 GB
                'qwen2.5:7b-instruct', // 5 GB (knapp auf 8 GB RAM)
                'gemma3:12b', // 8 GB (braucht GPU für gute Speed)
                // ── Mittel (GPU empfohlen, 12-16 GB VRAM) ──
                'gemma2:27b', // ~16 GB VRAM
                'qwen2.5:14b-instruct', // ~10 GB VRAM
                'llama3.1:8b', // 6 GB VRAM
                // ── Groß (16-24 GB VRAM, Firmen-Hardware) ──
                'gemma4:24b', // ~16 GB VRAM (analog XDA-Artikel)
                'qwen3-coder:30b', // ~18 GB VRAM (Coding-Workhorse)
                'qwen2.5:32b-instruct', // ~20 GB VRAM
                // ── Sehr groß (40+ GB VRAM / Multi-GPU) ──
                'llama3.1:70b', // ~40 GB VRAM
                'qwen2.5:72b-instruct', // ~45 GB VRAM
            ],
            openai: [
                'gpt-4o',
                'gpt-4o-mini',
                'gpt-4.1',
                'gpt-4.1-mini',
                'o1-mini',
                'o1-preview',
            ],
            anthropic: [
                'claude-opus-4-7',
                'claude-sonnet-4-6',
                'claude-haiku-4-5-20251001',
            ],
            openrouter: [
                // Cloud-Hosted-Variante grosser Open-Source-Modelle — wenn man die
                // selbe Modell-Familie nutzen will ohne eigene GPU-Hardware. Praktisch
                // als Mittel-Tier zwischen lokal-klein und Premium-Cloud.
                'deepseek/deepseek-v4-flash',
                'deepseek/deepseek-v4-pro',
                'deepseek/deepseek-chat-v3.1',
                'meta-llama/llama-3.3-70b-instruct',
                'meta-llama/llama-3.3-70b-instruct:free',
                'meta-llama/llama-3.1-405b-instruct',
                'qwen/qwen3-coder-30b',
                'qwen/qwen-2.5-72b-instruct',
                'google/gemma-4-24b',
                'google/gemma-2-27b-it',
                'openai/gpt-oss-120b:free',
            ],
            deepseek: [
                'deepseek-v4-flash',
                'deepseek-v4-pro',
                'deepseek-chat',
            ],
            openai_compat: [],
        };
    }
    set labels(v) {
        this.L = { ...ADD_MODEL_FORM_LABELS_EN, ...(v ?? {}) };
    }
    ngOnInit() {
        this.api.listKeys().subscribe({
            next: (list) => this.keys.set(list),
            error: () => this.keys.set([]),
        });
        this.api.listProviderServers().subscribe({
            next: (list) => this.providerServers.set(list ?? []),
            error: () => this.providerServers.set([]),
        });
        this.api.listCategories().subscribe({
            next: (list) => {
                this.categoriesFromBackend.set(Array.isArray(list) ? list : []);
                // Wenn das aktuell selektierte `category` nicht im Backend-Set steckt
                // (z.B. EduPro mit utility/content/general gegen Switcher-Schema cloud/
                // free-only), nimm die erste Backend-Kategorie als Default — sonst
                // submitted die Form einen ungültigen Wert.
                const opts = this.categoryDropdownOptions();
                if (opts.length && !opts.some(o => o.value === this.category)) {
                    this.category = opts[0].value;
                }
            },
            error: () => this.categoriesFromBackend.set([]),
        });
    }
    onProviderChange() {
        const def = this.defaultSettingKey[this.provider];
        if (def)
            this.apiKeySettingKey = def;
        const cat = this.defaultCategoryByProvider[this.provider];
        // Default-Category nur setzen wenn sie auch im Dropdown ist (sonst hätte
        // der User eine selektierte Kategorie die das Dropdown nicht anzeigt).
        if (cat && this.categoryDropdownOptions().some(o => o.value === cat)) {
            this.category = cat;
        }
    }
    modelIdSuggestions() {
        return this.modelIdSuggestionsByProvider[this.provider] ?? [];
    }
    /**
     * Normalisiert die Kategorie-Eingabe live während des Tippens
     * — lowercase, Trim, Whitespace → `-`. Erlaubte Zeichen sind
     * `[a-z0-9_-]{1,50}`; alles andere wird stillschweigend entfernt
     * (Backend würde sonst auf `general` zurückfallen). v0.10.2 — Folge
     * der Umstellung von `<select>` auf `<input list>` damit neue
     * Kategorien per Freitext angelegt werden können.
     */
    onCategoryInput() {
        const raw = (this.category ?? '').toString().trim().toLowerCase();
        const cleaned = raw.replace(/\s+/g, '-').replace(/[^a-z0-9_-]/g, '').slice(0, 50);
        if (cleaned !== this.category)
            this.category = cleaned;
    }
    /**
     * Optionen für das Kategorie-Dropdown. Reihenfolge:
     *   1. Backend-Kategorien (`/api/categories`) — wenn vorhanden, nutzt
     *      `displayName` falls gesetzt sonst Capitalized `name`.
     *   2. `L.categoryOptions` aus den Labels (Konsumenten-Default) — Fallback
     *      für Backend-Versionen ohne CategoryMeta-Endpoint.
     *
     * So bekommt jeder Konsument automatisch SEINE Kategorien (Switcher:
     * cloud/free-only/…, EduPro: utility/content/general) ohne dass die
     * Library oder der Konsument das hardcodieren muss.
     */
    categoryDropdownOptions() {
        const backend = this.categoriesFromBackend();
        const source = backend.length > 0
            ? backend.map(c => ({
                value: c.name,
                label: c.displayName?.trim() || this.prettifyCategory(c.name),
            }))
            : this.L.categoryOptions;
        return this.applyModeFilter(source);
    }
    /**
     * Filtert Kategorien nach {@link supermodelOn}. Ein Category-Name matcht als
     * Rollen-Compound wenn er entweder exakt einem Rollen-Namen entspricht
     * (`implement`) oder dem Muster `{role}-{suffix}` folgt (`implement-cloud`).
     */
    applyModeFilter(opts) {
        if (this.supermodelOn === undefined)
            return opts;
        return opts.filter(o => {
            const isRole = this.isRoleCategory(o.value);
            return this.supermodelOn ? isRole : !isRole;
        });
    }
    isRoleCategory(name) {
        const n = (name ?? '').toLowerCase();
        if (this.ROLE_AREAS.has(n))
            return true;
        const dash = n.indexOf('-');
        if (dash <= 0)
            return false;
        return this.ROLE_AREAS.has(n.substring(0, dash));
    }
    prettifyCategory(c) {
        return c.replace(/[-_]+/g, ' ').replace(/\b\w/g, ch => ch.toUpperCase());
    }
    /** Existierende Settings als Optionen + Default-Settings die noch nicht in DB sind. */
    keyOptions() {
        const existing = new Map(this.keys().map((k) => [k.settingKey, k.configured]));
        // Default-settingKeys aus dem Mapping ergänzen (auch wenn DB sie noch nicht hat)
        Object.values(this.defaultSettingKey).forEach((sk) => {
            if (!existing.has(sk))
                existing.set(sk, false);
        });
        return Array.from(existing.entries())
            .map(([settingKey, configured]) => ({ settingKey, configured }))
            .sort((a, b) => a.settingKey.localeCompare(b.settingKey));
    }
    onSubmit() {
        if (!this.provider || !this.modelId || !this.apiKeySettingKey)
            return;
        this.submitting.set(true);
        this.error.set(null);
        const body = {
            provider: this.provider.trim(),
            modelId: this.modelId.trim(),
            apiKeySettingKey: this.apiKeySettingKey.trim(),
            displayName: this.displayName?.trim() || undefined,
            category: this.category,
            cooldown503OverrideSec: this.cooldown503OverrideSec,
            providerServerName: this.providerServerName || undefined,
        };
        this.api.createModel(body).subscribe({
            next: (created) => {
                this.modelCreated.emit(created);
                this.modelId = '';
                this.displayName = '';
                this.cooldown503OverrideSec = null;
                this.providerServerName = '';
                this.submitting.set(false);
            },
            error: (err) => {
                this.error.set(err?.error?.error ?? this.L.errorFailed);
                this.submitting.set(false);
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AddModelFormComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: AddModelFormComponent, isStandalone: true, selector: "ki-add-model-form", inputs: { labels: "labels", supermodelOn: "supermodelOn", defaultCategoryByProvider: "defaultCategoryByProvider" }, outputs: { modelCreated: "modelCreated" }, ngImport: i0, template: `
    <form class="ki-add-model-form" (ngSubmit)="onSubmit()" #f="ngForm">
      <h4 class="ki-form-title">{{ L.title }}</h4>

      <div class="ki-grid">
        <select [(ngModel)]="provider"
                name="provider"
                (change)="onProviderChange()"
                class="ki-input">
          <option *ngFor="let p of L.providerOptions" [value]="p.value">{{ p.label }}</option>
        </select>

        <input [(ngModel)]="modelId"
               name="modelId"
               list="ki-model-id-suggestions"
               [placeholder]="L.fieldModelId"
               class="ki-input ki-mono"
               required />
        <datalist id="ki-model-id-suggestions">
          <option *ngFor="let s of modelIdSuggestions()" [value]="s"></option>
        </datalist>

        <select [(ngModel)]="apiKeySettingKey"
                name="apiKeySettingKey"
                class="ki-input ki-mono">
          <option value="" disabled>{{ L.fieldApiKeySettingKey }}</option>
          <option *ngFor="let k of keyOptions()" [value]="k.settingKey">
            {{ k.settingKey }} {{ k.configured ? '✓' : '' }}
          </option>
        </select>

        <!-- v0.10.2: <input list> statt <select> — bestehende Kategorien werden
             als Vorschläge angezeigt, der User kann aber auch eine NEUE Kategorie
             frei tippen (z.B. "local", "ollama") und damit eine neue Cascade
             implizit anlegen. Backend (llm-cascade ≥ 0.5.0) akzeptiert jeden
             Identifier nach [a-z0-9_-]{1,50} und fällt sonst auf "general" zurück.
             -->
        <input [(ngModel)]="category"
               name="category"
               list="ki-category-suggestions"
               [placeholder]="L.fieldCategory"
               [attr.aria-label]="L.fieldCategory"
               class="ki-input ki-mono"
               (change)="onCategoryInput()" />
        <datalist id="ki-category-suggestions">
          <option *ngFor="let c of categoryDropdownOptions()" [value]="c.value">{{ c.label }}</option>
        </datalist>

        <input [(ngModel)]="displayName"
               name="displayName"
               [placeholder]="L.fieldDisplayName"
               class="ki-input" />

        <input [(ngModel)]="cooldown503OverrideSec"
               name="cooldown503OverrideSec"
               type="number"
               [placeholder]="L.fieldCooldownOverride"
               class="ki-input" />

        <!-- v0.15.0 — Inferenz-Server nur für lokale/self-hosted Provider
             (Ollama / openai_compat). Cloud-Provider haben feste Endpoints. -->
        <select *ngIf="provider === 'ollama' || provider === 'openai_compat'"
                [(ngModel)]="providerServerName"
                name="providerServerName"
                class="ki-input ki-mono"
                [attr.aria-label]="L.fieldProviderServer">
          <option value="">{{ L.providerServerDefault }}</option>
          <option *ngFor="let s of providerServers()" [value]="s.name">{{ s.name }}</option>
        </select>

        <button type="submit"
                [disabled]="submitting() || !provider || !modelId || !apiKeySettingKey"
                class="ki-btn-primary">
          {{ submitting() ? L.btnAdding : L.btnAdd }}
        </button>
      </div>

      <p *ngIf="error()" class="ki-error">{{ error() }}</p>
      <p class="ki-hint">{{ L.hint }}</p>
    </form>
  `, isInline: true, styles: [".ki-add-model-form{font-family:inherit;padding:1rem 0;border-top:1px solid #e2e8f0}.ki-form-title{font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#475569;margin-bottom:.75rem}.ki-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(12rem,1fr));gap:.75rem}.ki-input{padding:.75rem;background:#f8fafc;border:2px solid #f1f5f9;border-radius:.75rem;font-size:.875rem;font-weight:700}.ki-mono{font-family:ui-monospace,monospace}.ki-btn-primary{padding:.75rem 1rem;background:#0f172a;color:#fff;border:none;border-radius:1rem;text-transform:uppercase;font-weight:800;letter-spacing:.1em;font-size:.75rem;cursor:pointer;grid-column:span 2}.ki-btn-primary:disabled{opacity:.4;cursor:not-allowed}.ki-error{color:#b91c1c;font-weight:700;margin-top:.5rem;font-size:.75rem}.ki-hint{color:#94a3b8;font-size:.7rem;font-weight:700;margin-top:.75rem}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i2.NgSelectOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.ɵNgSelectMultipleOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2.NumberValueAccessor, selector: "input[type=number][formControlName],input[type=number][formControl],input[type=number][ngModel]" }, { kind: "directive", type: i2.SelectControlValueAccessor, selector: "select:not([multiple])[formControlName],select:not([multiple])[formControl],select:not([multiple])[ngModel]", inputs: ["compareWith"] }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: i2.NgForm, selector: "form:not([ngNoForm]):not([formGroup]),ng-form,[ngForm]", inputs: ["ngFormOptions"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AddModelFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-add-model-form', standalone: true, imports: [CommonModule, FormsModule], template: `
    <form class="ki-add-model-form" (ngSubmit)="onSubmit()" #f="ngForm">
      <h4 class="ki-form-title">{{ L.title }}</h4>

      <div class="ki-grid">
        <select [(ngModel)]="provider"
                name="provider"
                (change)="onProviderChange()"
                class="ki-input">
          <option *ngFor="let p of L.providerOptions" [value]="p.value">{{ p.label }}</option>
        </select>

        <input [(ngModel)]="modelId"
               name="modelId"
               list="ki-model-id-suggestions"
               [placeholder]="L.fieldModelId"
               class="ki-input ki-mono"
               required />
        <datalist id="ki-model-id-suggestions">
          <option *ngFor="let s of modelIdSuggestions()" [value]="s"></option>
        </datalist>

        <select [(ngModel)]="apiKeySettingKey"
                name="apiKeySettingKey"
                class="ki-input ki-mono">
          <option value="" disabled>{{ L.fieldApiKeySettingKey }}</option>
          <option *ngFor="let k of keyOptions()" [value]="k.settingKey">
            {{ k.settingKey }} {{ k.configured ? '✓' : '' }}
          </option>
        </select>

        <!-- v0.10.2: <input list> statt <select> — bestehende Kategorien werden
             als Vorschläge angezeigt, der User kann aber auch eine NEUE Kategorie
             frei tippen (z.B. "local", "ollama") und damit eine neue Cascade
             implizit anlegen. Backend (llm-cascade ≥ 0.5.0) akzeptiert jeden
             Identifier nach [a-z0-9_-]{1,50} und fällt sonst auf "general" zurück.
             -->
        <input [(ngModel)]="category"
               name="category"
               list="ki-category-suggestions"
               [placeholder]="L.fieldCategory"
               [attr.aria-label]="L.fieldCategory"
               class="ki-input ki-mono"
               (change)="onCategoryInput()" />
        <datalist id="ki-category-suggestions">
          <option *ngFor="let c of categoryDropdownOptions()" [value]="c.value">{{ c.label }}</option>
        </datalist>

        <input [(ngModel)]="displayName"
               name="displayName"
               [placeholder]="L.fieldDisplayName"
               class="ki-input" />

        <input [(ngModel)]="cooldown503OverrideSec"
               name="cooldown503OverrideSec"
               type="number"
               [placeholder]="L.fieldCooldownOverride"
               class="ki-input" />

        <!-- v0.15.0 — Inferenz-Server nur für lokale/self-hosted Provider
             (Ollama / openai_compat). Cloud-Provider haben feste Endpoints. -->
        <select *ngIf="provider === 'ollama' || provider === 'openai_compat'"
                [(ngModel)]="providerServerName"
                name="providerServerName"
                class="ki-input ki-mono"
                [attr.aria-label]="L.fieldProviderServer">
          <option value="">{{ L.providerServerDefault }}</option>
          <option *ngFor="let s of providerServers()" [value]="s.name">{{ s.name }}</option>
        </select>

        <button type="submit"
                [disabled]="submitting() || !provider || !modelId || !apiKeySettingKey"
                class="ki-btn-primary">
          {{ submitting() ? L.btnAdding : L.btnAdd }}
        </button>
      </div>

      <p *ngIf="error()" class="ki-error">{{ error() }}</p>
      <p class="ki-hint">{{ L.hint }}</p>
    </form>
  `, styles: [".ki-add-model-form{font-family:inherit;padding:1rem 0;border-top:1px solid #e2e8f0}.ki-form-title{font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#475569;margin-bottom:.75rem}.ki-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(12rem,1fr));gap:.75rem}.ki-input{padding:.75rem;background:#f8fafc;border:2px solid #f1f5f9;border-radius:.75rem;font-size:.875rem;font-weight:700}.ki-mono{font-family:ui-monospace,monospace}.ki-btn-primary{padding:.75rem 1rem;background:#0f172a;color:#fff;border:none;border-radius:1rem;text-transform:uppercase;font-weight:800;letter-spacing:.1em;font-size:.75rem;cursor:pointer;grid-column:span 2}.ki-btn-primary:disabled{opacity:.4;cursor:not-allowed}.ki-error{color:#b91c1c;font-weight:700;margin-top:.5rem;font-size:.75rem}.ki-hint{color:#94a3b8;font-size:.7rem;font-weight:700;margin-top:.75rem}\n"] }]
        }], propDecorators: { modelCreated: [{
                type: Output
            }], labels: [{
                type: Input
            }], supermodelOn: [{
                type: Input
            }], defaultCategoryByProvider: [{
                type: Input
            }] } });

/**
 * Tri-State Cooldown-Override-Panel.
 *
 * **States:**
 * - `null` (Default) — jedes Modell nutzt seine eigene Cooldown-Logik (Standard)
 * - `true` (Force ON) — Cooldown global erzwingen (auch wenn Modelle individuell deaktiviert haben)
 * - `false` (Force OFF) — Cooldown global deaktivieren (Tests / Debug)
 *
 * **Effective-Badge** zeigt den vom Backend resolved Endzustand (`effective`,
 * `effectiveCooldown`).
 */
class CascadeCooldownComponent {
    constructor() {
        this.L = CASCADE_COOLDOWN_LABELS_EN;
        this.api = inject(KiModelsApiService);
        this.loading = signal(true);
        this.config = signal(null);
    }
    set labels(v) {
        this.L = { ...CASCADE_COOLDOWN_LABELS_EN, ...(v ?? {}) };
    }
    ngOnInit() {
        this.refresh();
    }
    refresh() {
        this.loading.set(true);
        this.api.getCascadeConfig().subscribe({
            next: (cfg) => {
                this.config.set(cfg);
                this.loading.set(false);
            },
            error: () => this.loading.set(false),
        });
    }
    set(value) {
        if (this.config()?.cooldownOverride === value)
            return;
        this.api.setCascadeConfig({ cooldownOverride: value }).subscribe((cfg) => this.config.set(cfg));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CascadeCooldownComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CascadeCooldownComponent, isStandalone: true, selector: "ki-cascade-cooldown", inputs: { labels: "labels" }, ngImport: i0, template: `
    <div class="ki-cooldown" *ngIf="config() as cfg">
      <h4 class="ki-section-title">{{ L.title }}</h4>
      <p class="ki-subtitle">{{ L.subtitle }}</p>

      <div class="ki-controls">
        <button (click)="set(null)"
                class="ki-state-btn"
                [class.ki-state-active]="cfg.cooldownOverride === null"
                [class.ki-state-default]="cfg.cooldownOverride === null">
          {{ L.default }}
        </button>
        <button (click)="set(true)"
                class="ki-state-btn"
                [class.ki-state-active]="cfg.cooldownOverride === true"
                [class.ki-state-on]="cfg.cooldownOverride === true">
          {{ L.forceOn }}
        </button>
        <button (click)="set(false)"
                class="ki-state-btn"
                [class.ki-state-active]="cfg.cooldownOverride === false"
                [class.ki-state-off]="cfg.cooldownOverride === false">
          {{ L.forceOff }}
        </button>

        <span class="ki-effective-badge"
              [class.ki-effective-on]="cfg.effectiveCooldown"
              [class.ki-effective-off]="!cfg.effectiveCooldown">
          {{ cfg.effectiveCooldown ? L.effectiveOn : L.effectiveOff }}
        </span>
      </div>

      <p class="ki-hint">{{ L.hint }}</p>
    </div>

    <div *ngIf="!config() && loading()" class="ki-muted">{{ L.loading }}</div>
    <div *ngIf="!config() && !loading()" class="ki-error">{{ L.errorLoad }}</div>
  `, isInline: true, styles: [".ki-cooldown{font-family:inherit;padding:1.5rem 0}.ki-section-title{font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#475569;margin-bottom:.5rem}.ki-subtitle{color:#64748b;font-size:.75rem;font-weight:700;margin-bottom:1.25rem}.ki-controls{display:flex;flex-wrap:wrap;gap:.5rem;align-items:center}.ki-state-btn{padding:.6rem 1rem;border-radius:1rem;font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;border:none;cursor:pointer;background:#f1f5f9;color:#475569;transition:background .15s}.ki-state-btn:hover{background:#e2e8f0}.ki-state-active.ki-state-default{background:#0f172a;color:#fff}.ki-state-active.ki-state-on{background:#10b981;color:#fff}.ki-state-active.ki-state-off{background:#f59e0b;color:#fff}.ki-effective-badge{margin-left:auto;padding:.3rem .75rem;border-radius:999px;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em}.ki-effective-on{background:#d1fae5;color:#065f46}.ki-effective-off{background:#fef3c7;color:#92400e}.ki-hint{color:#94a3b8;font-size:.7rem;font-weight:700;margin-top:1rem}.ki-muted{color:#888}.ki-error{color:#b91c1c;font-weight:700}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CascadeCooldownComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-cascade-cooldown', standalone: true, imports: [CommonModule], template: `
    <div class="ki-cooldown" *ngIf="config() as cfg">
      <h4 class="ki-section-title">{{ L.title }}</h4>
      <p class="ki-subtitle">{{ L.subtitle }}</p>

      <div class="ki-controls">
        <button (click)="set(null)"
                class="ki-state-btn"
                [class.ki-state-active]="cfg.cooldownOverride === null"
                [class.ki-state-default]="cfg.cooldownOverride === null">
          {{ L.default }}
        </button>
        <button (click)="set(true)"
                class="ki-state-btn"
                [class.ki-state-active]="cfg.cooldownOverride === true"
                [class.ki-state-on]="cfg.cooldownOverride === true">
          {{ L.forceOn }}
        </button>
        <button (click)="set(false)"
                class="ki-state-btn"
                [class.ki-state-active]="cfg.cooldownOverride === false"
                [class.ki-state-off]="cfg.cooldownOverride === false">
          {{ L.forceOff }}
        </button>

        <span class="ki-effective-badge"
              [class.ki-effective-on]="cfg.effectiveCooldown"
              [class.ki-effective-off]="!cfg.effectiveCooldown">
          {{ cfg.effectiveCooldown ? L.effectiveOn : L.effectiveOff }}
        </span>
      </div>

      <p class="ki-hint">{{ L.hint }}</p>
    </div>

    <div *ngIf="!config() && loading()" class="ki-muted">{{ L.loading }}</div>
    <div *ngIf="!config() && !loading()" class="ki-error">{{ L.errorLoad }}</div>
  `, styles: [".ki-cooldown{font-family:inherit;padding:1.5rem 0}.ki-section-title{font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#475569;margin-bottom:.5rem}.ki-subtitle{color:#64748b;font-size:.75rem;font-weight:700;margin-bottom:1.25rem}.ki-controls{display:flex;flex-wrap:wrap;gap:.5rem;align-items:center}.ki-state-btn{padding:.6rem 1rem;border-radius:1rem;font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;border:none;cursor:pointer;background:#f1f5f9;color:#475569;transition:background .15s}.ki-state-btn:hover{background:#e2e8f0}.ki-state-active.ki-state-default{background:#0f172a;color:#fff}.ki-state-active.ki-state-on{background:#10b981;color:#fff}.ki-state-active.ki-state-off{background:#f59e0b;color:#fff}.ki-effective-badge{margin-left:auto;padding:.3rem .75rem;border-radius:999px;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em}.ki-effective-on{background:#d1fae5;color:#065f46}.ki-effective-off{background:#fef3c7;color:#92400e}.ki-hint{color:#94a3b8;font-size:.7rem;font-weight:700;margin-top:1rem}.ki-muted{color:#888}.ki-error{color:#b91c1c;font-weight:700}\n"] }]
        }], propDecorators: { labels: [{
                type: Input
            }] } });

/**
 * Section zur Verwaltung aller API-Keys (settingKey-basiert).
 *
 * **Form (oben):** settingKey-Picker + Value-Input (mit Show/Hide) + Save-Button.
 * Konsument kann beim Add eines neuen Models einen settingKey wählen, der noch
 * keinen Value hat — der bleibt offen bis er hier gesetzt wird.
 *
 * **Status-Liste (unten):** alle konfigurierten settingKeys mit:
 * - Badge: Source (`db` vom Admin gesetzt oder `env` vom Boot-Default)
 * - Wert maskiert
 * - Actions: Edit (lädt in Form oben), Clear (löscht den DB-Override)
 *
 * **Event:** `(keyChanged)` emittet bei jedem Save/Clear damit Konsument seine
 * Modell-Liste neu laden kann (key-Konfiguration ändert sich → Models-Status
 * `keyConfigured` ändert sich).
 */
class ApiKeysSectionComponent {
    constructor() {
        this.keyChanged = new EventEmitter();
        this.L = API_KEYS_SECTION_LABELS_EN;
        this.api = inject(KiModelsApiService);
        this.loading = signal(true);
        this.keys = signal([]);
        // Form state
        this.settingKey = '';
        this.value = '';
        this.showValue = signal(false);
        this.saving = signal(false);
        this.clearing = signal(null);
        /** Bekannte Default-Settings + ihre Brand-Labels (für Add-Form Vorschläge). */
        this.defaultCards = [
            { settingKey: 'geminiApiKey', brand: 'Gemini (Google)' },
            { settingKey: 'openaiApiKey', brand: 'OpenAI' },
            { settingKey: 'anthropicApiKey', brand: 'Anthropic' },
            { settingKey: 'openrouterApiKey', brand: 'OpenRouter' },
            { settingKey: 'deepseekApiKey', brand: 'DeepSeek' },
            { settingKey: 'customApiKey', brand: 'Custom (OpenAI-compat)' },
        ];
        this.configuredKeys = computed(() => this.keys().filter((k) => k.configured));
    }
    set labels(v) {
        this.L = { ...API_KEYS_SECTION_LABELS_EN, ...(v ?? {}) };
    }
    /** Default-Settings + dynamische (aus DB) als Options im Dropdown. */
    keyOptions() {
        const fromApi = new Set(this.keys().map((k) => k.settingKey));
        const dynamic = Array.from(fromApi)
            .filter((k) => !this.defaultCards.find((d) => d.settingKey === k))
            .map((k) => ({ settingKey: k, brand: 'Custom' }));
        return [...this.defaultCards, ...dynamic].sort((a, b) => a.settingKey.localeCompare(b.settingKey));
    }
    ngOnInit() {
        this.reload();
    }
    reload() {
        this.loading.set(true);
        this.api.listKeys().subscribe({
            next: (list) => {
                this.keys.set(list);
                this.loading.set(false);
            },
            error: () => this.loading.set(false),
        });
    }
    canSave() {
        return !!this.settingKey && !this.saving();
    }
    save() {
        if (!this.canSave())
            return;
        this.saving.set(true);
        this.api.setKey(this.settingKey, { value: this.value }).subscribe({
            next: () => {
                this.keyChanged.emit(this.settingKey);
                this.value = '';
                this.showValue.set(false);
                this.saving.set(false);
                this.reload();
            },
            error: () => this.saving.set(false),
        });
    }
    editKey(k) {
        this.settingKey = k.settingKey;
        this.value = '';
        this.showValue.set(false);
    }
    clearKey(k) {
        if (!confirm(this.L.confirmClear(k.settingKey)))
            return;
        this.clearing.set(k.settingKey);
        this.api.setKey(k.settingKey, { value: '' }).subscribe({
            next: () => {
                this.keyChanged.emit(k.settingKey);
                this.clearing.set(null);
                this.reload();
            },
            error: () => this.clearing.set(null),
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ApiKeysSectionComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ApiKeysSectionComponent, isStandalone: true, selector: "ki-api-keys-section", inputs: { labels: "labels" }, outputs: { keyChanged: "keyChanged" }, ngImport: i0, template: `
    <div class="ki-keys-section">
      <h4 class="ki-section-title">{{ L.title }}</h4>
      <p class="ki-subtitle">{{ L.subtitle }}</p>

      <!-- Add/Edit Form -->
      <div class="ki-form-grid">
        <select [(ngModel)]="settingKey" class="ki-input ki-mono">
          <option value="" disabled>{{ L.fieldSettingKey }}</option>
          <option *ngFor="let k of keyOptions()" [value]="k.settingKey">
            {{ k.settingKey }} — {{ k.brand }}
          </option>
        </select>

        <div class="ki-input-wrap">
          <input [(ngModel)]="value"
                 [type]="showValue() ? 'text' : 'password'"
                 [placeholder]="L.fieldValue"
                 autocomplete="off"
                 spellcheck="false"
                 class="ki-input ki-mono ki-input-with-toggle" />
          <button type="button" (click)="showValue.set(!showValue())" class="ki-show-toggle">
            {{ showValue() ? L.btnHide : L.btnShow }}
          </button>
        </div>

        <button (click)="save()"
                [disabled]="!canSave() || saving()"
                class="ki-btn-primary">
          {{ saving() ? L.btnSaving : L.btnSave }}
        </button>
      </div>

      <!-- Status-Liste -->
      <ng-container *ngIf="configuredKeys().length > 0; else noKeys">
        <h5 class="ki-list-title">{{ L.listTitle }}</h5>
        <div class="ki-table-wrap">
          <table class="ki-table">
            <thead>
              <tr>
                <th>{{ L.colSettingKey }}</th>
                <th>{{ L.colSource }}</th>
                <th>{{ L.colValue }}</th>
                <th class="ki-right">{{ L.colActions }}</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let k of configuredKeys()">
                <td class="ki-mono">
                  <strong>{{ k.settingKey }}</strong>
                </td>
                <td>
                  <span class="ki-badge"
                        [class.ki-badge-db]="k.keySource === 'db'"
                        [class.ki-badge-env]="k.keySource !== 'db'">
                    {{ k.keySource === 'db' ? L.sourceDb : (k.configured ? L.sourceEnv : L.sourceMissing) }}
                  </span>
                </td>
                <td class="ki-mono ki-value">{{ k.valueMasked || '…' }}</td>
                <td class="ki-right">
                  <button (click)="editKey(k)" class="ki-btn-secondary">{{ L.btnEdit }}</button>
                  <button *ngIf="k.keySource === 'db'"
                          (click)="clearKey(k)"
                          [disabled]="clearing() === k.settingKey"
                          class="ki-btn-danger">
                    {{ clearing() === k.settingKey ? '…' : L.btnClear }}
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </ng-container>
      <ng-template #noKeys>
        <p class="ki-empty">{{ L.empty }}</p>
      </ng-template>

      <p class="ki-hint">{{ L.hint }}</p>
    </div>
  `, isInline: true, styles: [".ki-keys-section{font-family:inherit;padding:1.5rem 0}.ki-section-title{font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#475569;margin-bottom:.5rem}.ki-subtitle{color:#64748b;font-size:.75rem;font-weight:700;margin-bottom:1.25rem}.ki-list-title{font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#94a3b8;margin:1.5rem 0 .75rem}.ki-form-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(12rem,1fr));gap:.75rem;margin-bottom:1rem}.ki-input{padding:.75rem;background:#f8fafc;border:2px solid #f1f5f9;border-radius:.75rem;font-size:.875rem;font-weight:700}.ki-mono{font-family:ui-monospace,monospace}.ki-input-wrap{position:relative}.ki-input-with-toggle{width:100%;padding-right:4rem;box-sizing:border-box}.ki-show-toggle{position:absolute;right:.75rem;top:50%;transform:translateY(-50%);padding:.25rem .5rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;background:transparent;border:none;color:#64748b;cursor:pointer}.ki-btn-primary{grid-column:span 2;padding:.75rem 1rem;background:#dc2626;color:#fff;border:none;border-radius:1rem;text-transform:uppercase;font-weight:800;letter-spacing:.1em;font-size:.75rem;cursor:pointer}.ki-btn-primary:disabled{opacity:.4;cursor:not-allowed}.ki-btn-secondary,.ki-btn-danger{padding:.3rem .7rem;border-radius:.375rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;border:none;cursor:pointer}.ki-btn-secondary{background:#f1f5f9;color:#1e293b;margin-right:.25rem}.ki-btn-danger{background:#fee2e2;color:#991b1b}.ki-btn-danger:disabled{opacity:.4;cursor:not-allowed}.ki-table-wrap{overflow-x:auto}.ki-table{width:100%;border-collapse:collapse;font-size:.875rem}.ki-table thead{border-bottom:1px solid #f1f5f9}.ki-table th{padding:.5rem;text-align:left;text-transform:uppercase;font-size:.625rem;font-weight:800;letter-spacing:.1em;color:#94a3b8}.ki-table td{padding:.75rem .5rem;border-bottom:1px solid #f1f5f9;vertical-align:middle}.ki-right{text-align:right}.ki-badge{display:inline-block;padding:.25rem .7rem;border-radius:999px;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em}.ki-badge-db{background:#d1fae5;color:#065f46}.ki-badge-env{background:#e2e8f0;color:#475569}.ki-value{color:#64748b}.ki-empty{color:#94a3b8;font-style:italic;font-size:.75rem;font-weight:700}.ki-hint{color:#94a3b8;font-size:.7rem;font-weight:700;margin-top:1rem}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.NgSelectOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.ɵNgSelectMultipleOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2.SelectControlValueAccessor, selector: "select:not([multiple])[formControlName],select:not([multiple])[formControl],select:not([multiple])[ngModel]", inputs: ["compareWith"] }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ApiKeysSectionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-api-keys-section', standalone: true, imports: [CommonModule, FormsModule], template: `
    <div class="ki-keys-section">
      <h4 class="ki-section-title">{{ L.title }}</h4>
      <p class="ki-subtitle">{{ L.subtitle }}</p>

      <!-- Add/Edit Form -->
      <div class="ki-form-grid">
        <select [(ngModel)]="settingKey" class="ki-input ki-mono">
          <option value="" disabled>{{ L.fieldSettingKey }}</option>
          <option *ngFor="let k of keyOptions()" [value]="k.settingKey">
            {{ k.settingKey }} — {{ k.brand }}
          </option>
        </select>

        <div class="ki-input-wrap">
          <input [(ngModel)]="value"
                 [type]="showValue() ? 'text' : 'password'"
                 [placeholder]="L.fieldValue"
                 autocomplete="off"
                 spellcheck="false"
                 class="ki-input ki-mono ki-input-with-toggle" />
          <button type="button" (click)="showValue.set(!showValue())" class="ki-show-toggle">
            {{ showValue() ? L.btnHide : L.btnShow }}
          </button>
        </div>

        <button (click)="save()"
                [disabled]="!canSave() || saving()"
                class="ki-btn-primary">
          {{ saving() ? L.btnSaving : L.btnSave }}
        </button>
      </div>

      <!-- Status-Liste -->
      <ng-container *ngIf="configuredKeys().length > 0; else noKeys">
        <h5 class="ki-list-title">{{ L.listTitle }}</h5>
        <div class="ki-table-wrap">
          <table class="ki-table">
            <thead>
              <tr>
                <th>{{ L.colSettingKey }}</th>
                <th>{{ L.colSource }}</th>
                <th>{{ L.colValue }}</th>
                <th class="ki-right">{{ L.colActions }}</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let k of configuredKeys()">
                <td class="ki-mono">
                  <strong>{{ k.settingKey }}</strong>
                </td>
                <td>
                  <span class="ki-badge"
                        [class.ki-badge-db]="k.keySource === 'db'"
                        [class.ki-badge-env]="k.keySource !== 'db'">
                    {{ k.keySource === 'db' ? L.sourceDb : (k.configured ? L.sourceEnv : L.sourceMissing) }}
                  </span>
                </td>
                <td class="ki-mono ki-value">{{ k.valueMasked || '…' }}</td>
                <td class="ki-right">
                  <button (click)="editKey(k)" class="ki-btn-secondary">{{ L.btnEdit }}</button>
                  <button *ngIf="k.keySource === 'db'"
                          (click)="clearKey(k)"
                          [disabled]="clearing() === k.settingKey"
                          class="ki-btn-danger">
                    {{ clearing() === k.settingKey ? '…' : L.btnClear }}
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </ng-container>
      <ng-template #noKeys>
        <p class="ki-empty">{{ L.empty }}</p>
      </ng-template>

      <p class="ki-hint">{{ L.hint }}</p>
    </div>
  `, styles: [".ki-keys-section{font-family:inherit;padding:1.5rem 0}.ki-section-title{font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#475569;margin-bottom:.5rem}.ki-subtitle{color:#64748b;font-size:.75rem;font-weight:700;margin-bottom:1.25rem}.ki-list-title{font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#94a3b8;margin:1.5rem 0 .75rem}.ki-form-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(12rem,1fr));gap:.75rem;margin-bottom:1rem}.ki-input{padding:.75rem;background:#f8fafc;border:2px solid #f1f5f9;border-radius:.75rem;font-size:.875rem;font-weight:700}.ki-mono{font-family:ui-monospace,monospace}.ki-input-wrap{position:relative}.ki-input-with-toggle{width:100%;padding-right:4rem;box-sizing:border-box}.ki-show-toggle{position:absolute;right:.75rem;top:50%;transform:translateY(-50%);padding:.25rem .5rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;background:transparent;border:none;color:#64748b;cursor:pointer}.ki-btn-primary{grid-column:span 2;padding:.75rem 1rem;background:#dc2626;color:#fff;border:none;border-radius:1rem;text-transform:uppercase;font-weight:800;letter-spacing:.1em;font-size:.75rem;cursor:pointer}.ki-btn-primary:disabled{opacity:.4;cursor:not-allowed}.ki-btn-secondary,.ki-btn-danger{padding:.3rem .7rem;border-radius:.375rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;border:none;cursor:pointer}.ki-btn-secondary{background:#f1f5f9;color:#1e293b;margin-right:.25rem}.ki-btn-danger{background:#fee2e2;color:#991b1b}.ki-btn-danger:disabled{opacity:.4;cursor:not-allowed}.ki-table-wrap{overflow-x:auto}.ki-table{width:100%;border-collapse:collapse;font-size:.875rem}.ki-table thead{border-bottom:1px solid #f1f5f9}.ki-table th{padding:.5rem;text-align:left;text-transform:uppercase;font-size:.625rem;font-weight:800;letter-spacing:.1em;color:#94a3b8}.ki-table td{padding:.75rem .5rem;border-bottom:1px solid #f1f5f9;vertical-align:middle}.ki-right{text-align:right}.ki-badge{display:inline-block;padding:.25rem .7rem;border-radius:999px;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em}.ki-badge-db{background:#d1fae5;color:#065f46}.ki-badge-env{background:#e2e8f0;color:#475569}.ki-value{color:#64748b}.ki-empty{color:#94a3b8;font-style:italic;font-size:.75rem;font-weight:700}.ki-hint{color:#94a3b8;font-size:.7rem;font-weight:700;margin-top:1rem}\n"] }]
        }], propDecorators: { keyChanged: [{
                type: Output
            }], labels: [{
                type: Input
            }] } });

/**
 * Generischer Failover-Chain-Editor — von beiden Konsumenten (Switcher +
 * EduPro) genutzt. Komponente ist „dumm": sie hält keinen Zustand, sondern
 * emittet `(chainChanged)` bei jeder Edit-Aktion. Der Konsument entscheidet
 * was mit der neuen Chain passiert:
 *
 * - **Switcher** persistiert sie in `_switcher.fallback_chain` (Wrapper liest
 *   das + restartet Claude Code bei Quota-Fehler entlang der Chain).
 * - **EduPro** mapped die Chain auf cascade-models-CRUD (`orderIdx`-Reorder
 *   bei Reorder, POST bei Add, DELETE bei Remove). Damit ist die Chain in
 *   EduPro effektiv die enabled-Modell-Liste in `orderIdx`-Reihenfolge.
 *
 * Switcher-spezifische Features (Aktuelle-Stufe-Indikator, Promote-Button)
 * sind hinter `[showChainPosition]="true"` gegated und in EduPro standardmäßig
 * ausgeblendet.
 *
 * **Inputs:**
 * - `chain` — aktuelle Chain (`{provider, model}[]`)
 * - `availableModels` — Optionen für Modell-Dropdown pro Provider
 * - `availableProviders` — Optionen für Provider-Dropdown
 * - `chainPosition` — aktive Stufe (0-basiert, null = keine)
 * - `showChainPosition` — gated Aktuelle-Stufe-Zeile + Promote-Button
 * - `labels` — i18n-Override
 *
 * **Outputs:**
 * - `chainChanged` — neue Chain nach jeder Edit-Aktion
 * - `promoteRequested` — User klickt „Zurück zu Stufe 1" (nur bei
 *   `showChainPosition && chainPosition > 0` sichtbar)
 */
class FailoverChainComponent {
    constructor() {
        /** Aktuelle Chain. Die Komponente mutiert sie in-place beim Editieren und emittet `chainChanged`. */
        this.chain = [];
        /** Optionen für die Modell-Dropdowns. Pro Provider eine Liste an Modellen. */
        this.availableModels = [];
        /** Optionen für die Provider-Dropdowns. Default: anthropic/google/openrouter. */
        this.availableProviders = [
            { value: 'anthropic', label: 'Anthropic' },
            { value: 'google', label: 'Google AI Studio' },
            { value: 'openrouter', label: 'OpenRouter' },
        ];
        /** Aktive Stufe (0-basiert). Nur relevant bei `showChainPosition=true`. */
        this.chainPosition = null;
        /** Gated die Aktuelle-Stufe-Zeile + Promote-Button (Switcher-only-Feature). */
        this.showChainPosition = false;
        this.L = FAILOVER_CHAIN_LABELS_EN;
        this.chainChanged = new EventEmitter();
        this.promoteRequested = new EventEmitter();
    }
    /** Optionale i18n-Override-Strings. */
    set labels(v) {
        this.L = { ...FAILOVER_CHAIN_LABELS_EN, ...(v ?? {}) };
    }
    modelsFor(provider) {
        return this.availableModels.filter((m) => m.provider === provider);
    }
    /**
     * Wie {@link modelsFor}, aber zusätzlich gefiltert auf Modelle, die NICHT
     * bereits in einer ANDEREN Chain-Zeile ausgewählt sind. Verhindert, dass
     * der User das gleiche `{provider, model}`-Paar mehrfach in die Chain
     * packt — würde im Konsumenten-Diff (z.B. EduPros `onFailoverChainChanged`)
     * zu Mehrdeutigkeit führen (welche Zeile gehört zu welchem cascade-Modell)
     * und den vorherigen Inhaber implizit löschen.
     */
    modelsForRow(provider, rowIdx) {
        const blocked = new Set();
        for (let j = 0; j < this.chain.length; j++) {
            if (j === rowIdx)
                continue;
            blocked.add(`${this.chain[j].provider}|${this.chain[j].model}`);
        }
        return this.availableModels
            .filter((m) => m.provider === provider)
            .filter((m) => !blocked.has(`${m.provider}|${m.modelId}`));
    }
    /**
     * Filtere `availableProviders` auf Provider, die mind. EIN `availableModels`-
     * Eintrag haben. Verhindert dass User Provider-Werte aus dem Dropdown picken,
     * für die kein Modell konfiguriert ist (würde sonst beim Aktivieren in einen
     * „kein Provider-Bean"-Backend-Fehler laufen).
     *
     * Beispiel EduPro (cascade-Namensraum): hat nur Modelle mit `provider:'gemini'`
     * → Dropdown zeigt nur „Google AI Studio". Selbst wenn der Konsument
     * `availableProviders` mit `[anthropic, google, openrouter]` overridet,
     * werden Optionen ohne Modelle ausgeblendet.
     */
    validProviders() {
        const have = new Set(this.availableModels.map((m) => m.provider));
        return this.availableProviders.filter((p) => have.has(p.value));
    }
    onProviderChange(idx) {
        // Beim Provider-Wechsel: Modell auf erstes verfügbares des neuen Providers
        // setzen, das nicht bereits in einer anderen Zeile steht.
        const first = this.modelsForRow(this.chain[idx].provider, idx)[0];
        if (first)
            this.chain[idx].model = first.modelId;
        this.emit();
    }
    /**
     * True wenn es noch ein verfügbares Modell gibt, das NICHT bereits in der
     * Chain steht. Steuert das Disabled-State des „+ Stufe"-Buttons — verhindert
     * Klick-Versuche die sonst ein Duplikat (oder keinen Row) erzeugen würden.
     */
    canAdd() {
        if (this.availableModels.length === 0)
            return false;
        const inChain = new Set(this.chain.map((r) => `${r.provider}|${r.model}`));
        return this.availableModels.some((m) => !inChain.has(`${m.provider}|${m.modelId}`));
    }
    /**
     * Neue Chain-Stufe = erstes `availableModels`-Eintrag, der noch NICHT in der
     * Chain ist. Verhindert Duplikate beim Klick auf „+ Stufe".
     */
    addRow() {
        const inChain = new Set(this.chain.map((r) => `${r.provider}|${r.model}`));
        const first = this.availableModels.find((m) => !inChain.has(`${m.provider}|${m.modelId}`));
        if (!first)
            return; // Alles schon in Chain — Button sollte disabled sein
        this.chain = [...this.chain, { provider: first.provider, model: first.modelId }];
        this.emit();
    }
    removeRow(idx) {
        this.chain = this.chain.filter((_, i) => i !== idx);
        this.emit();
    }
    moveUp(idx) {
        if (idx === 0)
            return;
        const next = [...this.chain];
        [next[idx - 1], next[idx]] = [next[idx], next[idx - 1]];
        this.chain = next;
        this.emit();
    }
    moveDown(idx) {
        if (idx >= this.chain.length - 1)
            return;
        const next = [...this.chain];
        [next[idx], next[idx + 1]] = [next[idx + 1], next[idx]];
        this.chain = next;
        this.emit();
    }
    positionLabel() {
        const pos = this.chainPosition ?? 0;
        const entry = this.chain[pos];
        if (!entry)
            return this.L.positionLabel(pos, '–', '–');
        return this.L.positionLabel(pos, entry.provider, entry.model);
    }
    emit() {
        this.chainChanged.emit([...this.chain]);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FailoverChainComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FailoverChainComponent, isStandalone: true, selector: "ki-failover-chain", inputs: { chain: "chain", availableModels: "availableModels", availableProviders: "availableProviders", chainPosition: "chainPosition", showChainPosition: "showChainPosition", labels: "labels" }, outputs: { chainChanged: "chainChanged", promoteRequested: "promoteRequested" }, ngImport: i0, template: `
    <div>
      <p class="text-sm text-slate-600 dark:text-slate-300 mb-3">
        <strong class="font-semibold text-slate-900 dark:text-slate-100">{{ L.title }}</strong>
        — {{ L.description }}
      </p>

      <div *ngIf="chain.length === 0" class="text-sm italic text-slate-500 dark:text-slate-400 mb-3">
        {{ L.emptyState }}
      </div>

      <div class="space-y-2">
        <div *ngFor="let row of chain; let i = index" class="flex items-center gap-2">
          <span class="w-6 text-xs font-bold text-slate-500 dark:text-slate-400">{{ i + 1 }}.</span>
          <select
            [(ngModel)]="row.provider"
            (change)="onProviderChange(i)"
            class="flex-1 min-w-0 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-2.5 py-1.5 text-sm text-slate-900 dark:text-slate-100"
          >
            <option *ngFor="let p of validProviders()" [value]="p.value">{{ p.label }}</option>
          </select>
          <select
            [(ngModel)]="row.model"
            (change)="emit()"
            class="flex-1 min-w-0 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-2.5 py-1.5 text-sm text-slate-900 dark:text-slate-100"
          >
            <option *ngFor="let m of modelsForRow(row.provider, i)" [value]="m.modelId">{{ m.displayName }}</option>
          </select>
          <button
            type="button"
            (click)="moveUp(i)"
            [disabled]="i === 0"
            [title]="L.moveUpTitle"
            class="w-7 h-7 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-500 hover:bg-slate-300 dark:hover:bg-slate-600 disabled:opacity-40 disabled:cursor-not-allowed transition"
          >↑</button>
          <button
            type="button"
            (click)="moveDown(i)"
            [disabled]="i === chain.length - 1"
            [title]="L.moveDownTitle"
            class="w-7 h-7 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-500 hover:bg-slate-300 dark:hover:bg-slate-600 disabled:opacity-40 disabled:cursor-not-allowed transition"
          >↓</button>
          <button
            type="button"
            (click)="removeRow(i)"
            *ngIf="chain.length > 1"
            [title]="L.removeRowTitle"
            class="w-7 h-7 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-500 hover:bg-red-500 hover:text-white transition"
          >×</button>
        </div>
      </div>

      <button
        type="button"
        (click)="addRow()"
        [disabled]="!canAdd()"
        class="mt-3 px-3 py-1.5 text-xs font-bold rounded-lg border border-dashed border-slate-400 dark:border-slate-600 text-slate-600 dark:text-slate-300 hover:border-slate-950 dark:hover:border-slate-50 hover:text-slate-950 dark:hover:text-slate-50 disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:border-slate-400 disabled:hover:text-slate-600 transition"
      >+ {{ L.addRow }}</button>

      <div *ngIf="showChainPosition" class="flex items-center gap-3 mt-4 pt-3 border-t border-dashed border-slate-300 dark:border-slate-700">
        <span class="text-xs text-slate-500 dark:text-slate-400">{{ L.currentStep }}</span>
        <span class="flex-1 text-sm text-slate-700 dark:text-slate-200">{{ positionLabel() }}</span>
        <button
          type="button"
          *ngIf="(chainPosition ?? 0) > 0"
          (click)="promoteRequested.emit()"
          class="px-3 py-1.5 text-xs font-bold rounded-lg bg-slate-950 dark:bg-slate-50 text-slate-50 dark:text-slate-950 hover:opacity-90 transition"
        >{{ L.promote }}</button>
      </div>

      <p class="mt-3 text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
        {{ L.hint }}
      </p>
    </div>
  `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.NgSelectOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.ɵNgSelectMultipleOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.SelectControlValueAccessor, selector: "select:not([multiple])[formControlName],select:not([multiple])[formControl],select:not([multiple])[ngModel]", inputs: ["compareWith"] }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FailoverChainComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ki-failover-chain',
                    standalone: true,
                    imports: [CommonModule, FormsModule],
                    template: `
    <div>
      <p class="text-sm text-slate-600 dark:text-slate-300 mb-3">
        <strong class="font-semibold text-slate-900 dark:text-slate-100">{{ L.title }}</strong>
        — {{ L.description }}
      </p>

      <div *ngIf="chain.length === 0" class="text-sm italic text-slate-500 dark:text-slate-400 mb-3">
        {{ L.emptyState }}
      </div>

      <div class="space-y-2">
        <div *ngFor="let row of chain; let i = index" class="flex items-center gap-2">
          <span class="w-6 text-xs font-bold text-slate-500 dark:text-slate-400">{{ i + 1 }}.</span>
          <select
            [(ngModel)]="row.provider"
            (change)="onProviderChange(i)"
            class="flex-1 min-w-0 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-2.5 py-1.5 text-sm text-slate-900 dark:text-slate-100"
          >
            <option *ngFor="let p of validProviders()" [value]="p.value">{{ p.label }}</option>
          </select>
          <select
            [(ngModel)]="row.model"
            (change)="emit()"
            class="flex-1 min-w-0 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-2.5 py-1.5 text-sm text-slate-900 dark:text-slate-100"
          >
            <option *ngFor="let m of modelsForRow(row.provider, i)" [value]="m.modelId">{{ m.displayName }}</option>
          </select>
          <button
            type="button"
            (click)="moveUp(i)"
            [disabled]="i === 0"
            [title]="L.moveUpTitle"
            class="w-7 h-7 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-500 hover:bg-slate-300 dark:hover:bg-slate-600 disabled:opacity-40 disabled:cursor-not-allowed transition"
          >↑</button>
          <button
            type="button"
            (click)="moveDown(i)"
            [disabled]="i === chain.length - 1"
            [title]="L.moveDownTitle"
            class="w-7 h-7 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-500 hover:bg-slate-300 dark:hover:bg-slate-600 disabled:opacity-40 disabled:cursor-not-allowed transition"
          >↓</button>
          <button
            type="button"
            (click)="removeRow(i)"
            *ngIf="chain.length > 1"
            [title]="L.removeRowTitle"
            class="w-7 h-7 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-500 hover:bg-red-500 hover:text-white transition"
          >×</button>
        </div>
      </div>

      <button
        type="button"
        (click)="addRow()"
        [disabled]="!canAdd()"
        class="mt-3 px-3 py-1.5 text-xs font-bold rounded-lg border border-dashed border-slate-400 dark:border-slate-600 text-slate-600 dark:text-slate-300 hover:border-slate-950 dark:hover:border-slate-50 hover:text-slate-950 dark:hover:text-slate-50 disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:border-slate-400 disabled:hover:text-slate-600 transition"
      >+ {{ L.addRow }}</button>

      <div *ngIf="showChainPosition" class="flex items-center gap-3 mt-4 pt-3 border-t border-dashed border-slate-300 dark:border-slate-700">
        <span class="text-xs text-slate-500 dark:text-slate-400">{{ L.currentStep }}</span>
        <span class="flex-1 text-sm text-slate-700 dark:text-slate-200">{{ positionLabel() }}</span>
        <button
          type="button"
          *ngIf="(chainPosition ?? 0) > 0"
          (click)="promoteRequested.emit()"
          class="px-3 py-1.5 text-xs font-bold rounded-lg bg-slate-950 dark:bg-slate-50 text-slate-50 dark:text-slate-950 hover:opacity-90 transition"
        >{{ L.promote }}</button>
      </div>

      <p class="mt-3 text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
        {{ L.hint }}
      </p>
    </div>
  `,
                }]
        }], propDecorators: { chain: [{
                type: Input
            }], availableModels: [{
                type: Input
            }], availableProviders: [{
                type: Input
            }], chainPosition: [{
                type: Input
            }], showChainPosition: [{
                type: Input
            }], labels: [{
                type: Input
            }], chainChanged: [{
                type: Output
            }], promoteRequested: [{
                type: Output
            }] } });

/**
 * Phase S' (2026-05-21) — Wrapper-Komponente die N Cascade-Bereiche als
 * eigenständige Karten rendert. Jeder Bereich hat seine eigene
 * Failover-Chain + Cooldown-Anzeige.
 *
 * **Vertrag:** Backend liefert per {@code GET /cascades} eine Liste der
 * Cascade-Namen mit Stats. Pro Name filtert dieser Wrapper die Modelle aus
 * {@code /ai-models} nach {@code category=name} (plus {@code "general"} als
 * Fallback wenn der Name nicht selbst "general" ist) und übergibt die
 * Subset-Liste der "dummen" `<ki-failover-chain>`.
 *
 * **Reorder-Verhalten:** Wenn der Admin Up/Down innerhalb einer Cascade
 * drückt, mappt der Wrapper das in eine globale `reorderModels()`-Anfrage:
 * er nimmt die aktuelle Globale Liste, swappt nur die beiden Modelle der
 * jeweiligen Cascade, übermittelt die neue globale Reihenfolge.
 *
 * **Backward-Compat:** Wenn das Backend `/cascades` nicht kennt oder `[]`
 * liefert, zeigt die Komponente einen leeren Zustand mit Hinweis-Text
 * (Konsument kann dann auf alte 3-Categories-Tabellen fallback).
 */
class CascadesViewComponent {
    constructor() {
        this.L = CASCADES_VIEW_LABELS_EN;
        /**
         * Optional: Pro Cascade-Name eine Sub-Hint (z.B. „Lehrinhalte, Prüfungen, Chat").
         * Wenn nicht gesetzt, wird der Default-Hint aus `L.defaultHint` genommen.
         */
        this.hintByCascade = {};
        /** Provider-Optionen für das Dropdown im Failover-Editor. */
        this.providerOptions = [
            { value: 'gemini', label: 'Gemini (Google)' },
            { value: 'openai', label: 'OpenAI' },
            { value: 'anthropic', label: 'Anthropic' },
            { value: 'openrouter', label: 'OpenRouter' },
            { value: 'deepseek', label: 'DeepSeek' },
            { value: 'ollama', label: 'Ollama (local)' },
            { value: 'openai_compat', label: 'Custom OpenAI-compatible' },
        ];
        /** Wird emittet wenn der Admin in einer der Cascades reordert oder Modelle tauscht. */
        this.cascadeChanged = new EventEmitter();
        this.api = inject(KiModelsApiService);
        this.loading = signal(true);
        this.cascades = signal([]);
        this.allModels = signal([]);
        /**
         * Optionale Whitelist sichtbarer Cascade-Namen. `null`/`undefined` (Default) →
         * alle vom Backend gelieferten (bereits pool-gefilterten) Cascaden werden
         * gezeigt. Wird eine Liste gesetzt, werden NUR diese gerendert — der Switcher
         * blendet so je nach Supermodell-Zustand entweder nur die Pool-Cascade oder
         * nur die Rollen-Cascaden ein.
         */
        this._visibleCascades = signal(null);
        /**
         * Pool-Anzeigenamen für die Pool-gruppierte Matrix. Nur genutzt, wenn eine
         * `visibleCascades`-Whitelist gesetzt ist (Switcher-Fall) — dann werden die
         * Cascade-Cards zusätzlich nach Pool (cloud → free → local) gruppiert.
         */
        this.poolTitles = {
            cloud: 'Cloud — Premium (bezahlt)',
            free: 'Free — OpenRouter :free',
            local: 'Lokal — Ollama (privat)',
        };
        /** Cascaden nach optionaler Whitelist gefiltert (Template iteriert darüber). */
        this.displayedCascades = computed(() => {
            const allow = this._visibleCascades();
            const list = this.cascades();
            if (allow == null)
                return list;
            const set = new Set(allow);
            return list.filter((c) => set.has(c.name));
        });
        /** Bekannte Pools in Anzeige-Reihenfolge. */
        this.POOL_ORDER = ['cloud', 'free', 'local'];
        /**
         * Pool-gruppierte Cascade-Cards — nur aktiv, wenn eine `visibleCascades`-
         * Whitelist gesetzt ist. Reihenfolge cloud → free → local, innerhalb eines
         * Pools die bestehende `displayedCascades`-Ordnung. Nicht-poolbare Cascaden
         * (z.B. 'general') landen ohne Header in einer letzten Gruppe (key null).
         */
        this.cascadesByPool = computed(() => {
            const list = this.displayedCascades();
            if (this._visibleCascades() == null)
                return [{ pool: null, cascades: list }];
            const byPool = new Map();
            for (const c of list) {
                const p = this.poolOf(c.name);
                if (!byPool.has(p))
                    byPool.set(p, []);
                byPool.get(p).push(c);
            }
            const groups = [];
            for (const pool of this.POOL_ORDER) {
                const g = byPool.get(pool);
                if (g?.length)
                    groups.push({ pool, cascades: g });
            }
            const rest = byPool.get(null);
            if (rest?.length)
                groups.push({ pool: null, cascades: rest });
            return groups;
        });
        /**
         * Display-Metadaten pro Kategorie (v0.10.0). Wird beim init aus
         * `GET {base}/categories` geladen. Wenn der Endpoint nicht existiert
         * (Backward-Compat zu llm-cascade < 0.5), bleibt das Array leer und das
         * UI fällt auf den `[hintByCascade]`-Input bzw. `L.defaultHint` zurück.
         */
        this.categoriesMeta = signal([]);
        /**
         * Inline-Edit-State: Name der Kategorie die gerade editiert wird (oder
         * `null` wenn kein Edit aktiv). `editText` ist der aktuelle Textarea-Wert.
         * `saving` blockiert die Buttons während des PUT-Roundtrips.
         */
        this.editing = signal(null);
        this.editText = '';
        this.saving = signal(false);
        /**
         * v0.11.2 — separates Edit-State für displayName. Title + Description
         * können nicht gleichzeitig editiert werden — das Edit-Modell ist
         * exclusive pro Cascade-Card.
         */
        this.editingTitle = signal(null);
        this.editTitleText = '';
        this.savingTitle = signal(false);
        /**
         * v0.11.1 — beim Klick auf das Trash-Icon wird der Cascade-Name hier
         * gespeichert bis der DELETE-Roundtrip durch ist. So koennen wir nur den
         * gerade in Bearbeitung befindlichen Button disablen, nicht alle.
         */
        this.deletingMeta = signal(null);
        /**
         * Pro Cascade-Name die Chain (Array<{provider, model}>) als computed-Signal.
         * Stabile Referenz solange sich allModels nicht ändert — verhindert CD-Storms
         * im Failover-Chain-Child und stellt sicher dass die Berechnung erst läuft
         * wenn allModels wirklich befüllt ist.
         */
        this.chainsByCascade = computed(() => {
            const result = {};
            const models = this.allModels();
            const enabledOnly = models.filter(m => m.enabled && !m.autoDisabled);
            for (const c of this.cascades()) {
                const name = c.name.toLowerCase();
                const subset = enabledOnly.filter(m => {
                    const cat = (m.category ?? 'general').toLowerCase();
                    return cat === name || (name !== 'general' && cat === 'general');
                });
                result[c.name] = subset.map(m => ({ provider: m.provider, model: m.modelId }));
            }
            return result;
        });
        /**
         * Provider-Modell-Dropdown-Optionen (stable ref). Zeigt ALLE konfigurierten
         * Modelle an — auch deaktivierte (AUS) — damit die Cascade-Bereiche die eine
         * Verwaltungsfläche sind: genau die Modelle aus der Tabelle sind hier wählbar.
         * Nur autoDisabled (tot/wiederholt fehlgeschlagen) bleibt raus. Ein im Chain
         * gewähltes Modell wird in {@link #onChainChanged} automatisch aktiviert.
         */
        this.availableModelsAll = computed(() => {
            return this.allModels()
                .filter(m => !m.autoDisabled)
                .map(m => ({
                provider: m.provider,
                modelId: m.modelId,
                displayName: m.displayName ?? m.modelId,
            }));
        });
        /** Auto-Refresh (Sekunden). Default 0 = AUS: die View lädt nur beim Init und
         *  danach ausschließlich über den manuellen Refresh-Button. Periodisches
         *  Reload ließ den ganzen Bereich im Sekundentakt flackern. Opt-in bleibt
         *  möglich, indem ein Konsument einen Wert > 0 setzt. */
        this.autoRefreshSec = 0;
        this.refreshTimer = null;
    }
    set labels(v) {
        this.L = { ...CASCADES_VIEW_LABELS_EN, ...(v ?? {}) };
    }
    set visibleCascades(v) {
        this._visibleCascades.set(v ?? null);
    }
    /**
     * Leitet den Pool eines Cascade-Namens ab (analog models-table):
     *   bare Pool → Pool; 'free-only' → 'free'; Compound '{x}-{pool}' → Suffix;
     *   sonst → null.
     */
    poolOf(name) {
        if (name === 'free-only')
            return 'free';
        if (this.POOL_ORDER.includes(name))
            return name;
        const idx = name.lastIndexOf('-');
        if (idx >= 0) {
            const suffix = name.slice(idx + 1);
            if (this.POOL_ORDER.includes(suffix))
                return suffix;
        }
        return null;
    }
    /** Header-Label für eine Pool-Gruppe. */
    poolTitle(pool) {
        return this.poolTitles[pool]
            || pool.replace(/[-_]+/g, ' ').replace(/\b\w/g, ch => ch.toUpperCase());
    }
    ngOnInit() {
        this.reload();
        if (this.autoRefreshSec > 0) {
            this.refreshTimer = setInterval(() => this.reload(), this.autoRefreshSec * 1000);
        }
    }
    ngOnDestroy() {
        if (this.refreshTimer)
            clearInterval(this.refreshTimer);
        this.refreshTimer = null;
    }
    reload() {
        this.loading.set(true);
        // Parallel laden — Cascades-Stats + Modelle (für Filter pro Cascade) +
        // Categories-Display-Metadaten (v0.10.0). `firstValueFrom` statt
        // `.toPromise()`. Categories ist optional (404 → leer fallback).
        Promise.all([
            firstValueFrom(this.api.listCascades()).catch(() => []),
            firstValueFrom(this.api.listModels()).catch(() => []),
            firstValueFrom(this.api.listCategories()).catch(() => []),
        ]).then(([cs, ms, cats]) => {
            this.cascades.set(Array.isArray(cs) ? cs : []);
            this.allModels.set(Array.isArray(ms) ? ms : []);
            this.categoriesMeta.set(Array.isArray(cats) ? cats : []);
            this.loading.set(false);
        });
    }
    /**
     * Title-Lookup-Reihenfolge:
     *   1. `displayName` aus den Categories-Metadaten (User hat's gesetzt)
     *   2. Roher Cascade-Name (rückwärtskompatibel, bisheriges Verhalten)
     *
     * Der Cascade-Name selbst kommt vom Backend `/cascades` und ist bereits
     * der Kategorie-Identifier — wir capitalisieren ihn NICHT zusätzlich, weil
     * die alten UIs ihn bereits via `uppercase`-CSS rendern.
     */
    titleFor(cascadeName) {
        const meta = this.categoriesMeta().find(c => c.name === cascadeName.toLowerCase());
        return meta?.displayName?.trim() || cascadeName;
    }
    /**
     * Hint-Lookup-Reihenfolge:
     *   1. `description` aus den Categories-Metadaten (User-edit per Inline-Edit)
     *   2. `[hintByCascade]`-Input vom Konsumenten (sein hardcoded Default)
     *   3. `L.defaultHint` (Library-Englisch-Fallback)
     */
    hintFor(cascadeName) {
        const key = cascadeName.toLowerCase();
        const meta = this.categoriesMeta().find(c => c.name === key);
        return meta?.description?.trim()
            || this.hintByCascade[key]
            || this.L.defaultHint;
    }
    /** Klick auf den Hint → Edit-Mode aktivieren mit aktuellem Wert vorbefüllt. */
    startEdit(cascadeName) {
        const key = cascadeName.toLowerCase();
        const meta = this.categoriesMeta().find(c => c.name === key);
        // Vorgeladener Text: NUR die persistierte description, NICHT der Konsumenten-
        // Default — User soll nicht versehentlich den Hardcode festschreiben.
        this.editText = meta?.description ?? '';
        this.editing.set(cascadeName);
    }
    /** Escape oder Cancel-Button → Edit-Mode verlassen ohne Save. */
    cancelEdit() {
        this.editing.set(null);
        this.editText = '';
    }
    /**
     * Save-Button (oder Enter): PUT der neuen description an
     * `/categories/{name}`. Leerer String → wird als `null` gesendet
     * (Backend löscht das Feld), damit der Konsument-Default wieder greift.
     */
    saveEdit(cascadeName) {
        const key = cascadeName.toLowerCase();
        const trimmed = (this.editText ?? '').trim();
        this.saving.set(true);
        this.api.updateCategory(key, {
            description: trimmed.length === 0 ? null : trimmed,
        }).subscribe({
            next: () => {
                // Lokale Metadaten-Liste sofort patchen damit die UI ohne Reload
                // den neuen Wert zeigt — der nächste reload() würde es zwar auch
                // holen, aber der UX-Lag wäre sichtbar.
                const list = [...this.categoriesMeta()];
                const idx = list.findIndex(c => c.name === key);
                if (idx >= 0) {
                    list[idx] = { ...list[idx], description: trimmed || null };
                }
                else {
                    list.push({ name: key, description: trimmed || null });
                }
                this.categoriesMeta.set(list);
                this.editing.set(null);
                this.editText = '';
                this.saving.set(false);
            },
            error: (e) => {
                console.error('[ki-cascades-view] saveEdit failed', e);
                this.saving.set(false);
            },
        });
    }
    hasCooldown(c) {
        return c.cooldownSec && Object.keys(c.cooldownSec).length > 0;
    }
    /**
     * v0.11.2 — Inline-Edit für displayName. Click auf den Title öffnet ein
     * Input-Feld. Persistiert via PUT /api/categories/{name} mit nur dem
     * displayName-Feld (description bleibt unangetastet).
     */
    startEditTitle(cascadeName) {
        const key = cascadeName.toLowerCase();
        const meta = this.categoriesMeta().find(c => c.name === key);
        // Vorgeladener Text: NUR der persistierte displayName, NICHT der
        // capitalized Fallback — User soll nicht versehentlich den Fallback
        // als seinen eigenen Wert festschreiben.
        this.editTitleText = meta?.displayName ?? '';
        this.editingTitle.set(cascadeName);
    }
    cancelEditTitle() {
        this.editingTitle.set(null);
        this.editTitleText = '';
    }
    saveEditTitle(cascadeName) {
        const key = cascadeName.toLowerCase();
        const trimmed = (this.editTitleText ?? '').trim();
        this.savingTitle.set(true);
        this.api.updateCategory(key, {
            displayName: trimmed.length === 0 ? null : trimmed,
        }).subscribe({
            next: () => {
                const list = [...this.categoriesMeta()];
                const idx = list.findIndex(c => c.name === key);
                if (idx >= 0) {
                    list[idx] = { ...list[idx], displayName: trimmed || null };
                }
                else {
                    list.push({ name: key, displayName: trimmed || null });
                }
                this.categoriesMeta.set(list);
                this.editingTitle.set(null);
                this.editTitleText = '';
                this.savingTitle.set(false);
            },
            error: (e) => {
                console.error('[ki-cascades-view] saveEditTitle failed', e);
                this.savingTitle.set(false);
            },
        });
    }
    /**
     * v0.11.1 — true wenn fuer diese Kategorie eine `category_meta`-Zeile
     * im Backend existiert (User hat displayName oder description gesetzt).
     * Trash-Icon wird nur dann angezeigt — sonst gaebe es nichts zu loeschen.
     */
    hasMeta(cascadeName) {
        const key = cascadeName.toLowerCase();
        const meta = this.categoriesMeta().find(c => c.name === key);
        if (!meta)
            return false;
        const hasTitle = !!meta.displayName && meta.displayName.trim().length > 0;
        const hasDesc = !!meta.description && meta.description.trim().length > 0;
        return hasTitle || hasDesc;
    }
    /**
     * v0.11.1 — DELETE der `category_meta`-Zeile. Modelle bleiben unangetastet,
     * der Cascade-Bereich verschwindet erst wenn auch die Modelle weg sind
     * (oder umkategoriiert wurden). Nach Erfolg lokales Patchen + Reload.
     */
    deleteMeta(cascadeName) {
        const key = cascadeName.toLowerCase();
        if (!confirm(this.L.deleteMetaConfirm(this.titleFor(cascadeName))))
            return;
        this.deletingMeta.set(key);
        this.api.deleteCategoryMeta(key).subscribe({
            next: () => {
                // Lokal patchen damit Title + Description sofort auf Fallback gehen
                const list = this.categoriesMeta().map(c => c.name === key ? { ...c, displayName: null, description: null } : c);
                this.categoriesMeta.set(list);
                this.deletingMeta.set(null);
            },
            error: (e) => {
                console.error('[ki-cascades-view] deleteMeta failed', e);
                this.deletingMeta.set(null);
            },
        });
    }
    cooldownEntries(c) {
        return Object.entries(c.cooldownSec || {})
            .map(([key, sec]) => ({ key, sec: sec }));
    }
    /**
     * Cascade-scoped Reorder: nimmt die neue Cascade-spezifische Chain vom
     * Failover-Editor und übersetzt das in eine globale `reorderModels()`-
     * Anfrage. Die globale Liste wird so umsortiert, dass die Position der
     * cascade-eigenen Modelle der neuen Reihenfolge entspricht; alle anderen
     * Modelle bleiben in ihrer relativen Position.
     */
    onChainChanged(cascadeName, newChain) {
        const global = this.allModels();
        const idsInChain = new Set();
        const orderedCascadeIds = [];
        // Map ChainEntry → DB-id
        for (const entry of newChain) {
            const found = global.find(m => m.provider === entry.provider && m.modelId === entry.model);
            if (found) {
                idsInChain.add(found.id);
                orderedCascadeIds.push(found.id);
            }
        }
        // Cascade = Verwaltungsfläche: ins Chain gewählte Modelle werden AKTIVIERT,
        // kategorie-eigene Modelle die aus dem Chain entfernt wurden DEAKTIVIERT.
        // general-Modelle sind geteilt (in jeder Kategorie angehängt) → beim Editieren
        // einer anderen Kategorie NICHT anfassen: nur Modelle deren category == cascadeName.
        const cat = cascadeName.toLowerCase();
        const toEnable = global.filter(m => idsInChain.has(m.id) && !m.enabled);
        const toDisable = global.filter(m => !idsInChain.has(m.id) && m.enabled
            && ((m.category ?? 'general').toLowerCase() === cat));
        // Globale Liste neu komponieren: bei den cascade-Slots in der globalen
        // Reihenfolge die neue cascade-Order einsetzen, fremde Modelle behalten
        // ihre Position.
        const newGlobalOrder = [];
        let cascadeIdx = 0;
        for (const m of global) {
            if (idsInChain.has(m.id)) {
                newGlobalOrder.push(orderedCascadeIds[cascadeIdx++]);
            }
            else {
                newGlobalOrder.push(m.id);
            }
        }
        const applyReorder = () => this.api.reorderModels(newGlobalOrder).subscribe({
            next: () => {
                this.cascadeChanged.emit({ cascadeName, chain: newChain });
                this.reload();
            },
            error: (e) => console.error('[ki-cascades-view] reorder failed', e),
        });
        // Erst Enable/Disable (falls nötig), dann Reorder + Reload. Ohne Änderungen
        // direkt reordern.
        const ops = [
            ...toEnable.map(m => this.api.toggleModel(m.id, true)),
            ...toDisable.map(m => this.api.toggleModel(m.id, false)),
        ];
        if (ops.length === 0) {
            applyReorder();
        }
        else {
            forkJoin(ops).subscribe({
                next: () => applyReorder(),
                error: (e) => { console.error('[ki-cascades-view] enable/disable failed', e); applyReorder(); },
            });
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CascadesViewComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CascadesViewComponent, isStandalone: true, selector: "ki-cascades-view", inputs: { labels: "labels", chainLabels: "chainLabels", hintByCascade: "hintByCascade", providerOptions: "providerOptions", visibleCascades: "visibleCascades", poolTitles: "poolTitles", autoRefreshSec: "autoRefreshSec" }, outputs: { cascadeChanged: "cascadeChanged" }, ngImport: i0, template: `
    <div class="space-y-6">
      <!-- Sektion-Header: Titel + manueller Refresh (kein periodisches Reload mehr) -->
      <div class="flex items-center justify-between gap-3">
        <h3 class="text-sm font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300">
          {{ L.sectionTitle }}
        </h3>
        <button type="button"
                (click)="reload()"
                [disabled]="loading()"
                [title]="L.refreshTooltip"
                class="shrink-0 rounded-md bg-indigo-100 dark:bg-indigo-900/50 text-indigo-700 dark:text-indigo-300 px-2.5 py-1 text-sm hover:bg-indigo-200 dark:hover:bg-indigo-900 disabled:opacity-50 disabled:cursor-not-allowed transition">
          ↻
        </button>
      </div>

      <!-- Loading -->
      <div *ngIf="loading()" class="text-sm italic text-slate-500">
        {{ L.loading }}
      </div>

      <!-- Empty state — Backend liefert kein /cascades oder leere Liste -->
      <div *ngIf="!loading() && displayedCascades().length === 0"
           class="rounded-2xl border-2 border-dashed border-slate-300 dark:border-slate-700 p-6 text-center text-sm text-slate-500 dark:text-slate-400">
        <p class="font-medium">{{ L.empty }}</p>
        <p class="mt-1 text-xs">{{ L.emptyHint }}</p>
      </div>

      <!-- Cascade-Karten — pool-gruppiert (cloud → free → local), eine Card pro Bereich -->
      <div *ngIf="!loading() && displayedCascades().length > 0" class="space-y-8">
        <div *ngFor="let group of cascadesByPool()">
          <h3 *ngIf="group.pool"
              class="mb-3 pb-1 text-base font-black tracking-tight text-slate-900 dark:text-slate-100 border-b-2 border-slate-300 dark:border-slate-700">
            {{ poolTitle(group.pool) }}
          </h3>
          <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <article *ngFor="let c of group.cascades"
                 class="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm">
          <!-- Header -->
          <header class="mb-4 flex items-start justify-between gap-3">
            <div class="flex-1 min-w-0">
              <!-- Inline-Edit für displayName (v0.11.2). Click auf den Title →
                   Input. Enter speichert, Escape bricht ab. -->
              <ng-container *ngIf="editingTitle() !== c.name">
                <h3 class="text-lg font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wide cursor-pointer hover:text-emerald-700 dark:hover:text-emerald-400 transition"
                    [title]="L.editTitleTooltip"
                    (click)="startEditTitle(c.name)">
                  {{ titleFor(c.name) }}
                </h3>
              </ng-container>
              <ng-container *ngIf="editingTitle() === c.name">
                <input type="text"
                       class="w-full text-lg font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wide px-2 py-1 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                       [(ngModel)]="editTitleText"
                       [placeholder]="L.editTitlePlaceholder"
                       (keydown.enter)="$event.preventDefault(); saveEditTitle(c.name)"
                       (keydown.escape)="cancelEditTitle()"
                       autofocus />
                <div class="mt-1 flex gap-2 text-[10px]">
                  <button (click)="saveEditTitle(c.name)"
                          [disabled]="savingTitle()"
                          class="px-2 py-0.5 rounded bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold uppercase tracking-wide">
                    {{ L.editHintSave }}
                  </button>
                  <button (click)="cancelEditTitle()"
                          [disabled]="savingTitle()"
                          class="px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 disabled:opacity-50 text-slate-700 dark:text-slate-200 font-bold uppercase tracking-wide">
                    {{ L.editHintCancel }}
                  </button>
                </div>
              </ng-container>

              <!-- Inline-Edit für description (v0.10.0). Click auf den Text →
                   Textarea. Enter speichert, Escape bricht ab, Blur speichert.
                   Während Edit ist hint via 'editing()'-Signal blockiert. -->
              <ng-container *ngIf="editing() !== c.name">
                <p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5 cursor-pointer hover:text-slate-700 dark:hover:text-slate-200 transition"
                   [title]="L.editHintTooltip"
                   (click)="startEdit(c.name)">
                  {{ hintFor(c.name) }}
                </p>
              </ng-container>
              <ng-container *ngIf="editing() === c.name">
                <textarea
                  class="mt-1 w-full text-xs px-2 py-1.5 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  rows="2"
                  [(ngModel)]="editText"
                  [placeholder]="L.editHintPlaceholder"
                  (keydown.enter)="$event.preventDefault(); saveEdit(c.name)"
                  (keydown.escape)="cancelEdit()"
                  #editArea
                  autofocus></textarea>
                <div class="mt-1 flex gap-2 text-[10px]">
                  <button (click)="saveEdit(c.name)"
                          [disabled]="saving()"
                          class="px-2 py-0.5 rounded bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold uppercase tracking-wide">
                    {{ L.editHintSave }}
                  </button>
                  <button (click)="cancelEdit()"
                          [disabled]="saving()"
                          class="px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 disabled:opacity-50 text-slate-700 dark:text-slate-200 font-bold uppercase tracking-wide">
                    {{ L.editHintCancel }}
                  </button>
                </div>
              </ng-container>
            </div>
            <div class="shrink-0 flex items-center gap-1.5">
              <span *ngIf="c.currentModel"
                    class="text-[10px] font-mono px-2 py-1 rounded-md bg-emerald-100 dark:bg-emerald-900/50 text-emerald-700 dark:text-emerald-300">
                ● {{ c.currentModel }}
              </span>
              <!-- v0.11.1 — Trash-Icon zum Loeschen der category_meta-Zeile
                   (displayName + description). Sichtbar nur wenn die Cascade
                   ueberhaupt Custom-Texte hat (sonst gibts nichts zu loeschen).
                   Modelle bleiben unangetastet — User muss die ueber die
                   Models-Tabelle einzeln entfernen. -->
              <button *ngIf="hasMeta(c.name)"
                      (click)="deleteMeta(c.name)"
                      [disabled]="deletingMeta() === c.name || editing() === c.name"
                      [title]="L.deleteMetaTooltip"
                      class="text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 disabled:opacity-40 disabled:cursor-not-allowed text-base leading-none p-1 rounded transition">
                ✕
              </button>
            </div>
          </header>

          <!-- Failover-Chain Editor pro Cascade -->
          <ki-failover-chain
            [chain]="chainsByCascade()[c.name] || []"
            [availableModels]="availableModelsAll()"
            [availableProviders]="providerOptions"
            [labels]="chainLabels"
            (chainChanged)="onChainChanged(c.name, $event)">
          </ki-failover-chain>

          <!-- Cooldown-Anzeige pro Modell -->
          <div *ngIf="hasCooldown(c)" class="mt-4 pt-4 border-t border-slate-200 dark:border-slate-800">
            <p class="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
              {{ L.cooldownTitle }}
            </p>
            <div class="space-y-1">
              <div *ngFor="let entry of cooldownEntries(c)"
                   class="flex items-center justify-between text-xs">
                <code class="font-mono text-slate-700 dark:text-slate-300">{{ entry.key }}</code>
                <span [class.text-emerald-600]="entry.sec === 0"
                      [class.text-amber-600]="entry.sec > 0"
                      class="font-bold">
                  {{ entry.sec === 0 ? L.statusFree : (L.statusCooldown + ' ' + entry.sec + 's') }}
                </span>
              </div>
            </div>
          </div>
        </article>
          </div>
        </div>
      </div>
    </div>
  `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: FailoverChainComponent, selector: "ki-failover-chain", inputs: ["chain", "availableModels", "availableProviders", "chainPosition", "showChainPosition", "labels"], outputs: ["chainChanged", "promoteRequested"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CascadesViewComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-cascades-view', standalone: true, imports: [CommonModule, FormsModule, FailoverChainComponent], template: `
    <div class="space-y-6">
      <!-- Sektion-Header: Titel + manueller Refresh (kein periodisches Reload mehr) -->
      <div class="flex items-center justify-between gap-3">
        <h3 class="text-sm font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300">
          {{ L.sectionTitle }}
        </h3>
        <button type="button"
                (click)="reload()"
                [disabled]="loading()"
                [title]="L.refreshTooltip"
                class="shrink-0 rounded-md bg-indigo-100 dark:bg-indigo-900/50 text-indigo-700 dark:text-indigo-300 px-2.5 py-1 text-sm hover:bg-indigo-200 dark:hover:bg-indigo-900 disabled:opacity-50 disabled:cursor-not-allowed transition">
          ↻
        </button>
      </div>

      <!-- Loading -->
      <div *ngIf="loading()" class="text-sm italic text-slate-500">
        {{ L.loading }}
      </div>

      <!-- Empty state — Backend liefert kein /cascades oder leere Liste -->
      <div *ngIf="!loading() && displayedCascades().length === 0"
           class="rounded-2xl border-2 border-dashed border-slate-300 dark:border-slate-700 p-6 text-center text-sm text-slate-500 dark:text-slate-400">
        <p class="font-medium">{{ L.empty }}</p>
        <p class="mt-1 text-xs">{{ L.emptyHint }}</p>
      </div>

      <!-- Cascade-Karten — pool-gruppiert (cloud → free → local), eine Card pro Bereich -->
      <div *ngIf="!loading() && displayedCascades().length > 0" class="space-y-8">
        <div *ngFor="let group of cascadesByPool()">
          <h3 *ngIf="group.pool"
              class="mb-3 pb-1 text-base font-black tracking-tight text-slate-900 dark:text-slate-100 border-b-2 border-slate-300 dark:border-slate-700">
            {{ poolTitle(group.pool) }}
          </h3>
          <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <article *ngFor="let c of group.cascades"
                 class="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm">
          <!-- Header -->
          <header class="mb-4 flex items-start justify-between gap-3">
            <div class="flex-1 min-w-0">
              <!-- Inline-Edit für displayName (v0.11.2). Click auf den Title →
                   Input. Enter speichert, Escape bricht ab. -->
              <ng-container *ngIf="editingTitle() !== c.name">
                <h3 class="text-lg font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wide cursor-pointer hover:text-emerald-700 dark:hover:text-emerald-400 transition"
                    [title]="L.editTitleTooltip"
                    (click)="startEditTitle(c.name)">
                  {{ titleFor(c.name) }}
                </h3>
              </ng-container>
              <ng-container *ngIf="editingTitle() === c.name">
                <input type="text"
                       class="w-full text-lg font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wide px-2 py-1 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                       [(ngModel)]="editTitleText"
                       [placeholder]="L.editTitlePlaceholder"
                       (keydown.enter)="$event.preventDefault(); saveEditTitle(c.name)"
                       (keydown.escape)="cancelEditTitle()"
                       autofocus />
                <div class="mt-1 flex gap-2 text-[10px]">
                  <button (click)="saveEditTitle(c.name)"
                          [disabled]="savingTitle()"
                          class="px-2 py-0.5 rounded bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold uppercase tracking-wide">
                    {{ L.editHintSave }}
                  </button>
                  <button (click)="cancelEditTitle()"
                          [disabled]="savingTitle()"
                          class="px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 disabled:opacity-50 text-slate-700 dark:text-slate-200 font-bold uppercase tracking-wide">
                    {{ L.editHintCancel }}
                  </button>
                </div>
              </ng-container>

              <!-- Inline-Edit für description (v0.10.0). Click auf den Text →
                   Textarea. Enter speichert, Escape bricht ab, Blur speichert.
                   Während Edit ist hint via 'editing()'-Signal blockiert. -->
              <ng-container *ngIf="editing() !== c.name">
                <p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5 cursor-pointer hover:text-slate-700 dark:hover:text-slate-200 transition"
                   [title]="L.editHintTooltip"
                   (click)="startEdit(c.name)">
                  {{ hintFor(c.name) }}
                </p>
              </ng-container>
              <ng-container *ngIf="editing() === c.name">
                <textarea
                  class="mt-1 w-full text-xs px-2 py-1.5 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  rows="2"
                  [(ngModel)]="editText"
                  [placeholder]="L.editHintPlaceholder"
                  (keydown.enter)="$event.preventDefault(); saveEdit(c.name)"
                  (keydown.escape)="cancelEdit()"
                  #editArea
                  autofocus></textarea>
                <div class="mt-1 flex gap-2 text-[10px]">
                  <button (click)="saveEdit(c.name)"
                          [disabled]="saving()"
                          class="px-2 py-0.5 rounded bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold uppercase tracking-wide">
                    {{ L.editHintSave }}
                  </button>
                  <button (click)="cancelEdit()"
                          [disabled]="saving()"
                          class="px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 disabled:opacity-50 text-slate-700 dark:text-slate-200 font-bold uppercase tracking-wide">
                    {{ L.editHintCancel }}
                  </button>
                </div>
              </ng-container>
            </div>
            <div class="shrink-0 flex items-center gap-1.5">
              <span *ngIf="c.currentModel"
                    class="text-[10px] font-mono px-2 py-1 rounded-md bg-emerald-100 dark:bg-emerald-900/50 text-emerald-700 dark:text-emerald-300">
                ● {{ c.currentModel }}
              </span>
              <!-- v0.11.1 — Trash-Icon zum Loeschen der category_meta-Zeile
                   (displayName + description). Sichtbar nur wenn die Cascade
                   ueberhaupt Custom-Texte hat (sonst gibts nichts zu loeschen).
                   Modelle bleiben unangetastet — User muss die ueber die
                   Models-Tabelle einzeln entfernen. -->
              <button *ngIf="hasMeta(c.name)"
                      (click)="deleteMeta(c.name)"
                      [disabled]="deletingMeta() === c.name || editing() === c.name"
                      [title]="L.deleteMetaTooltip"
                      class="text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 disabled:opacity-40 disabled:cursor-not-allowed text-base leading-none p-1 rounded transition">
                ✕
              </button>
            </div>
          </header>

          <!-- Failover-Chain Editor pro Cascade -->
          <ki-failover-chain
            [chain]="chainsByCascade()[c.name] || []"
            [availableModels]="availableModelsAll()"
            [availableProviders]="providerOptions"
            [labels]="chainLabels"
            (chainChanged)="onChainChanged(c.name, $event)">
          </ki-failover-chain>

          <!-- Cooldown-Anzeige pro Modell -->
          <div *ngIf="hasCooldown(c)" class="mt-4 pt-4 border-t border-slate-200 dark:border-slate-800">
            <p class="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
              {{ L.cooldownTitle }}
            </p>
            <div class="space-y-1">
              <div *ngFor="let entry of cooldownEntries(c)"
                   class="flex items-center justify-between text-xs">
                <code class="font-mono text-slate-700 dark:text-slate-300">{{ entry.key }}</code>
                <span [class.text-emerald-600]="entry.sec === 0"
                      [class.text-amber-600]="entry.sec > 0"
                      class="font-bold">
                  {{ entry.sec === 0 ? L.statusFree : (L.statusCooldown + ' ' + entry.sec + 's') }}
                </span>
              </div>
            </div>
          </div>
        </article>
          </div>
        </div>
      </div>
    </div>
  ` }]
        }], propDecorators: { labels: [{
                type: Input
            }], chainLabels: [{
                type: Input
            }], hintByCascade: [{
                type: Input
            }], providerOptions: [{
                type: Input
            }], cascadeChanged: [{
                type: Output
            }], visibleCascades: [{
                type: Input
            }], poolTitles: [{
                type: Input
            }], autoRefreshSec: [{
                type: Input
            }] } });

/**
 * Admin-Component fuer Semantic Routing (Phase v0.11.0).
 *
 * Zeigt:
 *   - Counter-Stats (hits / misses / failures / cacheSize)
 *   - Liste aller Cache-Eintraege (purpose preview, gewaehlte Kategorie,
 *     Alter, Restlebenszeit) mit "X"-Button pro Eintrag
 *   - "Cache komplett leeren"-Button
 *   - Test-Preview-Input: tippe eine Task-Beschreibung, sieh welche Kategorie
 *     der Router waehlen wuerde (cached danach)
 *
 * Konsumenten-Setup: gleicher `KI_MODELS_API_BASE` wie die anderen Components.
 * Wenn das Backend < 0.6.0 ist (kein /routing-Endpoint), faellt es auf eine
 * leere Liste + Hinweistext zurueck statt Crash.
 */
class RoutingDecisionsComponent {
    constructor() {
        this.api = inject(KiModelsApiService);
        this.cache = signal(null);
        this.loading = signal(true);
        this.testing = signal(false);
        this.testResult = signal(null);
        this.testPurpose = '';
        /** v0.12.2: Wenn nicht-null, ist der Cascade-Override im Backend aktiv —
         *  Banner zeigt das. */
        this.overrideCategory = signal(null);
        /** Konsumenten-i18n-Override. Default = englische Labels. */
        this.L = ROUTING_DECISIONS_LABELS_EN;
    }
    set labels(v) {
        this.L = { ...ROUTING_DECISIONS_LABELS_EN, ...(v ?? {}) };
    }
    ngOnInit() {
        this.reload();
        this.loadOverride();
    }
    /**
     * v0.12.2: Override-Status laden (Bereich-Toggle aktiv?). Bei Backend
     * < 0.7.5 wird der Endpoint 404 zurückgeben → wir behandeln das wie
     * „kein Override aktiv" und der Banner bleibt versteckt.
     */
    loadOverride() {
        this.api.getPreferredCategory().subscribe({
            next: (resp) => this.overrideCategory.set(resp?.active && resp?.category ? resp.category : null),
            error: () => this.overrideCategory.set(null),
        });
    }
    reload() {
        this.loading.set(true);
        this.api.getRoutingCache().subscribe({
            next: (c) => {
                this.cache.set(c);
                this.loading.set(false);
            },
            error: () => {
                // Backend ohne Routing-Endpoint — leere Liste, kein Crash
                this.cache.set({
                    stats: { cacheSize: 0, cacheCapacity: 0, ttlSeconds: 0, hits: 0, misses: 0, failures: 0 },
                    entries: [],
                });
                this.loading.set(false);
            },
        });
    }
    runTest() {
        const purpose = this.testPurpose.trim();
        if (!purpose)
            return;
        this.testing.set(true);
        this.testResult.set(null);
        firstValueFrom(this.api.testRouting(purpose))
            .then((r) => {
            this.testResult.set(r);
            this.testing.set(false);
            this.reload();
        })
            .catch(() => this.testing.set(false));
    }
    clearAll() {
        if (!confirm(this.L.confirmClearAll))
            return;
        this.api.clearRoutingCache().subscribe(() => this.reload());
    }
    clearOne(e) {
        this.api.clearRoutingCacheEntry(e.purposeHash).subscribe(() => this.reload());
    }
    /** Sekunden → "23h 45m" / "12m 30s" / "45s". */
    formatDuration(seconds) {
        if (seconds <= 0)
            return '–';
        const h = Math.floor(seconds / 3600);
        const m = Math.floor((seconds % 3600) / 60);
        const s = seconds % 60;
        if (h > 0)
            return `${h}h ${m}m`;
        if (m > 0)
            return `${m}m ${s}s`;
        return `${s}s`;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: RoutingDecisionsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: RoutingDecisionsComponent, isStandalone: true, selector: "ki-routing-decisions", ngImport: i0, template: `
    <div class="ki-routing">
      <h4 class="ki-title">{{ L.title }}</h4>
      <p class="ki-subtitle">{{ L.subtitle }}</p>

      <!-- v0.12.2: Override-Banner. Erscheint nur wenn preferredCategory
           gesetzt ist (Bereich-Toggle im Konsumenten-UI aktiv). Cache wird
           dann nicht genutzt — der Banner erklärt warum die Tabelle unten
           leer/stale aussieht. -->
      <div *ngIf="overrideCategory() as cat"
           class="ki-override-banner">
        <strong>⚠ Bereich-Override aktiv:</strong>
        Alle Generate-Calls gehen jetzt an <code>{{ cat }}</code>.
        Semantic Routing + dieser Cache werden umgangen — die Einträge
        unten sind Historie.
      </div>

      <!-- Stats-Zeile -->
      <div class="ki-stats" *ngIf="cache() as c">
        <div class="ki-stat">
          <div class="ki-stat-num">{{ c.stats.cacheSize }}</div>
          <div class="ki-stat-label">{{ L.statSize }} / {{ c.stats.cacheCapacity }}</div>
        </div>
        <div class="ki-stat">
          <div class="ki-stat-num ki-ok">{{ c.stats.hits }}</div>
          <div class="ki-stat-label">{{ L.statHits }}</div>
        </div>
        <div class="ki-stat">
          <div class="ki-stat-num">{{ c.stats.misses }}</div>
          <div class="ki-stat-label">{{ L.statMisses }}</div>
        </div>
        <div class="ki-stat">
          <div class="ki-stat-num ki-warn">{{ c.stats.failures }}</div>
          <div class="ki-stat-label">{{ L.statFailures }}</div>
        </div>
      </div>

      <!-- Test-Preview -->
      <div class="ki-test-box">
        <label class="ki-test-label">{{ L.testLabel }}</label>
        <div class="ki-test-row">
          <input [(ngModel)]="testPurpose"
                 [placeholder]="L.testPlaceholder"
                 class="ki-input"
                 (keydown.enter)="runTest()" />
          <button (click)="runTest()"
                  [disabled]="testing() || !testPurpose.trim()"
                  class="ki-btn-primary">
            {{ testing() ? L.testing : L.btnTest }}
          </button>
        </div>
        <p *ngIf="testResult() as r" class="ki-test-result">
          → <strong>{{ r.category }}</strong>
          <span class="ki-muted">({{ r.latencyMs }}ms)</span>
        </p>
      </div>

      <!-- Cache-Liste -->
      <div class="ki-cache-header">
        <span>{{ L.entriesTitle }}</span>
        <button (click)="clearAll()"
                [disabled]="!cache()?.entries?.length"
                class="ki-btn-secondary">
          {{ L.btnClearAll }}
        </button>
      </div>

      <p *ngIf="loading()" class="ki-muted ki-tiny">{{ L.loading }}</p>
      <p *ngIf="!loading() && !(cache()?.entries?.length)" class="ki-empty">{{ L.empty }}</p>

      <table class="ki-table" *ngIf="(cache()?.entries?.length ?? 0) > 0">
        <thead>
          <tr>
            <th>{{ L.colPurpose }}</th>
            <th>{{ L.colCategory }}</th>
            <th>{{ L.colExpires }}</th>
            <th class="ki-right">{{ L.colActions }}</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let e of cache()?.entries">
            <td class="ki-truncate" [title]="e.purpose">{{ e.purpose }}</td>
            <td><span class="ki-pill">{{ e.category }}</span></td>
            <td class="ki-tiny ki-muted">{{ formatDuration(e.expiresInSeconds) }}</td>
            <td class="ki-right">
              <button (click)="clearOne(e)" class="ki-btn-icon" [title]="L.btnClearOne">✕</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  `, isInline: true, styles: [".ki-routing{font-family:inherit;padding:1rem 0}.ki-title{font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#475569;margin:0 0 .25rem}.ki-subtitle{font-size:.75rem;color:#94a3b8;margin:0 0 1rem}.ki-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(8rem,1fr));gap:.75rem;margin-bottom:1rem}.ki-stat{background:#f8fafc;border-radius:.75rem;padding:.75rem;text-align:center}.ki-stat-num{font-size:1.5rem;font-weight:800;color:#0f172a}.ki-stat-num.ki-ok{color:#059669}.ki-stat-num.ki-warn{color:#d97706}.ki-stat-label{font-size:.625rem;text-transform:uppercase;letter-spacing:.05em;font-weight:800;color:#64748b}.ki-test-box{background:#f1f5f9;border-radius:.75rem;padding:.75rem;margin-bottom:1rem}.ki-test-label{display:block;font-size:.7rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;color:#475569;margin-bottom:.5rem}.ki-test-row{display:flex;gap:.5rem}.ki-test-row .ki-input{flex:1}.ki-test-result{font-size:.875rem;margin:.5rem 0 0;color:#0f172a}.ki-cache-header{display:flex;justify-content:space-between;align-items:center;font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#475569;margin-bottom:.5rem}.ki-input{padding:.6rem;background:#fff;border:2px solid #e2e8f0;border-radius:.5rem;font-size:.875rem}.ki-btn-primary{padding:.6rem 1rem;background:#0f172a;color:#fff;border:none;border-radius:.5rem;font-size:.7rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;cursor:pointer}.ki-btn-primary:disabled{opacity:.4;cursor:not-allowed}.ki-btn-secondary{padding:.3rem .7rem;background:#fee2e2;color:#991b1b;border:none;border-radius:.375rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;cursor:pointer}.ki-btn-secondary:disabled{opacity:.3;cursor:not-allowed}.ki-btn-icon{background:transparent;border:none;color:#94a3b8;cursor:pointer;font-size:1rem;padding:.2rem .4rem}.ki-btn-icon:hover{color:#ef4444}.ki-table{width:100%;border-collapse:collapse;font-size:.875rem}.ki-table thead tr{border-bottom:2px solid #e2e8f0}.ki-table th{padding:.5rem;text-align:left;text-transform:uppercase;font-size:.6rem;font-weight:800;letter-spacing:.1em;color:#64748b}.ki-table td{padding:.5rem;border-bottom:1px solid #f1f5f9;vertical-align:middle}.ki-truncate{max-width:400px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ki-right{text-align:right}.ki-pill{display:inline-block;padding:.15rem .5rem;border-radius:.25rem;background:#e0e7ff;color:#3730a3;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em}.ki-muted{color:#94a3b8}.ki-tiny{font-size:.7rem}.ki-empty{text-align:center;color:#94a3b8;padding:1rem;font-size:.85rem}.ki-override-banner{background:#fef3c7;border:1px solid #fcd34d;color:#92400e;padding:.7rem .9rem;border-radius:.5rem;margin:.75rem 0 1rem;font-size:.8rem;line-height:1.4}.ki-override-banner code{background:#fde68a;padding:.1rem .4rem;border-radius:.25rem;font-family:ui-monospace,monospace;font-weight:700}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: RoutingDecisionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-routing-decisions', standalone: true, imports: [CommonModule, FormsModule], template: `
    <div class="ki-routing">
      <h4 class="ki-title">{{ L.title }}</h4>
      <p class="ki-subtitle">{{ L.subtitle }}</p>

      <!-- v0.12.2: Override-Banner. Erscheint nur wenn preferredCategory
           gesetzt ist (Bereich-Toggle im Konsumenten-UI aktiv). Cache wird
           dann nicht genutzt — der Banner erklärt warum die Tabelle unten
           leer/stale aussieht. -->
      <div *ngIf="overrideCategory() as cat"
           class="ki-override-banner">
        <strong>⚠ Bereich-Override aktiv:</strong>
        Alle Generate-Calls gehen jetzt an <code>{{ cat }}</code>.
        Semantic Routing + dieser Cache werden umgangen — die Einträge
        unten sind Historie.
      </div>

      <!-- Stats-Zeile -->
      <div class="ki-stats" *ngIf="cache() as c">
        <div class="ki-stat">
          <div class="ki-stat-num">{{ c.stats.cacheSize }}</div>
          <div class="ki-stat-label">{{ L.statSize }} / {{ c.stats.cacheCapacity }}</div>
        </div>
        <div class="ki-stat">
          <div class="ki-stat-num ki-ok">{{ c.stats.hits }}</div>
          <div class="ki-stat-label">{{ L.statHits }}</div>
        </div>
        <div class="ki-stat">
          <div class="ki-stat-num">{{ c.stats.misses }}</div>
          <div class="ki-stat-label">{{ L.statMisses }}</div>
        </div>
        <div class="ki-stat">
          <div class="ki-stat-num ki-warn">{{ c.stats.failures }}</div>
          <div class="ki-stat-label">{{ L.statFailures }}</div>
        </div>
      </div>

      <!-- Test-Preview -->
      <div class="ki-test-box">
        <label class="ki-test-label">{{ L.testLabel }}</label>
        <div class="ki-test-row">
          <input [(ngModel)]="testPurpose"
                 [placeholder]="L.testPlaceholder"
                 class="ki-input"
                 (keydown.enter)="runTest()" />
          <button (click)="runTest()"
                  [disabled]="testing() || !testPurpose.trim()"
                  class="ki-btn-primary">
            {{ testing() ? L.testing : L.btnTest }}
          </button>
        </div>
        <p *ngIf="testResult() as r" class="ki-test-result">
          → <strong>{{ r.category }}</strong>
          <span class="ki-muted">({{ r.latencyMs }}ms)</span>
        </p>
      </div>

      <!-- Cache-Liste -->
      <div class="ki-cache-header">
        <span>{{ L.entriesTitle }}</span>
        <button (click)="clearAll()"
                [disabled]="!cache()?.entries?.length"
                class="ki-btn-secondary">
          {{ L.btnClearAll }}
        </button>
      </div>

      <p *ngIf="loading()" class="ki-muted ki-tiny">{{ L.loading }}</p>
      <p *ngIf="!loading() && !(cache()?.entries?.length)" class="ki-empty">{{ L.empty }}</p>

      <table class="ki-table" *ngIf="(cache()?.entries?.length ?? 0) > 0">
        <thead>
          <tr>
            <th>{{ L.colPurpose }}</th>
            <th>{{ L.colCategory }}</th>
            <th>{{ L.colExpires }}</th>
            <th class="ki-right">{{ L.colActions }}</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let e of cache()?.entries">
            <td class="ki-truncate" [title]="e.purpose">{{ e.purpose }}</td>
            <td><span class="ki-pill">{{ e.category }}</span></td>
            <td class="ki-tiny ki-muted">{{ formatDuration(e.expiresInSeconds) }}</td>
            <td class="ki-right">
              <button (click)="clearOne(e)" class="ki-btn-icon" [title]="L.btnClearOne">✕</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  `, styles: [".ki-routing{font-family:inherit;padding:1rem 0}.ki-title{font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#475569;margin:0 0 .25rem}.ki-subtitle{font-size:.75rem;color:#94a3b8;margin:0 0 1rem}.ki-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(8rem,1fr));gap:.75rem;margin-bottom:1rem}.ki-stat{background:#f8fafc;border-radius:.75rem;padding:.75rem;text-align:center}.ki-stat-num{font-size:1.5rem;font-weight:800;color:#0f172a}.ki-stat-num.ki-ok{color:#059669}.ki-stat-num.ki-warn{color:#d97706}.ki-stat-label{font-size:.625rem;text-transform:uppercase;letter-spacing:.05em;font-weight:800;color:#64748b}.ki-test-box{background:#f1f5f9;border-radius:.75rem;padding:.75rem;margin-bottom:1rem}.ki-test-label{display:block;font-size:.7rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;color:#475569;margin-bottom:.5rem}.ki-test-row{display:flex;gap:.5rem}.ki-test-row .ki-input{flex:1}.ki-test-result{font-size:.875rem;margin:.5rem 0 0;color:#0f172a}.ki-cache-header{display:flex;justify-content:space-between;align-items:center;font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#475569;margin-bottom:.5rem}.ki-input{padding:.6rem;background:#fff;border:2px solid #e2e8f0;border-radius:.5rem;font-size:.875rem}.ki-btn-primary{padding:.6rem 1rem;background:#0f172a;color:#fff;border:none;border-radius:.5rem;font-size:.7rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;cursor:pointer}.ki-btn-primary:disabled{opacity:.4;cursor:not-allowed}.ki-btn-secondary{padding:.3rem .7rem;background:#fee2e2;color:#991b1b;border:none;border-radius:.375rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;cursor:pointer}.ki-btn-secondary:disabled{opacity:.3;cursor:not-allowed}.ki-btn-icon{background:transparent;border:none;color:#94a3b8;cursor:pointer;font-size:1rem;padding:.2rem .4rem}.ki-btn-icon:hover{color:#ef4444}.ki-table{width:100%;border-collapse:collapse;font-size:.875rem}.ki-table thead tr{border-bottom:2px solid #e2e8f0}.ki-table th{padding:.5rem;text-align:left;text-transform:uppercase;font-size:.6rem;font-weight:800;letter-spacing:.1em;color:#64748b}.ki-table td{padding:.5rem;border-bottom:1px solid #f1f5f9;vertical-align:middle}.ki-truncate{max-width:400px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ki-right{text-align:right}.ki-pill{display:inline-block;padding:.15rem .5rem;border-radius:.25rem;background:#e0e7ff;color:#3730a3;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em}.ki-muted{color:#94a3b8}.ki-tiny{font-size:.7rem}.ki-empty{text-align:center;color:#94a3b8;padding:1rem;font-size:.85rem}.ki-override-banner{background:#fef3c7;border:1px solid #fcd34d;color:#92400e;padding:.7rem .9rem;border-radius:.5rem;margin:.75rem 0 1rem;font-size:.8rem;line-height:1.4}.ki-override-banner code{background:#fde68a;padding:.1rem .4rem;border-radius:.25rem;font-family:ui-monospace,monospace;font-weight:700}\n"] }]
        }] });

/**
 * v0.7.1 / Library v0.12.0 — Quality-Bewertung pro Modell aus den letzten
 * 30 Tagen, sortiert worst-first (KILL-Kandidaten oben).
 *
 * <h3>Was zeigt das?</h3>
 * Eine simple Tabelle pro Modell mit:
 *  - Tier-Icon (★ top / ◐ ok / ▽ weak / ✗ kill)
 *  - Quality-Score (0.0 - 2.0+)
 *  - Success-Rate, Avg-Chars, Anzahl Calls
 *  - Rotes Highlighting für KILL-Kandidaten
 *
 * <h3>Wofür?</h3>
 * Admin sieht auf einen Blick welche Modelle nicht laufen. Statt durch
 * eine lange Liste zu scrollen ist das problematische ganz oben.
 *
 * <h3>Konsument-Use-Case:</h3>
 * - EduPro: in den Operations-Tab embedded, ersetzt die alte AI-Quality-Card
 * - Switcher: in Stats-Tab embedded
 */
class ModelsQualityStatsComponent {
    constructor() {
        this.api = inject(KiModelsApiService);
        /** Label oben — überschreibbar pro Konsument. */
        this.title = 'KI-Qualität — Stats der letzten 30 Tage';
        this.subtitle = 'Schlechte Modelle stehen oben. KILL-Kandidaten sollten deaktiviert werden.';
        this.sortBy = 'worst-first';
        /** Seitengröße der Tabelle. Pager nur sichtbar wenn mehr Zeilen. */
        this.pageSize = 10;
        this.rows = signal([]);
        this.loading = signal(true);
        this.page = signal(0);
        this.filter = signal('');
        this.sort = signal({ key: null, dir: null });
        this.viewRows = computed(() => sortRows(filterRows(this.rows(), this.filter(), ['provider', 'modelId', 'displayName', 'category']), this.sort()));
        this.pageRows = computed(() => paginate(this.viewRows(), this.page(), this.pageSize));
        // v0.12.1: Auto-Disable-Trigger
        this.running = signal(false);
        this.autoDisableEnabled = signal(false);
        this.autoDisableMinCalls = signal(50);
        this.lastResult = signal(null);
        /** Hide result-banner nach 8s. Timer-Ref damit reload nicht zwei Timer parallel laufen lässt. */
        this.resultTimer = null;
    }
    glyph(key) { return sortGlyph(this.sort(), key); }
    sortCol(key) { this.sort.set(nextSort(this.sort(), key)); this.page.set(0); }
    setFilter(v) { this.filter.set(v); this.page.set(0); }
    ngOnInit() {
        this.reload();
        this.loadAutoDisableConfig();
    }
    /**
     * Holt einmal beim Mount die Auto-Disable-Config. Bei Backend &lt; 0.7.3
     * (kein Endpoint) bleibt {@link autoDisableEnabled} false → der Button
     * wird gar nicht erst sichtbar. Saubere Backward-Compat.
     */
    loadAutoDisableConfig() {
        this.api.getQualityAutoDisableConfig().subscribe({
            next: (cfg) => {
                this.autoDisableEnabled.set(!!cfg?.enabled);
                if (cfg?.minCalls)
                    this.autoDisableMinCalls.set(cfg.minCalls);
            },
            error: () => {
                // Endpoint nicht da → Feature einfach nicht zeigen.
                this.autoDisableEnabled.set(false);
            },
        });
    }
    reload() {
        this.loading.set(true);
        this.page.set(0);
        this.api.getQualityStats(this.sortBy).subscribe({
            next: (rows) => {
                this.rows.set(Array.isArray(rows) ? rows : []);
                this.loading.set(false);
            },
            error: () => {
                // Backend < 0.7.2: leere Liste, kein Crash
                this.rows.set([]);
                this.loading.set(false);
            },
        });
    }
    /**
     * v0.12.1: triggert den Auto-Disable-Job im Backend, zeigt das Ergebnis
     * im Banner und lädt die Stats-Tabelle neu (damit die jetzt-disabled-
     * Modelle ihre neue {@code autoDisabled=true}-Markierung kriegen — die
     * Tabelle zeigt zwar nicht direkt das autoDisabled-Feld, aber das
     * UI-„DISABLE"-Badge basiert auf der frischen Server-Antwort).
     *
     * Bei Backend-Fehler (z.B. Endpoint nicht da): kurze rote Fallback-
     * Meldung „nicht verfügbar". Der Button bleibt nutzbar.
     */
    runAutoDisable() {
        if (this.running())
            return;
        this.running.set(true);
        if (this.resultTimer) {
            clearTimeout(this.resultTimer);
            this.resultTimer = null;
        }
        this.api.runQualityAutoDisable().subscribe({
            next: (report) => {
                this.lastResult.set({ disabled: report?.disabled ?? [] });
                this.running.set(false);
                this.reload();
                // Banner nach 8s automatisch zumachen — User muss nicht klicken.
                this.resultTimer = setTimeout(() => this.lastResult.set(null), 8000);
            },
            error: () => {
                this.lastResult.set({ disabled: [] });
                this.running.set(false);
                this.resultTimer = setTimeout(() => this.lastResult.set(null), 5000);
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ModelsQualityStatsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ModelsQualityStatsComponent, isStandalone: true, selector: "ki-models-quality-stats", inputs: { title: "title", subtitle: "subtitle", pageSize: "pageSize" }, ngImport: i0, template: `
    <div class="ki-quality-stats">
      <div class="ki-header">
        <div>
          <h4 class="ki-title">{{ title }}</h4>
          <p class="ki-subtitle">{{ subtitle }}</p>
        </div>
        <div class="ki-controls">
          <label class="ki-tiny ki-muted">Sortierung:</label>
          <select [(ngModel)]="sortBy" (change)="reload()" class="ki-select">
            <option value="worst-first">Schlechteste zuerst</option>
            <option value="best-first">Beste zuerst</option>
            <option value="calls-desc">Meist genutzte zuerst</option>
          </select>
          <button (click)="reload()" class="ki-btn-refresh" title="Tabelle neu laden">↻</button>
          <!--
            v0.12.1: Manueller Auto-Disable-Trigger. Sichtbar nur wenn das
            Backend-Feature aktiv ist (autoDisableEnabled signal). Sonst
            wäre's verwirrend einen Button zu zeigen der nichts macht.
            Tipp: Default-disabled solange noch geladen wird → kein
            Doppel-Klick beim Spam-Klicker.
          -->
          <button *ngIf="autoDisableEnabled()"
                  (click)="runAutoDisable()"
                  [disabled]="running()"
                  class="ki-btn-autodisable"
                  title="Killt jetzt sofort alle Modelle mit Tier=kill und genügend Calls — der Hintergrund-Job läuft sonst alle 6h">
            {{ running() ? 'Läuft…' : '✗ Auto-Disable jetzt' }}
          </button>
        </div>
      </div>

      <!-- v0.12.1: Result-Banner nach manuellem Run. Wird nach 8s
           ausgeblendet, kann via X-Klick weg-geklickt werden. Grün wenn
           was gekillt wurde, neutral wenn nichts zu tun war. -->
      <div *ngIf="lastResult() as r"
           class="ki-result-banner"
           [class.ki-result-killed]="r.disabled.length > 0"
           [class.ki-result-noop]="r.disabled.length === 0">
        <strong *ngIf="r.disabled.length > 0">
          ✗ {{ r.disabled.length }} Modell{{ r.disabled.length === 1 ? '' : 'e' }} auto-disabled
        </strong>
        <strong *ngIf="r.disabled.length === 0">
          ✓ Nichts zu tun — keine kill-Tier-Modelle mit ≥{{ autoDisableMinCalls() }} Calls
        </strong>
        <span class="ki-tiny ki-muted ki-result-detail" *ngIf="r.disabled.length > 0">
          {{ r.disabled.join(', ') }}
        </span>
        <button class="ki-result-dismiss" (click)="lastResult.set(null)" title="schließen">✕</button>
      </div>

      <p *ngIf="loading()" class="ki-muted">Lade Quality-Stats…</p>
      <p *ngIf="!loading() && rows().length === 0" class="ki-empty">
        Noch keine Stats — Modelle wurden in den letzten 30 Tagen nicht aufgerufen.
      </p>

      <input *ngIf="rows().length > 0"
        class="ki-filter" type="text" placeholder="Filtern…"
        [value]="filter()" (input)="setFilter($any($event.target).value)" />

      <table *ngIf="rows().length > 0" class="ki-table">
        <thead>
          <tr>
            <th></th>
            <th class="ki-sortable" (click)="sortCol('modelId')">Modell <span class="ki-glyph">{{ glyph('modelId') }}</span></th>
            <th class="ki-sortable" (click)="sortCol('category')">Kategorie <span class="ki-glyph">{{ glyph('category') }}</span></th>
            <th class="ki-right ki-sortable" (click)="sortCol('score')">Score <span class="ki-glyph">{{ glyph('score') }}</span></th>
            <th class="ki-right ki-sortable" (click)="sortCol('successRate')">Erfolg <span class="ki-glyph">{{ glyph('successRate') }}</span></th>
            <th class="ki-right ki-sortable" (click)="sortCol('callsLast30d')">Calls (30d) <span class="ki-glyph">{{ glyph('callsLast30d') }}</span></th>
            <th class="ki-right ki-sortable" (click)="sortCol('avgChars')">Ø Chars <span class="ki-glyph">{{ glyph('avgChars') }}</span></th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let r of pageRows()"
              [class.ki-row-kill]="r.kill"
              [class.ki-row-weak]="r.tier === 'weak'">
            <td class="ki-tier-icon" [class]="'ki-tier-' + r.tier">{{ r.tierIcon }}</td>
            <td class="ki-mono">
              <span class="ki-provider">{{ r.provider }}</span>
              <strong>{{ r.modelId }}</strong>
              <div *ngIf="r.displayName" class="ki-tiny ki-muted">{{ r.displayName }}</div>
            </td>
            <td class="ki-tiny">{{ r.category || '—' }}</td>
            <td class="ki-right ki-mono">
              <strong [class]="'ki-tier-' + r.tier">{{ r.score | number:'1.2-2' }}</strong>
            </td>
            <td class="ki-right">{{ (r.successRate * 100) | number:'1.0-1' }}%</td>
            <td class="ki-right">{{ r.callsLast30d }}</td>
            <td class="ki-right ki-tiny ki-muted">{{ r.avgChars }}</td>
            <td>
              <span *ngIf="r.kill" class="ki-kill-badge" title="Empfehlung: deaktivieren">DISABLE</span>
            </td>
          </tr>
        </tbody>
      </table>

      <ki-pager
        [total]="viewRows().length"
        [page]="page()"
        [pageSize]="pageSize"
        (pageChange)="page.set($event)">
      </ki-pager>
    </div>
  `, isInline: true, styles: [".ki-quality-stats{font-family:inherit;padding:1rem 0}.ki-header{display:flex;justify-content:space-between;align-items:flex-start;gap:1rem;margin-bottom:1rem}.ki-title{font-size:.85rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#1e293b;margin:0 0 .25rem}.ki-subtitle{font-size:.7rem;color:#64748b;margin:0}.ki-controls{display:flex;gap:.5rem;align-items:center}.ki-select{padding:.35rem .6rem;border:1px solid #cbd5e1;border-radius:.375rem;font-size:.75rem;background:#fff}.ki-btn-refresh{padding:.35rem .6rem;background:#e0e7ff;color:#3730a3;border:none;border-radius:.375rem;font-size:.8rem;cursor:pointer}.ki-btn-autodisable{padding:.35rem .7rem;background:#fee2e2;color:#991b1b;border:1px solid #fecaca;border-radius:.375rem;font-size:.7rem;font-weight:700;cursor:pointer;text-transform:uppercase;letter-spacing:.05em}.ki-btn-autodisable:hover{background:#fecaca}.ki-btn-autodisable:disabled{opacity:.5;cursor:not-allowed}.ki-result-banner{display:flex;align-items:center;gap:.75rem;flex-wrap:wrap;padding:.7rem .9rem;border-radius:.5rem;margin-bottom:.75rem;font-size:.8rem}.ki-result-killed{background:#fef2f2;border:1px solid #fecaca;color:#991b1b}.ki-result-noop{background:#f0fdf4;border:1px solid #bbf7d0;color:#166534}.ki-result-detail{flex:1;min-width:0;word-break:break-all}.ki-result-dismiss{background:transparent;border:none;color:inherit;cursor:pointer;font-weight:700;padding:0 .25rem;opacity:.6}.ki-result-dismiss:hover{opacity:1}.ki-filter{width:100%;box-sizing:border-box;padding:.4rem .6rem;margin-bottom:.5rem;border:1px solid #e2e8f0;border-radius:.375rem;font-size:.8rem}.ki-table{width:100%;border-collapse:collapse;font-size:.85rem}.ki-table thead tr{border-bottom:2px solid #e2e8f0}.ki-table th{padding:.5rem .6rem;text-align:left;text-transform:uppercase;font-size:.6rem;font-weight:800;letter-spacing:.08em;color:#64748b}.ki-sortable{cursor:pointer;-webkit-user-select:none;user-select:none;white-space:nowrap}.ki-sortable:hover{color:#4f46e5}.ki-glyph{font-size:.6rem;opacity:.6}.ki-table td{padding:.55rem .6rem;border-bottom:1px solid #f1f5f9;vertical-align:top}.ki-row-kill{background:linear-gradient(90deg,#fef2f2 0%,transparent 100%)}.ki-row-weak{background:linear-gradient(90deg,#fffbeb 0%,transparent 100%)}.ki-right{text-align:right}.ki-mono{font-family:ui-monospace,monospace}.ki-muted{color:#94a3b8}.ki-tiny{font-size:.7rem}.ki-provider{color:#4f46e5;font-weight:700;margin-right:.4rem}.ki-tier-icon{font-size:1.2rem;text-align:center;width:2.2rem}.ki-tier-top{color:#059669;font-weight:800}.ki-tier-ok{color:#d97706;font-weight:800}.ki-tier-weak{color:#ea580c;font-weight:800}.ki-tier-kill{color:#dc2626;font-weight:800}.ki-tier-unknown{color:#94a3b8}.ki-kill-badge{background:#fee2e2;color:#991b1b;padding:.2rem .4rem;border-radius:.25rem;font-size:.6rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em}.ki-empty{text-align:center;padding:1.5rem;color:#94a3b8}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: i1.DecimalPipe, name: "number" }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.NgSelectOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.ɵNgSelectMultipleOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.SelectControlValueAccessor, selector: "select:not([multiple])[formControlName],select:not([multiple])[formControl],select:not([multiple])[ngModel]", inputs: ["compareWith"] }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: KiPagerComponent, selector: "ki-pager", inputs: ["total", "page", "pageSize"], outputs: ["pageChange"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ModelsQualityStatsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-models-quality-stats', standalone: true, imports: [CommonModule, FormsModule, KiPagerComponent], template: `
    <div class="ki-quality-stats">
      <div class="ki-header">
        <div>
          <h4 class="ki-title">{{ title }}</h4>
          <p class="ki-subtitle">{{ subtitle }}</p>
        </div>
        <div class="ki-controls">
          <label class="ki-tiny ki-muted">Sortierung:</label>
          <select [(ngModel)]="sortBy" (change)="reload()" class="ki-select">
            <option value="worst-first">Schlechteste zuerst</option>
            <option value="best-first">Beste zuerst</option>
            <option value="calls-desc">Meist genutzte zuerst</option>
          </select>
          <button (click)="reload()" class="ki-btn-refresh" title="Tabelle neu laden">↻</button>
          <!--
            v0.12.1: Manueller Auto-Disable-Trigger. Sichtbar nur wenn das
            Backend-Feature aktiv ist (autoDisableEnabled signal). Sonst
            wäre's verwirrend einen Button zu zeigen der nichts macht.
            Tipp: Default-disabled solange noch geladen wird → kein
            Doppel-Klick beim Spam-Klicker.
          -->
          <button *ngIf="autoDisableEnabled()"
                  (click)="runAutoDisable()"
                  [disabled]="running()"
                  class="ki-btn-autodisable"
                  title="Killt jetzt sofort alle Modelle mit Tier=kill und genügend Calls — der Hintergrund-Job läuft sonst alle 6h">
            {{ running() ? 'Läuft…' : '✗ Auto-Disable jetzt' }}
          </button>
        </div>
      </div>

      <!-- v0.12.1: Result-Banner nach manuellem Run. Wird nach 8s
           ausgeblendet, kann via X-Klick weg-geklickt werden. Grün wenn
           was gekillt wurde, neutral wenn nichts zu tun war. -->
      <div *ngIf="lastResult() as r"
           class="ki-result-banner"
           [class.ki-result-killed]="r.disabled.length > 0"
           [class.ki-result-noop]="r.disabled.length === 0">
        <strong *ngIf="r.disabled.length > 0">
          ✗ {{ r.disabled.length }} Modell{{ r.disabled.length === 1 ? '' : 'e' }} auto-disabled
        </strong>
        <strong *ngIf="r.disabled.length === 0">
          ✓ Nichts zu tun — keine kill-Tier-Modelle mit ≥{{ autoDisableMinCalls() }} Calls
        </strong>
        <span class="ki-tiny ki-muted ki-result-detail" *ngIf="r.disabled.length > 0">
          {{ r.disabled.join(', ') }}
        </span>
        <button class="ki-result-dismiss" (click)="lastResult.set(null)" title="schließen">✕</button>
      </div>

      <p *ngIf="loading()" class="ki-muted">Lade Quality-Stats…</p>
      <p *ngIf="!loading() && rows().length === 0" class="ki-empty">
        Noch keine Stats — Modelle wurden in den letzten 30 Tagen nicht aufgerufen.
      </p>

      <input *ngIf="rows().length > 0"
        class="ki-filter" type="text" placeholder="Filtern…"
        [value]="filter()" (input)="setFilter($any($event.target).value)" />

      <table *ngIf="rows().length > 0" class="ki-table">
        <thead>
          <tr>
            <th></th>
            <th class="ki-sortable" (click)="sortCol('modelId')">Modell <span class="ki-glyph">{{ glyph('modelId') }}</span></th>
            <th class="ki-sortable" (click)="sortCol('category')">Kategorie <span class="ki-glyph">{{ glyph('category') }}</span></th>
            <th class="ki-right ki-sortable" (click)="sortCol('score')">Score <span class="ki-glyph">{{ glyph('score') }}</span></th>
            <th class="ki-right ki-sortable" (click)="sortCol('successRate')">Erfolg <span class="ki-glyph">{{ glyph('successRate') }}</span></th>
            <th class="ki-right ki-sortable" (click)="sortCol('callsLast30d')">Calls (30d) <span class="ki-glyph">{{ glyph('callsLast30d') }}</span></th>
            <th class="ki-right ki-sortable" (click)="sortCol('avgChars')">Ø Chars <span class="ki-glyph">{{ glyph('avgChars') }}</span></th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let r of pageRows()"
              [class.ki-row-kill]="r.kill"
              [class.ki-row-weak]="r.tier === 'weak'">
            <td class="ki-tier-icon" [class]="'ki-tier-' + r.tier">{{ r.tierIcon }}</td>
            <td class="ki-mono">
              <span class="ki-provider">{{ r.provider }}</span>
              <strong>{{ r.modelId }}</strong>
              <div *ngIf="r.displayName" class="ki-tiny ki-muted">{{ r.displayName }}</div>
            </td>
            <td class="ki-tiny">{{ r.category || '—' }}</td>
            <td class="ki-right ki-mono">
              <strong [class]="'ki-tier-' + r.tier">{{ r.score | number:'1.2-2' }}</strong>
            </td>
            <td class="ki-right">{{ (r.successRate * 100) | number:'1.0-1' }}%</td>
            <td class="ki-right">{{ r.callsLast30d }}</td>
            <td class="ki-right ki-tiny ki-muted">{{ r.avgChars }}</td>
            <td>
              <span *ngIf="r.kill" class="ki-kill-badge" title="Empfehlung: deaktivieren">DISABLE</span>
            </td>
          </tr>
        </tbody>
      </table>

      <ki-pager
        [total]="viewRows().length"
        [page]="page()"
        [pageSize]="pageSize"
        (pageChange)="page.set($event)">
      </ki-pager>
    </div>
  `, styles: [".ki-quality-stats{font-family:inherit;padding:1rem 0}.ki-header{display:flex;justify-content:space-between;align-items:flex-start;gap:1rem;margin-bottom:1rem}.ki-title{font-size:.85rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#1e293b;margin:0 0 .25rem}.ki-subtitle{font-size:.7rem;color:#64748b;margin:0}.ki-controls{display:flex;gap:.5rem;align-items:center}.ki-select{padding:.35rem .6rem;border:1px solid #cbd5e1;border-radius:.375rem;font-size:.75rem;background:#fff}.ki-btn-refresh{padding:.35rem .6rem;background:#e0e7ff;color:#3730a3;border:none;border-radius:.375rem;font-size:.8rem;cursor:pointer}.ki-btn-autodisable{padding:.35rem .7rem;background:#fee2e2;color:#991b1b;border:1px solid #fecaca;border-radius:.375rem;font-size:.7rem;font-weight:700;cursor:pointer;text-transform:uppercase;letter-spacing:.05em}.ki-btn-autodisable:hover{background:#fecaca}.ki-btn-autodisable:disabled{opacity:.5;cursor:not-allowed}.ki-result-banner{display:flex;align-items:center;gap:.75rem;flex-wrap:wrap;padding:.7rem .9rem;border-radius:.5rem;margin-bottom:.75rem;font-size:.8rem}.ki-result-killed{background:#fef2f2;border:1px solid #fecaca;color:#991b1b}.ki-result-noop{background:#f0fdf4;border:1px solid #bbf7d0;color:#166534}.ki-result-detail{flex:1;min-width:0;word-break:break-all}.ki-result-dismiss{background:transparent;border:none;color:inherit;cursor:pointer;font-weight:700;padding:0 .25rem;opacity:.6}.ki-result-dismiss:hover{opacity:1}.ki-filter{width:100%;box-sizing:border-box;padding:.4rem .6rem;margin-bottom:.5rem;border:1px solid #e2e8f0;border-radius:.375rem;font-size:.8rem}.ki-table{width:100%;border-collapse:collapse;font-size:.85rem}.ki-table thead tr{border-bottom:2px solid #e2e8f0}.ki-table th{padding:.5rem .6rem;text-align:left;text-transform:uppercase;font-size:.6rem;font-weight:800;letter-spacing:.08em;color:#64748b}.ki-sortable{cursor:pointer;-webkit-user-select:none;user-select:none;white-space:nowrap}.ki-sortable:hover{color:#4f46e5}.ki-glyph{font-size:.6rem;opacity:.6}.ki-table td{padding:.55rem .6rem;border-bottom:1px solid #f1f5f9;vertical-align:top}.ki-row-kill{background:linear-gradient(90deg,#fef2f2 0%,transparent 100%)}.ki-row-weak{background:linear-gradient(90deg,#fffbeb 0%,transparent 100%)}.ki-right{text-align:right}.ki-mono{font-family:ui-monospace,monospace}.ki-muted{color:#94a3b8}.ki-tiny{font-size:.7rem}.ki-provider{color:#4f46e5;font-weight:700;margin-right:.4rem}.ki-tier-icon{font-size:1.2rem;text-align:center;width:2.2rem}.ki-tier-top{color:#059669;font-weight:800}.ki-tier-ok{color:#d97706;font-weight:800}.ki-tier-weak{color:#ea580c;font-weight:800}.ki-tier-kill{color:#dc2626;font-weight:800}.ki-tier-unknown{color:#94a3b8}.ki-kill-badge{background:#fee2e2;color:#991b1b;padding:.2rem .4rem;border-radius:.25rem;font-size:.6rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em}.ki-empty{text-align:center;padding:1.5rem;color:#94a3b8}\n"] }]
        }], propDecorators: { title: [{
                type: Input
            }], subtitle: [{
                type: Input
            }], pageSize: [{
                type: Input
            }] } });

/**
 * v0.13.0 — Generisches Bereich-Toggle für Cascade-Kategorien.
 *
 * <h3>Was rendert die Component?</h3>
 * <ul>
 *   <li>Ein Toggle (`<button>`-Reihe) mit allen verfügbaren Cascade-Kategorien</li>
 *   <li>Einen kontextuellen Hint-Text (Semantic Routing aktiv vs Override aktiv)</li>
 *   <li>Eine Info-Card im Auto-Mode mit optionalem Scroll-Button zur Cascade-Bereich-
 *       Konfiguration weiter unten auf der Page</li>
 * </ul>
 *
 * <h3>Use-Case (Konsumenten)</h3>
 * <ul>
 *   <li><strong>Switcher</strong>: oben im sw-mode-panel als zweite Toggle-Zeile</li>
 *   <li><strong>EduPro</strong>: über der <code>&lt;ki-cascades-view&gt;</code>
 *       Card im Admin-Tab, damit der Admin das Semantic-Routing-Override toggeln kann</li>
 * </ul>
 *
 * <h3>Architektur-Hinweis</h3>
 * Die Component ist **pure presentational** — kein eigener API-Call. Der
 * Konsument fängt das `(categoryChanged)`-Event und persistiert via
 * {@code KiModelsApiService.setPreferredCategory()}. So bleibt die
 * Component testbar ohne HTTP-Mock und Konsumenten können
 * pre/post-Validierung machen (z.B. Bestätigungs-Dialog).
 *
 * <h3>Auto-Mode-Info-Card</h3>
 * Wenn die Component zusätzlich im Auto-Mode-Kontext gerendert wird (siehe
 * {@link autoMode}-Input), zeigt sie unter dem Toggle eine erklärende
 * Info-Card mit optionalem Scroll-Button zur Cascade-Konfiguration. Wer den
 * Bereich nur als Toggle (ohne Auto-Card) nutzen will, setzt {@link autoMode}
 * auf false (Default) — dann wird nur der Toggle gerendert.
 */
class CascadeModePanelComponent {
    constructor() {
        /**
         * Liste der verfügbaren Cascade-Kategorien (z.B. ['cloud', 'free-only']).
         * Leeres Array → die ganze Component rendert nichts.
         */
        this.categories = [];
        /** Aktuell aktiver Bereich. Leer = Semantic Routing (kein Override). */
        this.activeCategory = '';
        /** Optionale Hint-Strings pro Kategorie (z.B. "Bezahlte Premium-Modelle"). */
        this.categoryHintMap = {};
        /** Optionale Display-Titel pro Kategorie (Vorrang vor `categoryHintMap`).
         *  Beispiel: {`cloud`: 'Cloud — Premium-Modelle'} */
        this.categoryTitles = {};
        /**
         * Wenn true: zeigt zusätzlich eine Info-Card mit Auto-Failover-Hinweis +
         * optionalem Scroll-Button. Konsument setzt das wenn der umgebende Kontext
         * im Auto-Mode ist (z.B. Switcher: `mode === 'auto'`).
         */
        this.autoMode = false;
        /** Wenn gesetzt: DOM-ID, zu dem der Scroll-Button springen soll
         *  (z.B. "cascade-bereiche-section"). Wenn leer: kein Button. */
        this.scrollTargetId = '';
        /** Konsumenten-i18n-Override. Default = englische Labels. */
        this.L = CASCADE_MODE_PANEL_LABELS_EN;
        /** User klickt einen Bereich-Tab → propagiert nach oben. Idempotent. */
        this.categoryChanged = new EventEmitter();
    }
    set labels(v) {
        this.L = { ...CASCADE_MODE_PANEL_LABELS_EN, ...(v ?? {}) };
    }
    setCategory(c) {
        if (this.activeCategory === c)
            return;
        this.categoryChanged.emit(c);
    }
    /**
     * Display-Label für eine Kategorie. Priorität:
     * 1. categoryTitles[c]
     * 2. categoryHintMap[c]
     * 3. Capitalized-Slug ("free-only" → "Free Only")
     */
    labelFor(c) {
        return this.categoryTitles?.[c]
            ?? this.categoryHintMap?.[c]
            ?? c.split(/[-_]/).map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
    }
    /** Hint-Text rechts vom Toggle. */
    activeHintText() {
        if (!this.activeCategory)
            return this.L.hintSemanticRouting;
        return this.L.hintOverrideTemplate.replace('{cat}', this.labelFor(this.activeCategory));
    }
    /** Info-Card-Text wenn Bereich aktiv. */
    autoActiveText() {
        return this.L.autoCardActiveTemplate.replace('{cat}', this.labelFor(this.activeCategory));
    }
    /**
     * Scroll zur konfigurierten DOM-ID. Nutzt smooth-scroll und block:'start'
     * damit der User die Card oben am Viewport sieht.
     */
    scrollToTarget() {
        if (!this.scrollTargetId || typeof document === 'undefined')
            return;
        const el = document.getElementById(this.scrollTargetId);
        el?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CascadeModePanelComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CascadeModePanelComponent, isStandalone: true, selector: "ki-cascade-mode-panel", inputs: { categories: "categories", activeCategory: "activeCategory", categoryHintMap: "categoryHintMap", categoryTitles: "categoryTitles", autoMode: "autoMode", scrollTargetId: "scrollTargetId", labels: "labels" }, outputs: { categoryChanged: "categoryChanged" }, ngImport: i0, template: `
    <div class="ki-cmp">
      <!-- Bereich-Toggle: nur sichtbar wenn Categories vorhanden -->
      <div *ngIf="categories.length > 0" class="ki-cmp-row">
        <span class="ki-cmp-legend">{{ L.toggleLegend }}</span>
        <div class="ki-cmp-toggle">
          <!-- v0.14.1: „Auto"-Tab ganz links damit User den Override
               wieder abwählen kann ohne sich durch Browser-Devtools zu
               klicken. Aktiv wenn activeCategory leer ist (Semantic
               Routing). Klick setzt activeCategory = '' (kein Override). -->
          <button type="button"
                  (click)="setCategory('')"
                  class="ki-cmp-tab ki-cmp-tab-off"
                  [class.ki-cmp-tab-active]="!activeCategory"
                  [title]="L.hintSemanticRouting">
            {{ L.offButtonLabel }}
          </button>
          <button *ngFor="let c of categories"
                  type="button"
                  (click)="setCategory(c)"
                  class="ki-cmp-tab"
                  [class.ki-cmp-tab-active]="activeCategory === c">
            {{ labelFor(c) }}
          </button>
        </div>
        <span class="ki-cmp-hint">{{ activeHintText() }}</span>
      </div>

      <!-- Auto-Mode Info-Card (nur wenn autoMode=true) -->
      <div *ngIf="autoMode" class="ki-cmp-card">
        <ng-container *ngIf="activeCategory; else autoNoCategory">
          <p class="ki-cmp-card-text">
            {{ autoActiveText() }}
          </p>
          <button *ngIf="scrollTargetId"
                  type="button"
                  (click)="scrollToTarget()"
                  class="ki-cmp-card-btn">
            {{ L.btnScrollToCascade }}
          </button>
        </ng-container>
        <ng-template #autoNoCategory>
          <p class="ki-cmp-card-text-muted">
            {{ L.autoCardSemanticHint }}
          </p>
        </ng-template>
      </div>
    </div>
  `, isInline: true, styles: [".ki-cmp{font-family:inherit}.ki-cmp-row{display:flex;align-items:center;gap:.75rem;flex-wrap:wrap;margin:.25rem 0}.ki-cmp-legend{font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#64748b}.ki-cmp-toggle{display:inline-flex;padding:.25rem;border-radius:9999px;background:#f1f5f9;border:1px solid #e2e8f0}.ki-cmp-tab{padding:.35rem 1rem;font-size:.75rem;font-weight:700;letter-spacing:.025em;border-radius:9999px;border:none;background:transparent;color:#64748b;cursor:pointer;transition:background .15s,color .15s}.ki-cmp-tab:hover{color:#1e293b}.ki-cmp-tab-active{background:#0f172a;color:#f8fafc}.ki-cmp-tab-active:hover{color:#f8fafc}.ki-cmp-tab-off{font-style:italic}.ki-cmp-tab-off.ki-cmp-tab-active{background:#475569;color:#f8fafc}.ki-cmp-hint{font-size:.7rem;color:#64748b;font-style:italic}.ki-cmp-card{margin-top:.75rem;padding:.9rem 1rem;background:#f8fafc;border:1px solid #e2e8f0;border-radius:.75rem}.ki-cmp-card-text{margin:0 0 .5rem;font-size:.85rem;color:#334155;line-height:1.5}.ki-cmp-card-text-muted{margin:0;font-size:.85rem;color:#64748b;line-height:1.5}.ki-cmp-card-btn{padding:.4rem .9rem;background:#0f172a;color:#f8fafc;border:none;border-radius:.5rem;font-size:.75rem;font-weight:700;cursor:pointer;transition:opacity .15s}.ki-cmp-card-btn:hover{opacity:.9}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CascadeModePanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-cascade-mode-panel', standalone: true, imports: [CommonModule], template: `
    <div class="ki-cmp">
      <!-- Bereich-Toggle: nur sichtbar wenn Categories vorhanden -->
      <div *ngIf="categories.length > 0" class="ki-cmp-row">
        <span class="ki-cmp-legend">{{ L.toggleLegend }}</span>
        <div class="ki-cmp-toggle">
          <!-- v0.14.1: „Auto"-Tab ganz links damit User den Override
               wieder abwählen kann ohne sich durch Browser-Devtools zu
               klicken. Aktiv wenn activeCategory leer ist (Semantic
               Routing). Klick setzt activeCategory = '' (kein Override). -->
          <button type="button"
                  (click)="setCategory('')"
                  class="ki-cmp-tab ki-cmp-tab-off"
                  [class.ki-cmp-tab-active]="!activeCategory"
                  [title]="L.hintSemanticRouting">
            {{ L.offButtonLabel }}
          </button>
          <button *ngFor="let c of categories"
                  type="button"
                  (click)="setCategory(c)"
                  class="ki-cmp-tab"
                  [class.ki-cmp-tab-active]="activeCategory === c">
            {{ labelFor(c) }}
          </button>
        </div>
        <span class="ki-cmp-hint">{{ activeHintText() }}</span>
      </div>

      <!-- Auto-Mode Info-Card (nur wenn autoMode=true) -->
      <div *ngIf="autoMode" class="ki-cmp-card">
        <ng-container *ngIf="activeCategory; else autoNoCategory">
          <p class="ki-cmp-card-text">
            {{ autoActiveText() }}
          </p>
          <button *ngIf="scrollTargetId"
                  type="button"
                  (click)="scrollToTarget()"
                  class="ki-cmp-card-btn">
            {{ L.btnScrollToCascade }}
          </button>
        </ng-container>
        <ng-template #autoNoCategory>
          <p class="ki-cmp-card-text-muted">
            {{ L.autoCardSemanticHint }}
          </p>
        </ng-template>
      </div>
    </div>
  `, styles: [".ki-cmp{font-family:inherit}.ki-cmp-row{display:flex;align-items:center;gap:.75rem;flex-wrap:wrap;margin:.25rem 0}.ki-cmp-legend{font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#64748b}.ki-cmp-toggle{display:inline-flex;padding:.25rem;border-radius:9999px;background:#f1f5f9;border:1px solid #e2e8f0}.ki-cmp-tab{padding:.35rem 1rem;font-size:.75rem;font-weight:700;letter-spacing:.025em;border-radius:9999px;border:none;background:transparent;color:#64748b;cursor:pointer;transition:background .15s,color .15s}.ki-cmp-tab:hover{color:#1e293b}.ki-cmp-tab-active{background:#0f172a;color:#f8fafc}.ki-cmp-tab-active:hover{color:#f8fafc}.ki-cmp-tab-off{font-style:italic}.ki-cmp-tab-off.ki-cmp-tab-active{background:#475569;color:#f8fafc}.ki-cmp-hint{font-size:.7rem;color:#64748b;font-style:italic}.ki-cmp-card{margin-top:.75rem;padding:.9rem 1rem;background:#f8fafc;border:1px solid #e2e8f0;border-radius:.75rem}.ki-cmp-card-text{margin:0 0 .5rem;font-size:.85rem;color:#334155;line-height:1.5}.ki-cmp-card-text-muted{margin:0;font-size:.85rem;color:#64748b;line-height:1.5}.ki-cmp-card-btn{padding:.4rem .9rem;background:#0f172a;color:#f8fafc;border:none;border-radius:.5rem;font-size:.75rem;font-weight:700;cursor:pointer;transition:opacity .15s}.ki-cmp-card-btn:hover{opacity:.9}\n"] }]
        }], propDecorators: { categories: [{
                type: Input
            }], activeCategory: [{
                type: Input
            }], categoryHintMap: [{
                type: Input
            }], categoryTitles: [{
                type: Input
            }], autoMode: [{
                type: Input
            }], scrollTargetId: [{
                type: Input
            }], labels: [{
                type: Input
            }], categoryChanged: [{
                type: Output
            }] } });

/**
 * v0.14.0 — Performance-Tabelle pro Modell der letzten 30 Tage.
 *
 * Zeigt: provider · model · calls · success% · avg chars · est cost.
 *
 * Cost-Spalte erscheint nur wenn der Konsument ein {@link costMapping}
 * (USD pro 1M Output-Tokens pro Provider) liefert. Beispiel:
 * ```ts
 * costMapping = {
 *   gemini: 0.30,        // Gemini 2.5 Flash output
 *   anthropic: 5.00,     // Claude Sonnet/Haiku output (Approx)
 *   openrouter: 0.40,    // Avg DeepSeek/Llama free → small paid
 *   openai: 2.00,
 *   ollama: 0,           // lokal = kostenlos
 * }
 * ```
 *
 * Konsumenten-Use-Case:
 * - EduPro: ersetzt die alte `/admin/stats/llm-performance`-Tabelle im
 *   Operations-Tab
 * - Switcher: kann embedded werden in der Stats-Section (optional)
 */
class ModelsPerformanceComponent {
    constructor() {
        this.api = inject(KiModelsApiService);
        this.title = 'LLM-Performance — letzte 30 Tage';
        this.subtitle = 'Calls + Erfolg + Cost pro Provider/Modell.';
        /**
         * USD pro 1M Output-Tokens pro Provider. Konsument liefert sein Mapping.
         * Wenn leer/unset: Cost-Spalte wird ausgeblendet.
         *
         * Beispiel: `{ gemini: 0.30, anthropic: 5.00, openrouter: 0.40 }`.
         */
        this.costMapping = null;
        /** Token-Schätzung: ~4 chars pro Token. */
        this.CHARS_PER_TOKEN = 4;
        /** Währungs-Label hinter dem Cost-Wert. Default USD. */
        this.costCurrency = 'EUR';
        /** USD → EUR Konvertierungs-Faktor (Default Stand 2026). */
        this.usdToEur = 0.92;
        /** Seitengröße der Tabelle. Pager nur sichtbar wenn mehr Zeilen. */
        this.pageSize = 10;
        this.sortBy = 'calls-desc';
        this.rows = signal([]);
        this.loading = signal(true);
        this.page = signal(0);
        this.filter = signal('');
        this.sort = signal({ key: null, dir: null });
        this.viewRows = computed(() => sortRows(filterRows(this.rows(), this.filter(), ['provider', 'model']), this.sort()));
        this.pageRows = computed(() => paginate(this.viewRows(), this.page(), this.pageSize));
    }
    glyph(key) { return sortGlyph(this.sort(), key); }
    sortCol(key) { this.sort.set(nextSort(this.sort(), key)); this.page.set(0); }
    setFilter(v) { this.filter.set(v); this.page.set(0); }
    get hasCost() {
        return !!this.costMapping && Object.keys(this.costMapping).length > 0;
    }
    get costNote() {
        return this.costCurrency === 'EUR'
            ? `Provider-Preis (USD/1M Output-Tokens, *${this.usdToEur} → EUR)`
            : 'Provider-Preis (USD/1M Output-Tokens)';
    }
    ngOnInit() {
        this.reload();
    }
    reload() {
        this.loading.set(true);
        this.page.set(0);
        this.api.getPerformance(this.sortBy).subscribe({
            next: (rows) => {
                this.rows.set(Array.isArray(rows) ? rows : []);
                this.loading.set(false);
            },
            error: () => {
                this.rows.set([]);
                this.loading.set(false);
            },
        });
    }
    /**
     * Cost-Schätzung pro Zeile: `(totalChars / CHARS_PER_TOKEN) * (price / 1M)`
     * → USD, dann optional EUR-Konvertierung.
     */
    estCost(r) {
        if (!this.costMapping)
            return 0;
        const pricePerMillion = this.costMapping[r.provider] ?? 0;
        const tokens = r.totalChars / this.CHARS_PER_TOKEN;
        const usd = (tokens * pricePerMillion) / 1_000_000;
        return this.costCurrency === 'EUR' ? usd * this.usdToEur : usd;
    }
    successClass(rate) {
        if (rate >= 0.95)
            return 'ki-success-good';
        if (rate >= 0.7)
            return 'ki-success-ok';
        return 'ki-success-bad';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ModelsPerformanceComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ModelsPerformanceComponent, isStandalone: true, selector: "ki-models-performance", inputs: { title: "title", subtitle: "subtitle", costMapping: "costMapping", costCurrency: "costCurrency", usdToEur: "usdToEur", pageSize: "pageSize" }, ngImport: i0, template: `
    <div class="ki-perf">
      <div class="ki-header">
        <div>
          <h4 class="ki-title">{{ title }}</h4>
          <p class="ki-subtitle">{{ subtitle }}</p>
        </div>
        <div class="ki-controls">
          <label class="ki-tiny ki-muted">Sort:</label>
          <select [(ngModel)]="sortBy" (change)="reload()" class="ki-select">
            <option value="calls-desc">Meiste Calls</option>
            <option value="success-desc">Beste Success-Rate</option>
            <option value="chars-desc">Meiste Chars</option>
          </select>
          <button (click)="reload()" class="ki-btn-refresh" title="Tabelle neu laden">↻</button>
        </div>
      </div>

      <p *ngIf="loading()" class="ki-muted">Lade Performance-Stats…</p>
      <p *ngIf="!loading() && rows().length === 0" class="ki-empty">
        Keine Calls in den letzten 30 Tagen.
      </p>

      <input *ngIf="rows().length > 0"
        class="ki-filter" type="text" placeholder="Filtern…"
        [value]="filter()" (input)="setFilter($any($event.target).value)" />

      <table *ngIf="rows().length > 0" class="ki-table">
        <thead>
          <tr>
            <th class="ki-sortable" (click)="sortCol('model')">Modell <span class="ki-glyph">{{ glyph('model') }}</span></th>
            <th class="ki-right ki-sortable" (click)="sortCol('calls')">Calls <span class="ki-glyph">{{ glyph('calls') }}</span></th>
            <th class="ki-right ki-sortable" (click)="sortCol('successRate')">Erfolg <span class="ki-glyph">{{ glyph('successRate') }}</span></th>
            <th class="ki-right ki-sortable" (click)="sortCol('avgChars')">Ø Chars <span class="ki-glyph">{{ glyph('avgChars') }}</span></th>
            <th *ngIf="hasCost" class="ki-right">Cost (30d)</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let r of pageRows()">
            <td class="ki-mono">
              <span class="ki-provider">{{ r.provider }}</span>
              <strong>{{ r.model }}</strong>
            </td>
            <td class="ki-right ki-mono">{{ r.calls }}</td>
            <td class="ki-right">
              <span [class]="successClass(r.successRate)">
                {{ (r.successRate * 100) | number:'1.0-1' }}%
              </span>
            </td>
            <td class="ki-right ki-tiny ki-muted">{{ r.avgChars }}</td>
            <td *ngIf="hasCost" class="ki-right ki-mono">
              {{ estCost(r) | number:'1.2-4' }} {{ costCurrency }}
            </td>
          </tr>
        </tbody>
      </table>

      <ki-pager
        [total]="viewRows().length"
        [page]="page()"
        [pageSize]="pageSize"
        (pageChange)="page.set($event)">
      </ki-pager>

      <p *ngIf="hasCost" class="ki-cost-note">
        Cost geschätzt aus output_chars × {{ costNote }}.
        Free-Tier-Calls = 0 (Provider ohne Mapping kosten 0).
      </p>
    </div>
  `, isInline: true, styles: [".ki-perf{font-family:inherit;padding:1rem 0}.ki-header{display:flex;justify-content:space-between;align-items:flex-start;gap:1rem;margin-bottom:1rem}.ki-title{font-size:.85rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#1e293b;margin:0 0 .25rem}.ki-subtitle{font-size:.7rem;color:#64748b;margin:0}.ki-controls{display:flex;gap:.5rem;align-items:center}.ki-select{padding:.35rem .6rem;border:1px solid #cbd5e1;border-radius:.375rem;font-size:.75rem;background:#fff}.ki-btn-refresh{padding:.35rem .6rem;background:#e0e7ff;color:#3730a3;border:none;border-radius:.375rem;font-size:.8rem;cursor:pointer}.ki-filter{width:100%;box-sizing:border-box;padding:.4rem .6rem;margin-bottom:.5rem;border:1px solid #e2e8f0;border-radius:.375rem;font-size:.8rem}.ki-table{width:100%;border-collapse:collapse;font-size:.85rem}.ki-table thead tr{border-bottom:2px solid #e2e8f0}.ki-table th{padding:.5rem .6rem;text-align:left;text-transform:uppercase;font-size:.6rem;font-weight:800;letter-spacing:.08em;color:#64748b}.ki-sortable{cursor:pointer;-webkit-user-select:none;user-select:none;white-space:nowrap}.ki-sortable:hover{color:#4f46e5}.ki-glyph{font-size:.6rem;opacity:.6}.ki-table td{padding:.55rem .6rem;border-bottom:1px solid #f1f5f9}.ki-right{text-align:right}.ki-mono{font-family:ui-monospace,monospace}.ki-muted{color:#94a3b8}.ki-tiny{font-size:.7rem}.ki-provider{color:#4f46e5;font-weight:700;margin-right:.4rem}.ki-success-good{color:#059669;font-weight:700}.ki-success-ok{color:#d97706;font-weight:700}.ki-success-bad{color:#dc2626;font-weight:800}.ki-empty{text-align:center;padding:1.5rem;color:#94a3b8}.ki-cost-note{font-size:.7rem;color:#94a3b8;margin:.75rem 0 0;font-style:italic}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: i1.DecimalPipe, name: "number" }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.NgSelectOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.ɵNgSelectMultipleOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.SelectControlValueAccessor, selector: "select:not([multiple])[formControlName],select:not([multiple])[formControl],select:not([multiple])[ngModel]", inputs: ["compareWith"] }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: KiPagerComponent, selector: "ki-pager", inputs: ["total", "page", "pageSize"], outputs: ["pageChange"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ModelsPerformanceComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-models-performance', standalone: true, imports: [CommonModule, FormsModule, KiPagerComponent], template: `
    <div class="ki-perf">
      <div class="ki-header">
        <div>
          <h4 class="ki-title">{{ title }}</h4>
          <p class="ki-subtitle">{{ subtitle }}</p>
        </div>
        <div class="ki-controls">
          <label class="ki-tiny ki-muted">Sort:</label>
          <select [(ngModel)]="sortBy" (change)="reload()" class="ki-select">
            <option value="calls-desc">Meiste Calls</option>
            <option value="success-desc">Beste Success-Rate</option>
            <option value="chars-desc">Meiste Chars</option>
          </select>
          <button (click)="reload()" class="ki-btn-refresh" title="Tabelle neu laden">↻</button>
        </div>
      </div>

      <p *ngIf="loading()" class="ki-muted">Lade Performance-Stats…</p>
      <p *ngIf="!loading() && rows().length === 0" class="ki-empty">
        Keine Calls in den letzten 30 Tagen.
      </p>

      <input *ngIf="rows().length > 0"
        class="ki-filter" type="text" placeholder="Filtern…"
        [value]="filter()" (input)="setFilter($any($event.target).value)" />

      <table *ngIf="rows().length > 0" class="ki-table">
        <thead>
          <tr>
            <th class="ki-sortable" (click)="sortCol('model')">Modell <span class="ki-glyph">{{ glyph('model') }}</span></th>
            <th class="ki-right ki-sortable" (click)="sortCol('calls')">Calls <span class="ki-glyph">{{ glyph('calls') }}</span></th>
            <th class="ki-right ki-sortable" (click)="sortCol('successRate')">Erfolg <span class="ki-glyph">{{ glyph('successRate') }}</span></th>
            <th class="ki-right ki-sortable" (click)="sortCol('avgChars')">Ø Chars <span class="ki-glyph">{{ glyph('avgChars') }}</span></th>
            <th *ngIf="hasCost" class="ki-right">Cost (30d)</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let r of pageRows()">
            <td class="ki-mono">
              <span class="ki-provider">{{ r.provider }}</span>
              <strong>{{ r.model }}</strong>
            </td>
            <td class="ki-right ki-mono">{{ r.calls }}</td>
            <td class="ki-right">
              <span [class]="successClass(r.successRate)">
                {{ (r.successRate * 100) | number:'1.0-1' }}%
              </span>
            </td>
            <td class="ki-right ki-tiny ki-muted">{{ r.avgChars }}</td>
            <td *ngIf="hasCost" class="ki-right ki-mono">
              {{ estCost(r) | number:'1.2-4' }} {{ costCurrency }}
            </td>
          </tr>
        </tbody>
      </table>

      <ki-pager
        [total]="viewRows().length"
        [page]="page()"
        [pageSize]="pageSize"
        (pageChange)="page.set($event)">
      </ki-pager>

      <p *ngIf="hasCost" class="ki-cost-note">
        Cost geschätzt aus output_chars × {{ costNote }}.
        Free-Tier-Calls = 0 (Provider ohne Mapping kosten 0).
      </p>
    </div>
  `, styles: [".ki-perf{font-family:inherit;padding:1rem 0}.ki-header{display:flex;justify-content:space-between;align-items:flex-start;gap:1rem;margin-bottom:1rem}.ki-title{font-size:.85rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#1e293b;margin:0 0 .25rem}.ki-subtitle{font-size:.7rem;color:#64748b;margin:0}.ki-controls{display:flex;gap:.5rem;align-items:center}.ki-select{padding:.35rem .6rem;border:1px solid #cbd5e1;border-radius:.375rem;font-size:.75rem;background:#fff}.ki-btn-refresh{padding:.35rem .6rem;background:#e0e7ff;color:#3730a3;border:none;border-radius:.375rem;font-size:.8rem;cursor:pointer}.ki-filter{width:100%;box-sizing:border-box;padding:.4rem .6rem;margin-bottom:.5rem;border:1px solid #e2e8f0;border-radius:.375rem;font-size:.8rem}.ki-table{width:100%;border-collapse:collapse;font-size:.85rem}.ki-table thead tr{border-bottom:2px solid #e2e8f0}.ki-table th{padding:.5rem .6rem;text-align:left;text-transform:uppercase;font-size:.6rem;font-weight:800;letter-spacing:.08em;color:#64748b}.ki-sortable{cursor:pointer;-webkit-user-select:none;user-select:none;white-space:nowrap}.ki-sortable:hover{color:#4f46e5}.ki-glyph{font-size:.6rem;opacity:.6}.ki-table td{padding:.55rem .6rem;border-bottom:1px solid #f1f5f9}.ki-right{text-align:right}.ki-mono{font-family:ui-monospace,monospace}.ki-muted{color:#94a3b8}.ki-tiny{font-size:.7rem}.ki-provider{color:#4f46e5;font-weight:700;margin-right:.4rem}.ki-success-good{color:#059669;font-weight:700}.ki-success-ok{color:#d97706;font-weight:700}.ki-success-bad{color:#dc2626;font-weight:800}.ki-empty{text-align:center;padding:1.5rem;color:#94a3b8}.ki-cost-note{font-size:.7rem;color:#94a3b8;margin:.75rem 0 0;font-style:italic}\n"] }]
        }], propDecorators: { title: [{
                type: Input
            }], subtitle: [{
                type: Input
            }], costMapping: [{
                type: Input
            }], costCurrency: [{
                type: Input
            }], usdToEur: [{
                type: Input
            }], pageSize: [{
                type: Input
            }] } });

/**
 * v0.14.0 — Cooldown + Auto-Disable State pro Modell.
 *
 * Zeigt:
 * - rote Zeile bei `autoDisabled=true` (System hat das Modell gekillt)
 * - gelbe Zeile bei `cooldownRemainingSec > 0` (Modell hat gerade Fehler, kommt zurück)
 * - grüne / neutrale Zeile für gesunde Modelle
 * - Live-Auto-Refresh alle 30s damit der Cooldown-Counter live runterläuft
 *
 * Konsumenten-Use-Case:
 * - EduPro: ersetzt die `/admin/stats/gemini`-Card im Operations-Tab
 * - Switcher: kann embedded werden für Cooldown-Visibilität
 */
class ModelsCooldownStateComponent {
    constructor() {
        this.api = inject(KiModelsApiService);
        this.title = 'Cooldown-State — pro Modell';
        this.subtitle = 'Live-Status: KILLED (rot) → Cooldown (gelb) → ready (grün).';
        /** Auto-Refresh-Intervall in Sekunden. Default 30s. 0 disabled. */
        this.autoRefreshSec = 30;
        /** Seitengröße. Pager nur sichtbar wenn mehr Zeilen. Kein Page-Reset beim
         *  Auto-Refresh — paginate() klemmt defensiv. */
        this.pageSize = 10;
        this.rows = signal([]);
        this.loading = signal(true);
        this.page = signal(0);
        this.filter = signal('');
        this.sort = signal({ key: null, dir: null });
        this.viewRows = computed(() => sortRows(filterRows(this.rows(), this.filter(), ['provider', 'modelId', 'displayName', 'category', 'autoDisabledReason']), this.sort()));
        this.pageRows = computed(() => paginate(this.viewRows(), this.page(), this.pageSize));
        /** v0.15.0 — 1s-Tick, lässt den Cooldown-Zähler zwischen den Reloads sichtbar
         *  runterlaufen. `fetchedAt` = Zeitpunkt des letzten Backend-Werts. */
        this.tick = signal(Date.now());
        this.fetchedAt = Date.now();
        this.timer = null;
        this.tickTimer = null;
    }
    glyph(key) { return sortGlyph(this.sort(), key); }
    sortCol(key) { this.sort.set(nextSort(this.sort(), key)); this.page.set(0); }
    setFilter(v) { this.filter.set(v); this.page.set(0); }
    ngOnInit() {
        this.reload();
        if (this.autoRefreshSec > 0) {
            this.timer = setInterval(() => this.reload(), this.autoRefreshSec * 1000);
        }
        // Sekunden-Tick für die Live-Anzeige — rein lokal, kein API-Traffic.
        this.tickTimer = setInterval(() => this.tick.set(Date.now()), 1000);
    }
    ngOnDestroy() {
        if (this.timer)
            clearInterval(this.timer);
        if (this.tickTimer)
            clearInterval(this.tickTimer);
        this.timer = null;
        this.tickTimer = null;
    }
    reload() {
        this.loading.set(true);
        this.api.getCooldownState().subscribe({
            next: (rows) => {
                this.rows.set(Array.isArray(rows) ? rows : []);
                this.fetchedAt = Date.now();
                this.tick.set(this.fetchedAt);
                this.loading.set(false);
            },
            error: () => {
                this.rows.set([]);
                this.loading.set(false);
            },
        });
    }
    /**
     * v0.15.0 — Live-Restzeit: Backend-Wert minus seither vergangene Sekunden.
     * Liest {@link tick}, damit die Anzeige jede Sekunde neu berechnet wird.
     */
    liveRemaining(r) {
        const elapsed = Math.floor((this.tick() - this.fetchedAt) / 1000);
        return Math.max(0, (r.cooldownRemainingSec ?? 0) - elapsed);
    }
    statusIcon(r) {
        if (r.autoDisabled)
            return '✗';
        if (this.liveRemaining(r) > 0)
            return '⏳';
        if (!r.enabled)
            return '○';
        return '✓';
    }
    /**
     * Cooldown-Sekunden lesbar machen.
     * 0-90s: "Xs", 90s-90min: "Xm", 90min+: "Xh"
     */
    formatCooldown(sec) {
        if (sec < 90)
            return `${sec}s`;
        if (sec < 5400)
            return `${Math.round(sec / 60)}m`;
        return `${Math.round(sec / 3600)}h`;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ModelsCooldownStateComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ModelsCooldownStateComponent, isStandalone: true, selector: "ki-models-cooldown-state", inputs: { title: "title", subtitle: "subtitle", autoRefreshSec: "autoRefreshSec", pageSize: "pageSize" }, ngImport: i0, template: `
    <div class="ki-cd">
      <div class="ki-header">
        <div>
          <h4 class="ki-title">{{ title }}</h4>
          <p class="ki-subtitle">{{ subtitle }}</p>
        </div>
        <button (click)="reload()" class="ki-btn-refresh" title="Jetzt neu laden">↻</button>
      </div>

      <p *ngIf="loading()" class="ki-muted">Lade Cooldown-State…</p>
      <p *ngIf="!loading() && rows().length === 0" class="ki-empty">
        Keine Modelle konfiguriert.
      </p>

      <input *ngIf="rows().length > 0"
        class="ki-filter" type="text" placeholder="Filtern…"
        [value]="filter()" (input)="setFilter($any($event.target).value)" />

      <table *ngIf="rows().length > 0" class="ki-table">
        <thead>
          <tr>
            <th></th>
            <th class="ki-sortable" (click)="sortCol('modelId')">Modell <span class="ki-glyph">{{ glyph('modelId') }}</span></th>
            <th class="ki-sortable" (click)="sortCol('category')">Kategorie <span class="ki-glyph">{{ glyph('category') }}</span></th>
            <th class="ki-right">Status</th>
            <th>Grund</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let r of pageRows()"
              [class.ki-row-killed]="r.autoDisabled"
              [class.ki-row-cooldown]="!r.autoDisabled && liveRemaining(r) > 0">
            <td class="ki-icon">
              {{ statusIcon(r) }}
            </td>
            <td class="ki-mono">
              <span class="ki-provider">{{ r.provider }}</span>
              <strong>{{ r.modelId }}</strong>
              <div *ngIf="r.displayName" class="ki-tiny ki-muted">{{ r.displayName }}</div>
            </td>
            <td class="ki-tiny">{{ r.category || '—' }}</td>
            <td class="ki-right ki-mono">
              <span *ngIf="r.autoDisabled" class="ki-status-killed">KILLED</span>
              <span *ngIf="!r.autoDisabled && liveRemaining(r) > 0" class="ki-status-cooldown">
                {{ formatCooldown(liveRemaining(r)) }}
              </span>
              <span *ngIf="!r.autoDisabled && liveRemaining(r) === 0 && r.enabled" class="ki-status-ok">
                ready
              </span>
              <span *ngIf="!r.autoDisabled && liveRemaining(r) === 0 && !r.enabled" class="ki-status-off">
                off
              </span>
            </td>
            <td class="ki-tiny ki-muted ki-reason">
              {{ r.autoDisabledReason || '—' }}
            </td>
          </tr>
        </tbody>
      </table>

      <ki-pager
        [total]="viewRows().length"
        [page]="page()"
        [pageSize]="pageSize"
        (pageChange)="page.set($event)">
      </ki-pager>

      <p class="ki-foot ki-tiny ki-muted">
        Auto-Refresh alle {{ autoRefreshSec }}s. Cooldown-Zähler lebt im
        Backend, hier wird er nur visualisiert.
      </p>
    </div>
  `, isInline: true, styles: [".ki-cd{font-family:inherit;padding:1rem 0}.ki-header{display:flex;justify-content:space-between;align-items:flex-start;gap:1rem;margin-bottom:1rem}.ki-title{font-size:.85rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#1e293b;margin:0 0 .25rem}.ki-subtitle{font-size:.7rem;color:#64748b;margin:0}.ki-btn-refresh{padding:.35rem .6rem;background:#e0e7ff;color:#3730a3;border:none;border-radius:.375rem;font-size:.8rem;cursor:pointer}.ki-filter{width:100%;box-sizing:border-box;padding:.4rem .6rem;margin-bottom:.5rem;border:1px solid #e2e8f0;border-radius:.375rem;font-size:.8rem}.ki-table{width:100%;border-collapse:collapse;font-size:.85rem}.ki-table thead tr{border-bottom:2px solid #e2e8f0}.ki-table th{padding:.5rem .6rem;text-align:left;text-transform:uppercase;font-size:.6rem;font-weight:800;letter-spacing:.08em;color:#64748b}.ki-sortable{cursor:pointer;-webkit-user-select:none;user-select:none;white-space:nowrap}.ki-sortable:hover{color:#4f46e5}.ki-glyph{font-size:.6rem;opacity:.6}.ki-table td{padding:.55rem .6rem;border-bottom:1px solid #f1f5f9;vertical-align:top}.ki-row-killed{background:linear-gradient(90deg,#fef2f2 0%,transparent 100%)}.ki-row-cooldown{background:linear-gradient(90deg,#fffbeb 0%,transparent 100%)}.ki-icon{font-size:1.2rem;text-align:center;width:2rem}.ki-right{text-align:right}.ki-mono{font-family:ui-monospace,monospace}.ki-muted{color:#94a3b8}.ki-tiny{font-size:.7rem}.ki-provider{color:#4f46e5;font-weight:700;margin-right:.4rem}.ki-reason{max-width:24rem;word-break:break-word}.ki-status-killed{background:#fee2e2;color:#991b1b;padding:.2rem .5rem;border-radius:.25rem;font-size:.7rem;font-weight:800}.ki-status-cooldown{background:#fef3c7;color:#92400e;padding:.2rem .5rem;border-radius:.25rem;font-size:.7rem;font-weight:700}.ki-status-ok{color:#059669;font-weight:700;font-size:.7rem}.ki-status-off{color:#94a3b8;font-weight:600;font-size:.7rem}.ki-empty{text-align:center;padding:1.5rem;color:#94a3b8}.ki-foot{margin-top:.75rem;font-style:italic}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: KiPagerComponent, selector: "ki-pager", inputs: ["total", "page", "pageSize"], outputs: ["pageChange"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ModelsCooldownStateComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-models-cooldown-state', standalone: true, imports: [CommonModule, KiPagerComponent], template: `
    <div class="ki-cd">
      <div class="ki-header">
        <div>
          <h4 class="ki-title">{{ title }}</h4>
          <p class="ki-subtitle">{{ subtitle }}</p>
        </div>
        <button (click)="reload()" class="ki-btn-refresh" title="Jetzt neu laden">↻</button>
      </div>

      <p *ngIf="loading()" class="ki-muted">Lade Cooldown-State…</p>
      <p *ngIf="!loading() && rows().length === 0" class="ki-empty">
        Keine Modelle konfiguriert.
      </p>

      <input *ngIf="rows().length > 0"
        class="ki-filter" type="text" placeholder="Filtern…"
        [value]="filter()" (input)="setFilter($any($event.target).value)" />

      <table *ngIf="rows().length > 0" class="ki-table">
        <thead>
          <tr>
            <th></th>
            <th class="ki-sortable" (click)="sortCol('modelId')">Modell <span class="ki-glyph">{{ glyph('modelId') }}</span></th>
            <th class="ki-sortable" (click)="sortCol('category')">Kategorie <span class="ki-glyph">{{ glyph('category') }}</span></th>
            <th class="ki-right">Status</th>
            <th>Grund</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let r of pageRows()"
              [class.ki-row-killed]="r.autoDisabled"
              [class.ki-row-cooldown]="!r.autoDisabled && liveRemaining(r) > 0">
            <td class="ki-icon">
              {{ statusIcon(r) }}
            </td>
            <td class="ki-mono">
              <span class="ki-provider">{{ r.provider }}</span>
              <strong>{{ r.modelId }}</strong>
              <div *ngIf="r.displayName" class="ki-tiny ki-muted">{{ r.displayName }}</div>
            </td>
            <td class="ki-tiny">{{ r.category || '—' }}</td>
            <td class="ki-right ki-mono">
              <span *ngIf="r.autoDisabled" class="ki-status-killed">KILLED</span>
              <span *ngIf="!r.autoDisabled && liveRemaining(r) > 0" class="ki-status-cooldown">
                {{ formatCooldown(liveRemaining(r)) }}
              </span>
              <span *ngIf="!r.autoDisabled && liveRemaining(r) === 0 && r.enabled" class="ki-status-ok">
                ready
              </span>
              <span *ngIf="!r.autoDisabled && liveRemaining(r) === 0 && !r.enabled" class="ki-status-off">
                off
              </span>
            </td>
            <td class="ki-tiny ki-muted ki-reason">
              {{ r.autoDisabledReason || '—' }}
            </td>
          </tr>
        </tbody>
      </table>

      <ki-pager
        [total]="viewRows().length"
        [page]="page()"
        [pageSize]="pageSize"
        (pageChange)="page.set($event)">
      </ki-pager>

      <p class="ki-foot ki-tiny ki-muted">
        Auto-Refresh alle {{ autoRefreshSec }}s. Cooldown-Zähler lebt im
        Backend, hier wird er nur visualisiert.
      </p>
    </div>
  `, styles: [".ki-cd{font-family:inherit;padding:1rem 0}.ki-header{display:flex;justify-content:space-between;align-items:flex-start;gap:1rem;margin-bottom:1rem}.ki-title{font-size:.85rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#1e293b;margin:0 0 .25rem}.ki-subtitle{font-size:.7rem;color:#64748b;margin:0}.ki-btn-refresh{padding:.35rem .6rem;background:#e0e7ff;color:#3730a3;border:none;border-radius:.375rem;font-size:.8rem;cursor:pointer}.ki-filter{width:100%;box-sizing:border-box;padding:.4rem .6rem;margin-bottom:.5rem;border:1px solid #e2e8f0;border-radius:.375rem;font-size:.8rem}.ki-table{width:100%;border-collapse:collapse;font-size:.85rem}.ki-table thead tr{border-bottom:2px solid #e2e8f0}.ki-table th{padding:.5rem .6rem;text-align:left;text-transform:uppercase;font-size:.6rem;font-weight:800;letter-spacing:.08em;color:#64748b}.ki-sortable{cursor:pointer;-webkit-user-select:none;user-select:none;white-space:nowrap}.ki-sortable:hover{color:#4f46e5}.ki-glyph{font-size:.6rem;opacity:.6}.ki-table td{padding:.55rem .6rem;border-bottom:1px solid #f1f5f9;vertical-align:top}.ki-row-killed{background:linear-gradient(90deg,#fef2f2 0%,transparent 100%)}.ki-row-cooldown{background:linear-gradient(90deg,#fffbeb 0%,transparent 100%)}.ki-icon{font-size:1.2rem;text-align:center;width:2rem}.ki-right{text-align:right}.ki-mono{font-family:ui-monospace,monospace}.ki-muted{color:#94a3b8}.ki-tiny{font-size:.7rem}.ki-provider{color:#4f46e5;font-weight:700;margin-right:.4rem}.ki-reason{max-width:24rem;word-break:break-word}.ki-status-killed{background:#fee2e2;color:#991b1b;padding:.2rem .5rem;border-radius:.25rem;font-size:.7rem;font-weight:800}.ki-status-cooldown{background:#fef3c7;color:#92400e;padding:.2rem .5rem;border-radius:.25rem;font-size:.7rem;font-weight:700}.ki-status-ok{color:#059669;font-weight:700;font-size:.7rem}.ki-status-off{color:#94a3b8;font-weight:600;font-size:.7rem}.ki-empty{text-align:center;padding:1.5rem;color:#94a3b8}.ki-foot{margin-top:.75rem;font-style:italic}\n"] }]
        }], propDecorators: { title: [{
                type: Input
            }], subtitle: [{
                type: Input
            }], autoRefreshSec: [{
                type: Input
            }], pageSize: [{
                type: Input
            }] } });

/**
 * v0.15.0 — Verwaltung benannter Inferenz-Server (llm-cascade ≥ 0.8.0).
 *
 * Lokale Modelle (Ollama) laufen normalerweise auf „localhost"; über benannte
 * Server kann ein Modell seine Inferenz an einen externen Rechner auslagern.
 * Diese Komponente listet die Server + erlaubt Add/Edit/Delete/Set-Default.
 * Das pro-Modell-Dropdown lebt in `<ki-models-table>` / `<ki-add-model-form>`.
 *
 * **Event:** `(serversChanged)` nach jeder Mutation — Konsument kann z.B. die
 * Models-Table neu laden lassen damit das Server-Dropdown aktuell ist.
 *
 * **Graceful degrade:** Backend < 0.8.0 liefert 404 auf `/provider-servers` →
 * leere Liste + dezenter Hinweis, kein Fehler.
 */
class ProviderServersComponent {
    constructor() {
        this.serversChanged = new EventEmitter();
        this.L = PROVIDER_SERVERS_LABELS_EN;
        this.api = inject(KiModelsApiService);
        /** Seitengröße der Server-Tabelle. Pager nur sichtbar wenn mehr Zeilen. */
        this.pageSize = 10;
        this.loading = signal(true);
        this.saving = signal(false);
        this.servers = signal([]);
        this.error = signal(null);
        this.page = signal(0);
        this.filter = signal('');
        this.sort = signal({ key: null, dir: null });
        this.viewServers = computed(() => sortRows(filterRows(this.servers(), this.filter(), ['name', 'baseUrl', 'description']), this.sort()));
        this.pageServers = computed(() => paginate(this.viewServers(), this.page(), this.pageSize));
        /** Name des aktuell editierten Servers; null = Add-Modus. */
        this.editingName = signal(null);
        this.formName = '';
        this.formBaseUrl = '';
        this.formDescription = '';
    }
    set labels(v) {
        this.L = { ...PROVIDER_SERVERS_LABELS_EN, ...(v ?? {}) };
    }
    glyph(key) { return sortGlyph(this.sort(), key); }
    sortCol(key) { this.sort.set(nextSort(this.sort(), key)); this.page.set(0); }
    setFilter(v) { this.filter.set(v); this.page.set(0); }
    static { this.NAME_RE = /^[a-z0-9_-]{1,50}$/; }
    ngOnInit() {
        this.reload();
    }
    reload() {
        this.loading.set(true);
        this.page.set(0);
        this.api.listProviderServers().subscribe({
            next: (list) => { this.servers.set(list ?? []); this.loading.set(false); },
            error: () => { this.servers.set([]); this.loading.set(false); },
        });
    }
    startEdit(s) {
        this.editingName.set(s.name);
        this.formName = s.name;
        this.formBaseUrl = s.baseUrl;
        this.formDescription = s.description ?? '';
        this.error.set(null);
    }
    cancelEdit() {
        this.editingName.set(null);
        this.formName = '';
        this.formBaseUrl = '';
        this.formDescription = '';
        this.error.set(null);
    }
    save() {
        const name = (this.editingName() ?? this.formName).trim().toLowerCase();
        const baseUrl = this.formBaseUrl.trim();
        if (!baseUrl) {
            this.error.set(this.L.errorBaseUrlRequired);
            return;
        }
        if (!ProviderServersComponent.NAME_RE.test(name)) {
            this.error.set(this.L.errorNameFormat);
            return;
        }
        this.saving.set(true);
        this.error.set(null);
        this.api.upsertProviderServer(name, {
            baseUrl,
            description: this.formDescription.trim() || null,
        }).subscribe({
            next: () => { this.saving.set(false); this.cancelEdit(); this.reload(); this.serversChanged.emit(); },
            error: (err) => { this.saving.set(false); this.error.set(err?.error?.error ?? 'Error'); },
        });
    }
    setDefault(s) {
        this.api.upsertProviderServer(s.name, { baseUrl: s.baseUrl, isDefault: true }).subscribe({
            next: () => { this.reload(); this.serversChanged.emit(); },
            error: (err) => this.error.set(err?.error?.error ?? 'Error'),
        });
    }
    remove(s) {
        if (s.isDefault) {
            this.error.set(this.L.errorDeleteDefault);
            return;
        }
        if (!confirm(this.L.confirmDelete(s.name)))
            return;
        this.api.deleteProviderServer(s.name).subscribe({
            next: () => { this.reload(); this.serversChanged.emit(); },
            error: (err) => this.error.set(err?.error?.error ?? this.L.errorDeleteDefault),
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ProviderServersComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ProviderServersComponent, isStandalone: true, selector: "ki-provider-servers", inputs: { labels: "labels", pageSize: "pageSize" }, outputs: { serversChanged: "serversChanged" }, ngImport: i0, template: `
    <section class="ki-provider-servers">
      <header class="ki-ps-header">
        <h4 class="ki-ps-title">{{ L.title }}</h4>
        <p class="ki-ps-subtitle">{{ L.subtitle }}</p>
      </header>

      <p *ngIf="loading()" class="ki-ps-muted">{{ L.loading }}</p>

      <div *ngIf="!loading()" class="ki-ps-table-wrap">
        <input *ngIf="servers().length > 0"
          class="ki-ps-filter" type="text" placeholder="Filtern…"
          [value]="filter()" (input)="setFilter($any($event.target).value)" />
        <table class="ki-ps-table">
          <thead>
            <tr>
              <th class="ki-ps-sortable" (click)="sortCol('name')">{{ L.colName }} <span class="ki-ps-glyph">{{ glyph('name') }}</span></th>
              <th class="ki-ps-sortable" (click)="sortCol('baseUrl')">{{ L.colBaseUrl }} <span class="ki-ps-glyph">{{ glyph('baseUrl') }}</span></th>
              <th>{{ L.colDefault }}</th>
              <th class="ki-ps-right">{{ L.colActions }}</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let s of pageServers()">
              <td class="ki-ps-mono"><strong>{{ s.name }}</strong>
                <div *ngIf="s.description" class="ki-ps-tiny ki-ps-muted">{{ s.description }}</div>
              </td>
              <td class="ki-ps-mono ki-ps-tiny">{{ s.baseUrl }}</td>
              <td>
                <span *ngIf="s.isDefault" class="ki-ps-badge">{{ L.badgeDefault }}</span>
              </td>
              <td class="ki-ps-right">
                <button class="ki-ps-btn" (click)="startEdit(s)">{{ L.btnEdit }}</button>
                <button *ngIf="!s.isDefault" class="ki-ps-btn" (click)="setDefault(s)">{{ L.btnSetDefault }}</button>
                <button *ngIf="!s.isDefault" class="ki-ps-btn ki-ps-danger" (click)="remove(s)">{{ L.btnDelete }}</button>
              </td>
            </tr>
            <tr *ngIf="!servers().length">
              <td colspan="4" class="ki-ps-muted ki-ps-tiny">{{ L.empty }}</td>
            </tr>
          </tbody>
        </table>

        <ki-pager
          [total]="viewServers().length"
          [page]="page()"
          [pageSize]="pageSize"
          (pageChange)="page.set($event)">
        </ki-pager>
      </div>

      <!-- Add / Edit form -->
      <form class="ki-ps-form" (ngSubmit)="save()">
        <input [(ngModel)]="formName" name="psName" [placeholder]="L.fieldName"
               [readonly]="!!editingName()" class="ki-ps-input ki-ps-mono" />
        <input [(ngModel)]="formBaseUrl" name="psBaseUrl" [placeholder]="L.fieldBaseUrl"
               class="ki-ps-input ki-ps-mono" />
        <input [(ngModel)]="formDescription" name="psDesc" [placeholder]="L.fieldDescription"
               class="ki-ps-input" />
        <div class="ki-ps-form-actions">
          <button type="submit" class="ki-ps-btn ki-ps-primary"
                  [disabled]="saving() || !formBaseUrl.trim() || (!editingName() && !formName.trim())">
            {{ editingName() ? L.btnSave : L.btnAdd }}
          </button>
          <button type="button" *ngIf="editingName()" class="ki-ps-btn" (click)="cancelEdit()">{{ L.btnCancel }}</button>
        </div>
      </form>

      <p *ngIf="error()" class="ki-ps-error">{{ error() }}</p>
      <p class="ki-ps-hint">{{ L.hint }}</p>
    </section>
  `, isInline: true, styles: [".ki-provider-servers{font-family:inherit;padding:1rem 0}.ki-ps-title{font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#475569;margin:0 0 .25rem}.ki-ps-subtitle{font-size:.75rem;color:#64748b;margin:0 0 .75rem}.ki-ps-table-wrap{overflow-x:auto}.ki-ps-filter{width:100%;box-sizing:border-box;padding:.4rem .6rem;margin-bottom:.5rem;border:1px solid #e2e8f0;border-radius:.375rem;font-size:.8rem}.ki-ps-sortable{cursor:pointer;-webkit-user-select:none;user-select:none;white-space:nowrap}.ki-ps-sortable:hover{color:#4f46e5}.ki-ps-glyph{font-size:.6rem;opacity:.6}.ki-ps-table{width:100%;border-collapse:collapse;font-size:.8rem}.ki-ps-table th{text-align:left;padding:.35rem .5rem;color:#64748b;font-size:.65rem;text-transform:uppercase;letter-spacing:.05em;border-bottom:1px solid #e2e8f0}.ki-ps-table td{padding:.4rem .5rem;border-bottom:1px solid #f1f5f9;vertical-align:top}.ki-ps-right{text-align:right}.ki-ps-mono{font-family:ui-monospace,monospace}.ki-ps-tiny{font-size:.7rem}.ki-ps-muted{color:#94a3b8}.ki-ps-badge{display:inline-block;padding:.1rem .35rem;border-radius:.25rem;background:#d1fae5;color:#065f46;font-size:.6rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em}.ki-ps-btn{padding:.25rem .5rem;margin-left:.25rem;border:1px solid #cbd5e1;background:#fff;border-radius:.4rem;font-size:.7rem;font-weight:700;cursor:pointer}.ki-ps-btn:disabled{opacity:.4;cursor:not-allowed}.ki-ps-primary{background:#0f172a;color:#fff;border-color:#0f172a}.ki-ps-danger{color:#b91c1c;border-color:#fecaca}.ki-ps-form{display:flex;flex-wrap:wrap;gap:.5rem;margin-top:.75rem;align-items:center}.ki-ps-input{padding:.5rem;background:#f8fafc;border:2px solid #f1f5f9;border-radius:.5rem;font-size:.8rem;flex:1 1 12rem}.ki-ps-input[readonly]{opacity:.6}.ki-ps-form-actions{display:flex;gap:.25rem}.ki-ps-error{color:#b91c1c;font-weight:700;font-size:.75rem;margin-top:.5rem}.ki-ps-hint{color:#94a3b8;font-size:.7rem;font-weight:600;margin-top:.5rem}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: i2.NgForm, selector: "form:not([ngNoForm]):not([formGroup]),ng-form,[ngForm]", inputs: ["ngFormOptions"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "component", type: KiPagerComponent, selector: "ki-pager", inputs: ["total", "page", "pageSize"], outputs: ["pageChange"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ProviderServersComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-provider-servers', standalone: true, imports: [CommonModule, FormsModule, KiPagerComponent], template: `
    <section class="ki-provider-servers">
      <header class="ki-ps-header">
        <h4 class="ki-ps-title">{{ L.title }}</h4>
        <p class="ki-ps-subtitle">{{ L.subtitle }}</p>
      </header>

      <p *ngIf="loading()" class="ki-ps-muted">{{ L.loading }}</p>

      <div *ngIf="!loading()" class="ki-ps-table-wrap">
        <input *ngIf="servers().length > 0"
          class="ki-ps-filter" type="text" placeholder="Filtern…"
          [value]="filter()" (input)="setFilter($any($event.target).value)" />
        <table class="ki-ps-table">
          <thead>
            <tr>
              <th class="ki-ps-sortable" (click)="sortCol('name')">{{ L.colName }} <span class="ki-ps-glyph">{{ glyph('name') }}</span></th>
              <th class="ki-ps-sortable" (click)="sortCol('baseUrl')">{{ L.colBaseUrl }} <span class="ki-ps-glyph">{{ glyph('baseUrl') }}</span></th>
              <th>{{ L.colDefault }}</th>
              <th class="ki-ps-right">{{ L.colActions }}</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let s of pageServers()">
              <td class="ki-ps-mono"><strong>{{ s.name }}</strong>
                <div *ngIf="s.description" class="ki-ps-tiny ki-ps-muted">{{ s.description }}</div>
              </td>
              <td class="ki-ps-mono ki-ps-tiny">{{ s.baseUrl }}</td>
              <td>
                <span *ngIf="s.isDefault" class="ki-ps-badge">{{ L.badgeDefault }}</span>
              </td>
              <td class="ki-ps-right">
                <button class="ki-ps-btn" (click)="startEdit(s)">{{ L.btnEdit }}</button>
                <button *ngIf="!s.isDefault" class="ki-ps-btn" (click)="setDefault(s)">{{ L.btnSetDefault }}</button>
                <button *ngIf="!s.isDefault" class="ki-ps-btn ki-ps-danger" (click)="remove(s)">{{ L.btnDelete }}</button>
              </td>
            </tr>
            <tr *ngIf="!servers().length">
              <td colspan="4" class="ki-ps-muted ki-ps-tiny">{{ L.empty }}</td>
            </tr>
          </tbody>
        </table>

        <ki-pager
          [total]="viewServers().length"
          [page]="page()"
          [pageSize]="pageSize"
          (pageChange)="page.set($event)">
        </ki-pager>
      </div>

      <!-- Add / Edit form -->
      <form class="ki-ps-form" (ngSubmit)="save()">
        <input [(ngModel)]="formName" name="psName" [placeholder]="L.fieldName"
               [readonly]="!!editingName()" class="ki-ps-input ki-ps-mono" />
        <input [(ngModel)]="formBaseUrl" name="psBaseUrl" [placeholder]="L.fieldBaseUrl"
               class="ki-ps-input ki-ps-mono" />
        <input [(ngModel)]="formDescription" name="psDesc" [placeholder]="L.fieldDescription"
               class="ki-ps-input" />
        <div class="ki-ps-form-actions">
          <button type="submit" class="ki-ps-btn ki-ps-primary"
                  [disabled]="saving() || !formBaseUrl.trim() || (!editingName() && !formName.trim())">
            {{ editingName() ? L.btnSave : L.btnAdd }}
          </button>
          <button type="button" *ngIf="editingName()" class="ki-ps-btn" (click)="cancelEdit()">{{ L.btnCancel }}</button>
        </div>
      </form>

      <p *ngIf="error()" class="ki-ps-error">{{ error() }}</p>
      <p class="ki-ps-hint">{{ L.hint }}</p>
    </section>
  `, styles: [".ki-provider-servers{font-family:inherit;padding:1rem 0}.ki-ps-title{font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#475569;margin:0 0 .25rem}.ki-ps-subtitle{font-size:.75rem;color:#64748b;margin:0 0 .75rem}.ki-ps-table-wrap{overflow-x:auto}.ki-ps-filter{width:100%;box-sizing:border-box;padding:.4rem .6rem;margin-bottom:.5rem;border:1px solid #e2e8f0;border-radius:.375rem;font-size:.8rem}.ki-ps-sortable{cursor:pointer;-webkit-user-select:none;user-select:none;white-space:nowrap}.ki-ps-sortable:hover{color:#4f46e5}.ki-ps-glyph{font-size:.6rem;opacity:.6}.ki-ps-table{width:100%;border-collapse:collapse;font-size:.8rem}.ki-ps-table th{text-align:left;padding:.35rem .5rem;color:#64748b;font-size:.65rem;text-transform:uppercase;letter-spacing:.05em;border-bottom:1px solid #e2e8f0}.ki-ps-table td{padding:.4rem .5rem;border-bottom:1px solid #f1f5f9;vertical-align:top}.ki-ps-right{text-align:right}.ki-ps-mono{font-family:ui-monospace,monospace}.ki-ps-tiny{font-size:.7rem}.ki-ps-muted{color:#94a3b8}.ki-ps-badge{display:inline-block;padding:.1rem .35rem;border-radius:.25rem;background:#d1fae5;color:#065f46;font-size:.6rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em}.ki-ps-btn{padding:.25rem .5rem;margin-left:.25rem;border:1px solid #cbd5e1;background:#fff;border-radius:.4rem;font-size:.7rem;font-weight:700;cursor:pointer}.ki-ps-btn:disabled{opacity:.4;cursor:not-allowed}.ki-ps-primary{background:#0f172a;color:#fff;border-color:#0f172a}.ki-ps-danger{color:#b91c1c;border-color:#fecaca}.ki-ps-form{display:flex;flex-wrap:wrap;gap:.5rem;margin-top:.75rem;align-items:center}.ki-ps-input{padding:.5rem;background:#f8fafc;border:2px solid #f1f5f9;border-radius:.5rem;font-size:.8rem;flex:1 1 12rem}.ki-ps-input[readonly]{opacity:.6}.ki-ps-form-actions{display:flex;gap:.25rem}.ki-ps-error{color:#b91c1c;font-weight:700;font-size:.75rem;margin-top:.5rem}.ki-ps-hint{color:#94a3b8;font-size:.7rem;font-weight:600;margin-top:.5rem}\n"] }]
        }], propDecorators: { serversChanged: [{
                type: Output
            }], labels: [{
                type: Input
            }], pageSize: [{
                type: Input
            }] } });

/**
 * v0.17.0 — Datenschutz-Toggle für das „logPromptSnippet"-Setting.
 *
 * <h3>Was macht das?</h3>
 * Liest beim Mount `GET {base}/settings`, findet den Eintrag mit
 * `key === 'logPromptSnippet'` und zeigt einen Toggle. Ist das Setting
 * nicht vorhanden oder liefert das Backend einen Fehler (inkl. 404),
 * steht der Toggle auf AUS — Datenschutz als sicherer Default.
 *
 * <h3>Toggle-Aktion:</h3>
 * Beim Flippen ruft die Komponente `POST {base}/settings/logPromptSnippet`
 * mit `{ value: 'true' | 'false' }` auf. Bei Erfolg wird `enabled` auf
 * den neuen Wert gesetzt; bei Fehler bleibt der alte Wert erhalten und
 * ein kurzes Fehler-Feedback erscheint.
 *
 * <h3>Konsument-Use-Case:</h3>
 * - Switcher: in einem Datenschutz-Tab
 * - EduPro: in den Admin-Settings neben anderen App-Settings
 */
class PrivacySettingsComponent {
    constructor() {
        this.api = inject(KiModelsApiService);
        /** Titel oben — überschreibbar pro Konsument. */
        this.title = 'Datenschutz';
        this.subtitle = 'Speichert pro Delegations-Call einen gekürzten Prompt-Ausschnitt (max. 160 Zeichen) — nur für Debug/Live-Watch. Standard: AUS (Datenschutz).';
        /** Eindeutige ID damit label[for] korrekt funktioniert, auch wenn die Component mehrfach gemountet wird. */
        this.toggleId = `ki-privacy-toggle-${Math.random().toString(36).slice(2)}`;
        this.enabled = signal(false);
        this.loading = signal(true);
        this.saving = signal(false);
        this.savedMsg = signal(null);
        this.errorMsg = signal(null);
        this.savedTimer = null;
        this.errorTimer = null;
    }
    ngOnInit() {
        this.api.getSettings().subscribe({
            next: (settings) => {
                const entry = settings.find(s => s.key === 'logPromptSnippet');
                this.enabled.set(entry?.value === 'true');
                this.loading.set(false);
            },
            error: () => {
                // 404 oder Netzwerkfehler → sicherer Default: AUS
                this.enabled.set(false);
                this.loading.set(false);
            },
        });
    }
    ngOnDestroy() {
        if (this.savedTimer) {
            clearTimeout(this.savedTimer);
            this.savedTimer = null;
        }
        if (this.errorTimer) {
            clearTimeout(this.errorTimer);
            this.errorTimer = null;
        }
    }
    onToggle(event) {
        const next = event.target.checked;
        if (this.saving())
            return;
        this.saving.set(true);
        this.clearMessages();
        this.api.setSetting('logPromptSnippet', next ? 'true' : 'false').subscribe({
            next: () => {
                this.enabled.set(next);
                this.saving.set(false);
                this.savedMsg.set('Gespeichert.');
                this.savedTimer = setTimeout(() => this.savedMsg.set(null), 3000);
            },
            error: () => {
                // Fehler: Signal bleibt beim alten Wert — Checkbox springt zurück
                this.saving.set(false);
                this.errorMsg.set('Fehler beim Speichern — Einstellung nicht geändert.');
                this.errorTimer = setTimeout(() => this.errorMsg.set(null), 5000);
            },
        });
    }
    clearMessages() {
        if (this.savedTimer) {
            clearTimeout(this.savedTimer);
            this.savedTimer = null;
        }
        if (this.errorTimer) {
            clearTimeout(this.errorTimer);
            this.errorTimer = null;
        }
        this.savedMsg.set(null);
        this.errorMsg.set(null);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PrivacySettingsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: PrivacySettingsComponent, isStandalone: true, selector: "ki-privacy-settings", inputs: { title: "title", subtitle: "subtitle" }, ngImport: i0, template: `
    <div class="ki-privacy-settings">
      <div class="ki-header">
        <div>
          <h4 class="ki-title">{{ title }}</h4>
          <p class="ki-subtitle">{{ subtitle }}</p>
        </div>
      </div>

      <p *ngIf="loading()" class="ki-muted">Lade Einstellungen…</p>

      <div *ngIf="!loading()" class="ki-toggle-row">
        <label class="ki-toggle-label" [for]="toggleId">
          <span class="ki-toggle-text">
            Prompt-Logging
            <span class="ki-badge" [class.ki-badge-on]="enabled()" [class.ki-badge-off]="!enabled()">
              {{ enabled() ? 'AN' : 'AUS' }}
            </span>
          </span>
          <span class="ki-toggle-hint ki-muted">logPromptSnippet</span>
        </label>
        <div class="ki-toggle-control">
          <input
            type="checkbox"
            [id]="toggleId"
            [checked]="enabled()"
            [disabled]="saving()"
            (change)="onToggle($event)"
            class="ki-checkbox"
          />
          <label [for]="toggleId" class="ki-switch" [class.ki-switch-saving]="saving()"></label>
        </div>
      </div>

      <!-- Ehrlicher Hinweis: Logging greift nur für Cascade-Traffic -->
      <p *ngIf="!loading()" class="ki-scope-hint">
        Hinweis: Das Logging greift nur für Cascade-Traffic (z. B. free/local
        bzw. den nicht-direkten Anthropic-Pfad). Auf <strong>cloud+Anthropic
        direkt</strong> wird die Cascade umgangen — dort entstehen keine Logs,
        egal wie der Toggle steht. Geloggte Snippets sind im Panel
        „Prompt-Log“ sichtbar.
      </p>

      <!-- Feedback-Banner: Erfolg / Fehler nach dem Speichern -->
      <div *ngIf="savedMsg()" class="ki-feedback ki-feedback-ok">{{ savedMsg() }}</div>
      <div *ngIf="errorMsg()" class="ki-feedback ki-feedback-err">{{ errorMsg() }}</div>
    </div>
  `, isInline: true, styles: [".ki-privacy-settings{font-family:inherit;padding:1rem 0}.ki-header{margin-bottom:1rem}.ki-title{font-size:.85rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#1e293b;margin:0 0 .25rem}.ki-subtitle{font-size:.7rem;color:#64748b;margin:0}.ki-muted{color:#94a3b8}.ki-toggle-row{display:flex;justify-content:space-between;align-items:center;gap:1rem;padding:.75rem 1rem;border:1px solid #e2e8f0;border-radius:.5rem;background:#f8fafc}.ki-toggle-label{display:flex;flex-direction:column;gap:.15rem;cursor:pointer;flex:1}.ki-toggle-text{display:flex;align-items:center;gap:.5rem;font-size:.85rem;font-weight:600;color:#1e293b}.ki-toggle-hint{font-size:.7rem}.ki-badge{display:inline-block;padding:.1rem .35rem;border-radius:.25rem;font-size:.65rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em}.ki-badge-on{background:#dcfce7;color:#166534}.ki-badge-off{background:#f1f5f9;color:#64748b}.ki-toggle-control{display:flex;align-items:center;gap:.5rem;flex-shrink:0}.ki-checkbox{display:none}.ki-switch{position:relative;display:inline-block;width:2.5rem;height:1.4rem;background:#cbd5e1;border-radius:9999px;cursor:pointer;transition:background .2s}.ki-switch:after{content:\"\";position:absolute;top:.15rem;left:.15rem;width:1.1rem;height:1.1rem;background:#fff;border-radius:50%;transition:transform .2s}.ki-checkbox:checked+.ki-switch{background:#4f46e5}.ki-checkbox:checked+.ki-switch:after{transform:translate(1.1rem)}.ki-switch-saving{opacity:.5;cursor:not-allowed}.ki-scope-hint{margin:.6rem 0 0;padding:.5rem .75rem;background:#f8fafc;border:1px solid #e2e8f0;border-left:3px solid #94a3b8;border-radius:.375rem;font-size:.7rem;line-height:1.5;color:#64748b}.ki-scope-hint strong{color:#475569}.ki-feedback{margin-top:.6rem;padding:.5rem .75rem;border-radius:.375rem;font-size:.75rem;font-weight:600}.ki-feedback-ok{background:#f0fdf4;color:#166534;border:1px solid #bbf7d0}.ki-feedback-err{background:#fef2f2;color:#991b1b;border:1px solid #fecaca}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: PrivacySettingsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-privacy-settings', standalone: true, imports: [CommonModule, FormsModule], template: `
    <div class="ki-privacy-settings">
      <div class="ki-header">
        <div>
          <h4 class="ki-title">{{ title }}</h4>
          <p class="ki-subtitle">{{ subtitle }}</p>
        </div>
      </div>

      <p *ngIf="loading()" class="ki-muted">Lade Einstellungen…</p>

      <div *ngIf="!loading()" class="ki-toggle-row">
        <label class="ki-toggle-label" [for]="toggleId">
          <span class="ki-toggle-text">
            Prompt-Logging
            <span class="ki-badge" [class.ki-badge-on]="enabled()" [class.ki-badge-off]="!enabled()">
              {{ enabled() ? 'AN' : 'AUS' }}
            </span>
          </span>
          <span class="ki-toggle-hint ki-muted">logPromptSnippet</span>
        </label>
        <div class="ki-toggle-control">
          <input
            type="checkbox"
            [id]="toggleId"
            [checked]="enabled()"
            [disabled]="saving()"
            (change)="onToggle($event)"
            class="ki-checkbox"
          />
          <label [for]="toggleId" class="ki-switch" [class.ki-switch-saving]="saving()"></label>
        </div>
      </div>

      <!-- Ehrlicher Hinweis: Logging greift nur für Cascade-Traffic -->
      <p *ngIf="!loading()" class="ki-scope-hint">
        Hinweis: Das Logging greift nur für Cascade-Traffic (z. B. free/local
        bzw. den nicht-direkten Anthropic-Pfad). Auf <strong>cloud+Anthropic
        direkt</strong> wird die Cascade umgangen — dort entstehen keine Logs,
        egal wie der Toggle steht. Geloggte Snippets sind im Panel
        „Prompt-Log“ sichtbar.
      </p>

      <!-- Feedback-Banner: Erfolg / Fehler nach dem Speichern -->
      <div *ngIf="savedMsg()" class="ki-feedback ki-feedback-ok">{{ savedMsg() }}</div>
      <div *ngIf="errorMsg()" class="ki-feedback ki-feedback-err">{{ errorMsg() }}</div>
    </div>
  `, styles: [".ki-privacy-settings{font-family:inherit;padding:1rem 0}.ki-header{margin-bottom:1rem}.ki-title{font-size:.85rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#1e293b;margin:0 0 .25rem}.ki-subtitle{font-size:.7rem;color:#64748b;margin:0}.ki-muted{color:#94a3b8}.ki-toggle-row{display:flex;justify-content:space-between;align-items:center;gap:1rem;padding:.75rem 1rem;border:1px solid #e2e8f0;border-radius:.5rem;background:#f8fafc}.ki-toggle-label{display:flex;flex-direction:column;gap:.15rem;cursor:pointer;flex:1}.ki-toggle-text{display:flex;align-items:center;gap:.5rem;font-size:.85rem;font-weight:600;color:#1e293b}.ki-toggle-hint{font-size:.7rem}.ki-badge{display:inline-block;padding:.1rem .35rem;border-radius:.25rem;font-size:.65rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em}.ki-badge-on{background:#dcfce7;color:#166534}.ki-badge-off{background:#f1f5f9;color:#64748b}.ki-toggle-control{display:flex;align-items:center;gap:.5rem;flex-shrink:0}.ki-checkbox{display:none}.ki-switch{position:relative;display:inline-block;width:2.5rem;height:1.4rem;background:#cbd5e1;border-radius:9999px;cursor:pointer;transition:background .2s}.ki-switch:after{content:\"\";position:absolute;top:.15rem;left:.15rem;width:1.1rem;height:1.1rem;background:#fff;border-radius:50%;transition:transform .2s}.ki-checkbox:checked+.ki-switch{background:#4f46e5}.ki-checkbox:checked+.ki-switch:after{transform:translate(1.1rem)}.ki-switch-saving{opacity:.5;cursor:not-allowed}.ki-scope-hint{margin:.6rem 0 0;padding:.5rem .75rem;background:#f8fafc;border:1px solid #e2e8f0;border-left:3px solid #94a3b8;border-radius:.375rem;font-size:.7rem;line-height:1.5;color:#64748b}.ki-scope-hint strong{color:#475569}.ki-feedback{margin-top:.6rem;padding:.5rem .75rem;border-radius:.375rem;font-size:.75rem;font-weight:600}.ki-feedback-ok{background:#f0fdf4;color:#166534;border:1px solid #bbf7d0}.ki-feedback-err{background:#fef2f2;color:#991b1b;border:1px solid #fecaca}\n"] }]
        }], propDecorators: { title: [{
                type: Input
            }], subtitle: [{
                type: Input
            }] } });

/**
 * v0.17.0 — Supermodell-Rollen-Matrix (Compound-Kategorie-Übersicht).
 *
 * <h3>Was zeigt das?</h3>
 * Eine Tabelle/Grid der Compound-Kategorien {role}-{pool}, jeweils mit den
 * zugeordneten Modellen in Failover-Reihenfolge. Portiert aus dem Switcher
 * (Rollen-im-Pool-Panel, app.component.ts) als wiederverwendbare Library-
 * Komponente.
 *
 * <h3>Sichtbarkeit:</h3>
 * Die Matrix ist nur sichtbar wenn `supermodelOn = true` (Host setzt
 * explizit). Default ist `false` — nacktes Mount zeigt nichts. Wenn
 * `disabled = true`: Panel ist sichtbar aber gedimmt + gesperrt.
 *
 * <h3>Konsument-Use-Case:</h3>
 * - Switcher: `[supermodelOn]="supermodel()"` — zeigt Matrix wenn Supermodell aktiv
 * - EduPro: `[disabled]="true"` — Panel sichtbar aber Feature noch nicht freigeschaltet
 */
class SupermodelMatrixComponent {
    constructor() {
        this.api = inject(KiModelsApiService);
        // ─── Axis configuration ──────────────────────────────────────────────────
        this.pools = ['cloud', 'free', 'local'];
        this.roles = ['orchestrator', 'implement', 'review', 'research', 'dispatch'];
        /**
         * CRITICAL DEFAULT: false — panel renders NOTHING when false.
         * Host must explicitly pass supermodelOn=true to show the matrix.
         */
        this.supermodelOn = false;
        this.localOrchestratorPending = false;
        // ─── Disabled state ──────────────────────────────────────────────────────
        /**
         * When true: panel is visible but dimmed/locked (display-only).
         * EduPro mounts with disabled=true to preview the feature.
         */
        this.disabled = false;
        this.disabledHint = 'Supermodell — demnächst verfügbar';
        // ─── Default German metadata ─────────────────────────────────────────────
        this.DEFAULT_POOL_TITLES = {
            cloud: 'Cloud — Premium (bezahlt)',
            free: 'Free — OpenRouter :free',
            local: 'Lokal — Ollama (privat)',
        };
        this.DEFAULT_ROLE_META = {
            orchestrator: { label: 'Orchestrator', desc: 'Plant + synthetisiert (Claude Code selbst)' },
            implement: { label: 'Implement', desc: 'Bulk-Code, Backend, Boilerplate, CRUD' },
            review: { label: 'Review', desc: 'Korrektheit, Sicherheit, Tests' },
            research: { label: 'Research', desc: 'Web/Google, große Docs' },
            dispatch: { label: 'Dispatch', desc: 'Triviales: Commit-Msgs, Summaries' },
        };
        // ─── Reactive state ──────────────────────────────────────────────────────
        /** All models grouped by compound category key (role-pool). */
        this.matrixModels = signal({});
        /** Derived pool when activePool input is absent. */
        this.derivedPool = signal('');
        /** Resolved pool: input takes priority, then derived, then first pool. */
        this.effectivePool = computed(() => {
            if (this.activePool)
                return this.activePool;
            const d = this.derivedPool();
            return d || this.pools[0] || 'cloud';
        });
        /** Merged roleMeta: defaults + optional label overrides. */
        this.effectiveRoleMeta = computed(() => {
            return { ...this.DEFAULT_ROLE_META, ...(this.labels?.roleMeta ?? {}) };
        });
        /** Merged poolTitles: defaults + optional label overrides. */
        this.effectivePoolTitles = computed(() => {
            return { ...this.DEFAULT_POOL_TITLES, ...(this.labels?.poolTitles ?? {}) };
        });
        /**
         * True when supermodelOn=true but NO model matches any role-pool compound
         * key (e.g. EduPro backend with only utility/content/general categories).
         * Renders a calm empty state instead of crashing.
         */
        this.noMatrixData = computed(() => {
            const matrix = this.matrixModels();
            const pool = this.effectivePool();
            return this.roles.every(role => !(matrix[`${role}-${pool}`]?.length));
        });
    }
    // ─── Lifecycle ───────────────────────────────────────────────────────────
    ngOnInit() {
        this.loadModels();
        if (!this.activePool) {
            this.loadDerivedPool();
        }
    }
    /**
     * Öffentlicher Refresh — vom Host (z. B. <ki-models-page>) nach Pool-Wechsel
     * aufgerufen. Das Backend filtert die Modell-Liste nach aktivem Pool, daher
     * muss die Matrix neu laden wenn sich der Pool ändert — sonst zeigt sie die
     * (leeren) Zellen des alten Pools.
     */
    reload() {
        this.loadModels();
        if (!this.activePool) {
            this.loadDerivedPool();
        }
    }
    /**
     * Load all models and group them by compound category (role-pool).
     * Includes disabled models — they appear greyed out in the matrix.
     * On error: graceful empty ({}).
     */
    loadModels() {
        this.api.listModels().subscribe({
            next: (models) => {
                const matrix = {};
                for (const m of models) {
                    const cat = m.category || 'general';
                    (matrix[cat] ??= []).push({
                        provider: m.provider,
                        modelId: m.modelId,
                        displayName: m.displayName || m.modelId,
                        enabled: !!m.enabled,
                    });
                }
                this.matrixModels.set(matrix);
            },
            error: () => {
                // Backend unavailable or empty — graceful degradation.
                this.matrixModels.set({});
            },
        });
    }
    /**
     * Derive active pool from getPreferredCategory() when activePool input is absent.
     * Parses compound key format "<role>-<pool>"; falls back to pools[0] on error
     * or if the category does not match the compound pattern.
     */
    loadDerivedPool() {
        this.api.getPreferredCategory().subscribe({
            next: (resp) => {
                const cat = resp?.category || '';
                const parts = cat.split('-');
                if (parts.length >= 2) {
                    const possiblePool = parts[parts.length - 1];
                    const possibleRole = parts.slice(0, -1).join('-');
                    if (this.roles.includes(possibleRole) && this.pools.includes(possiblePool)) {
                        this.derivedPool.set(possiblePool);
                        return;
                    }
                }
                this.derivedPool.set(this.pools[0] || 'cloud');
            },
            error: () => {
                this.derivedPool.set(this.pools[0] || 'cloud');
            },
        });
    }
    // ─── Template helpers ────────────────────────────────────────────────────
    /**
     * Returns models for the compound cell {role}-{effectivePool}.
     * Order preserved from API (orderIdx = failover chain order).
     */
    cellModels(role) {
        return this.matrixModels()[`${role}-${this.effectivePool()}`] ?? [];
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SupermodelMatrixComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: SupermodelMatrixComponent, isStandalone: true, selector: "ki-supermodel-matrix", inputs: { pools: "pools", roles: "roles", activePool: "activePool", supermodelOn: "supermodelOn", localOrchestratorPending: "localOrchestratorPending", disabled: "disabled", disabledHint: "disabledHint", labels: "labels" }, ngImport: i0, template: `
    <section *ngIf="supermodelOn" class="ki-supermodel-matrix" [class.ki-disabled]="disabled">

      <!-- Disabled-Hint-Banner -->
      <div *ngIf="disabled" class="ki-disabled-hint">
        {{ disabledHint }}
      </div>

      <div [class.ki-dimmed]="disabled">
        <h2 class="ki-heading">Rollen im Pool „{{ effectivePoolTitles()[effectivePool()] || effectivePool() }}"</h2>
        <p class="ki-intro">
          Opus plant, delegiert pro Schritt an die günstigste Rolle (über <code class="ki-code">&#64;supermodel</code>) und prüft am Ende. ① ② = Failover-Kette mit Cooldown.
        </p>

        <p *ngIf="localOrchestratorPending && effectivePool() === 'local'" class="ki-warn">
          ⚠ Lokaler Orchestrator gewählt, aber kein lokales Modell aktiv — fail-closed (kein automatischer Cloud-Ausweich). Ollama-Modell ziehen + aktivieren.
        </p>

        <!-- Empty state when no compound categories match -->
        <p *ngIf="noMatrixData()" class="ki-empty-state">
          Keine Supermodell-Kategorien gefunden
        </p>

        <div *ngIf="!noMatrixData()" class="ki-grid">
          <div *ngFor="let role of roles" class="ki-role-card">
            <div class="ki-role-header">
              <strong class="ki-role-label">{{ effectiveRoleMeta()[role]?.label || role }}</strong>
              <code class="ki-role-code">{{ role }}-{{ effectivePool() }}</code>
            </div>
            <p class="ki-role-desc">{{ effectiveRoleMeta()[role]?.desc || '' }}</p>

            <!-- Models in failover order -->
            <ng-container *ngIf="cellModels(role).length > 0; else emptyCell">
              <div *ngFor="let m of cellModels(role); let i = index" class="ki-model-entry" [class.ki-model-disabled]="!m.enabled">
                {{ i + 1 }}. {{ m.displayName }} · {{ m.provider }}<span *ngIf="!m.enabled" class="ki-aus"> · aus</span>
              </div>
            </ng-container>

            <!-- Empty cell template -->
            <ng-template #emptyCell>
              <span class="ki-empty-cell">
                <ng-container *ngIf="role === 'research' && effectivePool() === 'local'">
                  Lokal/intern erlaubt (Intranet/VPN, offline) — nur öffentliches Web verweigert (fail-closed).
                </ng-container>
                <ng-container *ngIf="role === 'research' && effectivePool() !== 'local'">
                  Über Gemini-MCP (Grounding) — kein Cascade-Modell nötig.
                </ng-container>
                <ng-container *ngIf="role !== 'research'">
                  Kein Modell — Kategorie {{ role }}-{{ effectivePool() }} anlegen.
                </ng-container>
              </span>
            </ng-template>
          </div>
        </div>
      </div>
    </section>
  `, isInline: true, styles: [".ki-supermodel-matrix{font-family:inherit;padding:1rem 0}.ki-disabled-hint{background:#fef9c3;border:1px solid #fde68a;color:#92400e;padding:.5rem .9rem;border-radius:.5rem;font-size:.8rem;font-weight:600;margin-bottom:.75rem}.ki-dimmed{opacity:.55;pointer-events:none;-webkit-user-select:none;user-select:none}.ki-heading{font-size:1rem;font-weight:700;color:#1e293b;margin:0 0 .5rem}.ki-intro{font-size:.8rem;color:#64748b;margin:0 0 .75rem}.ki-code{font-family:ui-monospace,monospace;background:#f1f5f9;padding:.1rem .3rem;border-radius:.25rem;font-size:.75rem}.ki-warn{font-size:.8rem;color:#92400e;background:#fef3c7;border:1px solid #fde68a;border-radius:.375rem;padding:.5rem .75rem;margin-bottom:.75rem}.ki-empty-state{font-size:.85rem;color:#94a3b8;text-align:center;padding:1.5rem}.ki-grid{display:grid;grid-template-columns:1fr;gap:.75rem}@media (min-width: 640px){.ki-grid{grid-template-columns:1fr 1fr}}.ki-role-card{background:#f8fafc;border:1px solid #e2e8f0;border-radius:.75rem;padding:.9rem 1rem}.ki-role-header{display:flex;align-items:baseline;gap:.5rem;margin-bottom:.25rem;flex-wrap:wrap}.ki-role-label{font-size:.85rem;font-weight:700;color:#1e293b}.ki-role-code{font-family:ui-monospace,monospace;font-size:.65rem;color:#94a3b8}.ki-role-desc{font-size:.75rem;color:#64748b;margin:0 0 .5rem}.ki-model-entry{font-family:ui-monospace,monospace;font-size:.75rem;color:#334155;padding:.1rem 0}.ki-model-disabled{color:#94a3b8}.ki-aus{color:#ef4444;font-size:.7rem}.ki-empty-cell{font-size:.72rem;color:#94a3b8;font-style:italic}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: SupermodelMatrixComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-supermodel-matrix', standalone: true, imports: [CommonModule], template: `
    <section *ngIf="supermodelOn" class="ki-supermodel-matrix" [class.ki-disabled]="disabled">

      <!-- Disabled-Hint-Banner -->
      <div *ngIf="disabled" class="ki-disabled-hint">
        {{ disabledHint }}
      </div>

      <div [class.ki-dimmed]="disabled">
        <h2 class="ki-heading">Rollen im Pool „{{ effectivePoolTitles()[effectivePool()] || effectivePool() }}"</h2>
        <p class="ki-intro">
          Opus plant, delegiert pro Schritt an die günstigste Rolle (über <code class="ki-code">&#64;supermodel</code>) und prüft am Ende. ① ② = Failover-Kette mit Cooldown.
        </p>

        <p *ngIf="localOrchestratorPending && effectivePool() === 'local'" class="ki-warn">
          ⚠ Lokaler Orchestrator gewählt, aber kein lokales Modell aktiv — fail-closed (kein automatischer Cloud-Ausweich). Ollama-Modell ziehen + aktivieren.
        </p>

        <!-- Empty state when no compound categories match -->
        <p *ngIf="noMatrixData()" class="ki-empty-state">
          Keine Supermodell-Kategorien gefunden
        </p>

        <div *ngIf="!noMatrixData()" class="ki-grid">
          <div *ngFor="let role of roles" class="ki-role-card">
            <div class="ki-role-header">
              <strong class="ki-role-label">{{ effectiveRoleMeta()[role]?.label || role }}</strong>
              <code class="ki-role-code">{{ role }}-{{ effectivePool() }}</code>
            </div>
            <p class="ki-role-desc">{{ effectiveRoleMeta()[role]?.desc || '' }}</p>

            <!-- Models in failover order -->
            <ng-container *ngIf="cellModels(role).length > 0; else emptyCell">
              <div *ngFor="let m of cellModels(role); let i = index" class="ki-model-entry" [class.ki-model-disabled]="!m.enabled">
                {{ i + 1 }}. {{ m.displayName }} · {{ m.provider }}<span *ngIf="!m.enabled" class="ki-aus"> · aus</span>
              </div>
            </ng-container>

            <!-- Empty cell template -->
            <ng-template #emptyCell>
              <span class="ki-empty-cell">
                <ng-container *ngIf="role === 'research' && effectivePool() === 'local'">
                  Lokal/intern erlaubt (Intranet/VPN, offline) — nur öffentliches Web verweigert (fail-closed).
                </ng-container>
                <ng-container *ngIf="role === 'research' && effectivePool() !== 'local'">
                  Über Gemini-MCP (Grounding) — kein Cascade-Modell nötig.
                </ng-container>
                <ng-container *ngIf="role !== 'research'">
                  Kein Modell — Kategorie {{ role }}-{{ effectivePool() }} anlegen.
                </ng-container>
              </span>
            </ng-template>
          </div>
        </div>
      </div>
    </section>
  `, styles: [".ki-supermodel-matrix{font-family:inherit;padding:1rem 0}.ki-disabled-hint{background:#fef9c3;border:1px solid #fde68a;color:#92400e;padding:.5rem .9rem;border-radius:.5rem;font-size:.8rem;font-weight:600;margin-bottom:.75rem}.ki-dimmed{opacity:.55;pointer-events:none;-webkit-user-select:none;user-select:none}.ki-heading{font-size:1rem;font-weight:700;color:#1e293b;margin:0 0 .5rem}.ki-intro{font-size:.8rem;color:#64748b;margin:0 0 .75rem}.ki-code{font-family:ui-monospace,monospace;background:#f1f5f9;padding:.1rem .3rem;border-radius:.25rem;font-size:.75rem}.ki-warn{font-size:.8rem;color:#92400e;background:#fef3c7;border:1px solid #fde68a;border-radius:.375rem;padding:.5rem .75rem;margin-bottom:.75rem}.ki-empty-state{font-size:.85rem;color:#94a3b8;text-align:center;padding:1.5rem}.ki-grid{display:grid;grid-template-columns:1fr;gap:.75rem}@media (min-width: 640px){.ki-grid{grid-template-columns:1fr 1fr}}.ki-role-card{background:#f8fafc;border:1px solid #e2e8f0;border-radius:.75rem;padding:.9rem 1rem}.ki-role-header{display:flex;align-items:baseline;gap:.5rem;margin-bottom:.25rem;flex-wrap:wrap}.ki-role-label{font-size:.85rem;font-weight:700;color:#1e293b}.ki-role-code{font-family:ui-monospace,monospace;font-size:.65rem;color:#94a3b8}.ki-role-desc{font-size:.75rem;color:#64748b;margin:0 0 .5rem}.ki-model-entry{font-family:ui-monospace,monospace;font-size:.75rem;color:#334155;padding:.1rem 0}.ki-model-disabled{color:#94a3b8}.ki-aus{color:#ef4444;font-size:.7rem}.ki-empty-cell{font-size:.72rem;color:#94a3b8;font-style:italic}\n"] }]
        }], propDecorators: { pools: [{
                type: Input
            }], roles: [{
                type: Input
            }], activePool: [{
                type: Input
            }], supermodelOn: [{
                type: Input
            }], localOrchestratorPending: [{
                type: Input
            }], disabled: [{
                type: Input
            }], disabledHint: [{
                type: Input
            }], labels: [{
                type: Input
            }] } });

/**
 * v0.17.0 — Live-Browser-Watcher für Delegations-Calls.
 *
 * Zeigt die letzten `maxRows` Delegations-Calls in einer kompakten Tabelle.
 * - Zeit (toLocaleString — Datum + Uhrzeit), ✓/✗-Status (grün/rot), Provider:Modell,
 *   [Service], Output-Chars, und — falls `logPromptSnippet` AN — der Snippet.
 * - Auto-Refresh alle `autoRefreshSec` Sekunden (Default 5s).
 * - Graceful 404/Fehler → leerer Zustand, kein Crash.
 *
 * Konsumenten-Use-Case:
 * - Switcher/EduPro: ersetzt den Bash-Watcher; einbettbar in Admin-Tabs.
 */
class DelegationLiveComponent {
    constructor() {
        this.api = inject(KiModelsApiService);
        this.title = 'Delegationen — Live';
        this.subtitle = 'Letzte Aufrufe der Kaskade. Auto-Refresh.';
        /** Auto-Refresh-Intervall in Sekunden. Default 5s. 0 deaktiviert. */
        this.autoRefreshSec = 5;
        /** Maximale Anzahl angezeigter Zeilen. */
        this.maxRows = 50;
        /** Seitengröße. Pager nur sichtbar wenn mehr Zeilen geladen sind. */
        this.pageSize = 10;
        this.rows = signal([]);
        this.loading = signal(true);
        this.error = signal(false);
        this.page = signal(0);
        this.filter = signal('');
        this.sort = signal({ key: null, dir: null });
        this.viewRows = computed(() => sortRows(filterRows(this.rows(), this.filter(), ['provider', 'model', 'service', 'promptSnippet']), this.sort()));
        // Kein Page-Reset beim Auto-Refresh — paginate() klemmt die Seite defensiv,
        // sonst würde die Tabelle alle 5s auf Seite 0 zurückspringen.
        this.pageRows = computed(() => paginate(this.viewRows(), this.page(), this.pageSize));
        this.timer = null;
    }
    glyph(key) { return sortGlyph(this.sort(), key); }
    sortCol(key) { this.sort.set(nextSort(this.sort(), key)); this.page.set(0); }
    setFilter(v) { this.filter.set(v); this.page.set(0); }
    ngOnInit() {
        this.reload();
        if (this.autoRefreshSec > 0) {
            this.timer = setInterval(() => this.reload(), this.autoRefreshSec * 1000);
        }
    }
    ngOnDestroy() {
        if (this.timer)
            clearInterval(this.timer);
        this.timer = null;
    }
    reload() {
        this.api.getDelegationCalls().subscribe({
            next: (calls) => {
                const list = Array.isArray(calls) ? calls : [];
                this.rows.set(list.slice(0, this.maxRows));
                this.error.set(false);
                this.loading.set(false);
            },
            error: () => {
                this.rows.set([]);
                this.error.set(true);
                this.loading.set(false);
            },
        });
    }
    formatTime(calledAt) {
        try {
            const d = new Date(calledAt);
            if (isNaN(d.getTime()))
                return '—';
            // Datum + Uhrzeit — sonst sind Eintraege ueber mehrere Tage nicht
            // unterscheidbar (vorher nur toLocaleTimeString).
            return d.toLocaleString();
        }
        catch {
            return '—';
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DelegationLiveComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: DelegationLiveComponent, isStandalone: true, selector: "ki-delegation-live", inputs: { title: "title", subtitle: "subtitle", autoRefreshSec: "autoRefreshSec", maxRows: "maxRows", pageSize: "pageSize" }, ngImport: i0, template: `
    <div class="ki-dl">
      <div class="ki-header">
        <div>
          <h4 class="ki-title">{{ title }}</h4>
          <p class="ki-subtitle">{{ subtitle }}</p>
        </div>
        <button (click)="reload()" class="ki-btn-refresh" title="Jetzt neu laden">↻</button>
      </div>

      <p *ngIf="loading()" class="ki-muted">Lade Delegations-Calls…</p>

      <p *ngIf="!loading() && error()" class="ki-empty">
        Delegation-Log nicht verfügbar.
      </p>

      <p *ngIf="!loading() && !error() && rows().length === 0" class="ki-empty">
        Noch keine Delegations-Calls.
      </p>

      <input *ngIf="!loading() && !error() && rows().length > 0"
        class="ki-filter" type="text" placeholder="Filtern…"
        [value]="filter()" (input)="setFilter($any($event.target).value)" />

      <table *ngIf="!loading() && !error() && rows().length > 0" class="ki-table">
        <thead>
          <tr>
            <th></th>
            <th class="ki-sortable" (click)="sortCol('calledAt')">Zeit <span class="ki-glyph">{{ glyph('calledAt') }}</span></th>
            <th class="ki-sortable" (click)="sortCol('provider')">Provider : Modell <span class="ki-glyph">{{ glyph('provider') }}</span></th>
            <th class="ki-sortable" (click)="sortCol('service')">[Service] <span class="ki-glyph">{{ glyph('service') }}</span></th>
            <th class="ki-right ki-sortable" (click)="sortCol('outputChars')">Chars <span class="ki-glyph">{{ glyph('outputChars') }}</span></th>
            <th class="ki-snippet-head">Snippet</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let r of pageRows()"
              [class.ki-row-ok]="r.success"
              [class.ki-row-fail]="!r.success">
            <td class="ki-icon">
              <span *ngIf="r.success" class="ki-status-ok">✓</span>
              <span *ngIf="!r.success" class="ki-status-fail">✗</span>
            </td>
            <td class="ki-mono ki-tiny">{{ formatTime(r.calledAt) }}</td>
            <td class="ki-mono ki-tiny">
              <span class="ki-provider">{{ r.provider || '—' }}</span>
              <span *ngIf="r.provider && r.model">:</span>
              <span *ngIf="r.model" class="ki-model">{{ r.model }}</span>
              <span *ngIf="!r.provider && !r.model">—</span>
            </td>
            <td class="ki-tiny ki-muted">{{ r.service || '—' }}</td>
            <td class="ki-right ki-mono ki-tiny">{{ r.outputChars != null ? r.outputChars : '—' }}</td>
            <td class="ki-snippet ki-tiny ki-muted">
              <span *ngIf="r.promptSnippet">{{ r.promptSnippet }}</span>
            </td>
          </tr>
        </tbody>
      </table>

      <ki-pager
        [total]="viewRows().length"
        [page]="page()"
        [pageSize]="pageSize"
        (pageChange)="page.set($event)">
      </ki-pager>

      <p class="ki-foot ki-tiny ki-muted">
        Auto-Refresh alle {{ autoRefreshSec }}s · max. {{ maxRows }} Einträge.
      </p>
    </div>
  `, isInline: true, styles: [".ki-dl{font-family:inherit;padding:1rem 0}.ki-header{display:flex;justify-content:space-between;align-items:flex-start;gap:1rem;margin-bottom:1rem}.ki-title{font-size:.85rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#1e293b;margin:0 0 .25rem}.ki-subtitle{font-size:.7rem;color:#64748b;margin:0}.ki-btn-refresh{padding:.35rem .6rem;background:#e0e7ff;color:#3730a3;border:none;border-radius:.375rem;font-size:.8rem;cursor:pointer}.ki-filter{width:100%;box-sizing:border-box;padding:.4rem .6rem;margin-bottom:.5rem;border:1px solid #e2e8f0;border-radius:.375rem;font-size:.8rem}.ki-sortable{cursor:pointer;-webkit-user-select:none;user-select:none;white-space:nowrap}.ki-sortable:hover{color:#4f46e5}.ki-glyph{font-size:.6rem;opacity:.6}.ki-table{width:100%;border-collapse:collapse;font-size:.85rem}.ki-table thead tr{border-bottom:2px solid #e2e8f0}.ki-table th{padding:.5rem .6rem;text-align:left;text-transform:uppercase;font-size:.6rem;font-weight:800;letter-spacing:.08em;color:#64748b}.ki-table td{padding:.45rem .6rem;border-bottom:1px solid #f1f5f9;vertical-align:top}.ki-row-fail{background:linear-gradient(90deg,#fef2f2 0%,transparent 100%)}.ki-icon{width:2rem;text-align:center}.ki-right{text-align:right}.ki-mono{font-family:ui-monospace,monospace}.ki-muted{color:#94a3b8}.ki-tiny{font-size:.7rem}.ki-provider{color:#4f46e5;font-weight:700;margin-right:.15rem}.ki-model{color:#0f172a}.ki-status-ok{color:#059669;font-weight:800;font-size:.9rem}.ki-status-fail{color:#dc2626;font-weight:800;font-size:.9rem}.ki-snippet{max-width:20rem;word-break:break-word;white-space:pre-wrap}.ki-snippet-head{min-width:6rem}.ki-empty{text-align:center;padding:1.5rem;color:#94a3b8}.ki-foot{margin-top:.75rem;font-style:italic}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: KiPagerComponent, selector: "ki-pager", inputs: ["total", "page", "pageSize"], outputs: ["pageChange"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: DelegationLiveComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-delegation-live', standalone: true, imports: [CommonModule, KiPagerComponent], template: `
    <div class="ki-dl">
      <div class="ki-header">
        <div>
          <h4 class="ki-title">{{ title }}</h4>
          <p class="ki-subtitle">{{ subtitle }}</p>
        </div>
        <button (click)="reload()" class="ki-btn-refresh" title="Jetzt neu laden">↻</button>
      </div>

      <p *ngIf="loading()" class="ki-muted">Lade Delegations-Calls…</p>

      <p *ngIf="!loading() && error()" class="ki-empty">
        Delegation-Log nicht verfügbar.
      </p>

      <p *ngIf="!loading() && !error() && rows().length === 0" class="ki-empty">
        Noch keine Delegations-Calls.
      </p>

      <input *ngIf="!loading() && !error() && rows().length > 0"
        class="ki-filter" type="text" placeholder="Filtern…"
        [value]="filter()" (input)="setFilter($any($event.target).value)" />

      <table *ngIf="!loading() && !error() && rows().length > 0" class="ki-table">
        <thead>
          <tr>
            <th></th>
            <th class="ki-sortable" (click)="sortCol('calledAt')">Zeit <span class="ki-glyph">{{ glyph('calledAt') }}</span></th>
            <th class="ki-sortable" (click)="sortCol('provider')">Provider : Modell <span class="ki-glyph">{{ glyph('provider') }}</span></th>
            <th class="ki-sortable" (click)="sortCol('service')">[Service] <span class="ki-glyph">{{ glyph('service') }}</span></th>
            <th class="ki-right ki-sortable" (click)="sortCol('outputChars')">Chars <span class="ki-glyph">{{ glyph('outputChars') }}</span></th>
            <th class="ki-snippet-head">Snippet</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let r of pageRows()"
              [class.ki-row-ok]="r.success"
              [class.ki-row-fail]="!r.success">
            <td class="ki-icon">
              <span *ngIf="r.success" class="ki-status-ok">✓</span>
              <span *ngIf="!r.success" class="ki-status-fail">✗</span>
            </td>
            <td class="ki-mono ki-tiny">{{ formatTime(r.calledAt) }}</td>
            <td class="ki-mono ki-tiny">
              <span class="ki-provider">{{ r.provider || '—' }}</span>
              <span *ngIf="r.provider && r.model">:</span>
              <span *ngIf="r.model" class="ki-model">{{ r.model }}</span>
              <span *ngIf="!r.provider && !r.model">—</span>
            </td>
            <td class="ki-tiny ki-muted">{{ r.service || '—' }}</td>
            <td class="ki-right ki-mono ki-tiny">{{ r.outputChars != null ? r.outputChars : '—' }}</td>
            <td class="ki-snippet ki-tiny ki-muted">
              <span *ngIf="r.promptSnippet">{{ r.promptSnippet }}</span>
            </td>
          </tr>
        </tbody>
      </table>

      <ki-pager
        [total]="viewRows().length"
        [page]="page()"
        [pageSize]="pageSize"
        (pageChange)="page.set($event)">
      </ki-pager>

      <p class="ki-foot ki-tiny ki-muted">
        Auto-Refresh alle {{ autoRefreshSec }}s · max. {{ maxRows }} Einträge.
      </p>
    </div>
  `, styles: [".ki-dl{font-family:inherit;padding:1rem 0}.ki-header{display:flex;justify-content:space-between;align-items:flex-start;gap:1rem;margin-bottom:1rem}.ki-title{font-size:.85rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#1e293b;margin:0 0 .25rem}.ki-subtitle{font-size:.7rem;color:#64748b;margin:0}.ki-btn-refresh{padding:.35rem .6rem;background:#e0e7ff;color:#3730a3;border:none;border-radius:.375rem;font-size:.8rem;cursor:pointer}.ki-filter{width:100%;box-sizing:border-box;padding:.4rem .6rem;margin-bottom:.5rem;border:1px solid #e2e8f0;border-radius:.375rem;font-size:.8rem}.ki-sortable{cursor:pointer;-webkit-user-select:none;user-select:none;white-space:nowrap}.ki-sortable:hover{color:#4f46e5}.ki-glyph{font-size:.6rem;opacity:.6}.ki-table{width:100%;border-collapse:collapse;font-size:.85rem}.ki-table thead tr{border-bottom:2px solid #e2e8f0}.ki-table th{padding:.5rem .6rem;text-align:left;text-transform:uppercase;font-size:.6rem;font-weight:800;letter-spacing:.08em;color:#64748b}.ki-table td{padding:.45rem .6rem;border-bottom:1px solid #f1f5f9;vertical-align:top}.ki-row-fail{background:linear-gradient(90deg,#fef2f2 0%,transparent 100%)}.ki-icon{width:2rem;text-align:center}.ki-right{text-align:right}.ki-mono{font-family:ui-monospace,monospace}.ki-muted{color:#94a3b8}.ki-tiny{font-size:.7rem}.ki-provider{color:#4f46e5;font-weight:700;margin-right:.15rem}.ki-model{color:#0f172a}.ki-status-ok{color:#059669;font-weight:800;font-size:.9rem}.ki-status-fail{color:#dc2626;font-weight:800;font-size:.9rem}.ki-snippet{max-width:20rem;word-break:break-word;white-space:pre-wrap}.ki-snippet-head{min-width:6rem}.ki-empty{text-align:center;padding:1.5rem;color:#94a3b8}.ki-foot{margin-top:.75rem;font-style:italic}\n"] }]
        }], propDecorators: { title: [{
                type: Input
            }], subtitle: [{
                type: Input
            }], autoRefreshSec: [{
                type: Input
            }], maxRows: [{
                type: Input
            }], pageSize: [{
                type: Input
            }] } });

/**
 * v0.18.0 — Dependency-freier Area-Chart (reines SVG, portiert aus EduPro).
 * Smooth-Bézier-Linie, Gradient-Fill, Drop-Shadow, Hover-Punkte. Keine
 * npm-Dependency, keine Tailwind-Klassen (inline Styles).
 *
 * Eingabe: `series` als `{date,value}[]` (chronologisch). X-Labels zeigen
 * `MM-DD` (ISO-Datum ab Position 5). Speist den Erfolgs-Trend in
 * `<ki-call-overview>`.
 */
class KiAreaChartComponent {
    constructor() {
        this.series = [];
        this.color = '#6366f1';
        this.width = 600;
        this.height = 180;
        this.padX = 32;
        this.padY = 14;
        this.gradId = 'kig_' + Math.random().toString(36).slice(2, 9);
        this.shadowId = 'kis_' + Math.random().toString(36).slice(2, 9);
    }
    get maxValue() {
        if (!this.series?.length)
            return 0;
        return Math.max(0, ...this.series.map(d => d.value || 0));
    }
    get yTicks() {
        const max = Math.max(1, this.maxValue);
        const innerH = this.height - 2 * this.padY - 14;
        return [0.25, 0.5, 0.75, 1].map(frac => ({
            y: this.padY + innerH - innerH * frac,
            value: Math.round(max * frac),
        }));
    }
    get points() {
        if (!this.series?.length)
            return [];
        const max = Math.max(1, ...this.series.map(d => d.value || 0));
        const innerW = this.width - 2 * this.padX;
        const innerH = this.height - 2 * this.padY - 14;
        return this.series.map((d, i) => {
            const x = this.padX + (this.series.length === 1 ? innerW / 2 : (i / (this.series.length - 1)) * innerW);
            const y = this.padY + innerH - (d.value / max) * innerH;
            const short = (d.date || '').slice(5);
            return { x, y, value: d.value, label: d.date, shortLabel: short };
        });
    }
    get labelStep() {
        const n = this.series.length;
        if (n <= 7)
            return 1;
        if (n <= 14)
            return 2;
        if (n <= 21)
            return 3;
        return Math.ceil(n / 8);
    }
    get linePath() {
        const pts = this.points;
        if (pts.length === 0)
            return '';
        let d = `M ${pts[0].x} ${pts[0].y}`;
        for (let i = 1; i < pts.length; i++) {
            const prev = pts[i - 1];
            const cur = pts[i];
            const cx = (prev.x + cur.x) / 2;
            d += ` C ${cx} ${prev.y}, ${cx} ${cur.y}, ${cur.x} ${cur.y}`;
        }
        return d;
    }
    get areaPath() {
        const line = this.linePath;
        if (!line)
            return '';
        const pts = this.points;
        const baseY = this.height - this.padY - 14;
        return `${line} L ${pts[pts.length - 1].x} ${baseY} L ${pts[0].x} ${baseY} Z`;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: KiAreaChartComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: KiAreaChartComponent, isStandalone: true, selector: "ki-area-chart", inputs: { series: "series", color: "color", width: "width", height: "height" }, ngImport: i0, template: `
    <div class="ki-ac-wrap">
      <svg [attr.viewBox]="'0 0 ' + width + ' ' + height" preserveAspectRatio="none">
        <defs>
          <linearGradient [attr.id]="gradId" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" [attr.stop-color]="color" stop-opacity="0.55"></stop>
            <stop offset="55%" [attr.stop-color]="color" stop-opacity="0.18"></stop>
            <stop offset="100%" [attr.stop-color]="color" stop-opacity="0.01"></stop>
          </linearGradient>
          <filter [attr.id]="shadowId" x="-20%" y="-20%" width="140%" height="160%">
            <feGaussianBlur in="SourceAlpha" stdDeviation="1.5"/>
            <feOffset dy="2"/>
            <feComponentTransfer><feFuncA type="linear" slope="0.25"/></feComponentTransfer>
            <feMerge><feMergeNode/><feMergeNode in="SourceGraphic"/></feMerge>
          </filter>
        </defs>

        <g *ngFor="let g of yTicks">
          <line [attr.x1]="padX" [attr.x2]="width - padX"
                [attr.y1]="g.y" [attr.y2]="g.y"
                stroke="currentColor" stroke-opacity="0.06" stroke-dasharray="3 5" />
          <text [attr.x]="padX - 2" [attr.y]="g.y + 3" text-anchor="end"
                fill="currentColor" fill-opacity="0.4"
                font-size="8" font-weight="700" style="font-family: monospace;">{{ g.value }}</text>
        </g>

        <path *ngIf="points.length > 0" class="area-area"
              [attr.d]="areaPath" [attr.fill]="'url(#' + gradId + ')'" />
        <path *ngIf="points.length > 0" class="area-line"
              [attr.d]="linePath" fill="none" [attr.stroke]="color"
              stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round" />

        <g *ngFor="let pt of points; let i = index">
          <circle class="area-pt" [attr.cx]="pt.x" [attr.cy]="pt.y" r="3.5"
                  [attr.fill]="color" stroke="white" stroke-width="1.5"
                  [attr.filter]="'url(#' + shadowId + ')'">
            <title>{{ pt.label }}: {{ pt.value }}</title>
          </circle>
          <text *ngIf="i % labelStep === 0 || pt.value === maxValue"
                [attr.x]="pt.x" [attr.y]="pt.y - 8"
                text-anchor="middle"
                [attr.fill]="color" font-size="10.5" font-weight="900"
                style="font-family: inherit; pointer-events: none;">{{ pt.value }}</text>
        </g>

        <text *ngFor="let pt of points; let i = index"
              [attr.x]="pt.x" [attr.y]="height - 4"
              text-anchor="middle"
              [attr.opacity]="i % labelStep === 0 ? 0.55 : 0"
              fill="currentColor"
              font-size="9" font-weight="700"
              style="font-family: monospace;">{{ pt.shortLabel }}</text>
      </svg>
    </div>
  `, isInline: true, styles: [":host{display:block}.ki-ac-wrap{width:100%;color:#6366f1}.area-line{transition:filter .2s}.area-line:hover{filter:drop-shadow(0 2px 6px rgba(99,102,241,.4))}.area-pt{transition:r .15s,opacity .15s;cursor:crosshair}.area-pt:hover{r:6}.area-area{animation:kiAreaIn .8s ease-out both}@keyframes kiAreaIn{0%{opacity:0}to{opacity:1}}svg{width:100%;height:auto;display:block}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: KiAreaChartComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-area-chart', standalone: true, imports: [CommonModule], template: `
    <div class="ki-ac-wrap">
      <svg [attr.viewBox]="'0 0 ' + width + ' ' + height" preserveAspectRatio="none">
        <defs>
          <linearGradient [attr.id]="gradId" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" [attr.stop-color]="color" stop-opacity="0.55"></stop>
            <stop offset="55%" [attr.stop-color]="color" stop-opacity="0.18"></stop>
            <stop offset="100%" [attr.stop-color]="color" stop-opacity="0.01"></stop>
          </linearGradient>
          <filter [attr.id]="shadowId" x="-20%" y="-20%" width="140%" height="160%">
            <feGaussianBlur in="SourceAlpha" stdDeviation="1.5"/>
            <feOffset dy="2"/>
            <feComponentTransfer><feFuncA type="linear" slope="0.25"/></feComponentTransfer>
            <feMerge><feMergeNode/><feMergeNode in="SourceGraphic"/></feMerge>
          </filter>
        </defs>

        <g *ngFor="let g of yTicks">
          <line [attr.x1]="padX" [attr.x2]="width - padX"
                [attr.y1]="g.y" [attr.y2]="g.y"
                stroke="currentColor" stroke-opacity="0.06" stroke-dasharray="3 5" />
          <text [attr.x]="padX - 2" [attr.y]="g.y + 3" text-anchor="end"
                fill="currentColor" fill-opacity="0.4"
                font-size="8" font-weight="700" style="font-family: monospace;">{{ g.value }}</text>
        </g>

        <path *ngIf="points.length > 0" class="area-area"
              [attr.d]="areaPath" [attr.fill]="'url(#' + gradId + ')'" />
        <path *ngIf="points.length > 0" class="area-line"
              [attr.d]="linePath" fill="none" [attr.stroke]="color"
              stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round" />

        <g *ngFor="let pt of points; let i = index">
          <circle class="area-pt" [attr.cx]="pt.x" [attr.cy]="pt.y" r="3.5"
                  [attr.fill]="color" stroke="white" stroke-width="1.5"
                  [attr.filter]="'url(#' + shadowId + ')'">
            <title>{{ pt.label }}: {{ pt.value }}</title>
          </circle>
          <text *ngIf="i % labelStep === 0 || pt.value === maxValue"
                [attr.x]="pt.x" [attr.y]="pt.y - 8"
                text-anchor="middle"
                [attr.fill]="color" font-size="10.5" font-weight="900"
                style="font-family: inherit; pointer-events: none;">{{ pt.value }}</text>
        </g>

        <text *ngFor="let pt of points; let i = index"
              [attr.x]="pt.x" [attr.y]="height - 4"
              text-anchor="middle"
              [attr.opacity]="i % labelStep === 0 ? 0.55 : 0"
              fill="currentColor"
              font-size="9" font-weight="700"
              style="font-family: monospace;">{{ pt.shortLabel }}</text>
      </svg>
    </div>
  `, styles: [":host{display:block}.ki-ac-wrap{width:100%;color:#6366f1}.area-line{transition:filter .2s}.area-line:hover{filter:drop-shadow(0 2px 6px rgba(99,102,241,.4))}.area-pt{transition:r .15s,opacity .15s;cursor:crosshair}.area-pt:hover{r:6}.area-area{animation:kiAreaIn .8s ease-out both}@keyframes kiAreaIn{0%{opacity:0}to{opacity:1}}svg{width:100%;height:auto;display:block}\n"] }]
        }], propDecorators: { series: [{
                type: Input
            }], color: [{
                type: Input
            }], width: [{
                type: Input
            }], height: [{
                type: Input
            }] } });

const KI_PALETTE = [
    '#6366f1', '#10b981', '#f59e0b', '#ef4444', '#0ea5e9',
    '#a855f7', '#14b8a6', '#f97316', '#ec4899', '#84cc16',
];
/**
 * v0.18.0 — Dependency-freier Donut-Chart (reines SVG, portiert aus EduPro).
 * Animiertes Grow-in, Hover-Segmente, Center-Total, klickbare Legende mit
 * Anzahl + Prozent. Keine npm-Dependency, keine Tailwind-Klassen.
 *
 * Eingabe: `data` als `{key,label?,count,color?}[]`. Zeigt max. 8 Segmente.
 * Speist das Failover-out/Provider-Donut in `<ki-failover-analytics>`.
 */
class KiDonutChartComponent {
    constructor() {
        this.data = [];
        this.centerLabel = 'TOTAL';
        this.C = 2 * Math.PI * 38;
        this.glowId = 'kidg_' + Math.random().toString(36).slice(2, 9);
    }
    get total() {
        return (this.data || []).reduce((s, d) => s + (d.count || 0), 0);
    }
    get segments() {
        const total = this.total;
        if (total === 0)
            return [];
        let acc = 0;
        return (this.data || []).slice(0, 8).map((d, i) => {
            const frac = d.count / total;
            const len = frac * this.C;
            const seg = {
                key: d.key,
                label: d.label || d.key,
                count: d.count,
                pct: Math.round(frac * 100),
                color: d.color || KI_PALETTE[i % KI_PALETTE.length],
                dash: `${len} ${this.C - len}`,
                offset: -acc,
            };
            acc += len;
            return seg;
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: KiDonutChartComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: KiDonutChartComponent, isStandalone: true, selector: "ki-donut-chart", inputs: { data: "data", centerLabel: "centerLabel" }, ngImport: i0, template: `
    <div *ngIf="segments.length === 0" class="ki-donut-empty">Keine Daten.</div>

    <div *ngIf="segments.length > 0" class="ki-donut">
      <div class="ki-donut-svg-wrap">
        <svg viewBox="0 0 100 100">
          <defs>
            <filter [attr.id]="glowId" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur in="SourceAlpha" stdDeviation="1.2"/>
              <feOffset dy="1.5"/>
              <feComponentTransfer><feFuncA type="linear" slope="0.3"/></feComponentTransfer>
              <feMerge><feMergeNode/><feMergeNode in="SourceGraphic"/></feMerge>
            </filter>
          </defs>

          <circle cx="50" cy="50" r="38" fill="none" stroke="currentColor" stroke-opacity="0.06" stroke-width="14" />

          <g class="donut-grp" transform="rotate(-90 50 50)" [attr.filter]="'url(#' + glowId + ')'">
            <circle *ngFor="let s of segments" class="donut-seg"
                    cx="50" cy="50" r="38" fill="none"
                    [attr.stroke]="s.color"
                    stroke-width="14"
                    [attr.stroke-dasharray]="s.dash"
                    [attr.stroke-dashoffset]="s.offset"
                    stroke-linecap="butt">
              <title>{{ s.label }}: {{ s.count }} ({{ s.pct }}%)</title>
            </circle>
          </g>

          <text x="50" y="47" text-anchor="middle" font-size="13" font-weight="900"
                fill="currentColor" style="font-family: inherit;">{{ total }}</text>
          <text x="50" y="60" text-anchor="middle" font-size="5.5" font-weight="700"
                fill="currentColor" fill-opacity="0.45" letter-spacing="1.5"
                style="font-family: monospace;">{{ centerLabel }}</text>
        </svg>
      </div>

      <div class="ki-donut-legend">
        <div *ngFor="let s of segments" class="legend-row">
          <span class="legend-swatch" [style.background]="s.color"></span>
          <span class="legend-key">{{ s.label }}</span>
          <span class="legend-count">{{ s.count }}</span>
          <span class="legend-pct">{{ s.pct }}%</span>
        </div>
      </div>
    </div>
  `, isInline: true, styles: [":host{display:block}.ki-donut{display:flex;align-items:center;gap:1.5rem;color:#334155}.ki-donut-svg-wrap{width:11rem;height:11rem;flex-shrink:0}.donut-seg{transition:stroke-width .2s,opacity .2s;cursor:pointer}.donut-seg:hover{stroke-width:17}.donut-grp{animation:kiDonutIn .9s cubic-bezier(.4,0,.2,1) both}@keyframes kiDonutIn{0%{opacity:0}to{opacity:1}}.ki-donut-legend{flex:1;min-width:0;display:flex;flex-direction:column;gap:.25rem}.legend-row{display:flex;align-items:center;gap:.6rem;font-size:.75rem;padding:.2rem .4rem;border-radius:.25rem;transition:background .15s}.legend-row:hover{background:#94a3b81f}.legend-swatch{width:.75rem;height:.75rem;border-radius:.2rem;flex-shrink:0}.legend-key{font-weight:700;text-transform:uppercase;letter-spacing:-.01em;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.legend-count{margin-left:auto;font-weight:900;font-variant-numeric:tabular-nums}.legend-pct{color:#94a3b8;font-variant-numeric:tabular-nums;width:2.6rem;text-align:right;font-size:.65rem}.ki-donut-empty{color:#94a3b8;font-size:.8rem;padding:1.5rem 0}svg{width:100%;height:100%}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: KiDonutChartComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-donut-chart', standalone: true, imports: [CommonModule], template: `
    <div *ngIf="segments.length === 0" class="ki-donut-empty">Keine Daten.</div>

    <div *ngIf="segments.length > 0" class="ki-donut">
      <div class="ki-donut-svg-wrap">
        <svg viewBox="0 0 100 100">
          <defs>
            <filter [attr.id]="glowId" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur in="SourceAlpha" stdDeviation="1.2"/>
              <feOffset dy="1.5"/>
              <feComponentTransfer><feFuncA type="linear" slope="0.3"/></feComponentTransfer>
              <feMerge><feMergeNode/><feMergeNode in="SourceGraphic"/></feMerge>
            </filter>
          </defs>

          <circle cx="50" cy="50" r="38" fill="none" stroke="currentColor" stroke-opacity="0.06" stroke-width="14" />

          <g class="donut-grp" transform="rotate(-90 50 50)" [attr.filter]="'url(#' + glowId + ')'">
            <circle *ngFor="let s of segments" class="donut-seg"
                    cx="50" cy="50" r="38" fill="none"
                    [attr.stroke]="s.color"
                    stroke-width="14"
                    [attr.stroke-dasharray]="s.dash"
                    [attr.stroke-dashoffset]="s.offset"
                    stroke-linecap="butt">
              <title>{{ s.label }}: {{ s.count }} ({{ s.pct }}%)</title>
            </circle>
          </g>

          <text x="50" y="47" text-anchor="middle" font-size="13" font-weight="900"
                fill="currentColor" style="font-family: inherit;">{{ total }}</text>
          <text x="50" y="60" text-anchor="middle" font-size="5.5" font-weight="700"
                fill="currentColor" fill-opacity="0.45" letter-spacing="1.5"
                style="font-family: monospace;">{{ centerLabel }}</text>
        </svg>
      </div>

      <div class="ki-donut-legend">
        <div *ngFor="let s of segments" class="legend-row">
          <span class="legend-swatch" [style.background]="s.color"></span>
          <span class="legend-key">{{ s.label }}</span>
          <span class="legend-count">{{ s.count }}</span>
          <span class="legend-pct">{{ s.pct }}%</span>
        </div>
      </div>
    </div>
  `, styles: [":host{display:block}.ki-donut{display:flex;align-items:center;gap:1.5rem;color:#334155}.ki-donut-svg-wrap{width:11rem;height:11rem;flex-shrink:0}.donut-seg{transition:stroke-width .2s,opacity .2s;cursor:pointer}.donut-seg:hover{stroke-width:17}.donut-grp{animation:kiDonutIn .9s cubic-bezier(.4,0,.2,1) both}@keyframes kiDonutIn{0%{opacity:0}to{opacity:1}}.ki-donut-legend{flex:1;min-width:0;display:flex;flex-direction:column;gap:.25rem}.legend-row{display:flex;align-items:center;gap:.6rem;font-size:.75rem;padding:.2rem .4rem;border-radius:.25rem;transition:background .15s}.legend-row:hover{background:#94a3b81f}.legend-swatch{width:.75rem;height:.75rem;border-radius:.2rem;flex-shrink:0}.legend-key{font-weight:700;text-transform:uppercase;letter-spacing:-.01em;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.legend-count{margin-left:auto;font-weight:900;font-variant-numeric:tabular-nums}.legend-pct{color:#94a3b8;font-variant-numeric:tabular-nums;width:2.6rem;text-align:right;font-size:.65rem}.ki-donut-empty{color:#94a3b8;font-size:.8rem;padding:1.5rem 0}svg{width:100%;height:100%}\n"] }]
        }], propDecorators: { data: [{
                type: Input
            }], centerLabel: [{
                type: Input
            }] } });

/**
 * v0.18.0 — Geteiltes Analytics-Panel: Erfolgs-Trend (30 Tage) als Area-Chart,
 * KI-Calls-Totals-Cards (24h/7d/30d/✓/✗) und eine geschätzte-Kosten-Summary.
 *
 * Speist sich aus den genuin geteilten Endpunkten `/stats/trend` und
 * `/stats/totals` (llm-cascade → Switcher-Proxy). Kosten werden client-seitig
 * aus `outputChars30d` geschätzt: Tokens ≈ chars/4, € = tokens × Rate.
 *
 * Dependency-frei (reines SVG via `<ki-area-chart>`), keine Tailwind-Klassen.
 * Graceful: fehlende/leere Daten → Leer-Hinweis statt Crash.
 */
class CallOverviewComponent {
    constructor() {
        this.api = inject(KiModelsApiService);
        /** Konsumenten-i18n-Override. Default = englische Labels. */
        this.L = CALL_OVERVIEW_LABELS_EN;
        /** Tage für den Trend. Default 30. */
        this.trendDays = 30;
        /** Geschätzte Kosten pro 1 Mio. Output-Tokens (in der Währung von `currency`). */
        this.costPerMillionTokens = 2.0;
        this.currency = '€';
        this.trend = signal([]);
        this.totals = signal({});
        this.loading = signal(true);
        this.trendSeries = computed(() => this.trend().map((p) => ({ date: p.date, value: p.total })));
        this.outputChars = computed(() => this.totals().outputChars30d ?? 0);
        this.estTokens = computed(() => Math.round(this.outputChars() / 4));
        this.isEmpty = computed(() => this.trend().length === 0 && (this.totals().last30d ?? 0) === 0);
    }
    set labels(v) {
        this.L = { ...CALL_OVERVIEW_LABELS_EN, ...(v ?? {}) };
    }
    ngOnInit() {
        this.reload();
    }
    reload() {
        this.loading.set(true);
        let pending = 2;
        const done = () => { if (--pending === 0)
            this.loading.set(false); };
        this.api.getStatsTrend(this.trendDays).subscribe({
            next: (t) => { this.trend.set(Array.isArray(t) ? t : []); done(); },
            error: () => { this.trend.set([]); done(); },
        });
        this.api.getStatsTotals().subscribe({
            next: (t) => { this.totals.set(t ?? {}); done(); },
            error: () => { this.totals.set({}); done(); },
        });
    }
    estCostLabel() {
        const cost = (this.estTokens() / 1_000_000) * this.costPerMillionTokens;
        return `${this.currency}${cost.toFixed(2)}`;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CallOverviewComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CallOverviewComponent, isStandalone: true, selector: "ki-call-overview", inputs: { labels: "labels", trendDays: "trendDays", costPerMillionTokens: "costPerMillionTokens", currency: "currency" }, ngImport: i0, template: `
    <div class="ki-co">
      <div class="ki-header">
        <div>
          <h4 class="ki-title">{{ L.title }}</h4>
          <p class="ki-subtitle">{{ L.subtitle }}</p>
        </div>
        <button (click)="reload()" class="ki-btn-refresh" title="Neu laden">↻</button>
      </div>

      <p *ngIf="loading()" class="ki-muted">{{ L.loading }}</p>

      <ng-container *ngIf="!loading()">
        <p *ngIf="isEmpty()" class="ki-empty">{{ L.empty }}</p>

        <ng-container *ngIf="!isEmpty()">
          <div class="ki-section-label">{{ L.trendTitle }}</div>
          <ki-area-chart [series]="trendSeries()"></ki-area-chart>

          <div class="ki-cards">
            <div class="ki-card-stat">
              <div class="ki-card-num">{{ totals().last24h ?? 0 }}</div>
              <div class="ki-card-lbl">{{ L.card24h }}</div>
            </div>
            <div class="ki-card-stat">
              <div class="ki-card-num">{{ totals().last7d ?? 0 }}</div>
              <div class="ki-card-lbl">{{ L.card7d }}</div>
            </div>
            <div class="ki-card-stat">
              <div class="ki-card-num">{{ totals().last30d ?? 0 }}</div>
              <div class="ki-card-lbl">{{ L.card30d }}</div>
            </div>
            <div class="ki-card-stat ki-card-ok">
              <div class="ki-card-num">{{ totals().success30d ?? 0 }}</div>
              <div class="ki-card-lbl">{{ L.cardSuccess30d }}</div>
            </div>
            <div class="ki-card-stat ki-card-fail">
              <div class="ki-card-num">{{ totals().failed30d ?? 0 }}</div>
              <div class="ki-card-lbl">{{ L.cardFailed30d }}</div>
            </div>
          </div>

          <div class="ki-section-label">{{ L.costTitle }}</div>
          <div class="ki-cards">
            <div class="ki-card-stat">
              <div class="ki-card-num">{{ outputChars() | number }}</div>
              <div class="ki-card-lbl">{{ L.costChars }}</div>
            </div>
            <div class="ki-card-stat">
              <div class="ki-card-num">{{ estTokens() | number }}</div>
              <div class="ki-card-lbl">{{ L.costTokens }}</div>
            </div>
            <div class="ki-card-stat ki-card-cost">
              <div class="ki-card-num">{{ estCostLabel() }}</div>
              <div class="ki-card-lbl">{{ L.costMoney }}</div>
            </div>
          </div>
        </ng-container>
      </ng-container>
    </div>
  `, isInline: true, styles: [".ki-co{font-family:inherit;padding:1rem 0}.ki-header{display:flex;justify-content:space-between;align-items:flex-start;gap:1rem;margin-bottom:1rem}.ki-title{font-size:.85rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#1e293b;margin:0 0 .25rem}.ki-subtitle{font-size:.7rem;color:#64748b;margin:0}.ki-btn-refresh{padding:.35rem .6rem;background:#e0e7ff;color:#3730a3;border:none;border-radius:.375rem;font-size:.8rem;cursor:pointer}.ki-section-label{font-size:.65rem;font-weight:800;text-transform:uppercase;letter-spacing:.08em;color:#64748b;margin:1rem 0 .5rem}.ki-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(7rem,1fr));gap:.6rem;margin-bottom:.5rem}.ki-card-stat{background:#f8fafc;border:1px solid #e2e8f0;border-radius:.5rem;padding:.7rem .8rem;text-align:center}.ki-card-num{font-size:1.3rem;font-weight:900;color:#1e293b;font-variant-numeric:tabular-nums;line-height:1}.ki-card-lbl{font-size:.6rem;font-weight:700;text-transform:uppercase;letter-spacing:.04em;color:#94a3b8;margin-top:.35rem}.ki-card-ok .ki-card-num{color:#059669}.ki-card-fail .ki-card-num{color:#dc2626}.ki-card-cost .ki-card-num{color:#4f46e5}.ki-muted{color:#94a3b8}.ki-empty{text-align:center;padding:1.5rem;color:#94a3b8}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: i1.DecimalPipe, name: "number" }, { kind: "component", type: KiAreaChartComponent, selector: "ki-area-chart", inputs: ["series", "color", "width", "height"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CallOverviewComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-call-overview', standalone: true, imports: [CommonModule, KiAreaChartComponent], template: `
    <div class="ki-co">
      <div class="ki-header">
        <div>
          <h4 class="ki-title">{{ L.title }}</h4>
          <p class="ki-subtitle">{{ L.subtitle }}</p>
        </div>
        <button (click)="reload()" class="ki-btn-refresh" title="Neu laden">↻</button>
      </div>

      <p *ngIf="loading()" class="ki-muted">{{ L.loading }}</p>

      <ng-container *ngIf="!loading()">
        <p *ngIf="isEmpty()" class="ki-empty">{{ L.empty }}</p>

        <ng-container *ngIf="!isEmpty()">
          <div class="ki-section-label">{{ L.trendTitle }}</div>
          <ki-area-chart [series]="trendSeries()"></ki-area-chart>

          <div class="ki-cards">
            <div class="ki-card-stat">
              <div class="ki-card-num">{{ totals().last24h ?? 0 }}</div>
              <div class="ki-card-lbl">{{ L.card24h }}</div>
            </div>
            <div class="ki-card-stat">
              <div class="ki-card-num">{{ totals().last7d ?? 0 }}</div>
              <div class="ki-card-lbl">{{ L.card7d }}</div>
            </div>
            <div class="ki-card-stat">
              <div class="ki-card-num">{{ totals().last30d ?? 0 }}</div>
              <div class="ki-card-lbl">{{ L.card30d }}</div>
            </div>
            <div class="ki-card-stat ki-card-ok">
              <div class="ki-card-num">{{ totals().success30d ?? 0 }}</div>
              <div class="ki-card-lbl">{{ L.cardSuccess30d }}</div>
            </div>
            <div class="ki-card-stat ki-card-fail">
              <div class="ki-card-num">{{ totals().failed30d ?? 0 }}</div>
              <div class="ki-card-lbl">{{ L.cardFailed30d }}</div>
            </div>
          </div>

          <div class="ki-section-label">{{ L.costTitle }}</div>
          <div class="ki-cards">
            <div class="ki-card-stat">
              <div class="ki-card-num">{{ outputChars() | number }}</div>
              <div class="ki-card-lbl">{{ L.costChars }}</div>
            </div>
            <div class="ki-card-stat">
              <div class="ki-card-num">{{ estTokens() | number }}</div>
              <div class="ki-card-lbl">{{ L.costTokens }}</div>
            </div>
            <div class="ki-card-stat ki-card-cost">
              <div class="ki-card-num">{{ estCostLabel() }}</div>
              <div class="ki-card-lbl">{{ L.costMoney }}</div>
            </div>
          </div>
        </ng-container>
      </ng-container>
    </div>
  `, styles: [".ki-co{font-family:inherit;padding:1rem 0}.ki-header{display:flex;justify-content:space-between;align-items:flex-start;gap:1rem;margin-bottom:1rem}.ki-title{font-size:.85rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#1e293b;margin:0 0 .25rem}.ki-subtitle{font-size:.7rem;color:#64748b;margin:0}.ki-btn-refresh{padding:.35rem .6rem;background:#e0e7ff;color:#3730a3;border:none;border-radius:.375rem;font-size:.8rem;cursor:pointer}.ki-section-label{font-size:.65rem;font-weight:800;text-transform:uppercase;letter-spacing:.08em;color:#64748b;margin:1rem 0 .5rem}.ki-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(7rem,1fr));gap:.6rem;margin-bottom:.5rem}.ki-card-stat{background:#f8fafc;border:1px solid #e2e8f0;border-radius:.5rem;padding:.7rem .8rem;text-align:center}.ki-card-num{font-size:1.3rem;font-weight:900;color:#1e293b;font-variant-numeric:tabular-nums;line-height:1}.ki-card-lbl{font-size:.6rem;font-weight:700;text-transform:uppercase;letter-spacing:.04em;color:#94a3b8;margin-top:.35rem}.ki-card-ok .ki-card-num{color:#059669}.ki-card-fail .ki-card-num{color:#dc2626}.ki-card-cost .ki-card-num{color:#4f46e5}.ki-muted{color:#94a3b8}.ki-empty{text-align:center;padding:1.5rem;color:#94a3b8}\n"] }]
        }], propDecorators: { labels: [{
                type: Input
            }], trendDays: [{
                type: Input
            }], costPerMillionTokens: [{
                type: Input
            }], currency: [{
                type: Input
            }] } });

/**
 * v0.18.0 — Geteiltes Failover-Analytics-Panel: Donut „Failover-out / Provider"
 * (welcher Provider wurde wie oft aus der Kaskade gedroppt) plus eine
 * paginierte, sortier-/filterbare Provider×Grund-Tabelle.
 *
 * v0.19.0 — Zusätzlich eine Failover-/Toggle-Events-Timeline (letzte 50 mit
 * Datumsangaben) aus `/stats/failover`. Toggle-Umschaltungen (an/aus) tauchen
 * hier als `toggle_on`/`toggle_off` auf.
 *
 * v0.26.0 — Events-Timeline paginiert (eigener Pager, `pageSize` wie die
 * Provider×Grund-Tabelle) statt alle 50 auf einmal.
 *
 * v0.27.0 — Events als echte `ki-table` (thead/tbody, sortier- + filterbar +
 * Pager) statt Timeline-Divs — einheitliches Tabellen-Design im ganzen Panel.
 *
 * Dependency-frei (reines SVG via `<ki-donut-chart>`), Pager nur ab `pageSize`.
 * Graceful: leere/fehlende Daten → Leer-Hinweis.
 */
class FailoverAnalyticsComponent {
    constructor() {
        this.api = inject(KiModelsApiService);
        /** Konsumenten-i18n-Override. Default = englische Labels. */
        this.L = FAILOVER_ANALYTICS_LABELS_EN;
        /** Seitengröße der Provider×Grund-Tabelle. Default 10. */
        this.pageSize = 10;
        this.breakdown = signal({ byProvider: [], byProviderReason: [], byReason: [] });
        this.events = signal({ recent: [], total30d: 0 });
        this.loading = signal(true);
        this.page = signal(0);
        this.matrixFilter = signal('');
        this.matrixSort = signal({ key: null, dir: null });
        this.eventsFilter = signal('');
        this.eventsSort = signal({ key: null, dir: null });
        this.eventsPage = signal(0);
        this.byProviderReason = computed(() => this.breakdown().byProviderReason ?? []);
        this.matrixRows = computed(() => sortRows(filterRows(this.byProviderReason(), this.matrixFilter(), ['provider', 'reason']), this.matrixSort()));
        this.donutData = computed(() => (this.breakdown().byProvider ?? []).map((p) => ({
            key: p.provider,
            label: p.provider,
            count: p.failovers,
        })));
        this.pageRows = computed(() => paginate(this.matrixRows(), this.page(), this.pageSize));
        this.filteredEvents = computed(() => sortRows(filterRows(this.events().recent, this.eventsFilter(), ['type', 'fromModel', 'toModel', 'reason']), this.eventsSort()));
        this.eventsPageRows = computed(() => paginate(this.filteredEvents(), this.eventsPage(), this.pageSize));
        this.isEmpty = computed(() => (this.breakdown().byProvider ?? []).length === 0 &&
            this.byProviderReason().length === 0);
        this.allEmpty = computed(() => this.isEmpty() && this.events().recent.length === 0);
    }
    set labels(v) {
        this.L = { ...FAILOVER_ANALYTICS_LABELS_EN, ...(v ?? {}) };
    }
    ngOnInit() {
        this.reload();
    }
    glyph(key) {
        return sortGlyph(this.matrixSort(), key);
    }
    sortMatrix(key) {
        this.matrixSort.set(nextSort(this.matrixSort(), key));
        this.page.set(0);
    }
    setMatrixFilter(v) {
        this.matrixFilter.set(v);
        this.page.set(0);
    }
    setEventsFilter(v) {
        this.eventsFilter.set(v);
        this.eventsPage.set(0);
    }
    glyphE(key) {
        return sortGlyph(this.eventsSort(), key);
    }
    sortEvents(key) {
        this.eventsSort.set(nextSort(this.eventsSort(), key));
        this.eventsPage.set(0);
    }
    badgeClass(type) {
        switch (type) {
            case 'switch_down': return 'ki-badge-down';
            case 'switch_up':
            case 'promote_primary': return 'ki-badge-up';
            case 'toggle_on':
            case 'supermodel_on': return 'ki-badge-on';
            case 'toggle_off':
            case 'supermodel_off': return 'ki-badge-off';
            case 'pool_switch': return 'ki-badge-pool';
            default: return 'ki-badge-off';
        }
    }
    fmtWhen(iso) {
        if (!iso)
            return '';
        const d = new Date(iso);
        if (isNaN(d.getTime()))
            return iso;
        return d.toLocaleString([], {
            year: 'numeric', month: '2-digit', day: '2-digit',
            hour: '2-digit', minute: '2-digit',
        });
    }
    reload() {
        this.loading.set(true);
        this.page.set(0);
        this.eventsPage.set(0);
        this.api.getStatsFailoverBreakdown().subscribe({
            next: (b) => {
                this.breakdown.set(b ?? { byProvider: [], byProviderReason: [], byReason: [] });
                this.loading.set(false);
            },
            error: () => {
                this.breakdown.set({ byProvider: [], byProviderReason: [], byReason: [] });
                this.loading.set(false);
            },
        });
        this.api.getStatsFailover().subscribe({
            next: (e) => this.events.set(e ?? { recent: [], total30d: 0 }),
            error: () => this.events.set({ recent: [], total30d: 0 }),
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FailoverAnalyticsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FailoverAnalyticsComponent, isStandalone: true, selector: "ki-failover-analytics", inputs: { labels: "labels", pageSize: "pageSize" }, ngImport: i0, template: `
    <div class="ki-fa">
      <div class="ki-header">
        <div>
          <h4 class="ki-title">{{ L.title }}</h4>
          <p class="ki-subtitle">{{ L.subtitle }}</p>
        </div>
        <button (click)="reload()" class="ki-btn-refresh" title="Neu laden">↻</button>
      </div>

      <p *ngIf="loading()" class="ki-muted">{{ L.loading }}</p>

      <ng-container *ngIf="!loading()">
        <p *ngIf="allEmpty()" class="ki-empty">{{ L.empty }}</p>

        <ng-container *ngIf="!allEmpty()">
          <ng-container *ngIf="!isEmpty()">
            <div class="ki-section-label">{{ L.donutTitle }}</div>
            <ki-donut-chart [data]="donutData()" [centerLabel]="L.donutCenter"></ki-donut-chart>

            <div class="ki-section-label">{{ L.tableTitle }}</div>
            <input
              class="ki-filter"
              type="text"
              [placeholder]="L.filterPlaceholder"
              [value]="matrixFilter()"
              (input)="setMatrixFilter($any($event.target).value)" />
            <table *ngIf="byProviderReason().length > 0" class="ki-table">
              <thead>
                <tr>
                  <th class="ki-sortable" (click)="sortMatrix('provider')">{{ L.colProvider }} <span class="ki-glyph">{{ glyph('provider') }}</span></th>
                  <th class="ki-sortable" (click)="sortMatrix('reason')">{{ L.colReason }} <span class="ki-glyph">{{ glyph('reason') }}</span></th>
                  <th class="ki-right ki-sortable" (click)="sortMatrix('count')">{{ L.colCount }} <span class="ki-glyph">{{ glyph('count') }}</span></th>
                </tr>
              </thead>
              <tbody>
                <tr *ngFor="let r of pageRows()">
                  <td class="ki-mono"><span class="ki-provider">{{ r.provider || '—' }}</span></td>
                  <td class="ki-tiny">{{ r.reason || '—' }}</td>
                  <td class="ki-right ki-mono">{{ r.count }}</td>
                </tr>
              </tbody>
            </table>

            <ki-pager
              [total]="matrixRows().length"
              [page]="page()"
              [pageSize]="pageSize"
              (pageChange)="page.set($event)">
            </ki-pager>
          </ng-container>

          <!-- v0.19.0 — Failover-/Toggle-Events-Timeline -->
          <ng-container *ngIf="events().recent.length > 0">
            <div class="ki-section-label">
              {{ L.timelineTitle }}
              <span class="ki-30d">30d: {{ events().total30d }}</span>
            </div>
            <p class="ki-subtitle">{{ L.timelineHint }}</p>
            <input
              class="ki-filter"
              type="text"
              [placeholder]="L.filterPlaceholder"
              [value]="eventsFilter()"
              (input)="setEventsFilter($any($event.target).value)" />
            <table class="ki-table">
              <thead>
                <tr>
                  <th class="ki-sortable" (click)="sortEvents('type')">{{ L.colType }} <span class="ki-glyph">{{ glyphE('type') }}</span></th>
                  <th class="ki-sortable" (click)="sortEvents('fromModel')">{{ L.colTransition }} <span class="ki-glyph">{{ glyphE('fromModel') }}</span></th>
                  <th class="ki-sortable" (click)="sortEvents('reason')">{{ L.colReason }} <span class="ki-glyph">{{ glyphE('reason') }}</span></th>
                  <th class="ki-sortable" (click)="sortEvents('occurredAt')">{{ L.colWhen }} <span class="ki-glyph">{{ glyphE('occurredAt') }}</span></th>
                </tr>
              </thead>
              <tbody>
                <tr *ngFor="let e of eventsPageRows()">
                  <td><span class="ki-badge" [class]="badgeClass(e.type)">{{ e.type }}</span></td>
                  <td class="ki-mono ki-tiny">{{ e.fromModel || '—' }} → {{ e.toModel || '—' }}</td>
                  <td class="ki-tiny">{{ e.reason || '' }}<span *ngIf="e.cooldownSec"> ({{ e.cooldownSec }}s)</span></td>
                  <td class="ki-tiny ki-when">{{ fmtWhen(e.occurredAt) }}</td>
                </tr>
              </tbody>
            </table>

            <ki-pager
              [total]="filteredEvents().length"
              [page]="eventsPage()"
              [pageSize]="pageSize"
              (pageChange)="eventsPage.set($event)">
            </ki-pager>
          </ng-container>
        </ng-container>
      </ng-container>
    </div>
  `, isInline: true, styles: [".ki-fa{font-family:inherit;padding:1rem 0}.ki-header{display:flex;justify-content:space-between;align-items:flex-start;gap:1rem;margin-bottom:1rem}.ki-title{font-size:.85rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#1e293b;margin:0 0 .25rem}.ki-subtitle{font-size:.7rem;color:#64748b;margin:0 0 .5rem}.ki-btn-refresh{padding:.35rem .6rem;background:#e0e7ff;color:#3730a3;border:none;border-radius:.375rem;font-size:.8rem;cursor:pointer}.ki-section-label{font-size:.65rem;font-weight:800;text-transform:uppercase;letter-spacing:.08em;color:#64748b;margin:1rem 0 .5rem}.ki-30d{margin-left:.5rem;font-family:ui-monospace,monospace;color:#94a3b8}.ki-filter{width:100%;box-sizing:border-box;padding:.4rem .6rem;margin-bottom:.5rem;border:1px solid #e2e8f0;border-radius:.375rem;font-size:.8rem}.ki-table{width:100%;border-collapse:collapse;font-size:.85rem}.ki-table thead tr{border-bottom:2px solid #e2e8f0}.ki-table th{padding:.5rem .6rem;text-align:left;text-transform:uppercase;font-size:.6rem;font-weight:800;letter-spacing:.08em;color:#64748b}.ki-sortable{cursor:pointer;-webkit-user-select:none;user-select:none;white-space:nowrap}.ki-sortable:hover{color:#4f46e5}.ki-glyph{font-size:.6rem;opacity:.6}.ki-table td{padding:.5rem .6rem;border-bottom:1px solid #f1f5f9;vertical-align:top}.ki-right{text-align:right}.ki-mono{font-family:ui-monospace,monospace}.ki-muted{color:#94a3b8}.ki-tiny{font-size:.7rem}.ki-provider{color:#4f46e5;font-weight:700}.ki-empty{text-align:center;padding:1.5rem;color:#94a3b8}.ki-badge{display:inline-block;min-width:5.5rem;text-align:center;padding:.1rem .4rem;border-radius:.3rem;font-family:ui-monospace,monospace;font-size:.62rem;font-weight:700}.ki-badge-down{background:#fee2e2;color:#b91c1c}.ki-badge-up{background:#dcfce7;color:#15803d}.ki-badge-on{background:#dbeafe;color:#1d4ed8}.ki-badge-off{background:#f1f5f9;color:#475569}.ki-badge-pool{background:#ede9fe;color:#6d28d9}.ki-when{color:#94a3b8;white-space:nowrap}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: KiDonutChartComponent, selector: "ki-donut-chart", inputs: ["data", "centerLabel"] }, { kind: "component", type: KiPagerComponent, selector: "ki-pager", inputs: ["total", "page", "pageSize"], outputs: ["pageChange"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FailoverAnalyticsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-failover-analytics', standalone: true, imports: [CommonModule, KiDonutChartComponent, KiPagerComponent], template: `
    <div class="ki-fa">
      <div class="ki-header">
        <div>
          <h4 class="ki-title">{{ L.title }}</h4>
          <p class="ki-subtitle">{{ L.subtitle }}</p>
        </div>
        <button (click)="reload()" class="ki-btn-refresh" title="Neu laden">↻</button>
      </div>

      <p *ngIf="loading()" class="ki-muted">{{ L.loading }}</p>

      <ng-container *ngIf="!loading()">
        <p *ngIf="allEmpty()" class="ki-empty">{{ L.empty }}</p>

        <ng-container *ngIf="!allEmpty()">
          <ng-container *ngIf="!isEmpty()">
            <div class="ki-section-label">{{ L.donutTitle }}</div>
            <ki-donut-chart [data]="donutData()" [centerLabel]="L.donutCenter"></ki-donut-chart>

            <div class="ki-section-label">{{ L.tableTitle }}</div>
            <input
              class="ki-filter"
              type="text"
              [placeholder]="L.filterPlaceholder"
              [value]="matrixFilter()"
              (input)="setMatrixFilter($any($event.target).value)" />
            <table *ngIf="byProviderReason().length > 0" class="ki-table">
              <thead>
                <tr>
                  <th class="ki-sortable" (click)="sortMatrix('provider')">{{ L.colProvider }} <span class="ki-glyph">{{ glyph('provider') }}</span></th>
                  <th class="ki-sortable" (click)="sortMatrix('reason')">{{ L.colReason }} <span class="ki-glyph">{{ glyph('reason') }}</span></th>
                  <th class="ki-right ki-sortable" (click)="sortMatrix('count')">{{ L.colCount }} <span class="ki-glyph">{{ glyph('count') }}</span></th>
                </tr>
              </thead>
              <tbody>
                <tr *ngFor="let r of pageRows()">
                  <td class="ki-mono"><span class="ki-provider">{{ r.provider || '—' }}</span></td>
                  <td class="ki-tiny">{{ r.reason || '—' }}</td>
                  <td class="ki-right ki-mono">{{ r.count }}</td>
                </tr>
              </tbody>
            </table>

            <ki-pager
              [total]="matrixRows().length"
              [page]="page()"
              [pageSize]="pageSize"
              (pageChange)="page.set($event)">
            </ki-pager>
          </ng-container>

          <!-- v0.19.0 — Failover-/Toggle-Events-Timeline -->
          <ng-container *ngIf="events().recent.length > 0">
            <div class="ki-section-label">
              {{ L.timelineTitle }}
              <span class="ki-30d">30d: {{ events().total30d }}</span>
            </div>
            <p class="ki-subtitle">{{ L.timelineHint }}</p>
            <input
              class="ki-filter"
              type="text"
              [placeholder]="L.filterPlaceholder"
              [value]="eventsFilter()"
              (input)="setEventsFilter($any($event.target).value)" />
            <table class="ki-table">
              <thead>
                <tr>
                  <th class="ki-sortable" (click)="sortEvents('type')">{{ L.colType }} <span class="ki-glyph">{{ glyphE('type') }}</span></th>
                  <th class="ki-sortable" (click)="sortEvents('fromModel')">{{ L.colTransition }} <span class="ki-glyph">{{ glyphE('fromModel') }}</span></th>
                  <th class="ki-sortable" (click)="sortEvents('reason')">{{ L.colReason }} <span class="ki-glyph">{{ glyphE('reason') }}</span></th>
                  <th class="ki-sortable" (click)="sortEvents('occurredAt')">{{ L.colWhen }} <span class="ki-glyph">{{ glyphE('occurredAt') }}</span></th>
                </tr>
              </thead>
              <tbody>
                <tr *ngFor="let e of eventsPageRows()">
                  <td><span class="ki-badge" [class]="badgeClass(e.type)">{{ e.type }}</span></td>
                  <td class="ki-mono ki-tiny">{{ e.fromModel || '—' }} → {{ e.toModel || '—' }}</td>
                  <td class="ki-tiny">{{ e.reason || '' }}<span *ngIf="e.cooldownSec"> ({{ e.cooldownSec }}s)</span></td>
                  <td class="ki-tiny ki-when">{{ fmtWhen(e.occurredAt) }}</td>
                </tr>
              </tbody>
            </table>

            <ki-pager
              [total]="filteredEvents().length"
              [page]="eventsPage()"
              [pageSize]="pageSize"
              (pageChange)="eventsPage.set($event)">
            </ki-pager>
          </ng-container>
        </ng-container>
      </ng-container>
    </div>
  `, styles: [".ki-fa{font-family:inherit;padding:1rem 0}.ki-header{display:flex;justify-content:space-between;align-items:flex-start;gap:1rem;margin-bottom:1rem}.ki-title{font-size:.85rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#1e293b;margin:0 0 .25rem}.ki-subtitle{font-size:.7rem;color:#64748b;margin:0 0 .5rem}.ki-btn-refresh{padding:.35rem .6rem;background:#e0e7ff;color:#3730a3;border:none;border-radius:.375rem;font-size:.8rem;cursor:pointer}.ki-section-label{font-size:.65rem;font-weight:800;text-transform:uppercase;letter-spacing:.08em;color:#64748b;margin:1rem 0 .5rem}.ki-30d{margin-left:.5rem;font-family:ui-monospace,monospace;color:#94a3b8}.ki-filter{width:100%;box-sizing:border-box;padding:.4rem .6rem;margin-bottom:.5rem;border:1px solid #e2e8f0;border-radius:.375rem;font-size:.8rem}.ki-table{width:100%;border-collapse:collapse;font-size:.85rem}.ki-table thead tr{border-bottom:2px solid #e2e8f0}.ki-table th{padding:.5rem .6rem;text-align:left;text-transform:uppercase;font-size:.6rem;font-weight:800;letter-spacing:.08em;color:#64748b}.ki-sortable{cursor:pointer;-webkit-user-select:none;user-select:none;white-space:nowrap}.ki-sortable:hover{color:#4f46e5}.ki-glyph{font-size:.6rem;opacity:.6}.ki-table td{padding:.5rem .6rem;border-bottom:1px solid #f1f5f9;vertical-align:top}.ki-right{text-align:right}.ki-mono{font-family:ui-monospace,monospace}.ki-muted{color:#94a3b8}.ki-tiny{font-size:.7rem}.ki-provider{color:#4f46e5;font-weight:700}.ki-empty{text-align:center;padding:1.5rem;color:#94a3b8}.ki-badge{display:inline-block;min-width:5.5rem;text-align:center;padding:.1rem .4rem;border-radius:.3rem;font-family:ui-monospace,monospace;font-size:.62rem;font-weight:700}.ki-badge-down{background:#fee2e2;color:#b91c1c}.ki-badge-up{background:#dcfce7;color:#15803d}.ki-badge-on{background:#dbeafe;color:#1d4ed8}.ki-badge-off{background:#f1f5f9;color:#475569}.ki-badge-pool{background:#ede9fe;color:#6d28d9}.ki-when{color:#94a3b8;white-space:nowrap}\n"] }]
        }], propDecorators: { labels: [{
                type: Input
            }], pageSize: [{
                type: Input
            }] } });

/**
 * v0.20.0 — Prompt-Log-Panel: zeigt die zuletzt geloggten Prompt-Snippets
 * (Zeitpunkt/Service/Modell/Provider/Kategorie/Snippet/Status) aus
 * `GET {base}/stats/log-snippets?limit=N`.
 *
 * Ehrlicher Hinweis: Snippets entstehen NUR, wenn das Setting
 * `logPromptSnippet` AN ist UND der Traffic durch die Cascade lief. Der
 * direkte cloud+Anthropic-Pfad umgeht die Cascade → dort wird nichts geloggt.
 *
 * Card/Section-Struktur analog `<ki-call-overview>` / `<ki-failover-analytics>`.
 * Graceful: leeres Array → erklärender Leer-Hinweis statt Crash.
 */
class LogSnippetsComponent {
    constructor() {
        this.api = inject(KiModelsApiService);
        /** Titel oben — überschreibbar pro Konsument. */
        this.title = 'Prompt-Log';
        this.subtitle = 'Zuletzt geloggte Prompt-Snippets. Nur befüllt, wenn Prompt-Logging AN ist und Traffic durch die Cascade lief.';
        /** Wie viele Snippets geladen werden. Default 50. */
        this.limit = 50;
        this.rows = signal([]);
        this.loading = signal(true);
    }
    ngOnInit() {
        this.reload();
    }
    reload() {
        this.loading.set(true);
        this.api.getLogSnippets(this.limit).subscribe({
            next: (r) => { this.rows.set(Array.isArray(r) ? r : []); this.loading.set(false); },
            error: () => { this.rows.set([]); this.loading.set(false); },
        });
    }
    fmtWhen(iso) {
        if (!iso)
            return '—';
        const d = new Date(iso);
        if (isNaN(d.getTime()))
            return iso;
        return d.toLocaleString([], {
            year: 'numeric', month: '2-digit', day: '2-digit',
            hour: '2-digit', minute: '2-digit',
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: LogSnippetsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: LogSnippetsComponent, isStandalone: true, selector: "ki-log-snippets", inputs: { title: "title", subtitle: "subtitle", limit: "limit" }, ngImport: i0, template: `
    <div class="ki-ls">
      <div class="ki-header">
        <div>
          <h4 class="ki-title">{{ title }}</h4>
          <p class="ki-subtitle">{{ subtitle }}</p>
        </div>
        <button (click)="reload()" class="ki-btn-refresh" title="Neu laden">↻</button>
      </div>

      <p *ngIf="loading()" class="ki-muted">Lade Prompt-Log…</p>

      <ng-container *ngIf="!loading()">
        <div *ngIf="rows().length === 0" class="ki-empty">
          <p class="ki-empty-head">Keine Prompt-Snippets vorhanden.</p>
          <p class="ki-empty-body">
            Snippets werden nur geschrieben, wenn „Prompt-Logging“
            (<code>logPromptSnippet</code>) aktiv ist UND der Traffic durch die
            Cascade läuft. Der direkte cloud+Anthropic-Pfad umgeht die Cascade
            und wird nicht geloggt.
          </p>
        </div>

        <table *ngIf="rows().length > 0" class="ki-table">
          <thead>
            <tr>
              <th>Zeitpunkt</th>
              <th>Service</th>
              <th>Modell</th>
              <th>Provider</th>
              <th>Kategorie</th>
              <th>Snippet</th>
              <th class="ki-center">Status</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let r of rows()">
              <td class="ki-tiny ki-when">{{ fmtWhen(r.calledAt) }}</td>
              <td class="ki-tiny">{{ r.service || '—' }}</td>
              <td class="ki-mono ki-tiny">{{ r.model || '—' }}</td>
              <td class="ki-tiny"><span class="ki-provider">{{ r.provider || '—' }}</span></td>
              <td class="ki-tiny">{{ r.category || '—' }}</td>
              <td class="ki-snippet">{{ r.promptSnippet }}</td>
              <td class="ki-center">
                <span class="ki-badge" [class.ki-badge-ok]="r.success" [class.ki-badge-fail]="!r.success">
                  {{ r.success ? 'OK' : 'Fehler' }}
                </span>
              </td>
            </tr>
          </tbody>
        </table>
      </ng-container>
    </div>
  `, isInline: true, styles: [".ki-ls{font-family:inherit;padding:1rem 0}.ki-header{display:flex;justify-content:space-between;align-items:flex-start;gap:1rem;margin-bottom:1rem}.ki-title{font-size:.85rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#1e293b;margin:0 0 .25rem}.ki-subtitle{font-size:.7rem;color:#64748b;margin:0}.ki-btn-refresh{padding:.35rem .6rem;background:#e0e7ff;color:#3730a3;border:none;border-radius:.375rem;font-size:.8rem;cursor:pointer}.ki-muted{color:#94a3b8}.ki-table{width:100%;border-collapse:collapse;font-size:.85rem}.ki-table thead tr{border-bottom:2px solid #e2e8f0}.ki-table th{padding:.5rem .6rem;text-align:left;text-transform:uppercase;font-size:.6rem;font-weight:800;letter-spacing:.08em;color:#64748b;white-space:nowrap}.ki-table td{padding:.5rem .6rem;border-bottom:1px solid #f1f5f9;vertical-align:top}.ki-center{text-align:center}.ki-mono{font-family:ui-monospace,monospace}.ki-tiny{font-size:.7rem}.ki-when{white-space:nowrap;color:#94a3b8}.ki-provider{color:#4f46e5;font-weight:700}.ki-snippet{font-size:.72rem;color:#334155;max-width:28rem;overflow-wrap:anywhere;white-space:pre-wrap;line-height:1.35}.ki-badge{display:inline-block;padding:.1rem .4rem;border-radius:.3rem;font-size:.62rem;font-weight:800;text-transform:uppercase;letter-spacing:.04em}.ki-badge-ok{background:#dcfce7;color:#15803d}.ki-badge-fail{background:#fee2e2;color:#b91c1c}.ki-empty{background:#f8fafc;border:1px dashed #cbd5e1;border-radius:.5rem;padding:1.25rem 1.5rem;text-align:center}.ki-empty-head{font-weight:700;color:#475569;margin:0 0 .4rem;font-size:.85rem}.ki-empty-body{color:#64748b;margin:0;font-size:.72rem;line-height:1.5}.ki-empty-body code{font-family:ui-monospace,monospace;font-size:.68rem;background:#e2e8f0;padding:.05rem .25rem;border-radius:.2rem}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: LogSnippetsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-log-snippets', standalone: true, imports: [CommonModule], template: `
    <div class="ki-ls">
      <div class="ki-header">
        <div>
          <h4 class="ki-title">{{ title }}</h4>
          <p class="ki-subtitle">{{ subtitle }}</p>
        </div>
        <button (click)="reload()" class="ki-btn-refresh" title="Neu laden">↻</button>
      </div>

      <p *ngIf="loading()" class="ki-muted">Lade Prompt-Log…</p>

      <ng-container *ngIf="!loading()">
        <div *ngIf="rows().length === 0" class="ki-empty">
          <p class="ki-empty-head">Keine Prompt-Snippets vorhanden.</p>
          <p class="ki-empty-body">
            Snippets werden nur geschrieben, wenn „Prompt-Logging“
            (<code>logPromptSnippet</code>) aktiv ist UND der Traffic durch die
            Cascade läuft. Der direkte cloud+Anthropic-Pfad umgeht die Cascade
            und wird nicht geloggt.
          </p>
        </div>

        <table *ngIf="rows().length > 0" class="ki-table">
          <thead>
            <tr>
              <th>Zeitpunkt</th>
              <th>Service</th>
              <th>Modell</th>
              <th>Provider</th>
              <th>Kategorie</th>
              <th>Snippet</th>
              <th class="ki-center">Status</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let r of rows()">
              <td class="ki-tiny ki-when">{{ fmtWhen(r.calledAt) }}</td>
              <td class="ki-tiny">{{ r.service || '—' }}</td>
              <td class="ki-mono ki-tiny">{{ r.model || '—' }}</td>
              <td class="ki-tiny"><span class="ki-provider">{{ r.provider || '—' }}</span></td>
              <td class="ki-tiny">{{ r.category || '—' }}</td>
              <td class="ki-snippet">{{ r.promptSnippet }}</td>
              <td class="ki-center">
                <span class="ki-badge" [class.ki-badge-ok]="r.success" [class.ki-badge-fail]="!r.success">
                  {{ r.success ? 'OK' : 'Fehler' }}
                </span>
              </td>
            </tr>
          </tbody>
        </table>
      </ng-container>
    </div>
  `, styles: [".ki-ls{font-family:inherit;padding:1rem 0}.ki-header{display:flex;justify-content:space-between;align-items:flex-start;gap:1rem;margin-bottom:1rem}.ki-title{font-size:.85rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#1e293b;margin:0 0 .25rem}.ki-subtitle{font-size:.7rem;color:#64748b;margin:0}.ki-btn-refresh{padding:.35rem .6rem;background:#e0e7ff;color:#3730a3;border:none;border-radius:.375rem;font-size:.8rem;cursor:pointer}.ki-muted{color:#94a3b8}.ki-table{width:100%;border-collapse:collapse;font-size:.85rem}.ki-table thead tr{border-bottom:2px solid #e2e8f0}.ki-table th{padding:.5rem .6rem;text-align:left;text-transform:uppercase;font-size:.6rem;font-weight:800;letter-spacing:.08em;color:#64748b;white-space:nowrap}.ki-table td{padding:.5rem .6rem;border-bottom:1px solid #f1f5f9;vertical-align:top}.ki-center{text-align:center}.ki-mono{font-family:ui-monospace,monospace}.ki-tiny{font-size:.7rem}.ki-when{white-space:nowrap;color:#94a3b8}.ki-provider{color:#4f46e5;font-weight:700}.ki-snippet{font-size:.72rem;color:#334155;max-width:28rem;overflow-wrap:anywhere;white-space:pre-wrap;line-height:1.35}.ki-badge{display:inline-block;padding:.1rem .4rem;border-radius:.3rem;font-size:.62rem;font-weight:800;text-transform:uppercase;letter-spacing:.04em}.ki-badge-ok{background:#dcfce7;color:#15803d}.ki-badge-fail{background:#fee2e2;color:#b91c1c}.ki-empty{background:#f8fafc;border:1px dashed #cbd5e1;border-radius:.5rem;padding:1.25rem 1.5rem;text-align:center}.ki-empty-head{font-weight:700;color:#475569;margin:0 0 .4rem;font-size:.85rem}.ki-empty-body{color:#64748b;margin:0;font-size:.72rem;line-height:1.5}.ki-empty-body code{font-family:ui-monospace,monospace;font-size:.68rem;background:#e2e8f0;padding:.05rem .25rem;border-radius:.2rem}\n"] }]
        }], propDecorators: { title: [{
                type: Input
            }], subtitle: [{
                type: Input
            }], limit: [{
                type: Input
            }] } });

/**
 * v0.20.0 — Eigene Liste der Modus-/Toggle-Umschaltungen.
 *
 * Speist sich aus `/stats/failover` wie {@link import('./failover-analytics.component')},
 * zeigt aber NUR Host-/Toggle-Events:
 * `toggle_on` / `toggle_off` (Modell an/aus), `pool_switch` (Pool-Wechsel),
 * `supermodel_on` / `supermodel_off` (Supermodell-Achse).
 *
 * Gedacht für den „Modus"-Bereich im Switcher (neben dem Pool-/Supermodell-Panel),
 * damit man dort die letzten Schaltvorgänge mit Datum sieht. Header + absolute
 * Datumsangabe + Filter; Auto-Refresh damit Live-Toggles auftauchen.
 */
class ModeEventsComponent {
    constructor() {
        this.api = inject(KiModelsApiService);
        /** Konsumenten-i18n-Override. Default = englische Labels. */
        this.L = MODE_EVENTS_LABELS_EN;
        /** Auto-Refresh-Intervall in Sekunden. Default 10s. 0 deaktiviert. */
        this.autoRefreshSec = 10;
        this.events = signal([]);
        this.loading = signal(true);
        this.filter = signal('');
        this.modeEvents = computed(() => this.events().filter((e) => ModeEventsComponent.MODE_TYPES.has(e.type)));
        this.filteredEvents = computed(() => filterRows(this.modeEvents(), this.filter(), ['type', 'fromModel', 'toModel', 'reason']));
        this.timer = null;
    }
    set labels(v) {
        this.L = { ...MODE_EVENTS_LABELS_EN, ...(v ?? {}) };
    }
    /** Event-Typen die als „Modus-/Toggle-Umschaltung" gelten. */
    static { this.MODE_TYPES = new Set([
        'toggle_on', 'toggle_off', 'pool_switch', 'supermodel_on', 'supermodel_off',
        'model_switch',
    ]); }
    ngOnInit() {
        this.reload();
        if (this.autoRefreshSec > 0) {
            this.timer = setInterval(() => this.reload(), this.autoRefreshSec * 1000);
        }
    }
    ngOnDestroy() {
        if (this.timer)
            clearInterval(this.timer);
        this.timer = null;
    }
    setFilter(v) { this.filter.set(v); }
    reload() {
        this.api.getStatsFailover().subscribe({
            next: (e) => {
                this.events.set(Array.isArray(e?.recent) ? e.recent : []);
                this.loading.set(false);
            },
            error: () => {
                this.events.set([]);
                this.loading.set(false);
            },
        });
    }
    badgeClass(type) {
        switch (type) {
            case 'toggle_on':
            case 'supermodel_on': return 'ki-badge-on';
            case 'toggle_off':
            case 'supermodel_off': return 'ki-badge-off';
            case 'pool_switch': return 'ki-badge-pool';
            case 'model_switch': return 'ki-badge-switch';
            default: return 'ki-badge-off';
        }
    }
    fmtWhen(iso) {
        if (!iso)
            return '';
        const d = new Date(iso);
        if (isNaN(d.getTime()))
            return iso;
        return d.toLocaleString([], {
            year: 'numeric', month: '2-digit', day: '2-digit',
            hour: '2-digit', minute: '2-digit',
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ModeEventsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ModeEventsComponent, isStandalone: true, selector: "ki-mode-events", inputs: { labels: "labels", autoRefreshSec: "autoRefreshSec" }, ngImport: i0, template: `
    <div class="ki-me">
      <div class="ki-header">
        <div>
          <h4 class="ki-title">{{ L.title }}</h4>
          <p class="ki-subtitle">{{ L.subtitle }}</p>
        </div>
        <button (click)="reload()" class="ki-btn-refresh" title="Neu laden">↻</button>
      </div>

      <p *ngIf="loading()" class="ki-muted">{{ L.loading }}</p>

      <ng-container *ngIf="!loading()">
        <p *ngIf="modeEvents().length === 0" class="ki-empty">{{ L.empty }}</p>

        <ng-container *ngIf="modeEvents().length > 0">
          <input
            class="ki-filter"
            type="text"
            [placeholder]="L.filterPlaceholder"
            [value]="filter()"
            (input)="setFilter($any($event.target).value)" />

          <div class="ki-timeline">
            <div class="ki-event ki-event-head">
              <span class="ki-badge-head">{{ L.colType }}</span>
              <span class="ki-transition">{{ L.colTransition }}</span>
              <span class="ki-reason">{{ L.colReason }}</span>
              <span class="ki-when">{{ L.colWhen }}</span>
            </div>
            <div *ngFor="let e of filteredEvents()" class="ki-event">
              <span class="ki-badge" [class]="badgeClass(e.type)">{{ e.type }}</span>
              <span class="ki-mono ki-transition">{{ e.fromModel || '—' }} → {{ e.toModel || '—' }}</span>
              <span class="ki-tiny ki-reason">{{ e.reason || '' }}</span>
              <span class="ki-tiny ki-when">{{ fmtWhen(e.occurredAt) }}</span>
            </div>
          </div>
        </ng-container>
      </ng-container>
    </div>
  `, isInline: true, styles: [".ki-me{font-family:inherit}.ki-header{display:flex;justify-content:space-between;align-items:flex-start;gap:1rem;margin-bottom:.75rem}.ki-title{font-size:.7rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#1e293b;margin:0 0 .2rem}.ki-subtitle{font-size:.7rem;color:#64748b;margin:0}.ki-btn-refresh{padding:.35rem .6rem;background:#e0e7ff;color:#3730a3;border:none;border-radius:.375rem;font-size:.8rem;cursor:pointer}.ki-filter{width:100%;box-sizing:border-box;padding:.4rem .6rem;margin-bottom:.5rem;border:1px solid #e2e8f0;border-radius:.375rem;font-size:.8rem}.ki-muted{color:#94a3b8;font-size:.8rem}.ki-mono{font-family:ui-monospace,monospace}.ki-tiny{font-size:.7rem}.ki-empty{text-align:center;padding:1.25rem;color:#94a3b8;font-size:.8rem}.ki-timeline{background:#f8fafc;border:1px solid #e2e8f0;border-radius:.75rem;padding:.5rem .85rem}.ki-event{display:flex;align-items:center;gap:.6rem;padding:.35rem 0;border-bottom:1px solid #eef2f7;font-size:.72rem}.ki-event:last-child{border-bottom:none}.ki-event-head{text-transform:uppercase;font-size:.6rem;font-weight:800;letter-spacing:.08em;color:#64748b;border-bottom:2px solid #e2e8f0}.ki-badge-head{flex-shrink:0;min-width:6.5rem;text-align:center;padding:.1rem .4rem}.ki-badge{flex-shrink:0;min-width:6.5rem;text-align:center;padding:.1rem .4rem;border-radius:.3rem;font-family:ui-monospace,monospace;font-size:.62rem;font-weight:700}.ki-badge-down{background:#fee2e2;color:#b91c1c}.ki-badge-up{background:#dcfce7;color:#15803d}.ki-badge-on{background:#dbeafe;color:#1d4ed8}.ki-badge-off{background:#f1f5f9;color:#475569}.ki-badge-pool{background:#ede9fe;color:#6d28d9}.ki-badge-switch{background:#e0e7ff;color:#3730a3}.ki-transition{color:#334155;flex:1}.ki-reason{color:#64748b;flex:1}.ki-when{color:#94a3b8;text-align:right;white-space:nowrap}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ModeEventsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-mode-events', standalone: true, imports: [CommonModule], template: `
    <div class="ki-me">
      <div class="ki-header">
        <div>
          <h4 class="ki-title">{{ L.title }}</h4>
          <p class="ki-subtitle">{{ L.subtitle }}</p>
        </div>
        <button (click)="reload()" class="ki-btn-refresh" title="Neu laden">↻</button>
      </div>

      <p *ngIf="loading()" class="ki-muted">{{ L.loading }}</p>

      <ng-container *ngIf="!loading()">
        <p *ngIf="modeEvents().length === 0" class="ki-empty">{{ L.empty }}</p>

        <ng-container *ngIf="modeEvents().length > 0">
          <input
            class="ki-filter"
            type="text"
            [placeholder]="L.filterPlaceholder"
            [value]="filter()"
            (input)="setFilter($any($event.target).value)" />

          <div class="ki-timeline">
            <div class="ki-event ki-event-head">
              <span class="ki-badge-head">{{ L.colType }}</span>
              <span class="ki-transition">{{ L.colTransition }}</span>
              <span class="ki-reason">{{ L.colReason }}</span>
              <span class="ki-when">{{ L.colWhen }}</span>
            </div>
            <div *ngFor="let e of filteredEvents()" class="ki-event">
              <span class="ki-badge" [class]="badgeClass(e.type)">{{ e.type }}</span>
              <span class="ki-mono ki-transition">{{ e.fromModel || '—' }} → {{ e.toModel || '—' }}</span>
              <span class="ki-tiny ki-reason">{{ e.reason || '' }}</span>
              <span class="ki-tiny ki-when">{{ fmtWhen(e.occurredAt) }}</span>
            </div>
          </div>
        </ng-container>
      </ng-container>
    </div>
  `, styles: [".ki-me{font-family:inherit}.ki-header{display:flex;justify-content:space-between;align-items:flex-start;gap:1rem;margin-bottom:.75rem}.ki-title{font-size:.7rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#1e293b;margin:0 0 .2rem}.ki-subtitle{font-size:.7rem;color:#64748b;margin:0}.ki-btn-refresh{padding:.35rem .6rem;background:#e0e7ff;color:#3730a3;border:none;border-radius:.375rem;font-size:.8rem;cursor:pointer}.ki-filter{width:100%;box-sizing:border-box;padding:.4rem .6rem;margin-bottom:.5rem;border:1px solid #e2e8f0;border-radius:.375rem;font-size:.8rem}.ki-muted{color:#94a3b8;font-size:.8rem}.ki-mono{font-family:ui-monospace,monospace}.ki-tiny{font-size:.7rem}.ki-empty{text-align:center;padding:1.25rem;color:#94a3b8;font-size:.8rem}.ki-timeline{background:#f8fafc;border:1px solid #e2e8f0;border-radius:.75rem;padding:.5rem .85rem}.ki-event{display:flex;align-items:center;gap:.6rem;padding:.35rem 0;border-bottom:1px solid #eef2f7;font-size:.72rem}.ki-event:last-child{border-bottom:none}.ki-event-head{text-transform:uppercase;font-size:.6rem;font-weight:800;letter-spacing:.08em;color:#64748b;border-bottom:2px solid #e2e8f0}.ki-badge-head{flex-shrink:0;min-width:6.5rem;text-align:center;padding:.1rem .4rem}.ki-badge{flex-shrink:0;min-width:6.5rem;text-align:center;padding:.1rem .4rem;border-radius:.3rem;font-family:ui-monospace,monospace;font-size:.62rem;font-weight:700}.ki-badge-down{background:#fee2e2;color:#b91c1c}.ki-badge-up{background:#dcfce7;color:#15803d}.ki-badge-on{background:#dbeafe;color:#1d4ed8}.ki-badge-off{background:#f1f5f9;color:#475569}.ki-badge-pool{background:#ede9fe;color:#6d28d9}.ki-badge-switch{background:#e0e7ff;color:#3730a3}.ki-transition{color:#334155;flex:1}.ki-reason{color:#64748b;flex:1}.ki-when{color:#94a3b8;text-align:right;white-space:nowrap}\n"] }]
        }], propDecorators: { labels: [{
                type: Input
            }], autoRefreshSec: [{
                type: Input
            }] } });

/**
 * Default-Provider-Optionen für die Failover-Chain-Dropdowns. Wird genutzt
 * wenn der Konsument `cascadeProviderOptions` nicht setzt — ein leerer Default
 * würde den Provider-Dropdown komplett leer rendern (`validProviders()` filtert
 * gegen eine leere Liste). `validProviders()` engt diese Liste ohnehin auf die
 * Provider ein, für die wirklich Modelle existieren, also ist die volle Liste
 * hier unbedenklich. Spiegelt den Default in {@link CascadesViewComponent}.
 */
const DEFAULT_CASCADE_PROVIDER_OPTIONS = [
    { value: 'gemini', label: 'Gemini (Google)' },
    { value: 'openai', label: 'OpenAI' },
    { value: 'anthropic', label: 'Anthropic' },
    { value: 'openrouter', label: 'OpenRouter' },
    { value: 'deepseek', label: 'DeepSeek' },
    { value: 'ollama', label: 'Ollama (local)' },
    { value: 'openai_compat', label: 'Custom OpenAI-compatible' },
];
/**
 * ki-models-page — Single-Source Composer
 *
 * Renders every section in canonical order. A bare
 * `<ki-models-page></ki-models-page>` works with EduPro defaults.
 *
 * Canonical order:
 * Supermodell: supermodel-matrix (nur sichtbar wenn supermodelOn — oben damit
 *              der User die aktive Rollen-Matrix direkt beim Öffnen sieht)
 * Verwaltung: cascades-view → models-table →
 *             add-model-form → api-keys-section → privacy-settings
 * Statistiken: provider-servers → models-quality-stats →
 *              models-performance → models-cooldown-state →
 *              call-overview → failover-analytics → log-snippets →
 *              delegation-live
 */
class ModelsPageComponent {
    constructor() {
        /** Optional config bundle — all fields optional, defaults apply. */
        this.config = {};
        /** Template-Fallback für die Failover-Chain-Provider-Dropdowns. */
        this.defaultProviderOptions = DEFAULT_CASCADE_PROVIDER_OPTIONS;
        this.supermodelOn = false;
        this.localOrchestratorPending = false;
        this.supermodelDisabled = false;
        /**
         * Optionale Whitelist sichtbarer Kategorien/Cascaden — wird an
         * `<ki-models-table>` (visibleCategories) und `<ki-cascades-view>`
         * (visibleCascades) weitergereicht. `null` (Default) = alle zeigen
         * (EduPro). Der Switcher berechnet die Liste aus Pool + Supermodell-Zustand:
         * AUS → nur Pool-Kategorie, AN → nur Rollen-Kategorien des aktiven Pools.
         */
        this.visibleCategories = null;
        /**
         * Wenn `true`, filtert `<ki-add-model-form>` seine Kategorie-Auswahl gemäß
         * {@link supermodelOn}: AN-Modus zeigt nur Rollen-Areas, AUS-Modus zeigt nur
         * die übrigen Areas. Default `false` behält das EduPro-Verhalten (kein Filter).
         * Der Switcher-Konsument setzt das auf `true`.
         */
        this.addModelFilterEnabled = false;
        // ── Re-emitted outputs ─────────────────────────────────────────────
        this.modelChanged = new EventEmitter();
        this.activeModelChanged = new EventEmitter();
        this.modelCreated = new EventEmitter();
        this.keyChanged = new EventEmitter();
    }
    // ── Internal event handlers ────────────────────────────────────────
    onModelChanged(model) {
        this.modelChanged.emit(model);
    }
    onActiveModelChanged(model) {
        this.activeModelChanged.emit(model);
    }
    onModelCreated(model) {
        this.modelsTable?.reload();
        this.modelCreated.emit(model);
    }
    onKeyChanged(key) {
        this.modelsTable?.reload();
        this.keyChanged.emit(key);
    }
    onCascadeChanged() {
        // no-op at page level; cascade changes are handled internally
    }
    onServersChanged() {
        // servers changed — table may need refresh
        this.modelsTable?.reload();
    }
    /** Public reload — host can call after pool/config changes. */
    reload() {
        this.modelsTable?.reload();
        this.cascadesView?.reload();
        this.supermodelMatrix?.reload();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ModelsPageComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ModelsPageComponent, isStandalone: true, selector: "ki-models-page", inputs: { config: "config", activePool: "activePool", supermodelOn: "supermodelOn", localOrchestratorPending: "localOrchestratorPending", supermodelDisabled: "supermodelDisabled", supermodelDisabledHint: "supermodelDisabledHint", supermodelPools: "supermodelPools", supermodelRoles: "supermodelRoles", supermodelLabels: "supermodelLabels", visibleCategories: "visibleCategories", addModelFilterEnabled: "addModelFilterEnabled" }, outputs: { modelChanged: "modelChanged", activeModelChanged: "activeModelChanged", modelCreated: "modelCreated", keyChanged: "keyChanged" }, viewQueries: [{ propertyName: "modelsTable", first: true, predicate: ModelsTableComponent, descendants: true }, { propertyName: "cascadesView", first: true, predicate: CascadesViewComponent, descendants: true }, { propertyName: "supermodelMatrix", first: true, predicate: SupermodelMatrixComponent, descendants: true }], ngImport: i0, template: `
    <!-- ── Supermodell (oben — nur sichtbar wenn aktiv) ─────────────── -->

    <section class="ki-card" *ngIf="supermodelOn">
      <ki-supermodel-matrix
        [pools]="supermodelPools ?? ['cloud', 'free', 'local']"
        [roles]="supermodelRoles ?? ['orchestrator', 'implement', 'review', 'research', 'dispatch']"
        [activePool]="activePool"
        [supermodelOn]="supermodelOn"
        [localOrchestratorPending]="localOrchestratorPending"
        [disabled]="supermodelDisabled"
        [disabledHint]="supermodelDisabledHint ?? 'Supermodell — demnächst verfügbar'"
        [labels]="supermodelLabels">
      </ki-supermodel-matrix>
    </section>

    <!-- ── Verwaltung ─────────────────────────────────────────────────── -->

    <section class="ki-card">
      <ki-cascades-view
        [labels]="config.cascadesViewLabels"
        [chainLabels]="config.cascadeChainLabels"
        [hintByCascade]="config.cascadeHints ?? {}"
        [providerOptions]="config.cascadeProviderOptions ?? defaultProviderOptions"
        [visibleCascades]="visibleCategories"
        (cascadeChanged)="onCascadeChanged()">
      </ki-cascades-view>
    </section>

    <section class="ki-card">
      <ki-models-table
        [labels]="config.modelsTableLabels"
        [showActiveAction]="config.showActiveAction ?? false"
        [activeModelId]="config.activeModelId ?? null"
        [categoryTitles]="config.categoryTitles ?? {}"
        [categoryHints]="config.categoryHints ?? {}"
        [categoryOrder]="config.categoryOrder ?? []"
        [keylessProviders]="config.keylessProviders ?? []"
        [visibleCategories]="visibleCategories"
        (modelChanged)="onModelChanged($event)"
        (activeModelChanged)="onActiveModelChanged($event)">
      </ki-models-table>
    </section>

    <section class="ki-card">
      <ki-add-model-form
        [labels]="config.addModelFormLabels"
        [defaultCategoryByProvider]="config.defaultCategoryByProvider ?? {}"
        [supermodelOn]="addModelFilterEnabled ? supermodelOn : undefined"
        (modelCreated)="onModelCreated($event)">
      </ki-add-model-form>
    </section>

    <section class="ki-card">
      <ki-api-keys-section
        [labels]="config.apiKeysSectionLabels"
        (keyChanged)="onKeyChanged($event)">
      </ki-api-keys-section>
    </section>

    <section class="ki-card">
      <ki-privacy-settings
        [title]="config.privacyTitle ?? 'Datenschutz'"
        [subtitle]="config.privacySubtitle ?? 'Speichert pro Delegations-Call einen gekürzten Prompt-Ausschnitt (max. 160 Zeichen) — nur für Debug/Live-Watch. Standard: AUS (Datenschutz).'">
      </ki-privacy-settings>
    </section>

    <!-- ── Statistiken ────────────────────────────────────────────────── -->

    <section class="ki-card">
      <ki-provider-servers
        [labels]="config.providerServersLabels"
        (serversChanged)="onServersChanged()">
      </ki-provider-servers>
    </section>

    <section class="ki-card">
      <ki-models-quality-stats
        [title]="config.qualityTitle ?? 'KI-Qualität — Stats der letzten 30 Tage'"
        [subtitle]="config.qualitySubtitle ?? 'Schlechte Modelle stehen oben. KILL-Kandidaten sollten deaktiviert werden.'">
      </ki-models-quality-stats>
    </section>

    <section class="ki-card">
      <ki-models-performance
        [title]="config.performanceTitle ?? 'LLM-Performance — letzte 30 Tage'"
        [subtitle]="config.performanceSubtitle ?? 'Calls + Erfolg + Cost pro Provider/Modell.'"
        [costMapping]="config.costMapping ?? null"
        [costCurrency]="config.costCurrency ?? 'EUR'"
        [usdToEur]="config.usdToEur ?? 0.92">
      </ki-models-performance>
    </section>

    <section class="ki-card">
      <ki-models-cooldown-state
        [title]="config.cooldownTitle ?? 'Cooldown-State — pro Modell'"
        [subtitle]="config.cooldownSubtitle ?? 'Live-Status: KILLED (rot) → Cooldown (gelb) → ready (grün).'"
        [autoRefreshSec]="config.cooldownAutoRefreshSec ?? 30">
      </ki-models-cooldown-state>
    </section>

    <section class="ki-card">
      <ki-call-overview
        [labels]="config.callOverviewLabels"
        [costPerMillionTokens]="config.analyticsCostPerMillionTokens ?? 2.0">
      </ki-call-overview>
    </section>

    <section class="ki-card">
      <ki-failover-analytics
        [labels]="config.failoverAnalyticsLabels"
        [pageSize]="config.analyticsPageSize ?? 10">
      </ki-failover-analytics>
    </section>

    <section class="ki-card">
      <ki-log-snippets
        [title]="config.logSnippetsTitle ?? 'Prompt-Log'"
        [subtitle]="config.logSnippetsSubtitle ?? 'Zuletzt geloggte Prompt-Snippets. Nur befüllt, wenn Prompt-Logging AN ist und Traffic durch die Cascade lief (nicht auf dem direkten cloud+Anthropic-Pfad).'"
        [limit]="config.logSnippetsLimit ?? 50">
      </ki-log-snippets>
    </section>

    <section class="ki-card">
      <ki-delegation-live
        [title]="config.delegationTitle ?? 'Delegationen — Live'"
        [subtitle]="config.delegationSubtitle ?? 'Letzte Aufrufe der Kaskade. Auto-Refresh.'"
        [autoRefreshSec]="config.delegationAutoRefreshSec ?? 5"
        [maxRows]="config.delegationMaxRows ?? 50">
      </ki-delegation-live>
    </section>
  `, isInline: true, styles: [":host{display:block;padding:1.5rem}.ki-card{background:#fff;border:1px solid #e2e8f0;border-radius:.75rem;padding:1.5rem;margin-bottom:1.25rem;box-shadow:0 1px 3px #0000000f}.ki-card:last-child{margin-bottom:0}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: CascadesViewComponent, selector: "ki-cascades-view", inputs: ["labels", "chainLabels", "hintByCascade", "providerOptions", "visibleCascades", "poolTitles", "autoRefreshSec"], outputs: ["cascadeChanged"] }, { kind: "component", type: ModelsTableComponent, selector: "ki-models-table", inputs: ["labels", "showActiveAction", "activeModelId", "categoryTitles", "categoryHints", "categoryOrder", "visibleCategories", "poolTitles", "keylessProviders", "pageSize"], outputs: ["activeModelChanged", "modelChanged"] }, { kind: "component", type: AddModelFormComponent, selector: "ki-add-model-form", inputs: ["labels", "supermodelOn", "defaultCategoryByProvider"], outputs: ["modelCreated"] }, { kind: "component", type: ApiKeysSectionComponent, selector: "ki-api-keys-section", inputs: ["labels"], outputs: ["keyChanged"] }, { kind: "component", type: PrivacySettingsComponent, selector: "ki-privacy-settings", inputs: ["title", "subtitle"] }, { kind: "component", type: SupermodelMatrixComponent, selector: "ki-supermodel-matrix", inputs: ["pools", "roles", "activePool", "supermodelOn", "localOrchestratorPending", "disabled", "disabledHint", "labels"] }, { kind: "component", type: ProviderServersComponent, selector: "ki-provider-servers", inputs: ["labels", "pageSize"], outputs: ["serversChanged"] }, { kind: "component", type: ModelsQualityStatsComponent, selector: "ki-models-quality-stats", inputs: ["title", "subtitle", "pageSize"] }, { kind: "component", type: ModelsPerformanceComponent, selector: "ki-models-performance", inputs: ["title", "subtitle", "costMapping", "costCurrency", "usdToEur", "pageSize"] }, { kind: "component", type: ModelsCooldownStateComponent, selector: "ki-models-cooldown-state", inputs: ["title", "subtitle", "autoRefreshSec", "pageSize"] }, { kind: "component", type: CallOverviewComponent, selector: "ki-call-overview", inputs: ["labels", "trendDays", "costPerMillionTokens", "currency"] }, { kind: "component", type: FailoverAnalyticsComponent, selector: "ki-failover-analytics", inputs: ["labels", "pageSize"] }, { kind: "component", type: LogSnippetsComponent, selector: "ki-log-snippets", inputs: ["title", "subtitle", "limit"] }, { kind: "component", type: DelegationLiveComponent, selector: "ki-delegation-live", inputs: ["title", "subtitle", "autoRefreshSec", "maxRows", "pageSize"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ModelsPageComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-models-page', standalone: true, imports: [
                        CommonModule,
                        CascadesViewComponent,
                        ModelsTableComponent,
                        AddModelFormComponent,
                        ApiKeysSectionComponent,
                        PrivacySettingsComponent,
                        SupermodelMatrixComponent,
                        ProviderServersComponent,
                        ModelsQualityStatsComponent,
                        ModelsPerformanceComponent,
                        ModelsCooldownStateComponent,
                        CallOverviewComponent,
                        FailoverAnalyticsComponent,
                        LogSnippetsComponent,
                        DelegationLiveComponent,
                    ], template: `
    <!-- ── Supermodell (oben — nur sichtbar wenn aktiv) ─────────────── -->

    <section class="ki-card" *ngIf="supermodelOn">
      <ki-supermodel-matrix
        [pools]="supermodelPools ?? ['cloud', 'free', 'local']"
        [roles]="supermodelRoles ?? ['orchestrator', 'implement', 'review', 'research', 'dispatch']"
        [activePool]="activePool"
        [supermodelOn]="supermodelOn"
        [localOrchestratorPending]="localOrchestratorPending"
        [disabled]="supermodelDisabled"
        [disabledHint]="supermodelDisabledHint ?? 'Supermodell — demnächst verfügbar'"
        [labels]="supermodelLabels">
      </ki-supermodel-matrix>
    </section>

    <!-- ── Verwaltung ─────────────────────────────────────────────────── -->

    <section class="ki-card">
      <ki-cascades-view
        [labels]="config.cascadesViewLabels"
        [chainLabels]="config.cascadeChainLabels"
        [hintByCascade]="config.cascadeHints ?? {}"
        [providerOptions]="config.cascadeProviderOptions ?? defaultProviderOptions"
        [visibleCascades]="visibleCategories"
        (cascadeChanged)="onCascadeChanged()">
      </ki-cascades-view>
    </section>

    <section class="ki-card">
      <ki-models-table
        [labels]="config.modelsTableLabels"
        [showActiveAction]="config.showActiveAction ?? false"
        [activeModelId]="config.activeModelId ?? null"
        [categoryTitles]="config.categoryTitles ?? {}"
        [categoryHints]="config.categoryHints ?? {}"
        [categoryOrder]="config.categoryOrder ?? []"
        [keylessProviders]="config.keylessProviders ?? []"
        [visibleCategories]="visibleCategories"
        (modelChanged)="onModelChanged($event)"
        (activeModelChanged)="onActiveModelChanged($event)">
      </ki-models-table>
    </section>

    <section class="ki-card">
      <ki-add-model-form
        [labels]="config.addModelFormLabels"
        [defaultCategoryByProvider]="config.defaultCategoryByProvider ?? {}"
        [supermodelOn]="addModelFilterEnabled ? supermodelOn : undefined"
        (modelCreated)="onModelCreated($event)">
      </ki-add-model-form>
    </section>

    <section class="ki-card">
      <ki-api-keys-section
        [labels]="config.apiKeysSectionLabels"
        (keyChanged)="onKeyChanged($event)">
      </ki-api-keys-section>
    </section>

    <section class="ki-card">
      <ki-privacy-settings
        [title]="config.privacyTitle ?? 'Datenschutz'"
        [subtitle]="config.privacySubtitle ?? 'Speichert pro Delegations-Call einen gekürzten Prompt-Ausschnitt (max. 160 Zeichen) — nur für Debug/Live-Watch. Standard: AUS (Datenschutz).'">
      </ki-privacy-settings>
    </section>

    <!-- ── Statistiken ────────────────────────────────────────────────── -->

    <section class="ki-card">
      <ki-provider-servers
        [labels]="config.providerServersLabels"
        (serversChanged)="onServersChanged()">
      </ki-provider-servers>
    </section>

    <section class="ki-card">
      <ki-models-quality-stats
        [title]="config.qualityTitle ?? 'KI-Qualität — Stats der letzten 30 Tage'"
        [subtitle]="config.qualitySubtitle ?? 'Schlechte Modelle stehen oben. KILL-Kandidaten sollten deaktiviert werden.'">
      </ki-models-quality-stats>
    </section>

    <section class="ki-card">
      <ki-models-performance
        [title]="config.performanceTitle ?? 'LLM-Performance — letzte 30 Tage'"
        [subtitle]="config.performanceSubtitle ?? 'Calls + Erfolg + Cost pro Provider/Modell.'"
        [costMapping]="config.costMapping ?? null"
        [costCurrency]="config.costCurrency ?? 'EUR'"
        [usdToEur]="config.usdToEur ?? 0.92">
      </ki-models-performance>
    </section>

    <section class="ki-card">
      <ki-models-cooldown-state
        [title]="config.cooldownTitle ?? 'Cooldown-State — pro Modell'"
        [subtitle]="config.cooldownSubtitle ?? 'Live-Status: KILLED (rot) → Cooldown (gelb) → ready (grün).'"
        [autoRefreshSec]="config.cooldownAutoRefreshSec ?? 30">
      </ki-models-cooldown-state>
    </section>

    <section class="ki-card">
      <ki-call-overview
        [labels]="config.callOverviewLabels"
        [costPerMillionTokens]="config.analyticsCostPerMillionTokens ?? 2.0">
      </ki-call-overview>
    </section>

    <section class="ki-card">
      <ki-failover-analytics
        [labels]="config.failoverAnalyticsLabels"
        [pageSize]="config.analyticsPageSize ?? 10">
      </ki-failover-analytics>
    </section>

    <section class="ki-card">
      <ki-log-snippets
        [title]="config.logSnippetsTitle ?? 'Prompt-Log'"
        [subtitle]="config.logSnippetsSubtitle ?? 'Zuletzt geloggte Prompt-Snippets. Nur befüllt, wenn Prompt-Logging AN ist und Traffic durch die Cascade lief (nicht auf dem direkten cloud+Anthropic-Pfad).'"
        [limit]="config.logSnippetsLimit ?? 50">
      </ki-log-snippets>
    </section>

    <section class="ki-card">
      <ki-delegation-live
        [title]="config.delegationTitle ?? 'Delegationen — Live'"
        [subtitle]="config.delegationSubtitle ?? 'Letzte Aufrufe der Kaskade. Auto-Refresh.'"
        [autoRefreshSec]="config.delegationAutoRefreshSec ?? 5"
        [maxRows]="config.delegationMaxRows ?? 50">
      </ki-delegation-live>
    </section>
  `, styles: [":host{display:block;padding:1.5rem}.ki-card{background:#fff;border:1px solid #e2e8f0;border-radius:.75rem;padding:1.5rem;margin-bottom:1.25rem;box-shadow:0 1px 3px #0000000f}.ki-card:last-child{margin-bottom:0}\n"] }]
        }], propDecorators: { config: [{
                type: Input
            }], activePool: [{
                type: Input
            }], supermodelOn: [{
                type: Input
            }], localOrchestratorPending: [{
                type: Input
            }], supermodelDisabled: [{
                type: Input
            }], supermodelDisabledHint: [{
                type: Input
            }], supermodelPools: [{
                type: Input
            }], supermodelRoles: [{
                type: Input
            }], supermodelLabels: [{
                type: Input
            }], visibleCategories: [{
                type: Input
            }], addModelFilterEnabled: [{
                type: Input
            }], modelChanged: [{
                type: Output
            }], activeModelChanged: [{
                type: Output
            }], modelCreated: [{
                type: Output
            }], keyChanged: [{
                type: Output
            }], modelsTable: [{
                type: ViewChild,
                args: [ModelsTableComponent]
            }], cascadesView: [{
                type: ViewChild,
                args: [CascadesViewComponent]
            }], supermodelMatrix: [{
                type: ViewChild,
                args: [SupermodelMatrixComponent]
            }] } });

/*
 * Public API Surface of @dataclub/ki-models-ui
 *
 * Konsumenten importieren Components + Service + InjectionToken hier von:
 *   import { ModelsTableComponent, KI_MODELS_API_BASE } from '@dataclub/ki-models-ui';
 *
 * Module-Wrapper (für nicht-standalone-Apps) wird in Phase L.2 hinzugefügt.
 */
// ─── Models / Interfaces ─────────────────────────────────────────────────

/**
 * Generated bundle index. Do not edit.
 */

export { ADD_MODEL_FORM_LABELS_EN, AI_MODEL_CATEGORIES, AI_MODEL_CATEGORIES_DEFAULT_ORDER, API_KEYS_SECTION_LABELS_EN, AddModelFormComponent, ApiKeysSectionComponent, CALL_OVERVIEW_LABELS_EN, CASCADES_VIEW_LABELS_EN, CASCADE_COOLDOWN_LABELS_EN, CASCADE_MODE_PANEL_LABELS_EN, CallOverviewComponent, CascadeCooldownComponent, CascadeModePanelComponent, CascadesViewComponent, DEFAULT_CASCADE_PROVIDER_OPTIONS, DelegationLiveComponent, FAILOVER_ANALYTICS_LABELS_EN, FAILOVER_CHAIN_LABELS_EN, FailoverAnalyticsComponent, FailoverChainComponent, KI_MODELS_API_BASE, KiAreaChartComponent, KiDonutChartComponent, KiModelsApiService, KiPagerComponent, LogSnippetsComponent, MODELS_TABLE_LABELS_EN, MODE_EVENTS_LABELS_EN, ModeEventsComponent, ModelsCooldownStateComponent, ModelsPageComponent, ModelsPerformanceComponent, ModelsQualityStatsComponent, ModelsTableComponent, PROVIDER_SERVERS_LABELS_EN, PrivacySettingsComponent, ProviderServersComponent, ROUTING_DECISIONS_LABELS_EN, RoutingDecisionsComponent, SupermodelMatrixComponent, paginate };
//# sourceMappingURL=4dataclub-ki-models-ui.mjs.map
