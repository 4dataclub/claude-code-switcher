/*
 * Public API Surface of @dataclub/ki-models-ui
 *
 * Konsumenten importieren Components + Service + InjectionToken hier von:
 *   import { ModelsTableComponent, KI_MODELS_API_BASE } from '@dataclub/ki-models-ui';
 *
 * Module-Wrapper (für nicht-standalone-Apps) wird in Phase L.2 hinzugefügt.
 */
// ─── Models / Interfaces ─────────────────────────────────────────────────
export * from './lib/models/ai-model';
export * from './lib/models/api-key-setting';
export * from './lib/models/cascade-config';
export * from './lib/models/cascade';
export * from './lib/models/category';
export * from './lib/models/routing';
export * from './lib/models/quality';
export * from './lib/models/performance';
export * from './lib/models/cooldown';
export * from './lib/models/labels';
// ─── Service + InjectionToken ────────────────────────────────────────────
export * from './lib/services/ki-models-api.service';
export * from './lib/services/ki-models-api.token';
// ─── Components (standalone) ─────────────────────────────────────────────
export * from './lib/components/models-table.component';
export * from './lib/components/add-model-form.component';
export * from './lib/components/cascade-cooldown.component';
export * from './lib/components/api-keys-section.component';
export * from './lib/components/failover-chain.component';
export * from './lib/components/cascades-view.component';
export * from './lib/components/routing-decisions.component';
export * from './lib/components/models-quality-stats.component';
export * from './lib/components/cascade-mode-panel.component';
export * from './lib/components/models-performance.component';
export * from './lib/components/models-cooldown-state.component';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljLWFwaS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3Byb2plY3RzL2tpLW1vZGVscy11aS9zcmMvcHVibGljLWFwaS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7OztHQU9HO0FBRUgsNEVBQTRFO0FBQzVFLGNBQWMsdUJBQXVCLENBQUM7QUFDdEMsY0FBYyw4QkFBOEIsQ0FBQztBQUM3QyxjQUFjLDZCQUE2QixDQUFDO0FBQzVDLGNBQWMsc0JBQXNCLENBQUM7QUFDckMsY0FBYyx1QkFBdUIsQ0FBQztBQUN0QyxjQUFjLHNCQUFzQixDQUFDO0FBQ3JDLGNBQWMsc0JBQXNCLENBQUM7QUFDckMsY0FBYywwQkFBMEIsQ0FBQztBQUN6QyxjQUFjLHVCQUF1QixDQUFDO0FBQ3RDLGNBQWMscUJBQXFCLENBQUM7QUFFcEMsNEVBQTRFO0FBQzVFLGNBQWMsc0NBQXNDLENBQUM7QUFDckQsY0FBYyxvQ0FBb0MsQ0FBQztBQUVuRCw0RUFBNEU7QUFDNUUsY0FBYyx5Q0FBeUMsQ0FBQztBQUN4RCxjQUFjLDJDQUEyQyxDQUFDO0FBQzFELGNBQWMsNkNBQTZDLENBQUM7QUFDNUQsY0FBYyw2Q0FBNkMsQ0FBQztBQUM1RCxjQUFjLDJDQUEyQyxDQUFDO0FBQzFELGNBQWMsMENBQTBDLENBQUM7QUFDekQsY0FBYyw4Q0FBOEMsQ0FBQztBQUM3RCxjQUFjLGlEQUFpRCxDQUFDO0FBQ2hFLGNBQWMsK0NBQStDLENBQUM7QUFDOUQsY0FBYywrQ0FBK0MsQ0FBQztBQUM5RCxjQUFjLGtEQUFrRCxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIFB1YmxpYyBBUEkgU3VyZmFjZSBvZiBAZGF0YWNsdWIva2ktbW9kZWxzLXVpXG4gKlxuICogS29uc3VtZW50ZW4gaW1wb3J0aWVyZW4gQ29tcG9uZW50cyArIFNlcnZpY2UgKyBJbmplY3Rpb25Ub2tlbiBoaWVyIHZvbjpcbiAqICAgaW1wb3J0IHsgTW9kZWxzVGFibGVDb21wb25lbnQsIEtJX01PREVMU19BUElfQkFTRSB9IGZyb20gJ0BkYXRhY2x1Yi9raS1tb2RlbHMtdWknO1xuICpcbiAqIE1vZHVsZS1XcmFwcGVyIChmw7xyIG5pY2h0LXN0YW5kYWxvbmUtQXBwcykgd2lyZCBpbiBQaGFzZSBMLjIgaGluenVnZWbDvGd0LlxuICovXG5cbi8vIOKUgOKUgOKUgCBNb2RlbHMgLyBJbnRlcmZhY2VzIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuZXhwb3J0ICogZnJvbSAnLi9saWIvbW9kZWxzL2FpLW1vZGVsJztcbmV4cG9ydCAqIGZyb20gJy4vbGliL21vZGVscy9hcGkta2V5LXNldHRpbmcnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvbW9kZWxzL2Nhc2NhZGUtY29uZmlnJztcbmV4cG9ydCAqIGZyb20gJy4vbGliL21vZGVscy9jYXNjYWRlJztcbmV4cG9ydCAqIGZyb20gJy4vbGliL21vZGVscy9jYXRlZ29yeSc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9tb2RlbHMvcm91dGluZyc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9tb2RlbHMvcXVhbGl0eSc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9tb2RlbHMvcGVyZm9ybWFuY2UnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvbW9kZWxzL2Nvb2xkb3duJztcbmV4cG9ydCAqIGZyb20gJy4vbGliL21vZGVscy9sYWJlbHMnO1xuXG4vLyDilIDilIDilIAgU2VydmljZSArIEluamVjdGlvblRva2VuIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuZXhwb3J0ICogZnJvbSAnLi9saWIvc2VydmljZXMva2ktbW9kZWxzLWFwaS5zZXJ2aWNlJztcbmV4cG9ydCAqIGZyb20gJy4vbGliL3NlcnZpY2VzL2tpLW1vZGVscy1hcGkudG9rZW4nO1xuXG4vLyDilIDilIDilIAgQ29tcG9uZW50cyAoc3RhbmRhbG9uZSkg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5leHBvcnQgKiBmcm9tICcuL2xpYi9jb21wb25lbnRzL21vZGVscy10YWJsZS5jb21wb25lbnQnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvY29tcG9uZW50cy9hZGQtbW9kZWwtZm9ybS5jb21wb25lbnQnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvY29tcG9uZW50cy9jYXNjYWRlLWNvb2xkb3duLmNvbXBvbmVudCc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9jb21wb25lbnRzL2FwaS1rZXlzLXNlY3Rpb24uY29tcG9uZW50JztcbmV4cG9ydCAqIGZyb20gJy4vbGliL2NvbXBvbmVudHMvZmFpbG92ZXItY2hhaW4uY29tcG9uZW50JztcbmV4cG9ydCAqIGZyb20gJy4vbGliL2NvbXBvbmVudHMvY2FzY2FkZXMtdmlldy5jb21wb25lbnQnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvY29tcG9uZW50cy9yb3V0aW5nLWRlY2lzaW9ucy5jb21wb25lbnQnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvY29tcG9uZW50cy9tb2RlbHMtcXVhbGl0eS1zdGF0cy5jb21wb25lbnQnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvY29tcG9uZW50cy9jYXNjYWRlLW1vZGUtcGFuZWwuY29tcG9uZW50JztcbmV4cG9ydCAqIGZyb20gJy4vbGliL2NvbXBvbmVudHMvbW9kZWxzLXBlcmZvcm1hbmNlLmNvbXBvbmVudCc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9jb21wb25lbnRzL21vZGVscy1jb29sZG93bi1zdGF0ZS5jb21wb25lbnQnO1xuIl19