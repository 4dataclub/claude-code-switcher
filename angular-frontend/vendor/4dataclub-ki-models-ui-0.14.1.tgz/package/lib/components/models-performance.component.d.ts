import { OnInit } from '@angular/core';
import { PerformanceRow } from '../models/performance';
import * as i0 from "@angular/core";
/**
 * v0.14.0 — Performance-Tabelle pro Modell der letzten 30 Tage.
 *
 * Zeigt: provider · model · calls · success% · avg chars · est cost.
 *
 * Cost-Spalte erscheint nur wenn der Konsument ein {@link costMapping}
 * (USD pro 1M Output-Tokens pro Provider) liefert. Beispiel:
 * ```ts
 * costMapping = {
 *   gemini: 0.30,        // Gemini 2.5 Flash output
 *   anthropic: 5.00,     // Claude Sonnet/Haiku output (Approx)
 *   openrouter: 0.40,    // Avg DeepSeek/Llama free → small paid
 *   openai: 2.00,
 *   ollama: 0,           // lokal = kostenlos
 * }
 * ```
 *
 * Konsumenten-Use-Case:
 * - EduPro: ersetzt die alte `/admin/stats/llm-performance`-Tabelle im
 *   Operations-Tab
 * - Switcher: kann embedded werden in der Stats-Section (optional)
 */
export declare class ModelsPerformanceComponent implements OnInit {
    private readonly api;
    title: string;
    subtitle: string;
    /**
     * USD pro 1M Output-Tokens pro Provider. Konsument liefert sein Mapping.
     * Wenn leer/unset: Cost-Spalte wird ausgeblendet.
     *
     * Beispiel: `{ gemini: 0.30, anthropic: 5.00, openrouter: 0.40 }`.
     */
    costMapping: Record<string, number> | null;
    /** Token-Schätzung: ~4 chars pro Token. */
    private readonly CHARS_PER_TOKEN;
    /** Währungs-Label hinter dem Cost-Wert. Default USD. */
    costCurrency: 'USD' | 'EUR';
    /** USD → EUR Konvertierungs-Faktor (Default Stand 2026). */
    usdToEur: number;
    sortBy: 'calls-desc' | 'success-desc' | 'chars-desc';
    readonly rows: import("@angular/core").WritableSignal<PerformanceRow[]>;
    readonly loading: import("@angular/core").WritableSignal<boolean>;
    get hasCost(): boolean;
    get costNote(): string;
    ngOnInit(): void;
    reload(): void;
    /**
     * Cost-Schätzung pro Zeile: `(totalChars / CHARS_PER_TOKEN) * (price / 1M)`
     * → USD, dann optional EUR-Konvertierung.
     */
    estCost(r: PerformanceRow): number;
    successClass(rate: number): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ModelsPerformanceComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ModelsPerformanceComponent, "ki-models-performance", never, { "title": { "alias": "title"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "costMapping": { "alias": "costMapping"; "required": false; }; "costCurrency": { "alias": "costCurrency"; "required": false; }; "usdToEur": { "alias": "usdToEur"; "required": false; }; }, {}, never, never, true, never>;
}
