/*
 * Public API Surface of @dataclub/ki-models-ui
 *
 * Konsumenten importieren Components + Service + InjectionToken hier von:
 *   import { ModelsTableComponent, KI_MODELS_API_BASE } from '@dataclub/ki-models-ui';
 *
 * Module-Wrapper (für nicht-standalone-Apps) wird in Phase L.2 hinzugefügt.
 */
// ─── Models / Interfaces ─────────────────────────────────────────────────
export * from './lib/models/ai-model';
export * from './lib/models/api-key-setting';
export * from './lib/models/cascade-config';
export * from './lib/models/cascade';
export * from './lib/models/category';
export * from './lib/models/routing';
export * from './lib/models/labels';
// ─── Service + InjectionToken ────────────────────────────────────────────
export * from './lib/services/ki-models-api.service';
export * from './lib/services/ki-models-api.token';
// ─── Components (standalone) ─────────────────────────────────────────────
export * from './lib/components/models-table.component';
export * from './lib/components/add-model-form.component';
export * from './lib/components/cascade-cooldown.component';
export * from './lib/components/api-keys-section.component';
export * from './lib/components/failover-chain.component';
export * from './lib/components/cascades-view.component';
export * from './lib/components/routing-decisions.component';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljLWFwaS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3Byb2plY3RzL2tpLW1vZGVscy11aS9zcmMvcHVibGljLWFwaS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7Ozs7OztHQU9HO0FBRUgsNEVBQTRFO0FBQzVFLGNBQWMsdUJBQXVCLENBQUM7QUFDdEMsY0FBYyw4QkFBOEIsQ0FBQztBQUM3QyxjQUFjLDZCQUE2QixDQUFDO0FBQzVDLGNBQWMsc0JBQXNCLENBQUM7QUFDckMsY0FBYyx1QkFBdUIsQ0FBQztBQUN0QyxjQUFjLHNCQUFzQixDQUFDO0FBQ3JDLGNBQWMscUJBQXFCLENBQUM7QUFFcEMsNEVBQTRFO0FBQzVFLGNBQWMsc0NBQXNDLENBQUM7QUFDckQsY0FBYyxvQ0FBb0MsQ0FBQztBQUVuRCw0RUFBNEU7QUFDNUUsY0FBYyx5Q0FBeUMsQ0FBQztBQUN4RCxjQUFjLDJDQUEyQyxDQUFDO0FBQzFELGNBQWMsNkNBQTZDLENBQUM7QUFDNUQsY0FBYyw2Q0FBNkMsQ0FBQztBQUM1RCxjQUFjLDJDQUEyQyxDQUFDO0FBQzFELGNBQWMsMENBQTBDLENBQUM7QUFDekQsY0FBYyw4Q0FBOEMsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBQdWJsaWMgQVBJIFN1cmZhY2Ugb2YgQGRhdGFjbHViL2tpLW1vZGVscy11aVxuICpcbiAqIEtvbnN1bWVudGVuIGltcG9ydGllcmVuIENvbXBvbmVudHMgKyBTZXJ2aWNlICsgSW5qZWN0aW9uVG9rZW4gaGllciB2b246XG4gKiAgIGltcG9ydCB7IE1vZGVsc1RhYmxlQ29tcG9uZW50LCBLSV9NT0RFTFNfQVBJX0JBU0UgfSBmcm9tICdAZGF0YWNsdWIva2ktbW9kZWxzLXVpJztcbiAqXG4gKiBNb2R1bGUtV3JhcHBlciAoZsO8ciBuaWNodC1zdGFuZGFsb25lLUFwcHMpIHdpcmQgaW4gUGhhc2UgTC4yIGhpbnp1Z2Vmw7xndC5cbiAqL1xuXG4vLyDilIDilIDilIAgTW9kZWxzIC8gSW50ZXJmYWNlcyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmV4cG9ydCAqIGZyb20gJy4vbGliL21vZGVscy9haS1tb2RlbCc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9tb2RlbHMvYXBpLWtleS1zZXR0aW5nJztcbmV4cG9ydCAqIGZyb20gJy4vbGliL21vZGVscy9jYXNjYWRlLWNvbmZpZyc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9tb2RlbHMvY2FzY2FkZSc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9tb2RlbHMvY2F0ZWdvcnknO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvbW9kZWxzL3JvdXRpbmcnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvbW9kZWxzL2xhYmVscyc7XG5cbi8vIOKUgOKUgOKUgCBTZXJ2aWNlICsgSW5qZWN0aW9uVG9rZW4g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5leHBvcnQgKiBmcm9tICcuL2xpYi9zZXJ2aWNlcy9raS1tb2RlbHMtYXBpLnNlcnZpY2UnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvc2VydmljZXMva2ktbW9kZWxzLWFwaS50b2tlbic7XG5cbi8vIOKUgOKUgOKUgCBDb21wb25lbnRzIChzdGFuZGFsb25lKSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmV4cG9ydCAqIGZyb20gJy4vbGliL2NvbXBvbmVudHMvbW9kZWxzLXRhYmxlLmNvbXBvbmVudCc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9jb21wb25lbnRzL2FkZC1tb2RlbC1mb3JtLmNvbXBvbmVudCc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9jb21wb25lbnRzL2Nhc2NhZGUtY29vbGRvd24uY29tcG9uZW50JztcbmV4cG9ydCAqIGZyb20gJy4vbGliL2NvbXBvbmVudHMvYXBpLWtleXMtc2VjdGlvbi5jb21wb25lbnQnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvY29tcG9uZW50cy9mYWlsb3Zlci1jaGFpbi5jb21wb25lbnQnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvY29tcG9uZW50cy9jYXNjYWRlcy12aWV3LmNvbXBvbmVudCc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9jb21wb25lbnRzL3JvdXRpbmctZGVjaXNpb25zLmNvbXBvbmVudCc7XG4iXX0=