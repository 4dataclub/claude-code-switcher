import * as i0 from '@angular/core';
import { InjectionToken, inject, Injectable, EventEmitter, signal, computed, Input, Output, Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, firstValueFrom } from 'rxjs';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i2 from '@angular/forms';
import { FormsModule } from '@angular/forms';

/**
 * Well-known Kategorien-IDs als Convenience-Konstanten — KEIN Enum.
 * Konsumenten dürfen jeden String nutzen, der dem Identifier-Format genügt.
 * Diese Liste wird intern nur noch als Default-Order verwendet, falls der
 * Konsument keinen `[categoryOrder]`-Input liefert UND Modelle exakt diese
 * Kategorien haben (rückwärtskompatibel zu v0.9.x EduPro-Setup).
 */
const AI_MODEL_CATEGORIES_DEFAULT_ORDER = ['utility', 'content', 'general'];
/** @deprecated Seit v0.10.0 — siehe {@link AI_MODEL_CATEGORIES_DEFAULT_ORDER}. */
const AI_MODEL_CATEGORIES = AI_MODEL_CATEGORIES_DEFAULT_ORDER;

/**
 * Semantic-Routing-Modelle (Phase v0.11.0 — passend zu llm-cascade ≥ 0.6.0).
 *
 * Konzept: Caller schickt einen freien Task-Beschreibungs-String (`purpose`)
 * mit `POST /generate` statt einer hardcoded `category`. llm-cascade laesst
 * einen Mini-LLM-Call entscheiden welche der in `category_meta` gepflegten
 * Kategorien am besten passt. Ergebnis wird gecached (in-mem LRU, 24h TTL).
 *
 * Das Admin-UI nutzt diese Endpoints zur Cache-Inspection + manueller
 * Steuerung + Test-Preview (purpose-String eintippen, sehen welche Kategorie
 * gewaehlt wird, ohne den eigentlichen Generate-Call durchzufuehren).
 */

/**
 * v0.7.1 — Quality-Stats pro Modell (siehe llm-cascade ≥ 0.7.2).
 *
 * Wird vom Endpoint `GET {base}/stats/quality?sortBy=worst-first` als
 * Liste geliefert. Default-Sortierung „worst-first" weil Admin
 * Probleme sehen will, nicht die laufenden Top-Modelle.
 */

/**
 * Label-Maps für i18n-Override.
 *
 * Konsumenten (EduPro mit i18n-Pipe, Switcher mit eigenen Strings) übergeben
 * via `<ki-… [labels]="myLabels">` ihre eigenen Strings. Library nutzt sensible
 * englische Defaults wenn nichts überschrieben wird.
 */
const MODELS_TABLE_LABELS_EN = {
    refresh: 'Refresh',
    loading: 'Loading models…',
    empty: 'No models configured. Use the form below to add one.',
    colNum: '#',
    colProvider: 'Provider',
    colModelId: 'Model ID',
    colKey: 'Key',
    colEnabled: 'Enabled',
    colStatus: 'Status',
    colCategory: 'Category',
    colActions: 'Actions',
    keySet: 'Key set',
    keyMissing: 'Key missing',
    keyless: 'Local',
    on: 'ON',
    off: 'OFF',
    autoDisabled: 'Auto-disabled',
    free: 'Free',
    toggleNeedsKey: 'Key required before enabling',
    btnTest: 'Test',
    btnReenable: 'Re-enable',
    btnDelete: 'Delete',
    btnSetActive: 'Use now',
    activeBadge: 'ACTIVE',
    categoryUtility: 'Utility',
    categoryContent: 'Content',
    categoryGeneral: 'General (fallback)',
    categoryUtilityHint: 'Translations, audits, verifier — cheap/free models preferred.',
    categoryContentHint: 'Lesson content, exams, chat — quality matters.',
    categoryGeneralHint: 'Used in both cascades when category-specific models are exhausted.',
    confirmDelete: (id) => `Delete model "${id}"?`,
};
const ADD_MODEL_FORM_LABELS_EN = {
    title: 'Add Model',
    fieldModelId: 'Model ID (e.g. gemini-2.5-flash)',
    fieldApiKeySettingKey: 'API-Key Setting',
    fieldDisplayName: 'Display Name (optional)',
    fieldCategory: 'Category',
    fieldCooldownOverride: 'Cooldown 503 override (sec, optional)',
    btnAdd: 'Add Model',
    btnAdding: 'Adding…',
    hint: 'The API key setting holds the actual key value — it lives in the API-Keys section below. Multiple models may share the same setting key. Category routes the request: utility for translations/audits, content for lessons/exams, general for both.',
    errorRequired: 'Provider, Model ID and Setting Key are required',
    errorFailed: 'Failed to add model',
    providerOptions: [
        { value: 'gemini', label: 'Gemini (Google)' },
        { value: 'openai', label: 'OpenAI (api.openai.com)' },
        { value: 'anthropic', label: 'Anthropic (Claude)' },
        { value: 'openrouter', label: 'OpenRouter' },
        { value: 'deepseek', label: 'DeepSeek (api.deepseek.com)' },
        { value: 'ollama', label: 'Ollama (local)' },
        { value: 'openai_compat', label: 'Custom (self-hosted OpenAI API)' },
    ],
    categoryOptions: [
        { value: 'utility', label: 'Utility — translations, audits, verifier' },
        { value: 'content', label: 'Content — lessons, exams, chat' },
        { value: 'general', label: 'General — fallback for both' },
    ],
};
const CASCADE_COOLDOWN_LABELS_EN = {
    title: 'Cascade Cooldown',
    subtitle: 'Override the per-model cooldown behaviour globally.',
    default: 'Default',
    forceOn: 'Force ON',
    forceOff: 'Force OFF',
    effectiveOn: 'Effective: ON',
    effectiveOff: 'Effective: OFF',
    hint: 'Default = each model decides for itself. Force ON keeps cooldowns even when a model would skip them. Force OFF removes all cooldowns globally — use with care, useful for testing.',
    loading: 'Loading cascade config…',
    errorLoad: 'Failed to load cascade config.',
};
const API_KEYS_SECTION_LABELS_EN = {
    title: 'API Keys',
    subtitle: 'One value per setting-key. Multiple models referencing the same setting-key share the credential.',
    fieldSettingKey: 'Setting Key',
    fieldValue: 'Key value (empty to clear)',
    btnShow: 'Show',
    btnHide: 'Hide',
    btnSave: 'Save Key',
    btnSaving: 'Saving…',
    listTitle: 'Configured Keys',
    colSettingKey: 'Setting Key',
    colSource: 'Source',
    colValue: 'Value',
    colActions: 'Actions',
    sourceDb: 'DB (admin)',
    sourceEnv: 'ENV (boot)',
    sourceMissing: 'missing',
    btnEdit: 'Edit',
    btnClear: 'Clear',
    empty: 'No keys configured yet. Use the form above to add one.',
    hint: "Keys are stored in the consumer's settings table and never echoed to clients in plain text. The value is only used server-side to authenticate model calls.",
    confirmClear: (k) => `Clear DB-stored value for "${k}"? (Env fallback may still apply.)`,
};
const CASCADES_VIEW_LABELS_EN = {
    loading: 'Loading cascade areas…',
    empty: 'No cascade areas configured yet.',
    emptyHint: 'Add at least one model with a category to see it as a cascade card here.',
    defaultHint: 'Independent failover chain — own cooldown timer + sticky pointer.',
    cooldownTitle: 'Cooldown status',
    statusFree: 'free',
    statusCooldown: 'cooldown',
    editHintTooltip: 'Click to edit description',
    editHintPlaceholder: 'Describe what this cascade is for (e.g. "Premium tier — paid models, own cooldown")…',
    editHintSave: 'Save',
    editHintCancel: 'Cancel',
    deleteMetaTooltip: 'Delete display texts (models stay)',
    deleteMetaConfirm: (title) => `Delete display texts for "${title}"? Models stay; remove them in the Models table to make the cascade disappear entirely.`,
    editTitleTooltip: 'Click to edit display name',
    editTitlePlaceholder: 'Display name (e.g. "Free Only — Rate-Limited")…',
};
const FAILOVER_CHAIN_LABELS_EN = {
    title: 'Failover Chain',
    description: 'Order in which models are tried when one hits a quota / 503.',
    addRow: 'Add stage',
    removeRowTitle: 'Remove',
    moveUpTitle: 'Move up',
    moveDownTitle: 'Move down',
    currentStep: 'Current stage:',
    positionLabel: (pos, provider, model) => `Stage ${pos + 1} (${provider} · ${model})`,
    promote: '↶ Back to stage 1',
    hint: 'On quota error, the wrapper switches to the next stage and restarts.',
    emptyState: 'No stages configured. Add one to start.',
};
const ROUTING_DECISIONS_LABELS_EN = {
    title: 'Semantic Routing Cache',
    subtitle: 'Recent task-description → category routing decisions. Cached 24h.',
    statSize: 'Cached',
    statHits: 'Hits',
    statMisses: 'Misses',
    statFailures: 'Fallbacks',
    testLabel: 'Test a task description',
    testPlaceholder: 'e.g. "translate German i18n keys to English"',
    btnTest: 'Route it',
    testing: 'Routing…',
    entriesTitle: 'Cache entries',
    btnClearAll: 'Clear all',
    btnClearOne: 'Remove entry',
    loading: 'Loading…',
    empty: 'No routing decisions cached yet. Test one above, or wait for a real `purpose`-call.',
    colPurpose: 'Task description',
    colCategory: 'Chosen category',
    colExpires: 'Expires in',
    colActions: 'Actions',
    confirmClearAll: 'Clear the entire routing cache? All future requests will be re-routed.',
};

/**
 * Base-URL für die KI-Modell-Admin-API.
 *
 * Konsumenten konfigurieren das per `providers`:
 * ```ts
 * { provide: KI_MODELS_API_BASE, useValue: '/api/admin' }   // EduPro
 * { provide: KI_MODELS_API_BASE, useValue: '/api' }         // Switcher
 * ```
 *
 * Die Library hängt an die Base relative Pfade: `/ai-models`, `/api-keys`,
 * `/cascade-config`. Konsumenten müssen sicherstellen dass die Endpoints
 * dem in [`api-contract.md`](../../examples/api-contract.md) dokumentierten
 * Vertrag entsprechen.
 */
const KI_MODELS_API_BASE = new InjectionToken('KI_MODELS_API_BASE');

/**
 * Library-API-Service. Spricht alle KI-Modell-/API-Key-/Cascade-Endpoints
 * gegen die vom Konsumenten konfigurierte Base-URL (siehe `KI_MODELS_API_BASE`).
 *
 * **Vertrag:** Konsumentenseitige Endpoints müssen folgenden Pfaden entsprechen:
 *
 * ```
 * GET    {base}/ai-models                   → AiModel[]
 * POST   {base}/ai-models                   → AiModel
 * PUT    {base}/ai-models/{id}              → AiModel
 * DELETE {base}/ai-models/{id}              → { ok: true }
 * POST   {base}/ai-models/{id}/test         → { ok, latencyMs, error? }
 * POST   {base}/ai-models/reorder           → { ok: true }                body: { orderedIds }
 * POST   {base}/ai-models/{id}/toggle       → { id, ok, enabled }         body: { enabled }
 * GET    {base}/api-keys                    → ApiKeySetting[]
 * POST   {base}/api-keys/setting/{key}      → { ok: true }                body: { value }
 * GET    {base}/cascade-config              → CascadeConfig
 * PUT    {base}/cascade-config              → CascadeConfig
 * ```
 *
 * Backend-API-Drift zwischen EduPro und Switcher: jeder Konsument kann diesen
 * Service per Inheritance/Wrapper überschreiben oder via Subclass-Provider
 * austauschen, falls nötig.
 */
class KiModelsApiService {
    constructor() {
        this.http = inject(HttpClient);
        this.base = inject(KI_MODELS_API_BASE);
    }
    // ─── Models ──────────────────────────────────────────────────────────────
    listModels() {
        return this.http.get(`${this.base}/ai-models`);
    }
    createModel(body) {
        return this.http.post(`${this.base}/ai-models`, body);
    }
    updateModel(id, body) {
        return this.http.put(`${this.base}/ai-models/${id}`, body);
    }
    deleteModel(id) {
        return this.http.delete(`${this.base}/ai-models/${id}`);
    }
    /**
     * `skipped: true` zeigt an, dass das Konsument-Backend den Test bewusst
     * übersprungen hat (z.B. Switcher beim Anthropic-Modell ohne API-Key, weil
     * Max-OAuth den Live-Switch erlaubt aber kein API-Test möglich ist). Die
     * Tabelle deaktiviert das Modell in dem Fall NICHT auto.
     */
    testModel(id) {
        return this.http.post(`${this.base}/ai-models/${id}/test`, {});
    }
    reorderModels(orderedIds) {
        return this.http.post(`${this.base}/ai-models/reorder`, { orderedIds });
    }
    toggleModel(id, enabled) {
        return this.http.post(`${this.base}/ai-models/${id}/toggle`, { enabled });
    }
    // ─── API-Keys ────────────────────────────────────────────────────────────
    /**
     * Listet alle API-Key-Settings.
     *
     * Akzeptiert zwei Backend-Response-Shapes:
     * - **Array** (`ApiKeySetting[]`) — was die Library als Vertrag definiert
     *   (Switcher liefert das direkt unter `/cascade-settings`).
     * - **Object mit `settings`-Map** — was EduPros bestehender Endpoint
     *   `/admin/api-keys` liefert (`{settings: {key: {keyMasked, keySource, …}}}`).
     *
     * Bei Object-Form werden die Entries in das Array-Format gemapped, damit
     * die Components homogen mit `ApiKeySetting`-Items arbeiten. Pro Konsument
     * brauchen wir so keinen eigenen Adapter — die Library normalisiert selbst.
     */
    listKeys() {
        return this.http.get(`${this.base}/api-keys`).pipe(map((resp) => {
            if (Array.isArray(resp))
                return resp;
            // EduPro-Shape: { settings: { <key>: { keyMasked, keySource, keyConfigured, envVar, isDefault } } }
            if (resp && typeof resp === 'object' && resp.settings && typeof resp.settings === 'object') {
                return Object.entries(resp.settings).map(([settingKey, v]) => ({
                    settingKey,
                    valueMasked: v?.keyMasked ?? '',
                    configured: !!v?.keyConfigured,
                    keySource: v?.keySource ?? null,
                    envVar: v?.envVar ?? null,
                    isDefault: !!v?.isDefault,
                }));
            }
            return [];
        }));
    }
    setKey(settingKey, body) {
        return this.http.post(`${this.base}/api-keys/setting/${encodeURIComponent(settingKey)}`, body);
    }
    // ─── Cascades (Phase S' — Bereiche mit eigener Failover-Chain + Cooldown) ──
    /**
     * Liefert alle Cascade-Bereiche der Konsumenten-DB.
     *
     * **Vertrag**: Backend exponiert `GET {base}/cascades` → `Cascade[]`.
     * Frontend (z.B. `<ki-cascades-view>`) rendert eine Karte pro Eintrag.
     *
     * Fallback: liefert das Backend `[]` zurueck oder ist Endpoint nicht
     * verfuegbar, gibt der Wrapper-Component einen leeren Zustand — der
     * Konsument kann optional die alten 3 Default-Categories als Fallback
     * rendern.
     */
    listCascades() {
        return this.http.get(`${this.base}/cascades`);
    }
    /** Detail einer einzelnen Cascade. Selten direkt gebraucht; meistens reicht {@link #listCascades}. */
    getCascade(name) {
        return this.http.get(`${this.base}/cascades/${encodeURIComponent(name)}`);
    }
    // ─── Categories (Display-Metadaten pro Kategorie — v0.10.0) ─────────────
    /**
     * Liste aller Kategorien (Display-Metadaten). Backend vereint implizite
     * Kategorien aus `ai_model_config.category` mit persistierten
     * `category_meta`-Einträgen — Felder ohne gesetzte Metadaten kommen mit
     * `null` zurück. Wenn der Endpoint nicht existiert (Backward-Compat zu
     * llm-cascade < 0.5), liefert der Konsument `404`; das Frontend muss
     * dann selbst auf leeren Default zurückfallen.
     */
    listCategories() {
        return this.http.get(`${this.base}/categories`);
    }
    /**
     * Upsert für die Display-Metadaten einer Kategorie. Wird vom Inline-Edit
     * der Cascades-View aufgerufen. Partial-Update: Felder die nicht im Body
     * stehen werden NICHT angefasst; `null` löscht das Feld explizit.
     */
    updateCategory(name, body) {
        return this.http.put(`${this.base}/categories/${encodeURIComponent(name)}`, body);
    }
    /**
     * Löscht NUR die Metadaten-Zeile — die Kategorie selbst lebt weiter,
     * solange ein Modell sie nutzt. Nach Delete bekommt sie wieder die
     * UI-Fallbacks (capitalized name, leerer Hint).
     */
    deleteCategoryMeta(name) {
        return this.http.delete(`${this.base}/categories/${encodeURIComponent(name)}`);
    }
    // ─── Cascade-Config ──────────────────────────────────────────────────────
    getCascadeConfig() {
        return this.http.get(`${this.base}/cascade-config`);
    }
    setCascadeConfig(body) {
        return this.http.put(`${this.base}/cascade-config`, body);
    }
    // ─── Semantic Routing (Phase v0.11.0 — llm-cascade ≥ 0.6.0) ──────────────
    /**
     * Snapshot des Routing-Caches mit Counter-Stats. Wird vom
     * `<ki-routing-decisions>`-Component periodisch geladen damit der User
     * sieht welche purpose-Strings auf welche Kategorie geroutet wurden.
     */
    getRoutingCache() {
        return this.http.get(`${this.base}/routing/cache`);
    }
    /** Kompletter Cache leeren — User-Aktion im UI. */
    clearRoutingCache() {
        return this.http.delete(`${this.base}/routing/cache`);
    }
    /** Einzelnen Cache-Eintrag (per purposeHash) entfernen. */
    clearRoutingCacheEntry(purposeHash) {
        return this.http.delete(`${this.base}/routing/cache/${encodeURIComponent(purposeHash)}`);
    }
    /**
     * Test-Modus: einen purpose probe-routen ohne den eigentlichen Generate-
     * Call durchzufuehren. Cached das Ergebnis trotzdem (sodass der naechste
     * echte Call den gleichen Pfad nimmt). Praktisch um zu sehen welche
     * Kategorie der Router fuer eine bestimmte Task-Beschreibung waehlen
     * wuerde, bevor man's live ausrollt.
     */
    testRouting(purpose) {
        return this.http.post(`${this.base}/routing/test`, { purpose });
    }
    // ─── Quality-Stats (v0.7.1 — llm-cascade ≥ 0.7.2) ────────────────────────
    /**
     * Liefert Quality-Bewertung pro Modell aus den letzten 30 Tagen.
     * Default-Sortierung „worst-first": KILL-Kandidaten und schlechte Modelle
     * stehen oben, damit Admin Probleme sofort sieht.
     *
     * @param sortBy 'worst-first' (Default) | 'best-first' | 'calls-desc'
     */
    getQualityStats(sortBy = 'worst-first') {
        return this.http.get(`${this.base}/stats/quality?sortBy=${sortBy}`);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: KiModelsApiService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: KiModelsApiService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: KiModelsApiService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/**
 * Tabelle aller AI-Modelle in der Cascade-Reihenfolge.
 *
 * **Spalten:** #, Provider, Model-ID (+displayName), Key-Status, Enabled-Toggle,
 * Status (autoDisabled-Reason / Cooldown / Free), Actions (Up/Down, Test, Re-Enable,
 * Delete).
 *
 * **Events:**
 * - `(activeModelChanged)` — User klickt „Als aktiv setzen" (Switcher-Feature,
 *   wird in L.2/L.4 ergänzt wenn dem Component ein `[showActiveAction]="true"`
 *   Input mitgegeben wird). Aktuell nicht im Template (folgt L.2.1).
 * - `(modelChanged)` — emittet bei jeder mutating-Aktion (toggle/move/delete/
 *   test) damit der Konsument seine Modell-Liste neu laden kann.
 *
 * Labels sind englisch hardcoded — Konsument-spezifische Übersetzung folgt in
 * Phase L.3 via `@Input()`-Override-Pattern oder eigenem Translation-Service.
 */
class ModelsTableComponent {
    constructor() {
        this.activeModelChanged = new EventEmitter();
        this.modelChanged = new EventEmitter();
        this.L = MODELS_TABLE_LABELS_EN;
        /**
         * Aktiviert pro Modell-Zeile den „Als aktiv setzen"-Button (`btnSetActive`).
         * Default `false` — EduPro nutzt das nicht, Switcher schaltet's auf `true`.
         * Wenn das Modell bereits aktiv ist (siehe `activeModelId`), zeigt sich
         * stattdessen das AKTIV-Badge.
         */
        this.showActiveAction = false;
        /**
         * Aktive Modell-ID (`modelId`-Feld, nicht die DB-id). Wird mit jeder Zeile
         * verglichen um die AKTIV-Badge zu setzen. `null` = kein Modell aktiv.
         */
        this.activeModelId = null;
        /**
         * Anzeige-Titel pro Kategorie. Generisch seit v0.10.0 — Konsumenten reichen
         * eine Map aller Kategorien rein, die ihre Modelle nutzen. Fehlende
         * Einträge fallen auf `categoryUtility`/`categoryContent`/`categoryGeneral`
         * aus den Labels zurück (Backward-Compat zu v0.9.x), und für alles andere
         * auf den capitalized Kategorie-String selbst.
         *
         * Beispiele:
         *  - EduPro übergibt nichts → Defaults aus `MODELS_TABLE_LABELS_*` greifen.
         *  - Switcher übergibt `{ cloud: 'Cloud — Premium', 'free-only': 'Free Tier' }`.
         */
        this.categoryTitles = {};
        /** Sub-Beschreibung pro Kategorie. Selbe Fallback-Kette wie `categoryTitles`. */
        this.categoryHints = {};
        /**
         * Explizite Reihenfolge der Kategorie-Sektionen. Wenn leer (Default),
         * werden Kategorien in der Reihenfolge gezeigt, in der sie erstmals in
         * `models()` auftauchen — was wiederum der globalen `orderIdx`-Reihenfolge
         * folgt. Für deterministische UI: Konsument liefert seine Wunsch-Reihenfolge.
         */
        this.categoryOrder = [];
        /**
         * v0.11.3 — Konsumenten-spezifische Liste von Provider-Namen die keinen
         * API-Key brauchen. Zusätzlich zu dem `keyless`-Flag aus dem Backend.
         *
         * Beispiele:
         *  - Switcher: `['anthropic']` — Claude via Max-OAuth (Cookie), kein
         *    sk-ant-Key nötig. Cascade-Backend ruft anthropic nicht direkt;
         *    Wrapper handled das.
         *  - EduPro: `[]` — alle Cloud-Provider brauchen ihren Key, weil EduPro-
         *    Backend selbst HTTP-Calls an api.anthropic.com etc. macht.
         *
         * Default `[]`. Ollama ist immer keyless (vom Backend markiert), egal
         * was hier steht.
         */
        this.keylessProviders = [];
        this.api = inject(KiModelsApiService);
        this.loading = signal(true);
        this.models = signal([]);
        this.testResult = signal({});
        /**
         * Modelle gruppiert nach Kategorie. null/undefined/leer → `'general'`
         * (bleibt Default — passt zum llm-cascade-Backend, das ebenfalls auf
         * `general` fällt). Beliebige String-Kategorien werden akzeptiert.
         */
        this.modelsByCategory = computed(() => {
            const buckets = {};
            for (const m of this.models()) {
                const cat = m.category && m.category.trim() ? m.category : 'general';
                (buckets[cat] ??= []).push(m);
            }
            return buckets;
        });
        /**
         * Kategorien die mindestens 1 Modell enthalten. Reihenfolge:
         *   1. Explizit via `[categoryOrder]` — diese kommen zuerst (in der
         *      gegebenen Reihenfolge, sofern sie überhaupt Modelle enthalten).
         *   2. Alle restlichen Kategorien danach in der Reihenfolge ihres
         *      ersten Auftretens in `models()` (= globaler `orderIdx`).
         */
        this.categoriesWithModels = computed(() => {
            const by = this.modelsByCategory();
            const present = Object.keys(by);
            const seen = new Set();
            const ordered = [];
            for (const c of this.categoryOrder) {
                if (by[c]?.length && !seen.has(c)) {
                    ordered.push(c);
                    seen.add(c);
                }
            }
            for (const m of this.models()) {
                const c = m.category && m.category.trim() ? m.category : 'general';
                if (by[c]?.length && !seen.has(c)) {
                    ordered.push(c);
                    seen.add(c);
                }
            }
            for (const c of present) {
                if (!seen.has(c)) {
                    ordered.push(c);
                    seen.add(c);
                }
            }
            return ordered;
        });
    }
    /** Optionale Labels — Konsument gibt seine i18n-Strings rein. Default = englisch. */
    set labels(v) {
        this.L = { ...MODELS_TABLE_LABELS_EN, ...(v ?? {}) };
    }
    /**
     * Capitalize + Bindestrich/Underscore zu Leerzeichen — als letztes Fallback
     * für unbekannte Kategorien (z.B. `free-only` → `Free Only`, `cloud` → `Cloud`).
     * Damit sieht die UI auch ohne explizite `categoryTitles`-Map nicht roh aus.
     */
    prettifyCategory(c) {
        return c.replace(/[-_]+/g, ' ').replace(/\b\w/g, ch => ch.toUpperCase());
    }
    /**
     * Title-Lookup-Reihenfolge:
     *   1. Explizit via `[categoryTitles]`-Map (Konsumenten-Override)
     *   2. Backward-Compat zu v0.9.x: hardcoded utility/content/general aus Labels
     *   3. Capitalized Kategorie-String als Fallback
     */
    categoryTitle(c) {
        if (this.categoryTitles[c])
            return this.categoryTitles[c];
        if (c === 'utility')
            return this.L.categoryUtility;
        if (c === 'content')
            return this.L.categoryContent;
        if (c === 'general')
            return this.L.categoryGeneral;
        return this.prettifyCategory(c);
    }
    /**
     * Hint-Lookup-Reihenfolge analog `categoryTitle`. Wenn kein Hint gefunden:
     * leerer String (UI zeigt dann nur den Title).
     */
    categoryHint(c) {
        if (this.categoryHints[c])
            return this.categoryHints[c];
        if (c === 'utility')
            return this.L.categoryUtilityHint;
        if (c === 'content')
            return this.L.categoryContentHint;
        if (c === 'general')
            return this.L.categoryGeneralHint;
        return '';
    }
    ngOnInit() {
        this.reload();
    }
    reload() {
        this.loading.set(true);
        this.api.listModels().subscribe({
            next: (list) => {
                this.models.set(list);
                this.loading.set(false);
            },
            error: () => this.loading.set(false),
        });
    }
    toggle(m) {
        // v0.11.3 — keyless Modelle (Ollama, oder Konsument-Override für anthropic
        // via Max-OAuth) duerfen auch ohne keyConfigured aktiviert werden.
        if (!m.enabled && !m.keyConfigured && !this.isKeylessModel(m))
            return;
        this.api.toggleModel(m.id, !m.enabled).subscribe(() => {
            this.modelChanged.emit(m);
            this.reload();
        });
    }
    reEnable(m) {
        this.api.updateModel(m.id, { autoDisabled: false, enabled: true }).subscribe(() => {
            this.modelChanged.emit(m);
            this.reload();
        });
    }
    remove(m) {
        if (!confirm(this.L.confirmDelete(m.modelId)))
            return;
        this.api.deleteModel(m.id).subscribe(() => {
            this.modelChanged.emit(null);
            this.reload();
        });
    }
    move(idx, dir) {
        const target = idx + dir;
        if (target < 0 || target >= this.models().length)
            return;
        const ordered = [...this.models()];
        const [moved] = ordered.splice(idx, 1);
        ordered.splice(target, 0, moved);
        this.api.reorderModels(ordered.map((m) => m.id)).subscribe(() => {
            this.modelChanged.emit(moved);
            this.reload();
        });
    }
    /**
     * Move innerhalb einer Kategorie: tauscht zwei kategoriegleiche Modelle in der
     * globalen `orderIdx`-Liste. Cross-Kategorie-Swap nicht möglich (Buttons
     * sind am Ende der Kategorie disabled). Globale Reihenfolge bleibt stabil,
     * nur die zwei Positionen werden gewechselt.
     */
    moveInCategory(cat, idxInCat, dir) {
        const subset = this.modelsByCategory()[cat];
        const target = idxInCat + dir;
        if (target < 0 || target >= subset.length)
            return;
        const movedModel = subset[idxInCat];
        const swapModel = subset[target];
        const ordered = [...this.models()];
        const movedGlobalIdx = ordered.findIndex(m => m.id === movedModel.id);
        const swapGlobalIdx = ordered.findIndex(m => m.id === swapModel.id);
        if (movedGlobalIdx < 0 || swapGlobalIdx < 0)
            return;
        [ordered[movedGlobalIdx], ordered[swapGlobalIdx]] = [ordered[swapGlobalIdx], ordered[movedGlobalIdx]];
        this.api.reorderModels(ordered.map(m => m.id)).subscribe(() => {
            this.modelChanged.emit(movedModel);
            this.reload();
        });
    }
    test(m) {
        this.setTest(m.id, { pending: true });
        this.api.testModel(m.id).subscribe({
            next: (r) => {
                this.setTest(m.id, r);
                // Auto-disable nur bei *echten* Failed-Tests (Modell antwortet falsch
                // oder gar nicht). Wenn der Konsument-Backend den Test bewusst
                // übersprungen hat (`skipped: true`), ist das KEIN Grund das Modell
                // auto-zu-deaktivieren — z.B. Switcher kurzschließt den Anthropic-Test
                // wenn kein API-Key da ist, weil Max-OAuth den Live-Switch trotzdem
                // erlaubt. Das Modell ist nutzbar, nur nicht testbar.
                if (m.enabled && r.ok === false && r.skipped !== true) {
                    this.api.toggleModel(m.id, false).subscribe(() => this.reload());
                }
            },
            error: (e) => {
                this.setTest(m.id, { ok: false, error: e?.message ?? 'Error' });
                if (m.enabled)
                    this.api.toggleModel(m.id, false).subscribe(() => this.reload());
            },
        });
    }
    /**
     * „Als aktiv setzen"-Klick — emittet `activeModelChanged`. Der Konsument
     * (z.B. Switcher) entscheidet was passiert: typisch ist ein `/api/switch`
     * mit `{provider, modelId}` damit der Wrapper Claude Code mit dem neuen
     * Provider neu startet.
     */
    setActive(m) {
        this.activeModelChanged.emit(m);
    }
    /** True wenn die Zeile zum `activeModelId`-Input passt. */
    isActiveModel(m) {
        return !!this.activeModelId && m.modelId === this.activeModelId;
    }
    /**
     * v0.11.4 — true wenn das Modell als „keyless" zu rendern ist (blaues
     * "Lokal"-Badge statt "Key fehlt"/"Key set").
     *
     * Logik:
     *  1. Backend-keyless (`m.keyless===true`, z.B. Ollama lokal) → IMMER true
     *  2. Konsument-Override (`keylessProviders.includes(provider)`) + KEIN
     *     Key konfiguriert → true (Beispiel: Switcher-anthropic ohne sk-ant-Key,
     *     Wechsel läuft via Max-OAuth ohne API-Call)
     *  3. Konsument-Override + Key konfiguriert → FALSE — User hat einen Key
     *     gesetzt, also „Key set" anzeigen + Test geht (Switcher-anthropic mit
     *     sk-ant-Key → echter api.anthropic.com-Call funktioniert)
     *  4. Sonst → false (normaler Cloud-Provider mit/ohne Key)
     */
    isKeylessModel(m) {
        if (m.keyless === true)
            return true;
        return this.keylessProviders.includes(m.provider) && !m.keyConfigured;
    }
    truncate(s, n) {
        return s.length > n ? s.slice(0, n) + '…' : s;
    }
    setTest(id, r) {
        this.testResult.update((tr) => ({ ...tr, [id]: r }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ModelsTableComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ModelsTableComponent, isStandalone: true, selector: "ki-models-table", inputs: { labels: "labels", showActiveAction: "showActiveAction", activeModelId: "activeModelId", categoryTitles: "categoryTitles", categoryHints: "categoryHints", categoryOrder: "categoryOrder", keylessProviders: "keylessProviders" }, outputs: { activeModelChanged: "activeModelChanged", modelChanged: "modelChanged" }, ngImport: i0, template: `
    <div class="ki-models-table">
      <div class="ki-models-table-header">
        <button (click)="reload()" class="ki-btn-secondary">↻ {{ L.refresh }}</button>
      </div>

      <div *ngIf="loading()" class="ki-muted">{{ L.loading }}</div>

      <div *ngIf="!loading() && models().length === 0" class="ki-empty">
        {{ L.empty }}
      </div>

      <!-- Phase R: Gruppierte Ansicht nach Routing-Kategorie. Jede Section
           rendert ihre eigene Tabelle. Reorder (Pfeile) ist innerhalb einer
           Kategorie scoped — globaler orderIdx wird im Hintergrund neu
           vergeben, aber Cross-Kategorie-Swap ist nicht erlaubt. -->
      <div *ngIf="models().length > 0">
        <section *ngFor="let cat of categoriesWithModels()" class="ki-category-section">
          <header class="ki-category-header">
            <h4 class="ki-category-title">{{ categoryTitle(cat) }}</h4>
            <p class="ki-category-hint">{{ categoryHint(cat) }}</p>
          </header>

          <div class="ki-table-wrap">
            <table class="ki-table">
              <thead>
                <tr>
                  <th>{{ L.colNum }}</th>
                  <th>{{ L.colProvider }}</th>
                  <th>{{ L.colModelId }}</th>
                  <th>{{ L.colKey }}</th>
                  <th>{{ L.colEnabled }}</th>
                  <th>{{ L.colStatus }}</th>
                  <th class="ki-right">{{ L.colActions }}</th>
                </tr>
              </thead>
              <tbody>
                <tr *ngFor="let m of modelsByCategory()[cat]; let i = index"
                    [class.ki-row-auto-disabled]="m.autoDisabled">
                  <td class="ki-mono ki-muted">{{ i + 1 }}</td>
                  <td class="ki-mono ki-provider">{{ m.provider }}</td>
                  <td class="ki-mono">
                    <strong>{{ m.modelId }}</strong>
                    <div *ngIf="m.displayName" class="ki-muted ki-tiny">{{ m.displayName }}</div>
                  </td>
                  <td>
                    <span *ngIf="isKeylessModel(m)" class="ki-badge ki-badge-local">{{ L.keyless }}</span>
                    <span *ngIf="!isKeylessModel(m) && m.keyConfigured" class="ki-badge ki-badge-ok">{{ L.keySet }}</span>
                    <span *ngIf="!isKeylessModel(m) && !m.keyConfigured" class="ki-badge ki-badge-warn">{{ L.keyMissing }}</span>
                    <div class="ki-tiny ki-mono ki-muted">{{ m.apiKeySettingKey }}</div>
                  </td>
                  <td>
                    <button *ngIf="!m.autoDisabled"
                            (click)="toggle(m)"
                            [disabled]="!m.enabled && !m.keyConfigured && !isKeylessModel(m)"
                            [title]="(!m.enabled && !m.keyConfigured && !isKeylessModel(m)) ? L.toggleNeedsKey : ''"
                            class="ki-toggle"
                            [class.ki-toggle-on]="m.enabled"
                            [class.ki-toggle-off]="!m.enabled">
                      {{ m.enabled ? L.on : L.off }}
                    </button>
                    <span *ngIf="m.autoDisabled" class="ki-badge ki-badge-error">🚫 {{ L.autoDisabled }}</span>
                  </td>
                  <td>
                    <span *ngIf="m.autoDisabled" class="ki-tiny ki-error" [title]="m.autoDisabledReason || ''">
                      {{ truncate(m.autoDisabledReason || '', 60) }}
                    </span>
                    <span *ngIf="!m.autoDisabled && (m.cooldownRemainingSec ?? 0) > 0" class="ki-tiny ki-cooldown">
                      cd {{ m.cooldownRemainingSec }}s
                    </span>
                    <span *ngIf="!m.autoDisabled && !(m.cooldownRemainingSec ?? 0)" class="ki-tiny ki-ok">
                      {{ L.free }}
                    </span>
                    <div *ngIf="testResult()[m.id] as r" class="ki-tiny ki-mono"
                         [class.ki-ok]="r.ok"
                         [class.ki-error]="!r.ok && !r.pending">
                      <span *ngIf="r.pending">…</span>
                      <span *ngIf="r.ok">✓ {{ r.latencyMs }}ms</span>
                      <span *ngIf="!r.ok && !r.pending">✗ {{ truncate(r.error || '', 80) }}</span>
                    </div>
                  </td>
                  <td class="ki-right ki-actions">
                    <button (click)="moveInCategory(cat, i, -1)"
                            [disabled]="i === 0"
                            class="ki-btn-icon">↑</button>
                    <button (click)="moveInCategory(cat, i, 1)"
                            [disabled]="i === modelsByCategory()[cat].length - 1"
                            class="ki-btn-icon">↓</button>
                    <button (click)="test(m)" class="ki-btn-secondary">{{ L.btnTest }}</button>
                    <span *ngIf="showActiveAction && isActiveModel(m)" class="ki-badge ki-badge-active">{{ L.activeBadge }}</span>
                    <button
                      *ngIf="showActiveAction && !isActiveModel(m) && (m.keyConfigured || isKeylessModel(m)) && !m.autoDisabled"
                      (click)="setActive(m)"
                      class="ki-btn-primary"
                    >{{ L.btnSetActive }}</button>
                    <button *ngIf="m.autoDisabled" (click)="reEnable(m)" class="ki-btn-warn">{{ L.btnReenable }}</button>
                    <button (click)="remove(m)" class="ki-btn-danger">{{ L.btnDelete }}</button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </div>
  `, isInline: true, styles: [".ki-models-table{font-family:inherit}.ki-models-table-header{display:flex;justify-content:flex-end;margin-bottom:.75rem}.ki-category-section{margin-bottom:2rem}.ki-category-section:last-child{margin-bottom:0}.ki-category-header{margin-bottom:.5rem}.ki-category-title{font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.12em;color:#1e293b;margin:0 0 .15rem}.ki-category-hint{font-size:.7rem;color:#64748b;margin:0}.ki-muted{color:#888}.ki-tiny{font-size:.7rem}.ki-mono{font-family:ui-monospace,monospace}.ki-provider{color:#4f46e5;font-weight:700}.ki-empty{text-align:center;padding:2rem;color:#94a3b8;font-weight:600}.ki-table-wrap{overflow-x:auto}.ki-table{width:100%;border-collapse:collapse;font-size:.875rem}.ki-table thead tr{border-bottom:2px solid #e2e8f0}.ki-table th{padding:.75rem .5rem;text-align:left;text-transform:uppercase;font-size:.625rem;font-weight:800;letter-spacing:.1em;color:#64748b}.ki-table td{padding:.75rem .5rem;border-bottom:1px solid #f1f5f9;vertical-align:top}.ki-right{text-align:right}.ki-row-auto-disabled{background:#fef2f2}.ki-badge{display:inline-block;padding:.15rem .4rem;border-radius:.25rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em}.ki-badge-ok{background:#d1fae5;color:#065f46}.ki-badge-warn{background:#fee2e2;color:#991b1b}.ki-badge-local{background:#dbeafe;color:#1e40af}.ki-badge-error{background:#ef4444;color:#fff}.ki-toggle{padding:.25rem .6rem;border-radius:.375rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;border:none;cursor:pointer;transition:opacity .15s}.ki-toggle:disabled{opacity:.4;cursor:not-allowed}.ki-toggle-on{background:#10b981;color:#fff}.ki-toggle-off{background:#e2e8f0;color:#475569}.ki-actions{white-space:nowrap}.ki-actions>*{margin-left:.25rem}.ki-btn-icon,.ki-btn-secondary,.ki-btn-warn,.ki-btn-danger{padding:.25rem .6rem;border-radius:.375rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;border:none;cursor:pointer}.ki-btn-icon{background:#f1f5f9;color:#1e293b}.ki-btn-icon:disabled{opacity:.3;cursor:not-allowed}.ki-btn-secondary{background:#e0e7ff;color:#3730a3}.ki-btn-primary{background:#10b981;color:#fff}.ki-btn-warn{background:#fef3c7;color:#92400e}.ki-btn-danger{background:#fee2e2;color:#991b1b}.ki-btn-icon,.ki-btn-secondary,.ki-btn-primary,.ki-btn-warn,.ki-btn-danger{padding:.25rem .6rem;border-radius:.375rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;border:none;cursor:pointer}.ki-badge-active{background:#d1fae5;color:#065f46;border:1px solid #10b981}.ki-ok{color:#059669;font-weight:700}.ki-cooldown{color:#d97706;font-weight:700}.ki-error{color:#dc2626;font-weight:700}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ModelsTableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-models-table', standalone: true, imports: [CommonModule], template: `
    <div class="ki-models-table">
      <div class="ki-models-table-header">
        <button (click)="reload()" class="ki-btn-secondary">↻ {{ L.refresh }}</button>
      </div>

      <div *ngIf="loading()" class="ki-muted">{{ L.loading }}</div>

      <div *ngIf="!loading() && models().length === 0" class="ki-empty">
        {{ L.empty }}
      </div>

      <!-- Phase R: Gruppierte Ansicht nach Routing-Kategorie. Jede Section
           rendert ihre eigene Tabelle. Reorder (Pfeile) ist innerhalb einer
           Kategorie scoped — globaler orderIdx wird im Hintergrund neu
           vergeben, aber Cross-Kategorie-Swap ist nicht erlaubt. -->
      <div *ngIf="models().length > 0">
        <section *ngFor="let cat of categoriesWithModels()" class="ki-category-section">
          <header class="ki-category-header">
            <h4 class="ki-category-title">{{ categoryTitle(cat) }}</h4>
            <p class="ki-category-hint">{{ categoryHint(cat) }}</p>
          </header>

          <div class="ki-table-wrap">
            <table class="ki-table">
              <thead>
                <tr>
                  <th>{{ L.colNum }}</th>
                  <th>{{ L.colProvider }}</th>
                  <th>{{ L.colModelId }}</th>
                  <th>{{ L.colKey }}</th>
                  <th>{{ L.colEnabled }}</th>
                  <th>{{ L.colStatus }}</th>
                  <th class="ki-right">{{ L.colActions }}</th>
                </tr>
              </thead>
              <tbody>
                <tr *ngFor="let m of modelsByCategory()[cat]; let i = index"
                    [class.ki-row-auto-disabled]="m.autoDisabled">
                  <td class="ki-mono ki-muted">{{ i + 1 }}</td>
                  <td class="ki-mono ki-provider">{{ m.provider }}</td>
                  <td class="ki-mono">
                    <strong>{{ m.modelId }}</strong>
                    <div *ngIf="m.displayName" class="ki-muted ki-tiny">{{ m.displayName }}</div>
                  </td>
                  <td>
                    <span *ngIf="isKeylessModel(m)" class="ki-badge ki-badge-local">{{ L.keyless }}</span>
                    <span *ngIf="!isKeylessModel(m) && m.keyConfigured" class="ki-badge ki-badge-ok">{{ L.keySet }}</span>
                    <span *ngIf="!isKeylessModel(m) && !m.keyConfigured" class="ki-badge ki-badge-warn">{{ L.keyMissing }}</span>
                    <div class="ki-tiny ki-mono ki-muted">{{ m.apiKeySettingKey }}</div>
                  </td>
                  <td>
                    <button *ngIf="!m.autoDisabled"
                            (click)="toggle(m)"
                            [disabled]="!m.enabled && !m.keyConfigured && !isKeylessModel(m)"
                            [title]="(!m.enabled && !m.keyConfigured && !isKeylessModel(m)) ? L.toggleNeedsKey : ''"
                            class="ki-toggle"
                            [class.ki-toggle-on]="m.enabled"
                            [class.ki-toggle-off]="!m.enabled">
                      {{ m.enabled ? L.on : L.off }}
                    </button>
                    <span *ngIf="m.autoDisabled" class="ki-badge ki-badge-error">🚫 {{ L.autoDisabled }}</span>
                  </td>
                  <td>
                    <span *ngIf="m.autoDisabled" class="ki-tiny ki-error" [title]="m.autoDisabledReason || ''">
                      {{ truncate(m.autoDisabledReason || '', 60) }}
                    </span>
                    <span *ngIf="!m.autoDisabled && (m.cooldownRemainingSec ?? 0) > 0" class="ki-tiny ki-cooldown">
                      cd {{ m.cooldownRemainingSec }}s
                    </span>
                    <span *ngIf="!m.autoDisabled && !(m.cooldownRemainingSec ?? 0)" class="ki-tiny ki-ok">
                      {{ L.free }}
                    </span>
                    <div *ngIf="testResult()[m.id] as r" class="ki-tiny ki-mono"
                         [class.ki-ok]="r.ok"
                         [class.ki-error]="!r.ok && !r.pending">
                      <span *ngIf="r.pending">…</span>
                      <span *ngIf="r.ok">✓ {{ r.latencyMs }}ms</span>
                      <span *ngIf="!r.ok && !r.pending">✗ {{ truncate(r.error || '', 80) }}</span>
                    </div>
                  </td>
                  <td class="ki-right ki-actions">
                    <button (click)="moveInCategory(cat, i, -1)"
                            [disabled]="i === 0"
                            class="ki-btn-icon">↑</button>
                    <button (click)="moveInCategory(cat, i, 1)"
                            [disabled]="i === modelsByCategory()[cat].length - 1"
                            class="ki-btn-icon">↓</button>
                    <button (click)="test(m)" class="ki-btn-secondary">{{ L.btnTest }}</button>
                    <span *ngIf="showActiveAction && isActiveModel(m)" class="ki-badge ki-badge-active">{{ L.activeBadge }}</span>
                    <button
                      *ngIf="showActiveAction && !isActiveModel(m) && (m.keyConfigured || isKeylessModel(m)) && !m.autoDisabled"
                      (click)="setActive(m)"
                      class="ki-btn-primary"
                    >{{ L.btnSetActive }}</button>
                    <button *ngIf="m.autoDisabled" (click)="reEnable(m)" class="ki-btn-warn">{{ L.btnReenable }}</button>
                    <button (click)="remove(m)" class="ki-btn-danger">{{ L.btnDelete }}</button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </div>
  `, styles: [".ki-models-table{font-family:inherit}.ki-models-table-header{display:flex;justify-content:flex-end;margin-bottom:.75rem}.ki-category-section{margin-bottom:2rem}.ki-category-section:last-child{margin-bottom:0}.ki-category-header{margin-bottom:.5rem}.ki-category-title{font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.12em;color:#1e293b;margin:0 0 .15rem}.ki-category-hint{font-size:.7rem;color:#64748b;margin:0}.ki-muted{color:#888}.ki-tiny{font-size:.7rem}.ki-mono{font-family:ui-monospace,monospace}.ki-provider{color:#4f46e5;font-weight:700}.ki-empty{text-align:center;padding:2rem;color:#94a3b8;font-weight:600}.ki-table-wrap{overflow-x:auto}.ki-table{width:100%;border-collapse:collapse;font-size:.875rem}.ki-table thead tr{border-bottom:2px solid #e2e8f0}.ki-table th{padding:.75rem .5rem;text-align:left;text-transform:uppercase;font-size:.625rem;font-weight:800;letter-spacing:.1em;color:#64748b}.ki-table td{padding:.75rem .5rem;border-bottom:1px solid #f1f5f9;vertical-align:top}.ki-right{text-align:right}.ki-row-auto-disabled{background:#fef2f2}.ki-badge{display:inline-block;padding:.15rem .4rem;border-radius:.25rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em}.ki-badge-ok{background:#d1fae5;color:#065f46}.ki-badge-warn{background:#fee2e2;color:#991b1b}.ki-badge-local{background:#dbeafe;color:#1e40af}.ki-badge-error{background:#ef4444;color:#fff}.ki-toggle{padding:.25rem .6rem;border-radius:.375rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;border:none;cursor:pointer;transition:opacity .15s}.ki-toggle:disabled{opacity:.4;cursor:not-allowed}.ki-toggle-on{background:#10b981;color:#fff}.ki-toggle-off{background:#e2e8f0;color:#475569}.ki-actions{white-space:nowrap}.ki-actions>*{margin-left:.25rem}.ki-btn-icon,.ki-btn-secondary,.ki-btn-warn,.ki-btn-danger{padding:.25rem .6rem;border-radius:.375rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;border:none;cursor:pointer}.ki-btn-icon{background:#f1f5f9;color:#1e293b}.ki-btn-icon:disabled{opacity:.3;cursor:not-allowed}.ki-btn-secondary{background:#e0e7ff;color:#3730a3}.ki-btn-primary{background:#10b981;color:#fff}.ki-btn-warn{background:#fef3c7;color:#92400e}.ki-btn-danger{background:#fee2e2;color:#991b1b}.ki-btn-icon,.ki-btn-secondary,.ki-btn-primary,.ki-btn-warn,.ki-btn-danger{padding:.25rem .6rem;border-radius:.375rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;border:none;cursor:pointer}.ki-badge-active{background:#d1fae5;color:#065f46;border:1px solid #10b981}.ki-ok{color:#059669;font-weight:700}.ki-cooldown{color:#d97706;font-weight:700}.ki-error{color:#dc2626;font-weight:700}\n"] }]
        }], propDecorators: { activeModelChanged: [{
                type: Output
            }], modelChanged: [{
                type: Output
            }], labels: [{
                type: Input
            }], showActiveAction: [{
                type: Input
            }], activeModelId: [{
                type: Input
            }], categoryTitles: [{
                type: Input
            }], categoryHints: [{
                type: Input
            }], categoryOrder: [{
                type: Input
            }], keylessProviders: [{
                type: Input
            }] } });

/**
 * Form um ein neues AI-Modell zur Cascade hinzuzufügen.
 *
 * **Felder:**
 * - Provider-Dropdown (gemini, openai, anthropic, openrouter, deepseek, openai_compat)
 * - Model-ID-Combobox mit Provider-spezifischen Vorschlägen (datalist)
 * - apiKeySettingKey-Auswahl (vorbelegt aus existierenden API-Keys + Default per Provider)
 * - DisplayName (optional)
 * - Cooldown503OverrideSec (optional)
 * - Add-Button
 *
 * **Event:** `(modelCreated)` emittet das neue Model nach erfolgreichem POST.
 *
 * **Provider-Default-Keys:** Beim Provider-Wechsel wird `apiKeySettingKey`
 * automatisch auf `<provider>ApiKey` umgestellt (Convenience).
 */
class AddModelFormComponent {
    constructor() {
        this.modelCreated = new EventEmitter();
        this.L = ADD_MODEL_FORM_LABELS_EN;
        this.api = inject(KiModelsApiService);
        // Form state
        this.provider = 'gemini';
        this.modelId = '';
        this.apiKeySettingKey = 'geminiApiKey';
        this.displayName = '';
        /**
         * Aktuell gewählte Kategorie. Default `'content'` (Backward-Compat zu
         * EduPro-Setup). Konsumenten mit anderen Kategorie-Schemata setzen den
         * Default über `[defaultCategoryByProvider]` (siehe unten) oder ändern
         * `categoryOptions` in den Labels — die erste Option wird dann beim
         * Provider-Wechsel selektiert wenn kein Match passt.
         */
        this.category = 'content';
        this.cooldown503OverrideSec = null;
        this.submitting = signal(false);
        this.error = signal(null);
        this.keys = signal([]);
        /**
         * Kategorien aus dem Backend (v0.10.0 — `GET {base}/categories`). Wird im
         * `ngOnInit` befüllt; bei 404 (Backend ohne CategoryMeta-Endpoint) bleibt
         * das leer und das Dropdown fällt auf `L.categoryOptions` zurück
         * (Konsumenten-Labels — Backward-Compat zu EduPros utility/content/general).
         */
        this.categoriesFromBackend = signal([]);
        this.defaultSettingKey = {
            gemini: 'geminiApiKey',
            openai: 'openaiApiKey',
            anthropic: 'anthropicApiKey',
            openrouter: 'openrouterApiKey',
            deepseek: 'deepseekApiKey',
            ollama: 'ollamaApiKey',
            openai_compat: 'customApiKey',
        };
        /**
         * Default-Kategorie pro Provider — heuristisch, weil typische Use-Cases klar
         * sind. User kann immer überschreiben.
         *   gemini       → content (Lehrmaterial, hochwertige Generierung)
         *   ollama       → utility (lokal, billig, gut für Übersetzungen)
         *   openrouter   → general (Mischbestand, oft Fallback)
         *   andere       → general
         */
        /**
         * Default-Kategorie pro Provider (Backward-Compat zum EduPro-Schema
         * `utility`/`content`/`general`). Konsumenten mit eigenem Schema
         * (z.B. Switcher mit `cloud`/`free-only`) überschreiben das via
         * `[defaultCategoryByProvider]`.
         */
        this.defaultCategoryByProvider = {
            gemini: 'content',
            openai: 'content',
            anthropic: 'content',
            openrouter: 'general',
            deepseek: 'utility',
            ollama: 'utility',
            openai_compat: 'general',
        };
        this.modelIdSuggestionsByProvider = {
            gemini: [
                'gemini-2.5-flash',
                'gemini-2.5-flash-lite',
                'gemini-2.5-pro',
                'gemini-3-flash-preview',
                'gemini-3-pro-preview',
            ],
            // Ollama-Vorschläge — sortiert grob nach Größe (klein → groß).
            // Kleine Modelle (≤7B) laufen auf CPU-only-Servern; größere brauchen GPU
            // mit min. der angegebenen VRAM. Die ID ist nur ein Tipp im Dropdown —
            // Ollama pullt das Modell beim ersten Call automatisch wenn lokal nicht
            // vorhanden. Wer auf einer Firmen-Maschine mit 16+ GB VRAM arbeitet,
            // wählt entsprechend größere Modelle für mehr Qualität.
            ollama: [
                // ── Klein (CPU-tauglich, < 8 GB RAM) ──
                'llama3.2:3b', // 2 GB
                'gemma3:4b', // 3 GB
                'qwen2.5:7b-instruct', // 5 GB (knapp auf 8 GB RAM)
                'gemma3:12b', // 8 GB (braucht GPU für gute Speed)
                // ── Mittel (GPU empfohlen, 12-16 GB VRAM) ──
                'gemma2:27b', // ~16 GB VRAM
                'qwen2.5:14b-instruct', // ~10 GB VRAM
                'llama3.1:8b', // 6 GB VRAM
                // ── Groß (16-24 GB VRAM, Firmen-Hardware) ──
                'gemma4:24b', // ~16 GB VRAM (analog XDA-Artikel)
                'qwen3-coder:30b', // ~18 GB VRAM (Coding-Workhorse)
                'qwen2.5:32b-instruct', // ~20 GB VRAM
                // ── Sehr groß (40+ GB VRAM / Multi-GPU) ──
                'llama3.1:70b', // ~40 GB VRAM
                'qwen2.5:72b-instruct', // ~45 GB VRAM
            ],
            openai: [
                'gpt-4o',
                'gpt-4o-mini',
                'gpt-4.1',
                'gpt-4.1-mini',
                'o1-mini',
                'o1-preview',
            ],
            anthropic: [
                'claude-opus-4-7',
                'claude-sonnet-4-6',
                'claude-haiku-4-5-20251001',
            ],
            openrouter: [
                // Cloud-Hosted-Variante grosser Open-Source-Modelle — wenn man die
                // selbe Modell-Familie nutzen will ohne eigene GPU-Hardware. Praktisch
                // als Mittel-Tier zwischen lokal-klein und Premium-Cloud.
                'deepseek/deepseek-v4-flash',
                'deepseek/deepseek-v4-pro',
                'deepseek/deepseek-chat-v3.1',
                'meta-llama/llama-3.3-70b-instruct',
                'meta-llama/llama-3.3-70b-instruct:free',
                'meta-llama/llama-3.1-405b-instruct',
                'qwen/qwen3-coder-30b',
                'qwen/qwen-2.5-72b-instruct',
                'google/gemma-4-24b',
                'google/gemma-2-27b-it',
                'openai/gpt-oss-120b:free',
            ],
            deepseek: [
                'deepseek-v4-flash',
                'deepseek-v4-pro',
                'deepseek-chat',
            ],
            openai_compat: [],
        };
    }
    set labels(v) {
        this.L = { ...ADD_MODEL_FORM_LABELS_EN, ...(v ?? {}) };
    }
    ngOnInit() {
        this.api.listKeys().subscribe({
            next: (list) => this.keys.set(list),
            error: () => this.keys.set([]),
        });
        this.api.listCategories().subscribe({
            next: (list) => {
                this.categoriesFromBackend.set(Array.isArray(list) ? list : []);
                // Wenn das aktuell selektierte `category` nicht im Backend-Set steckt
                // (z.B. EduPro mit utility/content/general gegen Switcher-Schema cloud/
                // free-only), nimm die erste Backend-Kategorie als Default — sonst
                // submitted die Form einen ungültigen Wert.
                const opts = this.categoryDropdownOptions();
                if (opts.length && !opts.some(o => o.value === this.category)) {
                    this.category = opts[0].value;
                }
            },
            error: () => this.categoriesFromBackend.set([]),
        });
    }
    onProviderChange() {
        const def = this.defaultSettingKey[this.provider];
        if (def)
            this.apiKeySettingKey = def;
        const cat = this.defaultCategoryByProvider[this.provider];
        // Default-Category nur setzen wenn sie auch im Dropdown ist (sonst hätte
        // der User eine selektierte Kategorie die das Dropdown nicht anzeigt).
        if (cat && this.categoryDropdownOptions().some(o => o.value === cat)) {
            this.category = cat;
        }
    }
    modelIdSuggestions() {
        return this.modelIdSuggestionsByProvider[this.provider] ?? [];
    }
    /**
     * Normalisiert die Kategorie-Eingabe live während des Tippens
     * — lowercase, Trim, Whitespace → `-`. Erlaubte Zeichen sind
     * `[a-z0-9_-]{1,50}`; alles andere wird stillschweigend entfernt
     * (Backend würde sonst auf `general` zurückfallen). v0.10.2 — Folge
     * der Umstellung von `<select>` auf `<input list>` damit neue
     * Kategorien per Freitext angelegt werden können.
     */
    onCategoryInput() {
        const raw = (this.category ?? '').toString().trim().toLowerCase();
        const cleaned = raw.replace(/\s+/g, '-').replace(/[^a-z0-9_-]/g, '').slice(0, 50);
        if (cleaned !== this.category)
            this.category = cleaned;
    }
    /**
     * Optionen für das Kategorie-Dropdown. Reihenfolge:
     *   1. Backend-Kategorien (`/api/categories`) — wenn vorhanden, nutzt
     *      `displayName` falls gesetzt sonst Capitalized `name`.
     *   2. `L.categoryOptions` aus den Labels (Konsumenten-Default) — Fallback
     *      für Backend-Versionen ohne CategoryMeta-Endpoint.
     *
     * So bekommt jeder Konsument automatisch SEINE Kategorien (Switcher:
     * cloud/free-only/…, EduPro: utility/content/general) ohne dass die
     * Library oder der Konsument das hardcodieren muss.
     */
    categoryDropdownOptions() {
        const backend = this.categoriesFromBackend();
        if (backend.length > 0) {
            return backend.map(c => ({
                value: c.name,
                label: c.displayName?.trim() || this.prettifyCategory(c.name),
            }));
        }
        return this.L.categoryOptions;
    }
    prettifyCategory(c) {
        return c.replace(/[-_]+/g, ' ').replace(/\b\w/g, ch => ch.toUpperCase());
    }
    /** Existierende Settings als Optionen + Default-Settings die noch nicht in DB sind. */
    keyOptions() {
        const existing = new Map(this.keys().map((k) => [k.settingKey, k.configured]));
        // Default-settingKeys aus dem Mapping ergänzen (auch wenn DB sie noch nicht hat)
        Object.values(this.defaultSettingKey).forEach((sk) => {
            if (!existing.has(sk))
                existing.set(sk, false);
        });
        return Array.from(existing.entries())
            .map(([settingKey, configured]) => ({ settingKey, configured }))
            .sort((a, b) => a.settingKey.localeCompare(b.settingKey));
    }
    onSubmit() {
        if (!this.provider || !this.modelId || !this.apiKeySettingKey)
            return;
        this.submitting.set(true);
        this.error.set(null);
        const body = {
            provider: this.provider.trim(),
            modelId: this.modelId.trim(),
            apiKeySettingKey: this.apiKeySettingKey.trim(),
            displayName: this.displayName?.trim() || undefined,
            category: this.category,
            cooldown503OverrideSec: this.cooldown503OverrideSec,
        };
        this.api.createModel(body).subscribe({
            next: (created) => {
                this.modelCreated.emit(created);
                this.modelId = '';
                this.displayName = '';
                this.cooldown503OverrideSec = null;
                this.submitting.set(false);
            },
            error: (err) => {
                this.error.set(err?.error?.error ?? this.L.errorFailed);
                this.submitting.set(false);
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AddModelFormComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: AddModelFormComponent, isStandalone: true, selector: "ki-add-model-form", inputs: { labels: "labels", defaultCategoryByProvider: "defaultCategoryByProvider" }, outputs: { modelCreated: "modelCreated" }, ngImport: i0, template: `
    <form class="ki-add-model-form" (ngSubmit)="onSubmit()" #f="ngForm">
      <h4 class="ki-form-title">{{ L.title }}</h4>

      <div class="ki-grid">
        <select [(ngModel)]="provider"
                name="provider"
                (change)="onProviderChange()"
                class="ki-input">
          <option *ngFor="let p of L.providerOptions" [value]="p.value">{{ p.label }}</option>
        </select>

        <input [(ngModel)]="modelId"
               name="modelId"
               list="ki-model-id-suggestions"
               [placeholder]="L.fieldModelId"
               class="ki-input ki-mono"
               required />
        <datalist id="ki-model-id-suggestions">
          <option *ngFor="let s of modelIdSuggestions()" [value]="s"></option>
        </datalist>

        <select [(ngModel)]="apiKeySettingKey"
                name="apiKeySettingKey"
                class="ki-input ki-mono">
          <option value="" disabled>{{ L.fieldApiKeySettingKey }}</option>
          <option *ngFor="let k of keyOptions()" [value]="k.settingKey">
            {{ k.settingKey }} {{ k.configured ? '✓' : '' }}
          </option>
        </select>

        <!-- v0.10.2: <input list> statt <select> — bestehende Kategorien werden
             als Vorschläge angezeigt, der User kann aber auch eine NEUE Kategorie
             frei tippen (z.B. "local", "ollama") und damit eine neue Cascade
             implizit anlegen. Backend (llm-cascade ≥ 0.5.0) akzeptiert jeden
             Identifier nach [a-z0-9_-]{1,50} und fällt sonst auf "general" zurück.
             -->
        <input [(ngModel)]="category"
               name="category"
               list="ki-category-suggestions"
               [placeholder]="L.fieldCategory"
               [attr.aria-label]="L.fieldCategory"
               class="ki-input ki-mono"
               (change)="onCategoryInput()" />
        <datalist id="ki-category-suggestions">
          <option *ngFor="let c of categoryDropdownOptions()" [value]="c.value">{{ c.label }}</option>
        </datalist>

        <input [(ngModel)]="displayName"
               name="displayName"
               [placeholder]="L.fieldDisplayName"
               class="ki-input" />

        <input [(ngModel)]="cooldown503OverrideSec"
               name="cooldown503OverrideSec"
               type="number"
               [placeholder]="L.fieldCooldownOverride"
               class="ki-input" />

        <button type="submit"
                [disabled]="submitting() || !provider || !modelId || !apiKeySettingKey"
                class="ki-btn-primary">
          {{ submitting() ? L.btnAdding : L.btnAdd }}
        </button>
      </div>

      <p *ngIf="error()" class="ki-error">{{ error() }}</p>
      <p class="ki-hint">{{ L.hint }}</p>
    </form>
  `, isInline: true, styles: [".ki-add-model-form{font-family:inherit;padding:1rem 0;border-top:1px solid #e2e8f0}.ki-form-title{font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#475569;margin-bottom:.75rem}.ki-grid{display:grid;grid-template-columns:1fr 1fr;gap:.75rem}.ki-input{padding:.75rem;background:#f8fafc;border:2px solid #f1f5f9;border-radius:.75rem;font-size:.875rem;font-weight:700}.ki-mono{font-family:ui-monospace,monospace}.ki-btn-primary{padding:.75rem 1rem;background:#0f172a;color:#fff;border:none;border-radius:1rem;text-transform:uppercase;font-weight:800;letter-spacing:.1em;font-size:.75rem;cursor:pointer;grid-column:span 2}.ki-btn-primary:disabled{opacity:.4;cursor:not-allowed}.ki-error{color:#b91c1c;font-weight:700;margin-top:.5rem;font-size:.75rem}.ki-hint{color:#94a3b8;font-size:.7rem;font-weight:700;margin-top:.75rem}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i2.NgSelectOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.ɵNgSelectMultipleOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2.NumberValueAccessor, selector: "input[type=number][formControlName],input[type=number][formControl],input[type=number][ngModel]" }, { kind: "directive", type: i2.SelectControlValueAccessor, selector: "select:not([multiple])[formControlName],select:not([multiple])[formControl],select:not([multiple])[ngModel]", inputs: ["compareWith"] }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: i2.NgForm, selector: "form:not([ngNoForm]):not([formGroup]),ng-form,[ngForm]", inputs: ["ngFormOptions"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: AddModelFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-add-model-form', standalone: true, imports: [CommonModule, FormsModule], template: `
    <form class="ki-add-model-form" (ngSubmit)="onSubmit()" #f="ngForm">
      <h4 class="ki-form-title">{{ L.title }}</h4>

      <div class="ki-grid">
        <select [(ngModel)]="provider"
                name="provider"
                (change)="onProviderChange()"
                class="ki-input">
          <option *ngFor="let p of L.providerOptions" [value]="p.value">{{ p.label }}</option>
        </select>

        <input [(ngModel)]="modelId"
               name="modelId"
               list="ki-model-id-suggestions"
               [placeholder]="L.fieldModelId"
               class="ki-input ki-mono"
               required />
        <datalist id="ki-model-id-suggestions">
          <option *ngFor="let s of modelIdSuggestions()" [value]="s"></option>
        </datalist>

        <select [(ngModel)]="apiKeySettingKey"
                name="apiKeySettingKey"
                class="ki-input ki-mono">
          <option value="" disabled>{{ L.fieldApiKeySettingKey }}</option>
          <option *ngFor="let k of keyOptions()" [value]="k.settingKey">
            {{ k.settingKey }} {{ k.configured ? '✓' : '' }}
          </option>
        </select>

        <!-- v0.10.2: <input list> statt <select> — bestehende Kategorien werden
             als Vorschläge angezeigt, der User kann aber auch eine NEUE Kategorie
             frei tippen (z.B. "local", "ollama") und damit eine neue Cascade
             implizit anlegen. Backend (llm-cascade ≥ 0.5.0) akzeptiert jeden
             Identifier nach [a-z0-9_-]{1,50} und fällt sonst auf "general" zurück.
             -->
        <input [(ngModel)]="category"
               name="category"
               list="ki-category-suggestions"
               [placeholder]="L.fieldCategory"
               [attr.aria-label]="L.fieldCategory"
               class="ki-input ki-mono"
               (change)="onCategoryInput()" />
        <datalist id="ki-category-suggestions">
          <option *ngFor="let c of categoryDropdownOptions()" [value]="c.value">{{ c.label }}</option>
        </datalist>

        <input [(ngModel)]="displayName"
               name="displayName"
               [placeholder]="L.fieldDisplayName"
               class="ki-input" />

        <input [(ngModel)]="cooldown503OverrideSec"
               name="cooldown503OverrideSec"
               type="number"
               [placeholder]="L.fieldCooldownOverride"
               class="ki-input" />

        <button type="submit"
                [disabled]="submitting() || !provider || !modelId || !apiKeySettingKey"
                class="ki-btn-primary">
          {{ submitting() ? L.btnAdding : L.btnAdd }}
        </button>
      </div>

      <p *ngIf="error()" class="ki-error">{{ error() }}</p>
      <p class="ki-hint">{{ L.hint }}</p>
    </form>
  `, styles: [".ki-add-model-form{font-family:inherit;padding:1rem 0;border-top:1px solid #e2e8f0}.ki-form-title{font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#475569;margin-bottom:.75rem}.ki-grid{display:grid;grid-template-columns:1fr 1fr;gap:.75rem}.ki-input{padding:.75rem;background:#f8fafc;border:2px solid #f1f5f9;border-radius:.75rem;font-size:.875rem;font-weight:700}.ki-mono{font-family:ui-monospace,monospace}.ki-btn-primary{padding:.75rem 1rem;background:#0f172a;color:#fff;border:none;border-radius:1rem;text-transform:uppercase;font-weight:800;letter-spacing:.1em;font-size:.75rem;cursor:pointer;grid-column:span 2}.ki-btn-primary:disabled{opacity:.4;cursor:not-allowed}.ki-error{color:#b91c1c;font-weight:700;margin-top:.5rem;font-size:.75rem}.ki-hint{color:#94a3b8;font-size:.7rem;font-weight:700;margin-top:.75rem}\n"] }]
        }], propDecorators: { modelCreated: [{
                type: Output
            }], labels: [{
                type: Input
            }], defaultCategoryByProvider: [{
                type: Input
            }] } });

/**
 * Tri-State Cooldown-Override-Panel.
 *
 * **States:**
 * - `null` (Default) — jedes Modell nutzt seine eigene Cooldown-Logik (Standard)
 * - `true` (Force ON) — Cooldown global erzwingen (auch wenn Modelle individuell deaktiviert haben)
 * - `false` (Force OFF) — Cooldown global deaktivieren (Tests / Debug)
 *
 * **Effective-Badge** zeigt den vom Backend resolved Endzustand (`effective`,
 * `effectiveCooldown`).
 */
class CascadeCooldownComponent {
    constructor() {
        this.L = CASCADE_COOLDOWN_LABELS_EN;
        this.api = inject(KiModelsApiService);
        this.loading = signal(true);
        this.config = signal(null);
    }
    set labels(v) {
        this.L = { ...CASCADE_COOLDOWN_LABELS_EN, ...(v ?? {}) };
    }
    ngOnInit() {
        this.refresh();
    }
    refresh() {
        this.loading.set(true);
        this.api.getCascadeConfig().subscribe({
            next: (cfg) => {
                this.config.set(cfg);
                this.loading.set(false);
            },
            error: () => this.loading.set(false),
        });
    }
    set(value) {
        if (this.config()?.cooldownOverride === value)
            return;
        this.api.setCascadeConfig({ cooldownOverride: value }).subscribe((cfg) => this.config.set(cfg));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CascadeCooldownComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CascadeCooldownComponent, isStandalone: true, selector: "ki-cascade-cooldown", inputs: { labels: "labels" }, ngImport: i0, template: `
    <div class="ki-cooldown" *ngIf="config() as cfg">
      <h4 class="ki-section-title">{{ L.title }}</h4>
      <p class="ki-subtitle">{{ L.subtitle }}</p>

      <div class="ki-controls">
        <button (click)="set(null)"
                class="ki-state-btn"
                [class.ki-state-active]="cfg.cooldownOverride === null"
                [class.ki-state-default]="cfg.cooldownOverride === null">
          {{ L.default }}
        </button>
        <button (click)="set(true)"
                class="ki-state-btn"
                [class.ki-state-active]="cfg.cooldownOverride === true"
                [class.ki-state-on]="cfg.cooldownOverride === true">
          {{ L.forceOn }}
        </button>
        <button (click)="set(false)"
                class="ki-state-btn"
                [class.ki-state-active]="cfg.cooldownOverride === false"
                [class.ki-state-off]="cfg.cooldownOverride === false">
          {{ L.forceOff }}
        </button>

        <span class="ki-effective-badge"
              [class.ki-effective-on]="cfg.effectiveCooldown"
              [class.ki-effective-off]="!cfg.effectiveCooldown">
          {{ cfg.effectiveCooldown ? L.effectiveOn : L.effectiveOff }}
        </span>
      </div>

      <p class="ki-hint">{{ L.hint }}</p>
    </div>

    <div *ngIf="!config() && loading()" class="ki-muted">{{ L.loading }}</div>
    <div *ngIf="!config() && !loading()" class="ki-error">{{ L.errorLoad }}</div>
  `, isInline: true, styles: [".ki-cooldown{font-family:inherit;padding:1.5rem 0}.ki-section-title{font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#475569;margin-bottom:.5rem}.ki-subtitle{color:#64748b;font-size:.75rem;font-weight:700;margin-bottom:1.25rem}.ki-controls{display:flex;flex-wrap:wrap;gap:.5rem;align-items:center}.ki-state-btn{padding:.6rem 1rem;border-radius:1rem;font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;border:none;cursor:pointer;background:#f1f5f9;color:#475569;transition:background .15s}.ki-state-btn:hover{background:#e2e8f0}.ki-state-active.ki-state-default{background:#0f172a;color:#fff}.ki-state-active.ki-state-on{background:#10b981;color:#fff}.ki-state-active.ki-state-off{background:#f59e0b;color:#fff}.ki-effective-badge{margin-left:auto;padding:.3rem .75rem;border-radius:999px;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em}.ki-effective-on{background:#d1fae5;color:#065f46}.ki-effective-off{background:#fef3c7;color:#92400e}.ki-hint{color:#94a3b8;font-size:.7rem;font-weight:700;margin-top:1rem}.ki-muted{color:#888}.ki-error{color:#b91c1c;font-weight:700}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CascadeCooldownComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-cascade-cooldown', standalone: true, imports: [CommonModule], template: `
    <div class="ki-cooldown" *ngIf="config() as cfg">
      <h4 class="ki-section-title">{{ L.title }}</h4>
      <p class="ki-subtitle">{{ L.subtitle }}</p>

      <div class="ki-controls">
        <button (click)="set(null)"
                class="ki-state-btn"
                [class.ki-state-active]="cfg.cooldownOverride === null"
                [class.ki-state-default]="cfg.cooldownOverride === null">
          {{ L.default }}
        </button>
        <button (click)="set(true)"
                class="ki-state-btn"
                [class.ki-state-active]="cfg.cooldownOverride === true"
                [class.ki-state-on]="cfg.cooldownOverride === true">
          {{ L.forceOn }}
        </button>
        <button (click)="set(false)"
                class="ki-state-btn"
                [class.ki-state-active]="cfg.cooldownOverride === false"
                [class.ki-state-off]="cfg.cooldownOverride === false">
          {{ L.forceOff }}
        </button>

        <span class="ki-effective-badge"
              [class.ki-effective-on]="cfg.effectiveCooldown"
              [class.ki-effective-off]="!cfg.effectiveCooldown">
          {{ cfg.effectiveCooldown ? L.effectiveOn : L.effectiveOff }}
        </span>
      </div>

      <p class="ki-hint">{{ L.hint }}</p>
    </div>

    <div *ngIf="!config() && loading()" class="ki-muted">{{ L.loading }}</div>
    <div *ngIf="!config() && !loading()" class="ki-error">{{ L.errorLoad }}</div>
  `, styles: [".ki-cooldown{font-family:inherit;padding:1.5rem 0}.ki-section-title{font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#475569;margin-bottom:.5rem}.ki-subtitle{color:#64748b;font-size:.75rem;font-weight:700;margin-bottom:1.25rem}.ki-controls{display:flex;flex-wrap:wrap;gap:.5rem;align-items:center}.ki-state-btn{padding:.6rem 1rem;border-radius:1rem;font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;border:none;cursor:pointer;background:#f1f5f9;color:#475569;transition:background .15s}.ki-state-btn:hover{background:#e2e8f0}.ki-state-active.ki-state-default{background:#0f172a;color:#fff}.ki-state-active.ki-state-on{background:#10b981;color:#fff}.ki-state-active.ki-state-off{background:#f59e0b;color:#fff}.ki-effective-badge{margin-left:auto;padding:.3rem .75rem;border-radius:999px;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em}.ki-effective-on{background:#d1fae5;color:#065f46}.ki-effective-off{background:#fef3c7;color:#92400e}.ki-hint{color:#94a3b8;font-size:.7rem;font-weight:700;margin-top:1rem}.ki-muted{color:#888}.ki-error{color:#b91c1c;font-weight:700}\n"] }]
        }], propDecorators: { labels: [{
                type: Input
            }] } });

/**
 * Section zur Verwaltung aller API-Keys (settingKey-basiert).
 *
 * **Form (oben):** settingKey-Picker + Value-Input (mit Show/Hide) + Save-Button.
 * Konsument kann beim Add eines neuen Models einen settingKey wählen, der noch
 * keinen Value hat — der bleibt offen bis er hier gesetzt wird.
 *
 * **Status-Liste (unten):** alle konfigurierten settingKeys mit:
 * - Badge: Source (`db` vom Admin gesetzt oder `env` vom Boot-Default)
 * - Wert maskiert
 * - Actions: Edit (lädt in Form oben), Clear (löscht den DB-Override)
 *
 * **Event:** `(keyChanged)` emittet bei jedem Save/Clear damit Konsument seine
 * Modell-Liste neu laden kann (key-Konfiguration ändert sich → Models-Status
 * `keyConfigured` ändert sich).
 */
class ApiKeysSectionComponent {
    constructor() {
        this.keyChanged = new EventEmitter();
        this.L = API_KEYS_SECTION_LABELS_EN;
        this.api = inject(KiModelsApiService);
        this.loading = signal(true);
        this.keys = signal([]);
        // Form state
        this.settingKey = '';
        this.value = '';
        this.showValue = signal(false);
        this.saving = signal(false);
        this.clearing = signal(null);
        /** Bekannte Default-Settings + ihre Brand-Labels (für Add-Form Vorschläge). */
        this.defaultCards = [
            { settingKey: 'geminiApiKey', brand: 'Gemini (Google)' },
            { settingKey: 'openaiApiKey', brand: 'OpenAI' },
            { settingKey: 'anthropicApiKey', brand: 'Anthropic' },
            { settingKey: 'openrouterApiKey', brand: 'OpenRouter' },
            { settingKey: 'deepseekApiKey', brand: 'DeepSeek' },
            { settingKey: 'customApiKey', brand: 'Custom (OpenAI-compat)' },
        ];
        this.configuredKeys = computed(() => this.keys().filter((k) => k.configured));
    }
    set labels(v) {
        this.L = { ...API_KEYS_SECTION_LABELS_EN, ...(v ?? {}) };
    }
    /** Default-Settings + dynamische (aus DB) als Options im Dropdown. */
    keyOptions() {
        const fromApi = new Set(this.keys().map((k) => k.settingKey));
        const dynamic = Array.from(fromApi)
            .filter((k) => !this.defaultCards.find((d) => d.settingKey === k))
            .map((k) => ({ settingKey: k, brand: 'Custom' }));
        return [...this.defaultCards, ...dynamic].sort((a, b) => a.settingKey.localeCompare(b.settingKey));
    }
    ngOnInit() {
        this.reload();
    }
    reload() {
        this.loading.set(true);
        this.api.listKeys().subscribe({
            next: (list) => {
                this.keys.set(list);
                this.loading.set(false);
            },
            error: () => this.loading.set(false),
        });
    }
    canSave() {
        return !!this.settingKey && !this.saving();
    }
    save() {
        if (!this.canSave())
            return;
        this.saving.set(true);
        this.api.setKey(this.settingKey, { value: this.value }).subscribe({
            next: () => {
                this.keyChanged.emit(this.settingKey);
                this.value = '';
                this.showValue.set(false);
                this.saving.set(false);
                this.reload();
            },
            error: () => this.saving.set(false),
        });
    }
    editKey(k) {
        this.settingKey = k.settingKey;
        this.value = '';
        this.showValue.set(false);
    }
    clearKey(k) {
        if (!confirm(this.L.confirmClear(k.settingKey)))
            return;
        this.clearing.set(k.settingKey);
        this.api.setKey(k.settingKey, { value: '' }).subscribe({
            next: () => {
                this.keyChanged.emit(k.settingKey);
                this.clearing.set(null);
                this.reload();
            },
            error: () => this.clearing.set(null),
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ApiKeysSectionComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ApiKeysSectionComponent, isStandalone: true, selector: "ki-api-keys-section", inputs: { labels: "labels" }, outputs: { keyChanged: "keyChanged" }, ngImport: i0, template: `
    <div class="ki-keys-section">
      <h4 class="ki-section-title">{{ L.title }}</h4>
      <p class="ki-subtitle">{{ L.subtitle }}</p>

      <!-- Add/Edit Form -->
      <div class="ki-form-grid">
        <select [(ngModel)]="settingKey" class="ki-input ki-mono">
          <option value="" disabled>{{ L.fieldSettingKey }}</option>
          <option *ngFor="let k of keyOptions()" [value]="k.settingKey">
            {{ k.settingKey }} — {{ k.brand }}
          </option>
        </select>

        <div class="ki-input-wrap">
          <input [(ngModel)]="value"
                 [type]="showValue() ? 'text' : 'password'"
                 [placeholder]="L.fieldValue"
                 autocomplete="off"
                 spellcheck="false"
                 class="ki-input ki-mono ki-input-with-toggle" />
          <button type="button" (click)="showValue.set(!showValue())" class="ki-show-toggle">
            {{ showValue() ? L.btnHide : L.btnShow }}
          </button>
        </div>

        <button (click)="save()"
                [disabled]="!canSave() || saving()"
                class="ki-btn-primary">
          {{ saving() ? L.btnSaving : L.btnSave }}
        </button>
      </div>

      <!-- Status-Liste -->
      <ng-container *ngIf="configuredKeys().length > 0; else noKeys">
        <h5 class="ki-list-title">{{ L.listTitle }}</h5>
        <div class="ki-table-wrap">
          <table class="ki-table">
            <thead>
              <tr>
                <th>{{ L.colSettingKey }}</th>
                <th>{{ L.colSource }}</th>
                <th>{{ L.colValue }}</th>
                <th class="ki-right">{{ L.colActions }}</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let k of configuredKeys()">
                <td class="ki-mono">
                  <strong>{{ k.settingKey }}</strong>
                </td>
                <td>
                  <span class="ki-badge"
                        [class.ki-badge-db]="k.keySource === 'db'"
                        [class.ki-badge-env]="k.keySource !== 'db'">
                    {{ k.keySource === 'db' ? L.sourceDb : (k.configured ? L.sourceEnv : L.sourceMissing) }}
                  </span>
                </td>
                <td class="ki-mono ki-value">{{ k.valueMasked || '…' }}</td>
                <td class="ki-right">
                  <button (click)="editKey(k)" class="ki-btn-secondary">{{ L.btnEdit }}</button>
                  <button *ngIf="k.keySource === 'db'"
                          (click)="clearKey(k)"
                          [disabled]="clearing() === k.settingKey"
                          class="ki-btn-danger">
                    {{ clearing() === k.settingKey ? '…' : L.btnClear }}
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </ng-container>
      <ng-template #noKeys>
        <p class="ki-empty">{{ L.empty }}</p>
      </ng-template>

      <p class="ki-hint">{{ L.hint }}</p>
    </div>
  `, isInline: true, styles: [".ki-keys-section{font-family:inherit;padding:1.5rem 0}.ki-section-title{font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#475569;margin-bottom:.5rem}.ki-subtitle{color:#64748b;font-size:.75rem;font-weight:700;margin-bottom:1.25rem}.ki-list-title{font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#94a3b8;margin:1.5rem 0 .75rem}.ki-form-grid{display:grid;grid-template-columns:1fr 1fr;gap:.75rem;margin-bottom:1rem}.ki-input{padding:.75rem;background:#f8fafc;border:2px solid #f1f5f9;border-radius:.75rem;font-size:.875rem;font-weight:700}.ki-mono{font-family:ui-monospace,monospace}.ki-input-wrap{position:relative}.ki-input-with-toggle{width:100%;padding-right:4rem;box-sizing:border-box}.ki-show-toggle{position:absolute;right:.75rem;top:50%;transform:translateY(-50%);padding:.25rem .5rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;background:transparent;border:none;color:#64748b;cursor:pointer}.ki-btn-primary{grid-column:span 2;padding:.75rem 1rem;background:#dc2626;color:#fff;border:none;border-radius:1rem;text-transform:uppercase;font-weight:800;letter-spacing:.1em;font-size:.75rem;cursor:pointer}.ki-btn-primary:disabled{opacity:.4;cursor:not-allowed}.ki-btn-secondary,.ki-btn-danger{padding:.3rem .7rem;border-radius:.375rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;border:none;cursor:pointer}.ki-btn-secondary{background:#f1f5f9;color:#1e293b;margin-right:.25rem}.ki-btn-danger{background:#fee2e2;color:#991b1b}.ki-btn-danger:disabled{opacity:.4;cursor:not-allowed}.ki-table-wrap{overflow-x:auto}.ki-table{width:100%;border-collapse:collapse;font-size:.875rem}.ki-table thead{border-bottom:1px solid #f1f5f9}.ki-table th{padding:.5rem;text-align:left;text-transform:uppercase;font-size:.625rem;font-weight:800;letter-spacing:.1em;color:#94a3b8}.ki-table td{padding:.75rem .5rem;border-bottom:1px solid #f1f5f9;vertical-align:middle}.ki-right{text-align:right}.ki-badge{display:inline-block;padding:.25rem .7rem;border-radius:999px;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em}.ki-badge-db{background:#d1fae5;color:#065f46}.ki-badge-env{background:#e2e8f0;color:#475569}.ki-value{color:#64748b}.ki-empty{color:#94a3b8;font-style:italic;font-size:.75rem;font-weight:700}.ki-hint{color:#94a3b8;font-size:.7rem;font-weight:700;margin-top:1rem}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.NgSelectOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.ɵNgSelectMultipleOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2.SelectControlValueAccessor, selector: "select:not([multiple])[formControlName],select:not([multiple])[formControl],select:not([multiple])[ngModel]", inputs: ["compareWith"] }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ApiKeysSectionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-api-keys-section', standalone: true, imports: [CommonModule, FormsModule], template: `
    <div class="ki-keys-section">
      <h4 class="ki-section-title">{{ L.title }}</h4>
      <p class="ki-subtitle">{{ L.subtitle }}</p>

      <!-- Add/Edit Form -->
      <div class="ki-form-grid">
        <select [(ngModel)]="settingKey" class="ki-input ki-mono">
          <option value="" disabled>{{ L.fieldSettingKey }}</option>
          <option *ngFor="let k of keyOptions()" [value]="k.settingKey">
            {{ k.settingKey }} — {{ k.brand }}
          </option>
        </select>

        <div class="ki-input-wrap">
          <input [(ngModel)]="value"
                 [type]="showValue() ? 'text' : 'password'"
                 [placeholder]="L.fieldValue"
                 autocomplete="off"
                 spellcheck="false"
                 class="ki-input ki-mono ki-input-with-toggle" />
          <button type="button" (click)="showValue.set(!showValue())" class="ki-show-toggle">
            {{ showValue() ? L.btnHide : L.btnShow }}
          </button>
        </div>

        <button (click)="save()"
                [disabled]="!canSave() || saving()"
                class="ki-btn-primary">
          {{ saving() ? L.btnSaving : L.btnSave }}
        </button>
      </div>

      <!-- Status-Liste -->
      <ng-container *ngIf="configuredKeys().length > 0; else noKeys">
        <h5 class="ki-list-title">{{ L.listTitle }}</h5>
        <div class="ki-table-wrap">
          <table class="ki-table">
            <thead>
              <tr>
                <th>{{ L.colSettingKey }}</th>
                <th>{{ L.colSource }}</th>
                <th>{{ L.colValue }}</th>
                <th class="ki-right">{{ L.colActions }}</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let k of configuredKeys()">
                <td class="ki-mono">
                  <strong>{{ k.settingKey }}</strong>
                </td>
                <td>
                  <span class="ki-badge"
                        [class.ki-badge-db]="k.keySource === 'db'"
                        [class.ki-badge-env]="k.keySource !== 'db'">
                    {{ k.keySource === 'db' ? L.sourceDb : (k.configured ? L.sourceEnv : L.sourceMissing) }}
                  </span>
                </td>
                <td class="ki-mono ki-value">{{ k.valueMasked || '…' }}</td>
                <td class="ki-right">
                  <button (click)="editKey(k)" class="ki-btn-secondary">{{ L.btnEdit }}</button>
                  <button *ngIf="k.keySource === 'db'"
                          (click)="clearKey(k)"
                          [disabled]="clearing() === k.settingKey"
                          class="ki-btn-danger">
                    {{ clearing() === k.settingKey ? '…' : L.btnClear }}
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </ng-container>
      <ng-template #noKeys>
        <p class="ki-empty">{{ L.empty }}</p>
      </ng-template>

      <p class="ki-hint">{{ L.hint }}</p>
    </div>
  `, styles: [".ki-keys-section{font-family:inherit;padding:1.5rem 0}.ki-section-title{font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#475569;margin-bottom:.5rem}.ki-subtitle{color:#64748b;font-size:.75rem;font-weight:700;margin-bottom:1.25rem}.ki-list-title{font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#94a3b8;margin:1.5rem 0 .75rem}.ki-form-grid{display:grid;grid-template-columns:1fr 1fr;gap:.75rem;margin-bottom:1rem}.ki-input{padding:.75rem;background:#f8fafc;border:2px solid #f1f5f9;border-radius:.75rem;font-size:.875rem;font-weight:700}.ki-mono{font-family:ui-monospace,monospace}.ki-input-wrap{position:relative}.ki-input-with-toggle{width:100%;padding-right:4rem;box-sizing:border-box}.ki-show-toggle{position:absolute;right:.75rem;top:50%;transform:translateY(-50%);padding:.25rem .5rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;background:transparent;border:none;color:#64748b;cursor:pointer}.ki-btn-primary{grid-column:span 2;padding:.75rem 1rem;background:#dc2626;color:#fff;border:none;border-radius:1rem;text-transform:uppercase;font-weight:800;letter-spacing:.1em;font-size:.75rem;cursor:pointer}.ki-btn-primary:disabled{opacity:.4;cursor:not-allowed}.ki-btn-secondary,.ki-btn-danger{padding:.3rem .7rem;border-radius:.375rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;border:none;cursor:pointer}.ki-btn-secondary{background:#f1f5f9;color:#1e293b;margin-right:.25rem}.ki-btn-danger{background:#fee2e2;color:#991b1b}.ki-btn-danger:disabled{opacity:.4;cursor:not-allowed}.ki-table-wrap{overflow-x:auto}.ki-table{width:100%;border-collapse:collapse;font-size:.875rem}.ki-table thead{border-bottom:1px solid #f1f5f9}.ki-table th{padding:.5rem;text-align:left;text-transform:uppercase;font-size:.625rem;font-weight:800;letter-spacing:.1em;color:#94a3b8}.ki-table td{padding:.75rem .5rem;border-bottom:1px solid #f1f5f9;vertical-align:middle}.ki-right{text-align:right}.ki-badge{display:inline-block;padding:.25rem .7rem;border-radius:999px;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em}.ki-badge-db{background:#d1fae5;color:#065f46}.ki-badge-env{background:#e2e8f0;color:#475569}.ki-value{color:#64748b}.ki-empty{color:#94a3b8;font-style:italic;font-size:.75rem;font-weight:700}.ki-hint{color:#94a3b8;font-size:.7rem;font-weight:700;margin-top:1rem}\n"] }]
        }], propDecorators: { keyChanged: [{
                type: Output
            }], labels: [{
                type: Input
            }] } });

/**
 * Generischer Failover-Chain-Editor — von beiden Konsumenten (Switcher +
 * EduPro) genutzt. Komponente ist „dumm": sie hält keinen Zustand, sondern
 * emittet `(chainChanged)` bei jeder Edit-Aktion. Der Konsument entscheidet
 * was mit der neuen Chain passiert:
 *
 * - **Switcher** persistiert sie in `_switcher.fallback_chain` (Wrapper liest
 *   das + restartet Claude Code bei Quota-Fehler entlang der Chain).
 * - **EduPro** mapped die Chain auf cascade-models-CRUD (`orderIdx`-Reorder
 *   bei Reorder, POST bei Add, DELETE bei Remove). Damit ist die Chain in
 *   EduPro effektiv die enabled-Modell-Liste in `orderIdx`-Reihenfolge.
 *
 * Switcher-spezifische Features (Aktuelle-Stufe-Indikator, Promote-Button)
 * sind hinter `[showChainPosition]="true"` gegated und in EduPro standardmäßig
 * ausgeblendet.
 *
 * **Inputs:**
 * - `chain` — aktuelle Chain (`{provider, model}[]`)
 * - `availableModels` — Optionen für Modell-Dropdown pro Provider
 * - `availableProviders` — Optionen für Provider-Dropdown
 * - `chainPosition` — aktive Stufe (0-basiert, null = keine)
 * - `showChainPosition` — gated Aktuelle-Stufe-Zeile + Promote-Button
 * - `labels` — i18n-Override
 *
 * **Outputs:**
 * - `chainChanged` — neue Chain nach jeder Edit-Aktion
 * - `promoteRequested` — User klickt „Zurück zu Stufe 1" (nur bei
 *   `showChainPosition && chainPosition > 0` sichtbar)
 */
class FailoverChainComponent {
    constructor() {
        /** Aktuelle Chain. Die Komponente mutiert sie in-place beim Editieren und emittet `chainChanged`. */
        this.chain = [];
        /** Optionen für die Modell-Dropdowns. Pro Provider eine Liste an Modellen. */
        this.availableModels = [];
        /** Optionen für die Provider-Dropdowns. Default: anthropic/google/openrouter. */
        this.availableProviders = [
            { value: 'anthropic', label: 'Anthropic' },
            { value: 'google', label: 'Google AI Studio' },
            { value: 'openrouter', label: 'OpenRouter' },
        ];
        /** Aktive Stufe (0-basiert). Nur relevant bei `showChainPosition=true`. */
        this.chainPosition = null;
        /** Gated die Aktuelle-Stufe-Zeile + Promote-Button (Switcher-only-Feature). */
        this.showChainPosition = false;
        this.L = FAILOVER_CHAIN_LABELS_EN;
        this.chainChanged = new EventEmitter();
        this.promoteRequested = new EventEmitter();
    }
    /** Optionale i18n-Override-Strings. */
    set labels(v) {
        this.L = { ...FAILOVER_CHAIN_LABELS_EN, ...(v ?? {}) };
    }
    modelsFor(provider) {
        return this.availableModels.filter((m) => m.provider === provider);
    }
    /**
     * Wie {@link modelsFor}, aber zusätzlich gefiltert auf Modelle, die NICHT
     * bereits in einer ANDEREN Chain-Zeile ausgewählt sind. Verhindert, dass
     * der User das gleiche `{provider, model}`-Paar mehrfach in die Chain
     * packt — würde im Konsumenten-Diff (z.B. EduPros `onFailoverChainChanged`)
     * zu Mehrdeutigkeit führen (welche Zeile gehört zu welchem cascade-Modell)
     * und den vorherigen Inhaber implizit löschen.
     */
    modelsForRow(provider, rowIdx) {
        const blocked = new Set();
        for (let j = 0; j < this.chain.length; j++) {
            if (j === rowIdx)
                continue;
            blocked.add(`${this.chain[j].provider}|${this.chain[j].model}`);
        }
        return this.availableModels
            .filter((m) => m.provider === provider)
            .filter((m) => !blocked.has(`${m.provider}|${m.modelId}`));
    }
    /**
     * Filtere `availableProviders` auf Provider, die mind. EIN `availableModels`-
     * Eintrag haben. Verhindert dass User Provider-Werte aus dem Dropdown picken,
     * für die kein Modell konfiguriert ist (würde sonst beim Aktivieren in einen
     * „kein Provider-Bean"-Backend-Fehler laufen).
     *
     * Beispiel EduPro (cascade-Namensraum): hat nur Modelle mit `provider:'gemini'`
     * → Dropdown zeigt nur „Google AI Studio". Selbst wenn der Konsument
     * `availableProviders` mit `[anthropic, google, openrouter]` overridet,
     * werden Optionen ohne Modelle ausgeblendet.
     */
    validProviders() {
        const have = new Set(this.availableModels.map((m) => m.provider));
        return this.availableProviders.filter((p) => have.has(p.value));
    }
    onProviderChange(idx) {
        // Beim Provider-Wechsel: Modell auf erstes verfügbares des neuen Providers
        // setzen, das nicht bereits in einer anderen Zeile steht.
        const first = this.modelsForRow(this.chain[idx].provider, idx)[0];
        if (first)
            this.chain[idx].model = first.modelId;
        this.emit();
    }
    /**
     * True wenn es noch ein verfügbares Modell gibt, das NICHT bereits in der
     * Chain steht. Steuert das Disabled-State des „+ Stufe"-Buttons — verhindert
     * Klick-Versuche die sonst ein Duplikat (oder keinen Row) erzeugen würden.
     */
    canAdd() {
        if (this.availableModels.length === 0)
            return false;
        const inChain = new Set(this.chain.map((r) => `${r.provider}|${r.model}`));
        return this.availableModels.some((m) => !inChain.has(`${m.provider}|${m.modelId}`));
    }
    /**
     * Neue Chain-Stufe = erstes `availableModels`-Eintrag, der noch NICHT in der
     * Chain ist. Verhindert Duplikate beim Klick auf „+ Stufe".
     */
    addRow() {
        const inChain = new Set(this.chain.map((r) => `${r.provider}|${r.model}`));
        const first = this.availableModels.find((m) => !inChain.has(`${m.provider}|${m.modelId}`));
        if (!first)
            return; // Alles schon in Chain — Button sollte disabled sein
        this.chain = [...this.chain, { provider: first.provider, model: first.modelId }];
        this.emit();
    }
    removeRow(idx) {
        this.chain = this.chain.filter((_, i) => i !== idx);
        this.emit();
    }
    moveUp(idx) {
        if (idx === 0)
            return;
        const next = [...this.chain];
        [next[idx - 1], next[idx]] = [next[idx], next[idx - 1]];
        this.chain = next;
        this.emit();
    }
    moveDown(idx) {
        if (idx >= this.chain.length - 1)
            return;
        const next = [...this.chain];
        [next[idx], next[idx + 1]] = [next[idx + 1], next[idx]];
        this.chain = next;
        this.emit();
    }
    positionLabel() {
        const pos = this.chainPosition ?? 0;
        const entry = this.chain[pos];
        if (!entry)
            return this.L.positionLabel(pos, '–', '–');
        return this.L.positionLabel(pos, entry.provider, entry.model);
    }
    emit() {
        this.chainChanged.emit([...this.chain]);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FailoverChainComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: FailoverChainComponent, isStandalone: true, selector: "ki-failover-chain", inputs: { chain: "chain", availableModels: "availableModels", availableProviders: "availableProviders", chainPosition: "chainPosition", showChainPosition: "showChainPosition", labels: "labels" }, outputs: { chainChanged: "chainChanged", promoteRequested: "promoteRequested" }, ngImport: i0, template: `
    <div>
      <p class="text-sm text-slate-600 dark:text-slate-300 mb-3">
        <strong class="font-semibold text-slate-900 dark:text-slate-100">{{ L.title }}</strong>
        — {{ L.description }}
      </p>

      <div *ngIf="chain.length === 0" class="text-sm italic text-slate-500 dark:text-slate-400 mb-3">
        {{ L.emptyState }}
      </div>

      <div class="space-y-2">
        <div *ngFor="let row of chain; let i = index" class="flex items-center gap-2">
          <span class="w-6 text-xs font-bold text-slate-500 dark:text-slate-400">{{ i + 1 }}.</span>
          <select
            [(ngModel)]="row.provider"
            (change)="onProviderChange(i)"
            class="flex-1 min-w-0 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-2.5 py-1.5 text-sm text-slate-900 dark:text-slate-100"
          >
            <option *ngFor="let p of validProviders()" [value]="p.value">{{ p.label }}</option>
          </select>
          <select
            [(ngModel)]="row.model"
            (change)="emit()"
            class="flex-1 min-w-0 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-2.5 py-1.5 text-sm text-slate-900 dark:text-slate-100"
          >
            <option *ngFor="let m of modelsForRow(row.provider, i)" [value]="m.modelId">{{ m.displayName }}</option>
          </select>
          <button
            type="button"
            (click)="moveUp(i)"
            [disabled]="i === 0"
            [title]="L.moveUpTitle"
            class="w-7 h-7 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-500 hover:bg-slate-300 dark:hover:bg-slate-600 disabled:opacity-40 disabled:cursor-not-allowed transition"
          >↑</button>
          <button
            type="button"
            (click)="moveDown(i)"
            [disabled]="i === chain.length - 1"
            [title]="L.moveDownTitle"
            class="w-7 h-7 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-500 hover:bg-slate-300 dark:hover:bg-slate-600 disabled:opacity-40 disabled:cursor-not-allowed transition"
          >↓</button>
          <button
            type="button"
            (click)="removeRow(i)"
            *ngIf="chain.length > 1"
            [title]="L.removeRowTitle"
            class="w-7 h-7 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-500 hover:bg-red-500 hover:text-white transition"
          >×</button>
        </div>
      </div>

      <button
        type="button"
        (click)="addRow()"
        [disabled]="!canAdd()"
        class="mt-3 px-3 py-1.5 text-xs font-bold rounded-lg border border-dashed border-slate-400 dark:border-slate-600 text-slate-600 dark:text-slate-300 hover:border-slate-950 dark:hover:border-slate-50 hover:text-slate-950 dark:hover:text-slate-50 disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:border-slate-400 disabled:hover:text-slate-600 transition"
      >+ {{ L.addRow }}</button>

      <div *ngIf="showChainPosition" class="flex items-center gap-3 mt-4 pt-3 border-t border-dashed border-slate-300 dark:border-slate-700">
        <span class="text-xs text-slate-500 dark:text-slate-400">{{ L.currentStep }}</span>
        <span class="flex-1 text-sm text-slate-700 dark:text-slate-200">{{ positionLabel() }}</span>
        <button
          type="button"
          *ngIf="(chainPosition ?? 0) > 0"
          (click)="promoteRequested.emit()"
          class="px-3 py-1.5 text-xs font-bold rounded-lg bg-slate-950 dark:bg-slate-50 text-slate-50 dark:text-slate-950 hover:opacity-90 transition"
        >{{ L.promote }}</button>
      </div>

      <p class="mt-3 text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
        {{ L.hint }}
      </p>
    </div>
  `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.NgSelectOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.ɵNgSelectMultipleOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.SelectControlValueAccessor, selector: "select:not([multiple])[formControlName],select:not([multiple])[formControl],select:not([multiple])[ngModel]", inputs: ["compareWith"] }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: FailoverChainComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ki-failover-chain',
                    standalone: true,
                    imports: [CommonModule, FormsModule],
                    template: `
    <div>
      <p class="text-sm text-slate-600 dark:text-slate-300 mb-3">
        <strong class="font-semibold text-slate-900 dark:text-slate-100">{{ L.title }}</strong>
        — {{ L.description }}
      </p>

      <div *ngIf="chain.length === 0" class="text-sm italic text-slate-500 dark:text-slate-400 mb-3">
        {{ L.emptyState }}
      </div>

      <div class="space-y-2">
        <div *ngFor="let row of chain; let i = index" class="flex items-center gap-2">
          <span class="w-6 text-xs font-bold text-slate-500 dark:text-slate-400">{{ i + 1 }}.</span>
          <select
            [(ngModel)]="row.provider"
            (change)="onProviderChange(i)"
            class="flex-1 min-w-0 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-2.5 py-1.5 text-sm text-slate-900 dark:text-slate-100"
          >
            <option *ngFor="let p of validProviders()" [value]="p.value">{{ p.label }}</option>
          </select>
          <select
            [(ngModel)]="row.model"
            (change)="emit()"
            class="flex-1 min-w-0 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-2.5 py-1.5 text-sm text-slate-900 dark:text-slate-100"
          >
            <option *ngFor="let m of modelsForRow(row.provider, i)" [value]="m.modelId">{{ m.displayName }}</option>
          </select>
          <button
            type="button"
            (click)="moveUp(i)"
            [disabled]="i === 0"
            [title]="L.moveUpTitle"
            class="w-7 h-7 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-500 hover:bg-slate-300 dark:hover:bg-slate-600 disabled:opacity-40 disabled:cursor-not-allowed transition"
          >↑</button>
          <button
            type="button"
            (click)="moveDown(i)"
            [disabled]="i === chain.length - 1"
            [title]="L.moveDownTitle"
            class="w-7 h-7 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-500 hover:bg-slate-300 dark:hover:bg-slate-600 disabled:opacity-40 disabled:cursor-not-allowed transition"
          >↓</button>
          <button
            type="button"
            (click)="removeRow(i)"
            *ngIf="chain.length > 1"
            [title]="L.removeRowTitle"
            class="w-7 h-7 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-500 hover:bg-red-500 hover:text-white transition"
          >×</button>
        </div>
      </div>

      <button
        type="button"
        (click)="addRow()"
        [disabled]="!canAdd()"
        class="mt-3 px-3 py-1.5 text-xs font-bold rounded-lg border border-dashed border-slate-400 dark:border-slate-600 text-slate-600 dark:text-slate-300 hover:border-slate-950 dark:hover:border-slate-50 hover:text-slate-950 dark:hover:text-slate-50 disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:border-slate-400 disabled:hover:text-slate-600 transition"
      >+ {{ L.addRow }}</button>

      <div *ngIf="showChainPosition" class="flex items-center gap-3 mt-4 pt-3 border-t border-dashed border-slate-300 dark:border-slate-700">
        <span class="text-xs text-slate-500 dark:text-slate-400">{{ L.currentStep }}</span>
        <span class="flex-1 text-sm text-slate-700 dark:text-slate-200">{{ positionLabel() }}</span>
        <button
          type="button"
          *ngIf="(chainPosition ?? 0) > 0"
          (click)="promoteRequested.emit()"
          class="px-3 py-1.5 text-xs font-bold rounded-lg bg-slate-950 dark:bg-slate-50 text-slate-50 dark:text-slate-950 hover:opacity-90 transition"
        >{{ L.promote }}</button>
      </div>

      <p class="mt-3 text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
        {{ L.hint }}
      </p>
    </div>
  `,
                }]
        }], propDecorators: { chain: [{
                type: Input
            }], availableModels: [{
                type: Input
            }], availableProviders: [{
                type: Input
            }], chainPosition: [{
                type: Input
            }], showChainPosition: [{
                type: Input
            }], labels: [{
                type: Input
            }], chainChanged: [{
                type: Output
            }], promoteRequested: [{
                type: Output
            }] } });

/**
 * Phase S' (2026-05-21) — Wrapper-Komponente die N Cascade-Bereiche als
 * eigenständige Karten rendert. Jeder Bereich hat seine eigene
 * Failover-Chain + Cooldown-Anzeige.
 *
 * **Vertrag:** Backend liefert per {@code GET /cascades} eine Liste der
 * Cascade-Namen mit Stats. Pro Name filtert dieser Wrapper die Modelle aus
 * {@code /ai-models} nach {@code category=name} (plus {@code "general"} als
 * Fallback wenn der Name nicht selbst "general" ist) und übergibt die
 * Subset-Liste der "dummen" `<ki-failover-chain>`.
 *
 * **Reorder-Verhalten:** Wenn der Admin Up/Down innerhalb einer Cascade
 * drückt, mappt der Wrapper das in eine globale `reorderModels()`-Anfrage:
 * er nimmt die aktuelle Globale Liste, swappt nur die beiden Modelle der
 * jeweiligen Cascade, übermittelt die neue globale Reihenfolge.
 *
 * **Backward-Compat:** Wenn das Backend `/cascades` nicht kennt oder `[]`
 * liefert, zeigt die Komponente einen leeren Zustand mit Hinweis-Text
 * (Konsument kann dann auf alte 3-Categories-Tabellen fallback).
 */
class CascadesViewComponent {
    constructor() {
        this.L = CASCADES_VIEW_LABELS_EN;
        /**
         * Optional: Pro Cascade-Name eine Sub-Hint (z.B. „Lehrinhalte, Prüfungen, Chat").
         * Wenn nicht gesetzt, wird der Default-Hint aus `L.defaultHint` genommen.
         */
        this.hintByCascade = {};
        /** Provider-Optionen für das Dropdown im Failover-Editor. */
        this.providerOptions = [
            { value: 'gemini', label: 'Gemini (Google)' },
            { value: 'openai', label: 'OpenAI' },
            { value: 'anthropic', label: 'Anthropic' },
            { value: 'openrouter', label: 'OpenRouter' },
            { value: 'deepseek', label: 'DeepSeek' },
            { value: 'ollama', label: 'Ollama (local)' },
            { value: 'openai_compat', label: 'Custom OpenAI-compatible' },
        ];
        /** Wird emittet wenn der Admin in einer der Cascades reordert oder Modelle tauscht. */
        this.cascadeChanged = new EventEmitter();
        this.api = inject(KiModelsApiService);
        this.loading = signal(true);
        this.cascades = signal([]);
        this.allModels = signal([]);
        /**
         * Display-Metadaten pro Kategorie (v0.10.0). Wird beim init aus
         * `GET {base}/categories` geladen. Wenn der Endpoint nicht existiert
         * (Backward-Compat zu llm-cascade < 0.5), bleibt das Array leer und das
         * UI fällt auf den `[hintByCascade]`-Input bzw. `L.defaultHint` zurück.
         */
        this.categoriesMeta = signal([]);
        /**
         * Inline-Edit-State: Name der Kategorie die gerade editiert wird (oder
         * `null` wenn kein Edit aktiv). `editText` ist der aktuelle Textarea-Wert.
         * `saving` blockiert die Buttons während des PUT-Roundtrips.
         */
        this.editing = signal(null);
        this.editText = '';
        this.saving = signal(false);
        /**
         * v0.11.2 — separates Edit-State für displayName. Title + Description
         * können nicht gleichzeitig editiert werden — das Edit-Modell ist
         * exclusive pro Cascade-Card.
         */
        this.editingTitle = signal(null);
        this.editTitleText = '';
        this.savingTitle = signal(false);
        /**
         * v0.11.1 — beim Klick auf das Trash-Icon wird der Cascade-Name hier
         * gespeichert bis der DELETE-Roundtrip durch ist. So koennen wir nur den
         * gerade in Bearbeitung befindlichen Button disablen, nicht alle.
         */
        this.deletingMeta = signal(null);
        /**
         * Pro Cascade-Name die Chain (Array<{provider, model}>) als computed-Signal.
         * Stabile Referenz solange sich allModels nicht ändert — verhindert CD-Storms
         * im Failover-Chain-Child und stellt sicher dass die Berechnung erst läuft
         * wenn allModels wirklich befüllt ist.
         */
        this.chainsByCascade = computed(() => {
            const result = {};
            const models = this.allModels();
            const enabledOnly = models.filter(m => m.enabled && !m.autoDisabled);
            for (const c of this.cascades()) {
                const name = c.name.toLowerCase();
                const subset = enabledOnly.filter(m => {
                    const cat = (m.category ?? 'general').toLowerCase();
                    return cat === name || (name !== 'general' && cat === 'general');
                });
                result[c.name] = subset.map(m => ({ provider: m.provider, model: m.modelId }));
            }
            return result;
        });
        /** Provider-Modell-Dropdown-Optionen, ebenfalls als computed (stable ref). */
        this.availableModelsAll = computed(() => {
            return this.allModels()
                .filter(m => m.enabled && !m.autoDisabled)
                .map(m => ({
                provider: m.provider,
                modelId: m.modelId,
                displayName: m.displayName ?? m.modelId,
            }));
        });
    }
    set labels(v) {
        this.L = { ...CASCADES_VIEW_LABELS_EN, ...(v ?? {}) };
    }
    ngOnInit() {
        this.reload();
    }
    reload() {
        this.loading.set(true);
        // Parallel laden — Cascades-Stats + Modelle (für Filter pro Cascade) +
        // Categories-Display-Metadaten (v0.10.0). `firstValueFrom` statt
        // `.toPromise()`. Categories ist optional (404 → leer fallback).
        Promise.all([
            firstValueFrom(this.api.listCascades()).catch(() => []),
            firstValueFrom(this.api.listModels()).catch(() => []),
            firstValueFrom(this.api.listCategories()).catch(() => []),
        ]).then(([cs, ms, cats]) => {
            this.cascades.set(Array.isArray(cs) ? cs : []);
            this.allModels.set(Array.isArray(ms) ? ms : []);
            this.categoriesMeta.set(Array.isArray(cats) ? cats : []);
            this.loading.set(false);
        });
    }
    /**
     * Title-Lookup-Reihenfolge:
     *   1. `displayName` aus den Categories-Metadaten (User hat's gesetzt)
     *   2. Roher Cascade-Name (rückwärtskompatibel, bisheriges Verhalten)
     *
     * Der Cascade-Name selbst kommt vom Backend `/cascades` und ist bereits
     * der Kategorie-Identifier — wir capitalisieren ihn NICHT zusätzlich, weil
     * die alten UIs ihn bereits via `uppercase`-CSS rendern.
     */
    titleFor(cascadeName) {
        const meta = this.categoriesMeta().find(c => c.name === cascadeName.toLowerCase());
        return meta?.displayName?.trim() || cascadeName;
    }
    /**
     * Hint-Lookup-Reihenfolge:
     *   1. `description` aus den Categories-Metadaten (User-edit per Inline-Edit)
     *   2. `[hintByCascade]`-Input vom Konsumenten (sein hardcoded Default)
     *   3. `L.defaultHint` (Library-Englisch-Fallback)
     */
    hintFor(cascadeName) {
        const key = cascadeName.toLowerCase();
        const meta = this.categoriesMeta().find(c => c.name === key);
        return meta?.description?.trim()
            || this.hintByCascade[key]
            || this.L.defaultHint;
    }
    /** Klick auf den Hint → Edit-Mode aktivieren mit aktuellem Wert vorbefüllt. */
    startEdit(cascadeName) {
        const key = cascadeName.toLowerCase();
        const meta = this.categoriesMeta().find(c => c.name === key);
        // Vorgeladener Text: NUR die persistierte description, NICHT der Konsumenten-
        // Default — User soll nicht versehentlich den Hardcode festschreiben.
        this.editText = meta?.description ?? '';
        this.editing.set(cascadeName);
    }
    /** Escape oder Cancel-Button → Edit-Mode verlassen ohne Save. */
    cancelEdit() {
        this.editing.set(null);
        this.editText = '';
    }
    /**
     * Save-Button (oder Enter): PUT der neuen description an
     * `/categories/{name}`. Leerer String → wird als `null` gesendet
     * (Backend löscht das Feld), damit der Konsument-Default wieder greift.
     */
    saveEdit(cascadeName) {
        const key = cascadeName.toLowerCase();
        const trimmed = (this.editText ?? '').trim();
        this.saving.set(true);
        this.api.updateCategory(key, {
            description: trimmed.length === 0 ? null : trimmed,
        }).subscribe({
            next: () => {
                // Lokale Metadaten-Liste sofort patchen damit die UI ohne Reload
                // den neuen Wert zeigt — der nächste reload() würde es zwar auch
                // holen, aber der UX-Lag wäre sichtbar.
                const list = [...this.categoriesMeta()];
                const idx = list.findIndex(c => c.name === key);
                if (idx >= 0) {
                    list[idx] = { ...list[idx], description: trimmed || null };
                }
                else {
                    list.push({ name: key, description: trimmed || null });
                }
                this.categoriesMeta.set(list);
                this.editing.set(null);
                this.editText = '';
                this.saving.set(false);
            },
            error: (e) => {
                console.error('[ki-cascades-view] saveEdit failed', e);
                this.saving.set(false);
            },
        });
    }
    hasCooldown(c) {
        return c.cooldownSec && Object.keys(c.cooldownSec).length > 0;
    }
    /**
     * v0.11.2 — Inline-Edit für displayName. Click auf den Title öffnet ein
     * Input-Feld. Persistiert via PUT /api/categories/{name} mit nur dem
     * displayName-Feld (description bleibt unangetastet).
     */
    startEditTitle(cascadeName) {
        const key = cascadeName.toLowerCase();
        const meta = this.categoriesMeta().find(c => c.name === key);
        // Vorgeladener Text: NUR der persistierte displayName, NICHT der
        // capitalized Fallback — User soll nicht versehentlich den Fallback
        // als seinen eigenen Wert festschreiben.
        this.editTitleText = meta?.displayName ?? '';
        this.editingTitle.set(cascadeName);
    }
    cancelEditTitle() {
        this.editingTitle.set(null);
        this.editTitleText = '';
    }
    saveEditTitle(cascadeName) {
        const key = cascadeName.toLowerCase();
        const trimmed = (this.editTitleText ?? '').trim();
        this.savingTitle.set(true);
        this.api.updateCategory(key, {
            displayName: trimmed.length === 0 ? null : trimmed,
        }).subscribe({
            next: () => {
                const list = [...this.categoriesMeta()];
                const idx = list.findIndex(c => c.name === key);
                if (idx >= 0) {
                    list[idx] = { ...list[idx], displayName: trimmed || null };
                }
                else {
                    list.push({ name: key, displayName: trimmed || null });
                }
                this.categoriesMeta.set(list);
                this.editingTitle.set(null);
                this.editTitleText = '';
                this.savingTitle.set(false);
            },
            error: (e) => {
                console.error('[ki-cascades-view] saveEditTitle failed', e);
                this.savingTitle.set(false);
            },
        });
    }
    /**
     * v0.11.1 — true wenn fuer diese Kategorie eine `category_meta`-Zeile
     * im Backend existiert (User hat displayName oder description gesetzt).
     * Trash-Icon wird nur dann angezeigt — sonst gaebe es nichts zu loeschen.
     */
    hasMeta(cascadeName) {
        const key = cascadeName.toLowerCase();
        const meta = this.categoriesMeta().find(c => c.name === key);
        if (!meta)
            return false;
        const hasTitle = !!meta.displayName && meta.displayName.trim().length > 0;
        const hasDesc = !!meta.description && meta.description.trim().length > 0;
        return hasTitle || hasDesc;
    }
    /**
     * v0.11.1 — DELETE der `category_meta`-Zeile. Modelle bleiben unangetastet,
     * der Cascade-Bereich verschwindet erst wenn auch die Modelle weg sind
     * (oder umkategoriiert wurden). Nach Erfolg lokales Patchen + Reload.
     */
    deleteMeta(cascadeName) {
        const key = cascadeName.toLowerCase();
        if (!confirm(this.L.deleteMetaConfirm(this.titleFor(cascadeName))))
            return;
        this.deletingMeta.set(key);
        this.api.deleteCategoryMeta(key).subscribe({
            next: () => {
                // Lokal patchen damit Title + Description sofort auf Fallback gehen
                const list = this.categoriesMeta().map(c => c.name === key ? { ...c, displayName: null, description: null } : c);
                this.categoriesMeta.set(list);
                this.deletingMeta.set(null);
            },
            error: (e) => {
                console.error('[ki-cascades-view] deleteMeta failed', e);
                this.deletingMeta.set(null);
            },
        });
    }
    cooldownEntries(c) {
        return Object.entries(c.cooldownSec || {})
            .map(([key, sec]) => ({ key, sec: sec }));
    }
    /**
     * Cascade-scoped Reorder: nimmt die neue Cascade-spezifische Chain vom
     * Failover-Editor und übersetzt das in eine globale `reorderModels()`-
     * Anfrage. Die globale Liste wird so umsortiert, dass die Position der
     * cascade-eigenen Modelle der neuen Reihenfolge entspricht; alle anderen
     * Modelle bleiben in ihrer relativen Position.
     */
    onChainChanged(cascadeName, newChain) {
        const global = this.allModels();
        const idsInChain = new Set();
        const orderedCascadeIds = [];
        // Map ChainEntry → DB-id
        for (const entry of newChain) {
            const found = global.find(m => m.provider === entry.provider && m.modelId === entry.model);
            if (found) {
                idsInChain.add(found.id);
                orderedCascadeIds.push(found.id);
            }
        }
        // Globale Liste neu komponieren: bei den cascade-Slots in der globalen
        // Reihenfolge die neue cascade-Order einsetzen, fremde Modelle behalten
        // ihre Position.
        const newGlobalOrder = [];
        let cascadeIdx = 0;
        for (const m of global) {
            if (idsInChain.has(m.id)) {
                newGlobalOrder.push(orderedCascadeIds[cascadeIdx++]);
            }
            else {
                newGlobalOrder.push(m.id);
            }
        }
        this.api.reorderModels(newGlobalOrder).subscribe({
            next: () => {
                this.cascadeChanged.emit({ cascadeName, chain: newChain });
                this.reload();
            },
            error: (e) => console.error('[ki-cascades-view] reorder failed', e),
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CascadesViewComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: CascadesViewComponent, isStandalone: true, selector: "ki-cascades-view", inputs: { labels: "labels", chainLabels: "chainLabels", hintByCascade: "hintByCascade", providerOptions: "providerOptions" }, outputs: { cascadeChanged: "cascadeChanged" }, ngImport: i0, template: `
    <div class="space-y-6">
      <!-- Loading -->
      <div *ngIf="loading()" class="text-sm italic text-slate-500">
        {{ L.loading }}
      </div>

      <!-- Empty state — Backend liefert kein /cascades oder leere Liste -->
      <div *ngIf="!loading() && cascades().length === 0"
           class="rounded-2xl border-2 border-dashed border-slate-300 dark:border-slate-700 p-6 text-center text-sm text-slate-500 dark:text-slate-400">
        <p class="font-medium">{{ L.empty }}</p>
        <p class="mt-1 text-xs">{{ L.emptyHint }}</p>
      </div>

      <!-- Cascade-Karten — eine pro Bereich -->
      <div *ngIf="!loading() && cascades().length > 0"
           class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <article *ngFor="let c of cascades()"
                 class="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm">
          <!-- Header -->
          <header class="mb-4 flex items-start justify-between gap-3">
            <div class="flex-1 min-w-0">
              <!-- Inline-Edit für displayName (v0.11.2). Click auf den Title →
                   Input. Enter speichert, Escape bricht ab. -->
              <ng-container *ngIf="editingTitle() !== c.name">
                <h3 class="text-lg font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wide cursor-pointer hover:text-emerald-700 dark:hover:text-emerald-400 transition"
                    [title]="L.editTitleTooltip"
                    (click)="startEditTitle(c.name)">
                  {{ titleFor(c.name) }}
                </h3>
              </ng-container>
              <ng-container *ngIf="editingTitle() === c.name">
                <input type="text"
                       class="w-full text-lg font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wide px-2 py-1 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                       [(ngModel)]="editTitleText"
                       [placeholder]="L.editTitlePlaceholder"
                       (keydown.enter)="$event.preventDefault(); saveEditTitle(c.name)"
                       (keydown.escape)="cancelEditTitle()"
                       autofocus />
                <div class="mt-1 flex gap-2 text-[10px]">
                  <button (click)="saveEditTitle(c.name)"
                          [disabled]="savingTitle()"
                          class="px-2 py-0.5 rounded bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold uppercase tracking-wide">
                    {{ L.editHintSave }}
                  </button>
                  <button (click)="cancelEditTitle()"
                          [disabled]="savingTitle()"
                          class="px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 disabled:opacity-50 text-slate-700 dark:text-slate-200 font-bold uppercase tracking-wide">
                    {{ L.editHintCancel }}
                  </button>
                </div>
              </ng-container>

              <!-- Inline-Edit für description (v0.10.0). Click auf den Text →
                   Textarea. Enter speichert, Escape bricht ab, Blur speichert.
                   Während Edit ist hint via 'editing()'-Signal blockiert. -->
              <ng-container *ngIf="editing() !== c.name">
                <p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5 cursor-pointer hover:text-slate-700 dark:hover:text-slate-200 transition"
                   [title]="L.editHintTooltip"
                   (click)="startEdit(c.name)">
                  {{ hintFor(c.name) }}
                </p>
              </ng-container>
              <ng-container *ngIf="editing() === c.name">
                <textarea
                  class="mt-1 w-full text-xs px-2 py-1.5 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  rows="2"
                  [(ngModel)]="editText"
                  [placeholder]="L.editHintPlaceholder"
                  (keydown.enter)="$event.preventDefault(); saveEdit(c.name)"
                  (keydown.escape)="cancelEdit()"
                  #editArea
                  autofocus></textarea>
                <div class="mt-1 flex gap-2 text-[10px]">
                  <button (click)="saveEdit(c.name)"
                          [disabled]="saving()"
                          class="px-2 py-0.5 rounded bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold uppercase tracking-wide">
                    {{ L.editHintSave }}
                  </button>
                  <button (click)="cancelEdit()"
                          [disabled]="saving()"
                          class="px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 disabled:opacity-50 text-slate-700 dark:text-slate-200 font-bold uppercase tracking-wide">
                    {{ L.editHintCancel }}
                  </button>
                </div>
              </ng-container>
            </div>
            <div class="shrink-0 flex items-center gap-1.5">
              <span *ngIf="c.currentModel"
                    class="text-[10px] font-mono px-2 py-1 rounded-md bg-emerald-100 dark:bg-emerald-900/50 text-emerald-700 dark:text-emerald-300">
                ● {{ c.currentModel }}
              </span>
              <!-- v0.11.1 — Trash-Icon zum Loeschen der category_meta-Zeile
                   (displayName + description). Sichtbar nur wenn die Cascade
                   ueberhaupt Custom-Texte hat (sonst gibts nichts zu loeschen).
                   Modelle bleiben unangetastet — User muss die ueber die
                   Models-Tabelle einzeln entfernen. -->
              <button *ngIf="hasMeta(c.name)"
                      (click)="deleteMeta(c.name)"
                      [disabled]="deletingMeta() === c.name || editing() === c.name"
                      [title]="L.deleteMetaTooltip"
                      class="text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 disabled:opacity-40 disabled:cursor-not-allowed text-base leading-none p-1 rounded transition">
                ✕
              </button>
            </div>
          </header>

          <!-- Failover-Chain Editor pro Cascade -->
          <ki-failover-chain
            [chain]="chainsByCascade()[c.name] || []"
            [availableModels]="availableModelsAll()"
            [availableProviders]="providerOptions"
            [labels]="chainLabels"
            (chainChanged)="onChainChanged(c.name, $event)">
          </ki-failover-chain>

          <!-- Cooldown-Anzeige pro Modell -->
          <div *ngIf="hasCooldown(c)" class="mt-4 pt-4 border-t border-slate-200 dark:border-slate-800">
            <p class="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
              {{ L.cooldownTitle }}
            </p>
            <div class="space-y-1">
              <div *ngFor="let entry of cooldownEntries(c)"
                   class="flex items-center justify-between text-xs">
                <code class="font-mono text-slate-700 dark:text-slate-300">{{ entry.key }}</code>
                <span [class.text-emerald-600]="entry.sec === 0"
                      [class.text-amber-600]="entry.sec > 0"
                      class="font-bold">
                  {{ entry.sec === 0 ? L.statusFree : (L.statusCooldown + ' ' + entry.sec + 's') }}
                </span>
              </div>
            </div>
          </div>
        </article>
      </div>
    </div>
  `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: FailoverChainComponent, selector: "ki-failover-chain", inputs: ["chain", "availableModels", "availableProviders", "chainPosition", "showChainPosition", "labels"], outputs: ["chainChanged", "promoteRequested"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: CascadesViewComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-cascades-view', standalone: true, imports: [CommonModule, FormsModule, FailoverChainComponent], template: `
    <div class="space-y-6">
      <!-- Loading -->
      <div *ngIf="loading()" class="text-sm italic text-slate-500">
        {{ L.loading }}
      </div>

      <!-- Empty state — Backend liefert kein /cascades oder leere Liste -->
      <div *ngIf="!loading() && cascades().length === 0"
           class="rounded-2xl border-2 border-dashed border-slate-300 dark:border-slate-700 p-6 text-center text-sm text-slate-500 dark:text-slate-400">
        <p class="font-medium">{{ L.empty }}</p>
        <p class="mt-1 text-xs">{{ L.emptyHint }}</p>
      </div>

      <!-- Cascade-Karten — eine pro Bereich -->
      <div *ngIf="!loading() && cascades().length > 0"
           class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <article *ngFor="let c of cascades()"
                 class="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm">
          <!-- Header -->
          <header class="mb-4 flex items-start justify-between gap-3">
            <div class="flex-1 min-w-0">
              <!-- Inline-Edit für displayName (v0.11.2). Click auf den Title →
                   Input. Enter speichert, Escape bricht ab. -->
              <ng-container *ngIf="editingTitle() !== c.name">
                <h3 class="text-lg font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wide cursor-pointer hover:text-emerald-700 dark:hover:text-emerald-400 transition"
                    [title]="L.editTitleTooltip"
                    (click)="startEditTitle(c.name)">
                  {{ titleFor(c.name) }}
                </h3>
              </ng-container>
              <ng-container *ngIf="editingTitle() === c.name">
                <input type="text"
                       class="w-full text-lg font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wide px-2 py-1 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                       [(ngModel)]="editTitleText"
                       [placeholder]="L.editTitlePlaceholder"
                       (keydown.enter)="$event.preventDefault(); saveEditTitle(c.name)"
                       (keydown.escape)="cancelEditTitle()"
                       autofocus />
                <div class="mt-1 flex gap-2 text-[10px]">
                  <button (click)="saveEditTitle(c.name)"
                          [disabled]="savingTitle()"
                          class="px-2 py-0.5 rounded bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold uppercase tracking-wide">
                    {{ L.editHintSave }}
                  </button>
                  <button (click)="cancelEditTitle()"
                          [disabled]="savingTitle()"
                          class="px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 disabled:opacity-50 text-slate-700 dark:text-slate-200 font-bold uppercase tracking-wide">
                    {{ L.editHintCancel }}
                  </button>
                </div>
              </ng-container>

              <!-- Inline-Edit für description (v0.10.0). Click auf den Text →
                   Textarea. Enter speichert, Escape bricht ab, Blur speichert.
                   Während Edit ist hint via 'editing()'-Signal blockiert. -->
              <ng-container *ngIf="editing() !== c.name">
                <p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5 cursor-pointer hover:text-slate-700 dark:hover:text-slate-200 transition"
                   [title]="L.editHintTooltip"
                   (click)="startEdit(c.name)">
                  {{ hintFor(c.name) }}
                </p>
              </ng-container>
              <ng-container *ngIf="editing() === c.name">
                <textarea
                  class="mt-1 w-full text-xs px-2 py-1.5 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  rows="2"
                  [(ngModel)]="editText"
                  [placeholder]="L.editHintPlaceholder"
                  (keydown.enter)="$event.preventDefault(); saveEdit(c.name)"
                  (keydown.escape)="cancelEdit()"
                  #editArea
                  autofocus></textarea>
                <div class="mt-1 flex gap-2 text-[10px]">
                  <button (click)="saveEdit(c.name)"
                          [disabled]="saving()"
                          class="px-2 py-0.5 rounded bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold uppercase tracking-wide">
                    {{ L.editHintSave }}
                  </button>
                  <button (click)="cancelEdit()"
                          [disabled]="saving()"
                          class="px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 disabled:opacity-50 text-slate-700 dark:text-slate-200 font-bold uppercase tracking-wide">
                    {{ L.editHintCancel }}
                  </button>
                </div>
              </ng-container>
            </div>
            <div class="shrink-0 flex items-center gap-1.5">
              <span *ngIf="c.currentModel"
                    class="text-[10px] font-mono px-2 py-1 rounded-md bg-emerald-100 dark:bg-emerald-900/50 text-emerald-700 dark:text-emerald-300">
                ● {{ c.currentModel }}
              </span>
              <!-- v0.11.1 — Trash-Icon zum Loeschen der category_meta-Zeile
                   (displayName + description). Sichtbar nur wenn die Cascade
                   ueberhaupt Custom-Texte hat (sonst gibts nichts zu loeschen).
                   Modelle bleiben unangetastet — User muss die ueber die
                   Models-Tabelle einzeln entfernen. -->
              <button *ngIf="hasMeta(c.name)"
                      (click)="deleteMeta(c.name)"
                      [disabled]="deletingMeta() === c.name || editing() === c.name"
                      [title]="L.deleteMetaTooltip"
                      class="text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 disabled:opacity-40 disabled:cursor-not-allowed text-base leading-none p-1 rounded transition">
                ✕
              </button>
            </div>
          </header>

          <!-- Failover-Chain Editor pro Cascade -->
          <ki-failover-chain
            [chain]="chainsByCascade()[c.name] || []"
            [availableModels]="availableModelsAll()"
            [availableProviders]="providerOptions"
            [labels]="chainLabels"
            (chainChanged)="onChainChanged(c.name, $event)">
          </ki-failover-chain>

          <!-- Cooldown-Anzeige pro Modell -->
          <div *ngIf="hasCooldown(c)" class="mt-4 pt-4 border-t border-slate-200 dark:border-slate-800">
            <p class="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
              {{ L.cooldownTitle }}
            </p>
            <div class="space-y-1">
              <div *ngFor="let entry of cooldownEntries(c)"
                   class="flex items-center justify-between text-xs">
                <code class="font-mono text-slate-700 dark:text-slate-300">{{ entry.key }}</code>
                <span [class.text-emerald-600]="entry.sec === 0"
                      [class.text-amber-600]="entry.sec > 0"
                      class="font-bold">
                  {{ entry.sec === 0 ? L.statusFree : (L.statusCooldown + ' ' + entry.sec + 's') }}
                </span>
              </div>
            </div>
          </div>
        </article>
      </div>
    </div>
  ` }]
        }], propDecorators: { labels: [{
                type: Input
            }], chainLabels: [{
                type: Input
            }], hintByCascade: [{
                type: Input
            }], providerOptions: [{
                type: Input
            }], cascadeChanged: [{
                type: Output
            }] } });

/**
 * Admin-Component fuer Semantic Routing (Phase v0.11.0).
 *
 * Zeigt:
 *   - Counter-Stats (hits / misses / failures / cacheSize)
 *   - Liste aller Cache-Eintraege (purpose preview, gewaehlte Kategorie,
 *     Alter, Restlebenszeit) mit "X"-Button pro Eintrag
 *   - "Cache komplett leeren"-Button
 *   - Test-Preview-Input: tippe eine Task-Beschreibung, sieh welche Kategorie
 *     der Router waehlen wuerde (cached danach)
 *
 * Konsumenten-Setup: gleicher `KI_MODELS_API_BASE` wie die anderen Components.
 * Wenn das Backend < 0.6.0 ist (kein /routing-Endpoint), faellt es auf eine
 * leere Liste + Hinweistext zurueck statt Crash.
 */
class RoutingDecisionsComponent {
    constructor() {
        this.api = inject(KiModelsApiService);
        this.cache = signal(null);
        this.loading = signal(true);
        this.testing = signal(false);
        this.testResult = signal(null);
        this.testPurpose = '';
        /** Konsumenten-i18n-Override. Default = englische Labels. */
        this.L = ROUTING_DECISIONS_LABELS_EN;
    }
    set labels(v) {
        this.L = { ...ROUTING_DECISIONS_LABELS_EN, ...(v ?? {}) };
    }
    ngOnInit() {
        this.reload();
    }
    reload() {
        this.loading.set(true);
        this.api.getRoutingCache().subscribe({
            next: (c) => {
                this.cache.set(c);
                this.loading.set(false);
            },
            error: () => {
                // Backend ohne Routing-Endpoint — leere Liste, kein Crash
                this.cache.set({
                    stats: { cacheSize: 0, cacheCapacity: 0, ttlSeconds: 0, hits: 0, misses: 0, failures: 0 },
                    entries: [],
                });
                this.loading.set(false);
            },
        });
    }
    runTest() {
        const purpose = this.testPurpose.trim();
        if (!purpose)
            return;
        this.testing.set(true);
        this.testResult.set(null);
        firstValueFrom(this.api.testRouting(purpose))
            .then((r) => {
            this.testResult.set(r);
            this.testing.set(false);
            this.reload();
        })
            .catch(() => this.testing.set(false));
    }
    clearAll() {
        if (!confirm(this.L.confirmClearAll))
            return;
        this.api.clearRoutingCache().subscribe(() => this.reload());
    }
    clearOne(e) {
        this.api.clearRoutingCacheEntry(e.purposeHash).subscribe(() => this.reload());
    }
    /** Sekunden → "23h 45m" / "12m 30s" / "45s". */
    formatDuration(seconds) {
        if (seconds <= 0)
            return '–';
        const h = Math.floor(seconds / 3600);
        const m = Math.floor((seconds % 3600) / 60);
        const s = seconds % 60;
        if (h > 0)
            return `${h}h ${m}m`;
        if (m > 0)
            return `${m}m ${s}s`;
        return `${s}s`;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: RoutingDecisionsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: RoutingDecisionsComponent, isStandalone: true, selector: "ki-routing-decisions", ngImport: i0, template: `
    <div class="ki-routing">
      <h4 class="ki-title">{{ L.title }}</h4>
      <p class="ki-subtitle">{{ L.subtitle }}</p>

      <!-- Stats-Zeile -->
      <div class="ki-stats" *ngIf="cache() as c">
        <div class="ki-stat">
          <div class="ki-stat-num">{{ c.stats.cacheSize }}</div>
          <div class="ki-stat-label">{{ L.statSize }} / {{ c.stats.cacheCapacity }}</div>
        </div>
        <div class="ki-stat">
          <div class="ki-stat-num ki-ok">{{ c.stats.hits }}</div>
          <div class="ki-stat-label">{{ L.statHits }}</div>
        </div>
        <div class="ki-stat">
          <div class="ki-stat-num">{{ c.stats.misses }}</div>
          <div class="ki-stat-label">{{ L.statMisses }}</div>
        </div>
        <div class="ki-stat">
          <div class="ki-stat-num ki-warn">{{ c.stats.failures }}</div>
          <div class="ki-stat-label">{{ L.statFailures }}</div>
        </div>
      </div>

      <!-- Test-Preview -->
      <div class="ki-test-box">
        <label class="ki-test-label">{{ L.testLabel }}</label>
        <div class="ki-test-row">
          <input [(ngModel)]="testPurpose"
                 [placeholder]="L.testPlaceholder"
                 class="ki-input"
                 (keydown.enter)="runTest()" />
          <button (click)="runTest()"
                  [disabled]="testing() || !testPurpose.trim()"
                  class="ki-btn-primary">
            {{ testing() ? L.testing : L.btnTest }}
          </button>
        </div>
        <p *ngIf="testResult() as r" class="ki-test-result">
          → <strong>{{ r.category }}</strong>
          <span class="ki-muted">({{ r.latencyMs }}ms)</span>
        </p>
      </div>

      <!-- Cache-Liste -->
      <div class="ki-cache-header">
        <span>{{ L.entriesTitle }}</span>
        <button (click)="clearAll()"
                [disabled]="!cache()?.entries?.length"
                class="ki-btn-secondary">
          {{ L.btnClearAll }}
        </button>
      </div>

      <p *ngIf="loading()" class="ki-muted ki-tiny">{{ L.loading }}</p>
      <p *ngIf="!loading() && !(cache()?.entries?.length)" class="ki-empty">{{ L.empty }}</p>

      <table class="ki-table" *ngIf="(cache()?.entries?.length ?? 0) > 0">
        <thead>
          <tr>
            <th>{{ L.colPurpose }}</th>
            <th>{{ L.colCategory }}</th>
            <th>{{ L.colExpires }}</th>
            <th class="ki-right">{{ L.colActions }}</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let e of cache()?.entries">
            <td class="ki-truncate" [title]="e.purpose">{{ e.purpose }}</td>
            <td><span class="ki-pill">{{ e.category }}</span></td>
            <td class="ki-tiny ki-muted">{{ formatDuration(e.expiresInSeconds) }}</td>
            <td class="ki-right">
              <button (click)="clearOne(e)" class="ki-btn-icon" [title]="L.btnClearOne">✕</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  `, isInline: true, styles: [".ki-routing{font-family:inherit;padding:1rem 0}.ki-title{font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#475569;margin:0 0 .25rem}.ki-subtitle{font-size:.75rem;color:#94a3b8;margin:0 0 1rem}.ki-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:.75rem;margin-bottom:1rem}.ki-stat{background:#f8fafc;border-radius:.75rem;padding:.75rem;text-align:center}.ki-stat-num{font-size:1.5rem;font-weight:800;color:#0f172a}.ki-stat-num.ki-ok{color:#059669}.ki-stat-num.ki-warn{color:#d97706}.ki-stat-label{font-size:.625rem;text-transform:uppercase;letter-spacing:.05em;font-weight:800;color:#64748b}.ki-test-box{background:#f1f5f9;border-radius:.75rem;padding:.75rem;margin-bottom:1rem}.ki-test-label{display:block;font-size:.7rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;color:#475569;margin-bottom:.5rem}.ki-test-row{display:flex;gap:.5rem}.ki-test-row .ki-input{flex:1}.ki-test-result{font-size:.875rem;margin:.5rem 0 0;color:#0f172a}.ki-cache-header{display:flex;justify-content:space-between;align-items:center;font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#475569;margin-bottom:.5rem}.ki-input{padding:.6rem;background:#fff;border:2px solid #e2e8f0;border-radius:.5rem;font-size:.875rem}.ki-btn-primary{padding:.6rem 1rem;background:#0f172a;color:#fff;border:none;border-radius:.5rem;font-size:.7rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;cursor:pointer}.ki-btn-primary:disabled{opacity:.4;cursor:not-allowed}.ki-btn-secondary{padding:.3rem .7rem;background:#fee2e2;color:#991b1b;border:none;border-radius:.375rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;cursor:pointer}.ki-btn-secondary:disabled{opacity:.3;cursor:not-allowed}.ki-btn-icon{background:transparent;border:none;color:#94a3b8;cursor:pointer;font-size:1rem;padding:.2rem .4rem}.ki-btn-icon:hover{color:#ef4444}.ki-table{width:100%;border-collapse:collapse;font-size:.875rem}.ki-table thead tr{border-bottom:2px solid #e2e8f0}.ki-table th{padding:.5rem;text-align:left;text-transform:uppercase;font-size:.6rem;font-weight:800;letter-spacing:.1em;color:#64748b}.ki-table td{padding:.5rem;border-bottom:1px solid #f1f5f9;vertical-align:middle}.ki-truncate{max-width:400px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ki-right{text-align:right}.ki-pill{display:inline-block;padding:.15rem .5rem;border-radius:.25rem;background:#e0e7ff;color:#3730a3;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em}.ki-muted{color:#94a3b8}.ki-tiny{font-size:.7rem}.ki-empty{text-align:center;color:#94a3b8;padding:1rem;font-size:.85rem}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: RoutingDecisionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-routing-decisions', standalone: true, imports: [CommonModule, FormsModule], template: `
    <div class="ki-routing">
      <h4 class="ki-title">{{ L.title }}</h4>
      <p class="ki-subtitle">{{ L.subtitle }}</p>

      <!-- Stats-Zeile -->
      <div class="ki-stats" *ngIf="cache() as c">
        <div class="ki-stat">
          <div class="ki-stat-num">{{ c.stats.cacheSize }}</div>
          <div class="ki-stat-label">{{ L.statSize }} / {{ c.stats.cacheCapacity }}</div>
        </div>
        <div class="ki-stat">
          <div class="ki-stat-num ki-ok">{{ c.stats.hits }}</div>
          <div class="ki-stat-label">{{ L.statHits }}</div>
        </div>
        <div class="ki-stat">
          <div class="ki-stat-num">{{ c.stats.misses }}</div>
          <div class="ki-stat-label">{{ L.statMisses }}</div>
        </div>
        <div class="ki-stat">
          <div class="ki-stat-num ki-warn">{{ c.stats.failures }}</div>
          <div class="ki-stat-label">{{ L.statFailures }}</div>
        </div>
      </div>

      <!-- Test-Preview -->
      <div class="ki-test-box">
        <label class="ki-test-label">{{ L.testLabel }}</label>
        <div class="ki-test-row">
          <input [(ngModel)]="testPurpose"
                 [placeholder]="L.testPlaceholder"
                 class="ki-input"
                 (keydown.enter)="runTest()" />
          <button (click)="runTest()"
                  [disabled]="testing() || !testPurpose.trim()"
                  class="ki-btn-primary">
            {{ testing() ? L.testing : L.btnTest }}
          </button>
        </div>
        <p *ngIf="testResult() as r" class="ki-test-result">
          → <strong>{{ r.category }}</strong>
          <span class="ki-muted">({{ r.latencyMs }}ms)</span>
        </p>
      </div>

      <!-- Cache-Liste -->
      <div class="ki-cache-header">
        <span>{{ L.entriesTitle }}</span>
        <button (click)="clearAll()"
                [disabled]="!cache()?.entries?.length"
                class="ki-btn-secondary">
          {{ L.btnClearAll }}
        </button>
      </div>

      <p *ngIf="loading()" class="ki-muted ki-tiny">{{ L.loading }}</p>
      <p *ngIf="!loading() && !(cache()?.entries?.length)" class="ki-empty">{{ L.empty }}</p>

      <table class="ki-table" *ngIf="(cache()?.entries?.length ?? 0) > 0">
        <thead>
          <tr>
            <th>{{ L.colPurpose }}</th>
            <th>{{ L.colCategory }}</th>
            <th>{{ L.colExpires }}</th>
            <th class="ki-right">{{ L.colActions }}</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let e of cache()?.entries">
            <td class="ki-truncate" [title]="e.purpose">{{ e.purpose }}</td>
            <td><span class="ki-pill">{{ e.category }}</span></td>
            <td class="ki-tiny ki-muted">{{ formatDuration(e.expiresInSeconds) }}</td>
            <td class="ki-right">
              <button (click)="clearOne(e)" class="ki-btn-icon" [title]="L.btnClearOne">✕</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  `, styles: [".ki-routing{font-family:inherit;padding:1rem 0}.ki-title{font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#475569;margin:0 0 .25rem}.ki-subtitle{font-size:.75rem;color:#94a3b8;margin:0 0 1rem}.ki-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:.75rem;margin-bottom:1rem}.ki-stat{background:#f8fafc;border-radius:.75rem;padding:.75rem;text-align:center}.ki-stat-num{font-size:1.5rem;font-weight:800;color:#0f172a}.ki-stat-num.ki-ok{color:#059669}.ki-stat-num.ki-warn{color:#d97706}.ki-stat-label{font-size:.625rem;text-transform:uppercase;letter-spacing:.05em;font-weight:800;color:#64748b}.ki-test-box{background:#f1f5f9;border-radius:.75rem;padding:.75rem;margin-bottom:1rem}.ki-test-label{display:block;font-size:.7rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;color:#475569;margin-bottom:.5rem}.ki-test-row{display:flex;gap:.5rem}.ki-test-row .ki-input{flex:1}.ki-test-result{font-size:.875rem;margin:.5rem 0 0;color:#0f172a}.ki-cache-header{display:flex;justify-content:space-between;align-items:center;font-size:.75rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#475569;margin-bottom:.5rem}.ki-input{padding:.6rem;background:#fff;border:2px solid #e2e8f0;border-radius:.5rem;font-size:.875rem}.ki-btn-primary{padding:.6rem 1rem;background:#0f172a;color:#fff;border:none;border-radius:.5rem;font-size:.7rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;cursor:pointer}.ki-btn-primary:disabled{opacity:.4;cursor:not-allowed}.ki-btn-secondary{padding:.3rem .7rem;background:#fee2e2;color:#991b1b;border:none;border-radius:.375rem;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em;cursor:pointer}.ki-btn-secondary:disabled{opacity:.3;cursor:not-allowed}.ki-btn-icon{background:transparent;border:none;color:#94a3b8;cursor:pointer;font-size:1rem;padding:.2rem .4rem}.ki-btn-icon:hover{color:#ef4444}.ki-table{width:100%;border-collapse:collapse;font-size:.875rem}.ki-table thead tr{border-bottom:2px solid #e2e8f0}.ki-table th{padding:.5rem;text-align:left;text-transform:uppercase;font-size:.6rem;font-weight:800;letter-spacing:.1em;color:#64748b}.ki-table td{padding:.5rem;border-bottom:1px solid #f1f5f9;vertical-align:middle}.ki-truncate{max-width:400px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ki-right{text-align:right}.ki-pill{display:inline-block;padding:.15rem .5rem;border-radius:.25rem;background:#e0e7ff;color:#3730a3;font-size:.625rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em}.ki-muted{color:#94a3b8}.ki-tiny{font-size:.7rem}.ki-empty{text-align:center;color:#94a3b8;padding:1rem;font-size:.85rem}\n"] }]
        }] });

/**
 * v0.7.1 / Library v0.12.0 — Quality-Bewertung pro Modell aus den letzten
 * 30 Tagen, sortiert worst-first (KILL-Kandidaten oben).
 *
 * <h3>Was zeigt das?</h3>
 * Eine simple Tabelle pro Modell mit:
 *  - Tier-Icon (★ top / ◐ ok / ▽ weak / ✗ kill)
 *  - Quality-Score (0.0 - 2.0+)
 *  - Success-Rate, Avg-Chars, Anzahl Calls
 *  - Rotes Highlighting für KILL-Kandidaten
 *
 * <h3>Wofür?</h3>
 * Admin sieht auf einen Blick welche Modelle nicht laufen. Statt durch
 * eine lange Liste zu scrollen ist das problematische ganz oben.
 *
 * <h3>Konsument-Use-Case:</h3>
 * - EduPro: in den Operations-Tab embedded, ersetzt die alte AI-Quality-Card
 * - Switcher: in Stats-Tab embedded
 */
class ModelsQualityStatsComponent {
    constructor() {
        this.api = inject(KiModelsApiService);
        /** Label oben — überschreibbar pro Konsument. */
        this.title = 'KI-Qualität — Stats der letzten 30 Tage';
        this.subtitle = 'Schlechte Modelle stehen oben. KILL-Kandidaten sollten deaktiviert werden.';
        this.sortBy = 'worst-first';
        this.rows = signal([]);
        this.loading = signal(true);
    }
    ngOnInit() {
        this.reload();
    }
    reload() {
        this.loading.set(true);
        this.api.getQualityStats(this.sortBy).subscribe({
            next: (rows) => {
                this.rows.set(Array.isArray(rows) ? rows : []);
                this.loading.set(false);
            },
            error: () => {
                // Backend < 0.7.2: leere Liste, kein Crash
                this.rows.set([]);
                this.loading.set(false);
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ModelsQualityStatsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: ModelsQualityStatsComponent, isStandalone: true, selector: "ki-models-quality-stats", inputs: { title: "title", subtitle: "subtitle" }, ngImport: i0, template: `
    <div class="ki-quality-stats">
      <div class="ki-header">
        <div>
          <h4 class="ki-title">{{ title }}</h4>
          <p class="ki-subtitle">{{ subtitle }}</p>
        </div>
        <div class="ki-controls">
          <label class="ki-tiny ki-muted">Sortierung:</label>
          <select [(ngModel)]="sortBy" (change)="reload()" class="ki-select">
            <option value="worst-first">Schlechteste zuerst</option>
            <option value="best-first">Beste zuerst</option>
            <option value="calls-desc">Meist genutzte zuerst</option>
          </select>
          <button (click)="reload()" class="ki-btn-refresh">↻</button>
        </div>
      </div>

      <p *ngIf="loading()" class="ki-muted">Lade Quality-Stats…</p>
      <p *ngIf="!loading() && rows().length === 0" class="ki-empty">
        Noch keine Stats — Modelle wurden in den letzten 30 Tagen nicht aufgerufen.
      </p>

      <table *ngIf="rows().length > 0" class="ki-table">
        <thead>
          <tr>
            <th></th>
            <th>Modell</th>
            <th>Kategorie</th>
            <th class="ki-right">Score</th>
            <th class="ki-right">Erfolg</th>
            <th class="ki-right">Calls (30d)</th>
            <th class="ki-right">Ø Chars</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let r of rows()"
              [class.ki-row-kill]="r.kill"
              [class.ki-row-weak]="r.tier === 'weak'">
            <td class="ki-tier-icon" [class]="'ki-tier-' + r.tier">{{ r.tierIcon }}</td>
            <td class="ki-mono">
              <span class="ki-provider">{{ r.provider }}</span>
              <strong>{{ r.modelId }}</strong>
              <div *ngIf="r.displayName" class="ki-tiny ki-muted">{{ r.displayName }}</div>
            </td>
            <td class="ki-tiny">{{ r.category || '—' }}</td>
            <td class="ki-right ki-mono">
              <strong [class]="'ki-tier-' + r.tier">{{ r.score | number:'1.2-2' }}</strong>
            </td>
            <td class="ki-right">{{ (r.successRate * 100) | number:'1.0-1' }}%</td>
            <td class="ki-right">{{ r.callsLast30d }}</td>
            <td class="ki-right ki-tiny ki-muted">{{ r.avgChars }}</td>
            <td>
              <span *ngIf="r.kill" class="ki-kill-badge" title="Empfehlung: deaktivieren">DISABLE</span>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  `, isInline: true, styles: [".ki-quality-stats{font-family:inherit;padding:1rem 0}.ki-header{display:flex;justify-content:space-between;align-items:flex-start;gap:1rem;margin-bottom:1rem}.ki-title{font-size:.85rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#1e293b;margin:0 0 .25rem}.ki-subtitle{font-size:.7rem;color:#64748b;margin:0}.ki-controls{display:flex;gap:.5rem;align-items:center}.ki-select{padding:.35rem .6rem;border:1px solid #cbd5e1;border-radius:.375rem;font-size:.75rem;background:#fff}.ki-btn-refresh{padding:.35rem .6rem;background:#e0e7ff;color:#3730a3;border:none;border-radius:.375rem;font-size:.8rem;cursor:pointer}.ki-table{width:100%;border-collapse:collapse;font-size:.85rem}.ki-table thead tr{border-bottom:2px solid #e2e8f0}.ki-table th{padding:.5rem .6rem;text-align:left;text-transform:uppercase;font-size:.6rem;font-weight:800;letter-spacing:.08em;color:#64748b}.ki-table td{padding:.55rem .6rem;border-bottom:1px solid #f1f5f9;vertical-align:top}.ki-row-kill{background:linear-gradient(90deg,#fef2f2 0%,transparent 100%)}.ki-row-weak{background:linear-gradient(90deg,#fffbeb 0%,transparent 100%)}.ki-right{text-align:right}.ki-mono{font-family:ui-monospace,monospace}.ki-muted{color:#94a3b8}.ki-tiny{font-size:.7rem}.ki-provider{color:#4f46e5;font-weight:700;margin-right:.4rem}.ki-tier-icon{font-size:1.2rem;text-align:center;width:2.2rem}.ki-tier-top{color:#059669;font-weight:800}.ki-tier-ok{color:#d97706;font-weight:800}.ki-tier-weak{color:#ea580c;font-weight:800}.ki-tier-kill{color:#dc2626;font-weight:800}.ki-tier-unknown{color:#94a3b8}.ki-kill-badge{background:#fee2e2;color:#991b1b;padding:.2rem .4rem;border-radius:.25rem;font-size:.6rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em}.ki-empty{text-align:center;padding:1.5rem;color:#94a3b8}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: i1.DecimalPipe, name: "number" }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.NgSelectOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.ɵNgSelectMultipleOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i2.SelectControlValueAccessor, selector: "select:not([multiple])[formControlName],select:not([multiple])[formControl],select:not([multiple])[ngModel]", inputs: ["compareWith"] }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: ModelsQualityStatsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ki-models-quality-stats', standalone: true, imports: [CommonModule, FormsModule], template: `
    <div class="ki-quality-stats">
      <div class="ki-header">
        <div>
          <h4 class="ki-title">{{ title }}</h4>
          <p class="ki-subtitle">{{ subtitle }}</p>
        </div>
        <div class="ki-controls">
          <label class="ki-tiny ki-muted">Sortierung:</label>
          <select [(ngModel)]="sortBy" (change)="reload()" class="ki-select">
            <option value="worst-first">Schlechteste zuerst</option>
            <option value="best-first">Beste zuerst</option>
            <option value="calls-desc">Meist genutzte zuerst</option>
          </select>
          <button (click)="reload()" class="ki-btn-refresh">↻</button>
        </div>
      </div>

      <p *ngIf="loading()" class="ki-muted">Lade Quality-Stats…</p>
      <p *ngIf="!loading() && rows().length === 0" class="ki-empty">
        Noch keine Stats — Modelle wurden in den letzten 30 Tagen nicht aufgerufen.
      </p>

      <table *ngIf="rows().length > 0" class="ki-table">
        <thead>
          <tr>
            <th></th>
            <th>Modell</th>
            <th>Kategorie</th>
            <th class="ki-right">Score</th>
            <th class="ki-right">Erfolg</th>
            <th class="ki-right">Calls (30d)</th>
            <th class="ki-right">Ø Chars</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let r of rows()"
              [class.ki-row-kill]="r.kill"
              [class.ki-row-weak]="r.tier === 'weak'">
            <td class="ki-tier-icon" [class]="'ki-tier-' + r.tier">{{ r.tierIcon }}</td>
            <td class="ki-mono">
              <span class="ki-provider">{{ r.provider }}</span>
              <strong>{{ r.modelId }}</strong>
              <div *ngIf="r.displayName" class="ki-tiny ki-muted">{{ r.displayName }}</div>
            </td>
            <td class="ki-tiny">{{ r.category || '—' }}</td>
            <td class="ki-right ki-mono">
              <strong [class]="'ki-tier-' + r.tier">{{ r.score | number:'1.2-2' }}</strong>
            </td>
            <td class="ki-right">{{ (r.successRate * 100) | number:'1.0-1' }}%</td>
            <td class="ki-right">{{ r.callsLast30d }}</td>
            <td class="ki-right ki-tiny ki-muted">{{ r.avgChars }}</td>
            <td>
              <span *ngIf="r.kill" class="ki-kill-badge" title="Empfehlung: deaktivieren">DISABLE</span>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  `, styles: [".ki-quality-stats{font-family:inherit;padding:1rem 0}.ki-header{display:flex;justify-content:space-between;align-items:flex-start;gap:1rem;margin-bottom:1rem}.ki-title{font-size:.85rem;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#1e293b;margin:0 0 .25rem}.ki-subtitle{font-size:.7rem;color:#64748b;margin:0}.ki-controls{display:flex;gap:.5rem;align-items:center}.ki-select{padding:.35rem .6rem;border:1px solid #cbd5e1;border-radius:.375rem;font-size:.75rem;background:#fff}.ki-btn-refresh{padding:.35rem .6rem;background:#e0e7ff;color:#3730a3;border:none;border-radius:.375rem;font-size:.8rem;cursor:pointer}.ki-table{width:100%;border-collapse:collapse;font-size:.85rem}.ki-table thead tr{border-bottom:2px solid #e2e8f0}.ki-table th{padding:.5rem .6rem;text-align:left;text-transform:uppercase;font-size:.6rem;font-weight:800;letter-spacing:.08em;color:#64748b}.ki-table td{padding:.55rem .6rem;border-bottom:1px solid #f1f5f9;vertical-align:top}.ki-row-kill{background:linear-gradient(90deg,#fef2f2 0%,transparent 100%)}.ki-row-weak{background:linear-gradient(90deg,#fffbeb 0%,transparent 100%)}.ki-right{text-align:right}.ki-mono{font-family:ui-monospace,monospace}.ki-muted{color:#94a3b8}.ki-tiny{font-size:.7rem}.ki-provider{color:#4f46e5;font-weight:700;margin-right:.4rem}.ki-tier-icon{font-size:1.2rem;text-align:center;width:2.2rem}.ki-tier-top{color:#059669;font-weight:800}.ki-tier-ok{color:#d97706;font-weight:800}.ki-tier-weak{color:#ea580c;font-weight:800}.ki-tier-kill{color:#dc2626;font-weight:800}.ki-tier-unknown{color:#94a3b8}.ki-kill-badge{background:#fee2e2;color:#991b1b;padding:.2rem .4rem;border-radius:.25rem;font-size:.6rem;font-weight:800;text-transform:uppercase;letter-spacing:.05em}.ki-empty{text-align:center;padding:1.5rem;color:#94a3b8}\n"] }]
        }], propDecorators: { title: [{
                type: Input
            }], subtitle: [{
                type: Input
            }] } });

/*
 * Public API Surface of @dataclub/ki-models-ui
 *
 * Konsumenten importieren Components + Service + InjectionToken hier von:
 *   import { ModelsTableComponent, KI_MODELS_API_BASE } from '@dataclub/ki-models-ui';
 *
 * Module-Wrapper (für nicht-standalone-Apps) wird in Phase L.2 hinzugefügt.
 */
// ─── Models / Interfaces ─────────────────────────────────────────────────

/**
 * Generated bundle index. Do not edit.
 */

export { ADD_MODEL_FORM_LABELS_EN, AI_MODEL_CATEGORIES, AI_MODEL_CATEGORIES_DEFAULT_ORDER, API_KEYS_SECTION_LABELS_EN, AddModelFormComponent, ApiKeysSectionComponent, CASCADES_VIEW_LABELS_EN, CASCADE_COOLDOWN_LABELS_EN, CascadeCooldownComponent, CascadesViewComponent, FAILOVER_CHAIN_LABELS_EN, FailoverChainComponent, KI_MODELS_API_BASE, KiModelsApiService, MODELS_TABLE_LABELS_EN, ModelsQualityStatsComponent, ModelsTableComponent, ROUTING_DECISIONS_LABELS_EN, RoutingDecisionsComponent };
//# sourceMappingURL=4dataclub-ki-models-ui.mjs.map
