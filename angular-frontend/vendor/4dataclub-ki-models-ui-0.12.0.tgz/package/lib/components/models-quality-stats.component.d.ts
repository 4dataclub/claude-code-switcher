import { OnInit } from '@angular/core';
import { QualityStatRow } from '../models/quality';
import * as i0 from "@angular/core";
/**
 * v0.7.1 / Library v0.12.0 — Quality-Bewertung pro Modell aus den letzten
 * 30 Tagen, sortiert worst-first (KILL-Kandidaten oben).
 *
 * <h3>Was zeigt das?</h3>
 * Eine simple Tabelle pro Modell mit:
 *  - Tier-Icon (★ top / ◐ ok / ▽ weak / ✗ kill)
 *  - Quality-Score (0.0 - 2.0+)
 *  - Success-Rate, Avg-Chars, Anzahl Calls
 *  - Rotes Highlighting für KILL-Kandidaten
 *
 * <h3>Wofür?</h3>
 * Admin sieht auf einen Blick welche Modelle nicht laufen. Statt durch
 * eine lange Liste zu scrollen ist das problematische ganz oben.
 *
 * <h3>Konsument-Use-Case:</h3>
 * - EduPro: in den Operations-Tab embedded, ersetzt die alte AI-Quality-Card
 * - Switcher: in Stats-Tab embedded
 */
export declare class ModelsQualityStatsComponent implements OnInit {
    private readonly api;
    /** Label oben — überschreibbar pro Konsument. */
    title: string;
    subtitle: string;
    sortBy: 'worst-first' | 'best-first' | 'calls-desc';
    readonly rows: import("@angular/core").WritableSignal<QualityStatRow[]>;
    readonly loading: import("@angular/core").WritableSignal<boolean>;
    ngOnInit(): void;
    reload(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ModelsQualityStatsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ModelsQualityStatsComponent, "ki-models-quality-stats", never, { "title": { "alias": "title"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; }, {}, never, never, true, never>;
}
