import { EventEmitter, OnInit } from '@angular/core';
import { AiModel } from '../models/ai-model';
import { Cascade } from '../models/cascade';
import { Category } from '../models/category';
import { ChainEntry } from '../models/cascade-config';
import { CascadesViewLabels, FailoverChainLabels } from '../models/labels';
import * as i0 from "@angular/core";
/**
 * Phase S' (2026-05-21) — Wrapper-Komponente die N Cascade-Bereiche als
 * eigenständige Karten rendert. Jeder Bereich hat seine eigene
 * Failover-Chain + Cooldown-Anzeige.
 *
 * **Vertrag:** Backend liefert per {@code GET /cascades} eine Liste der
 * Cascade-Namen mit Stats. Pro Name filtert dieser Wrapper die Modelle aus
 * {@code /ai-models} nach {@code category=name} (plus {@code "general"} als
 * Fallback wenn der Name nicht selbst "general" ist) und übergibt die
 * Subset-Liste der "dummen" `<ki-failover-chain>`.
 *
 * **Reorder-Verhalten:** Wenn der Admin Up/Down innerhalb einer Cascade
 * drückt, mappt der Wrapper das in eine globale `reorderModels()`-Anfrage:
 * er nimmt die aktuelle Globale Liste, swappt nur die beiden Modelle der
 * jeweiligen Cascade, übermittelt die neue globale Reihenfolge.
 *
 * **Backward-Compat:** Wenn das Backend `/cascades` nicht kennt oder `[]`
 * liefert, zeigt die Komponente einen leeren Zustand mit Hinweis-Text
 * (Konsument kann dann auf alte 3-Categories-Tabellen fallback).
 */
export declare class CascadesViewComponent implements OnInit {
    set labels(v: Partial<CascadesViewLabels> | undefined);
    L: CascadesViewLabels;
    chainLabels?: Partial<FailoverChainLabels>;
    /**
     * Optional: Pro Cascade-Name eine Sub-Hint (z.B. „Lehrinhalte, Prüfungen, Chat").
     * Wenn nicht gesetzt, wird der Default-Hint aus `L.defaultHint` genommen.
     */
    hintByCascade: Record<string, string>;
    /** Provider-Optionen für das Dropdown im Failover-Editor. */
    providerOptions: {
        value: string;
        label: string;
    }[];
    /** Wird emittet wenn der Admin in einer der Cascades reordert oder Modelle tauscht. */
    cascadeChanged: EventEmitter<{
        cascadeName: string;
        chain: ChainEntry[];
    }>;
    private readonly api;
    readonly loading: import("@angular/core").WritableSignal<boolean>;
    readonly cascades: import("@angular/core").WritableSignal<Cascade[]>;
    readonly allModels: import("@angular/core").WritableSignal<AiModel[]>;
    /**
     * Display-Metadaten pro Kategorie (v0.10.0). Wird beim init aus
     * `GET {base}/categories` geladen. Wenn der Endpoint nicht existiert
     * (Backward-Compat zu llm-cascade < 0.5), bleibt das Array leer und das
     * UI fällt auf den `[hintByCascade]`-Input bzw. `L.defaultHint` zurück.
     */
    readonly categoriesMeta: import("@angular/core").WritableSignal<Category[]>;
    /**
     * Inline-Edit-State: Name der Kategorie die gerade editiert wird (oder
     * `null` wenn kein Edit aktiv). `editText` ist der aktuelle Textarea-Wert.
     * `saving` blockiert die Buttons während des PUT-Roundtrips.
     */
    readonly editing: import("@angular/core").WritableSignal<string | null>;
    editText: string;
    readonly saving: import("@angular/core").WritableSignal<boolean>;
    /**
     * Pro Cascade-Name die Chain (Array<{provider, model}>) als computed-Signal.
     * Stabile Referenz solange sich allModels nicht ändert — verhindert CD-Storms
     * im Failover-Chain-Child und stellt sicher dass die Berechnung erst läuft
     * wenn allModels wirklich befüllt ist.
     */
    readonly chainsByCascade: import("@angular/core").Signal<Record<string, ChainEntry[]>>;
    /** Provider-Modell-Dropdown-Optionen, ebenfalls als computed (stable ref). */
    readonly availableModelsAll: import("@angular/core").Signal<{
        provider: string;
        modelId: string;
        displayName: string;
    }[]>;
    ngOnInit(): void;
    reload(): void;
    /**
     * Title-Lookup-Reihenfolge:
     *   1. `displayName` aus den Categories-Metadaten (User hat's gesetzt)
     *   2. Roher Cascade-Name (rückwärtskompatibel, bisheriges Verhalten)
     *
     * Der Cascade-Name selbst kommt vom Backend `/cascades` und ist bereits
     * der Kategorie-Identifier — wir capitalisieren ihn NICHT zusätzlich, weil
     * die alten UIs ihn bereits via `uppercase`-CSS rendern.
     */
    titleFor(cascadeName: string): string;
    /**
     * Hint-Lookup-Reihenfolge:
     *   1. `description` aus den Categories-Metadaten (User-edit per Inline-Edit)
     *   2. `[hintByCascade]`-Input vom Konsumenten (sein hardcoded Default)
     *   3. `L.defaultHint` (Library-Englisch-Fallback)
     */
    hintFor(cascadeName: string): string;
    /** Klick auf den Hint → Edit-Mode aktivieren mit aktuellem Wert vorbefüllt. */
    startEdit(cascadeName: string): void;
    /** Escape oder Cancel-Button → Edit-Mode verlassen ohne Save. */
    cancelEdit(): void;
    /**
     * Save-Button (oder Enter): PUT der neuen description an
     * `/categories/{name}`. Leerer String → wird als `null` gesendet
     * (Backend löscht das Feld), damit der Konsument-Default wieder greift.
     */
    saveEdit(cascadeName: string): void;
    hasCooldown(c: Cascade): boolean;
    cooldownEntries(c: Cascade): {
        key: string;
        sec: number;
    }[];
    /**
     * Cascade-scoped Reorder: nimmt die neue Cascade-spezifische Chain vom
     * Failover-Editor und übersetzt das in eine globale `reorderModels()`-
     * Anfrage. Die globale Liste wird so umsortiert, dass die Position der
     * cascade-eigenen Modelle der neuen Reihenfolge entspricht; alle anderen
     * Modelle bleiben in ihrer relativen Position.
     */
    onChainChanged(cascadeName: string, newChain: ChainEntry[]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CascadesViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CascadesViewComponent, "ki-cascades-view", never, { "labels": { "alias": "labels"; "required": false; }; "chainLabels": { "alias": "chainLabels"; "required": false; }; "hintByCascade": { "alias": "hintByCascade"; "required": false; }; "providerOptions": { "alias": "providerOptions"; "required": false; }; }, { "cascadeChanged": "cascadeChanged"; }, never, never, true, never>;
}
