import { Observable } from 'rxjs';
import { AiModel, AiModelCreate, AiModelUpdate } from '../models/ai-model';
import { ApiKeySetting, ApiKeySettingUpdate } from '../models/api-key-setting';
import { CascadeConfig, CascadeConfigUpdate } from '../models/cascade-config';
import { Cascade } from '../models/cascade';
import { Category, CategoryUpdate } from '../models/category';
import * as i0 from "@angular/core";
/**
 * Library-API-Service. Spricht alle KI-Modell-/API-Key-/Cascade-Endpoints
 * gegen die vom Konsumenten konfigurierte Base-URL (siehe `KI_MODELS_API_BASE`).
 *
 * **Vertrag:** Konsumentenseitige Endpoints müssen folgenden Pfaden entsprechen:
 *
 * ```
 * GET    {base}/ai-models                   → AiModel[]
 * POST   {base}/ai-models                   → AiModel
 * PUT    {base}/ai-models/{id}              → AiModel
 * DELETE {base}/ai-models/{id}              → { ok: true }
 * POST   {base}/ai-models/{id}/test         → { ok, latencyMs, error? }
 * POST   {base}/ai-models/reorder           → { ok: true }                body: { orderedIds }
 * POST   {base}/ai-models/{id}/toggle       → { id, ok, enabled }         body: { enabled }
 * GET    {base}/api-keys                    → ApiKeySetting[]
 * POST   {base}/api-keys/setting/{key}      → { ok: true }                body: { value }
 * GET    {base}/cascade-config              → CascadeConfig
 * PUT    {base}/cascade-config              → CascadeConfig
 * ```
 *
 * Backend-API-Drift zwischen EduPro und Switcher: jeder Konsument kann diesen
 * Service per Inheritance/Wrapper überschreiben oder via Subclass-Provider
 * austauschen, falls nötig.
 */
export declare class KiModelsApiService {
    private readonly http;
    private readonly base;
    listModels(): Observable<AiModel[]>;
    createModel(body: AiModelCreate): Observable<AiModel>;
    updateModel(id: number, body: AiModelUpdate): Observable<AiModel>;
    deleteModel(id: number): Observable<{
        ok: boolean;
    }>;
    /**
     * `skipped: true` zeigt an, dass das Konsument-Backend den Test bewusst
     * übersprungen hat (z.B. Switcher beim Anthropic-Modell ohne API-Key, weil
     * Max-OAuth den Live-Switch erlaubt aber kein API-Test möglich ist). Die
     * Tabelle deaktiviert das Modell in dem Fall NICHT auto.
     */
    testModel(id: number): Observable<{
        ok: boolean;
        latencyMs?: number;
        error?: string;
        skipped?: boolean;
    }>;
    reorderModels(orderedIds: number[]): Observable<{
        ok: boolean;
    }>;
    toggleModel(id: number, enabled: boolean): Observable<{
        id: number;
        ok: boolean;
        enabled: boolean;
    }>;
    /**
     * Listet alle API-Key-Settings.
     *
     * Akzeptiert zwei Backend-Response-Shapes:
     * - **Array** (`ApiKeySetting[]`) — was die Library als Vertrag definiert
     *   (Switcher liefert das direkt unter `/cascade-settings`).
     * - **Object mit `settings`-Map** — was EduPros bestehender Endpoint
     *   `/admin/api-keys` liefert (`{settings: {key: {keyMasked, keySource, …}}}`).
     *
     * Bei Object-Form werden die Entries in das Array-Format gemapped, damit
     * die Components homogen mit `ApiKeySetting`-Items arbeiten. Pro Konsument
     * brauchen wir so keinen eigenen Adapter — die Library normalisiert selbst.
     */
    listKeys(): Observable<ApiKeySetting[]>;
    setKey(settingKey: string, body: ApiKeySettingUpdate): Observable<{
        ok: boolean;
    }>;
    /**
     * Liefert alle Cascade-Bereiche der Konsumenten-DB.
     *
     * **Vertrag**: Backend exponiert `GET {base}/cascades` → `Cascade[]`.
     * Frontend (z.B. `<ki-cascades-view>`) rendert eine Karte pro Eintrag.
     *
     * Fallback: liefert das Backend `[]` zurueck oder ist Endpoint nicht
     * verfuegbar, gibt der Wrapper-Component einen leeren Zustand — der
     * Konsument kann optional die alten 3 Default-Categories als Fallback
     * rendern.
     */
    listCascades(): Observable<Cascade[]>;
    /** Detail einer einzelnen Cascade. Selten direkt gebraucht; meistens reicht {@link #listCascades}. */
    getCascade(name: string): Observable<Cascade>;
    /**
     * Liste aller Kategorien (Display-Metadaten). Backend vereint implizite
     * Kategorien aus `ai_model_config.category` mit persistierten
     * `category_meta`-Einträgen — Felder ohne gesetzte Metadaten kommen mit
     * `null` zurück. Wenn der Endpoint nicht existiert (Backward-Compat zu
     * llm-cascade < 0.5), liefert der Konsument `404`; das Frontend muss
     * dann selbst auf leeren Default zurückfallen.
     */
    listCategories(): Observable<Category[]>;
    /**
     * Upsert für die Display-Metadaten einer Kategorie. Wird vom Inline-Edit
     * der Cascades-View aufgerufen. Partial-Update: Felder die nicht im Body
     * stehen werden NICHT angefasst; `null` löscht das Feld explizit.
     */
    updateCategory(name: string, body: CategoryUpdate): Observable<{
        ok: boolean;
    }>;
    /**
     * Löscht NUR die Metadaten-Zeile — die Kategorie selbst lebt weiter,
     * solange ein Modell sie nutzt. Nach Delete bekommt sie wieder die
     * UI-Fallbacks (capitalized name, leerer Hint).
     */
    deleteCategoryMeta(name: string): Observable<{
        ok: boolean;
    }>;
    getCascadeConfig(): Observable<CascadeConfig>;
    setCascadeConfig(body: CascadeConfigUpdate): Observable<CascadeConfig>;
    static ɵfac: i0.ɵɵFactoryDeclaration<KiModelsApiService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<KiModelsApiService>;
}
